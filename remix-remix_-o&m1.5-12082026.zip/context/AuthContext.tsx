import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { auth, db } from '../services/firebase';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  updateProfile
} from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  signup: (email: string, pass: string, name: string, role: UserRole) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfileWithRetry = async (uid: string, attempts = 3): Promise<any> => {
    for (let i = 0; i < attempts; i++) {
      try {
        const userDoc = await getDoc(doc(db, "users", uid));
        if (userDoc.exists()) return userDoc.data();
      } catch (e) {
        console.warn(`Attempt ${i+1} failed to fetch profile:`, e);
      }
      if (i < attempts - 1) await new Promise(resolve => setTimeout(resolve, 500));
    }
    return null;
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      if (firebaseUser) {
        try {
          const userData = await fetchProfileWithRetry(firebaseUser.uid);
          if (userData) {
            // Robust normalization
            let rawRole = (userData.role || 'ENGINEER').toString().toUpperCase();
            
            // Map variations to standard enum keys
            if (rawRole === 'ADMINISTRATOR' || rawRole === 'ADMIN') rawRole = UserRole.ADMIN;
            if (rawRole === 'DEVELOPER') rawRole = UserRole.DEVELOPER;
            if (rawRole === 'PROJECT_MANAGER' || rawRole === 'PM') rawRole = UserRole.PROJECT_MANAGER;
            if (rawRole === 'ENGINEER') rawRole = UserRole.ENGINEER;
            
            setUser({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: userData.displayName || firebaseUser.displayName || 'User',
              role: rawRole as UserRole
            });
          } else {
            setUser(null);
          }
        } catch (e) {
          console.error("Auth profile fetch error:", e);
          setUser(null);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (error: any) {
      setLoading(false);
      throw error;
    }
  };

  const signup = async (email: string, pass: string, name: string, role: UserRole) => {
    setLoading(true);
    try {
      const { user: firebaseUser } = await createUserWithEmailAndPassword(auth, email, pass);
      await updateProfile(firebaseUser, { displayName: name });
      await setDoc(doc(db, "users", firebaseUser.uid), {
        email,
        displayName: name,
        role: role.toUpperCase(),
        createdAt: new Date().toISOString()
      });
      setUser({
        uid: firebaseUser.uid,
        email,
        displayName: name,
        role
      });
    } catch (error: any) {
      setLoading(false);
      throw error;
    }
  };

  const logout = async () => {
    await signOut(auth);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};