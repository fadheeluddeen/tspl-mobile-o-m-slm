const fs = require('fs');

const path = 'utils/excelExport.ts';
let code = fs.readFileSync(path, 'utf8');

code = code.replace(/\{ header: 'Sr No', key: 'srNo', width: 10 \},\n\s*\{ header: 'kWh Generated Initial', key: 'kwhInitial', width: 25 \}/, 
  "{ header: 'Sr No', key: 'srNo', width: 10 },\n        { header: '% LOAD', key: 'percentLoad', width: 15 },\n        { header: 'TIME', key: 'time', width: 15 },\n        { header: 'kWh Generated Initial', key: 'kwhInitial', width: 25 }");

fs.writeFileSync(path, code);
