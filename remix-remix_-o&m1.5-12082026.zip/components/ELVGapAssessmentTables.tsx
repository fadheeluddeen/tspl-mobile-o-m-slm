
import React, { useMemo } from 'react';
import { ELVGapAssessmentReading, ELVChecklistRow, ELVGapAnalysisRow, UserRole, ObservationRecommendationRow } from '../types';
import { useAuth } from '../context/AuthContext';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

interface ChecklistTableProps {
  systemName: string;
  rows: ELVChecklistRow[];
  readOnly: boolean;
  updateChecklistRow: (systemName: string, rowId: string, field: keyof ELVChecklistRow, value: any) => void;
}

const ChecklistTable: React.FC<ChecklistTableProps> = ({ systemName, rows, readOnly, updateChecklistRow }) => (
  <div className="bg-white rounded-lg border border-black shadow-sm overflow-hidden mb-8">
    <div className="bg-slate-50 px-4 py-3 border-b border-black">
      <h3 className="font-bold text-slate-800 uppercase tracking-tight">{systemName}</h3>
    </div>
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm border-collapse">
        <thead>
          <tr className="bg-slate-100 text-slate-700 font-bold border-b border-black">
            <th className="px-3 py-2 border-r border-black w-16 text-center">No</th>
            <th className="px-3 py-2 border-r border-black">Description</th>
            <th className="px-3 py-2 border-r border-black w-48 text-center">Result</th>
            <th className="px-3 py-2 border-r border-black">Remarks</th>
            <th className="px-3 py-2">Corrective Actions</th>
          </tr>
        </thead>
        <tbody>
{(rows).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

          {rows.map(row => (
            <tr key={row.id} className={`${row.isHeader ? 'bg-slate-50 font-bold' : ''} border-b border-black last:border-b-0`}>
              <td className="px-3 py-2 border-r border-black text-center">{row.no}</td>
              <td className="px-3 py-2 border-r border-black">{row.description}</td>
              <td className="px-3 py-2 border-r border-black text-center whitespace-nowrap">
                {!row.isHeader ? (
                  <div className="flex items-center justify-center gap-4">
                    {['Yes', 'No', 'N/A'].map(opt => (
                      <label key={opt} className="inline-flex items-center cursor-pointer">
                        <input 
                          type="radio"
                          name={`res-${row.id}`}
                          checked={row.result === opt}
                          onChange={() => updateChecklistRow(systemName, row.id, 'result', opt as any)}
                          disabled={readOnly}
                          className="w-4 h-4 text-blue-600 focus:ring-blue-50 border-black"
                        />
                        <span className="ml-1 text-xs font-medium">{opt}</span>
                      </label>
                    ))}
                  </div>
                ) : null}
              </td>
              <td className="px-1 py-1 border-r border-black">
                {!row.isHeader ? (
                  <input 
                    value={row.remarks} 
                    onChange={e => updateChecklistRow(systemName, row.id, 'remarks', e.target.value)}
                    disabled={readOnly}
                    className="w-full px-2 py-1 bg-transparent border-none outline-none text-xs"
                    placeholder="Add technical remarks..."
                  />
                ) : null}
              </td>
              <td className="px-1 py-1">
                {!row.isHeader ? (
                  <input 
                    value={row.correctiveActions} 
                    onChange={e => updateChecklistRow(systemName, row.id, 'correctiveActions', e.target.value)}
                    disabled={readOnly}
                    className="w-full px-2 py-1 bg-transparent border-none outline-none text-xs"
                    placeholder="Specify corrective actions..."
                  />
                ) : null}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

interface ELVGapAssessmentTablesProps {
  data: ELVGapAssessmentReading;
  onChange: (data: ELVGapAssessmentReading) => void;
  readOnly?: boolean;
}

export const ELVGapAssessmentTables: React.FC<ELVGapAssessmentTablesProps> = ({ data: rawData, onChange, readOnly = false }) => {
  const { user } = useAuth();
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();
  // Migration logic to ensure requested row descriptions and headings are up-to-date
  const data = useMemo(() => {
    if (!rawData || !rawData.systems) return rawData;
    
    let changed = false;
    const updatedSystems = { ...rawData.systems };

    // Migrate BMS heading to WLD heading
    const oldKeys = ["BMS (Water Leak Detection)", "BMS(Water Leakage Detection)"];
    const newKey = "WLD (Water Leakage Detection  System)";
    
    oldKeys.forEach(oldKey => {
      if (updatedSystems[oldKey] && !updatedSystems[newKey]) {
        updatedSystems[newKey] = updatedSystems[oldKey];
        delete updatedSystems[oldKey];
        changed = true;
      }
    });

    // Migration for VESDA System descriptions
    if (updatedSystems["VESDA System"]) {
      const vesdaRows = updatedSystems["VESDA System"];
      const updatedVesdaRows = vesdaRows.map(row => {
        if (row.no === "2.1" && row.description === "Sampling pipe - leaks or breakages") {
          changed = true;
          return { ...row, description: "Sampling pipe-No leaks (or) breakages" };
        }
        if (row.no === "2.2" && row.description === "Airflow fault alarms (high/low flow conditions) if any") {
          changed = true;
          return { ...row, description: "No Airflow fault alarms (high/low flow conditions)" };
        }
        return row;
      });
      if (changed) {
        updatedSystems["VESDA System"] = updatedVesdaRows;
      }
    }

    if (!changed) return rawData;

    return {
      ...rawData,
      systems: updatedSystems
    };
  }, [rawData]);

  const updateField = (field: keyof ELVGapAssessmentReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const updateChecklistRow = (systemName: string, rowId: string, field: keyof ELVChecklistRow, value: any) => {
    if (readOnly) return;
    const systemRows = data.systems[systemName] || [];
    const newRows = systemRows.map(row => row.id === rowId ? { ...row, [field]: value } : row);
    onChange({
      ...data,
      systems: {
        ...data.systems,
        [systemName]: newRows
      }
    });
  };

  const addGapAnalysisRow = () => {
    if (readOnly) return;
    const rows = [...(data.gapAnalysisRows || [])];
    const newRow: ELVGapAnalysisRow = {
      id: `gap-${Date.now()}`,
      no: rows.length + 1,
      standard: "TIA-942",
      section: "",
      requirement: "",
      system: "",
      implementation: "",
      compliance: "-",
      correctiveActions: ""
    };
    updateField('gapAnalysisRows', [...rows, newRow]);
  };

  const deleteGapAnalysisRow = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this gap analysis requirement row?",
      onConfirm: () => {
        const rows = (data.gapAnalysisRows || []).filter(r => r.id !== id);
        // Auto-increment logic
        const renumbered = rows.map((r, i) => ({ ...r, no: i + 1 }));
        updateField('gapAnalysisRows', renumbered);
      }
    });
  };

  const updateGapAnalysisRow = (id: string, field: keyof ELVGapAnalysisRow, value: any) => {
    if (readOnly) return;
    const rows = (data.gapAnalysisRows || []).map(r => r.id === id ? { ...r, [field]: value } : r);
    updateField('gapAnalysisRows', rows);
  };

  const autoFillChecklist = () => {
    if (readOnly) return;
    const results = ['Yes', 'No', 'N/A'];
    const randomRemarks = [
      "Verified and found satisfactory.",
      "Minor dust observed, cleaned.",
      "Connection tightened.",
      "Labeling updated.",
      "No issues found during inspection."
    ];
    const randomActions = [
      "N/A",
      "Cleaned the device.",
      "Tightened the connections.",
      "Replaced the battery.",
      "Updated the logbook."
    ];

    const updatedSystems = { ...data.systems };
    Object.keys(updatedSystems).forEach(systemName => {
      updatedSystems[systemName] = updatedSystems[systemName].map(row => {
        if (row.isHeader) return row;
        return {
          ...row,
          result: results[Math.floor(Math.random() * results.length)] as any,
          remarks: randomRemarks[Math.floor(Math.random() * randomRemarks.length)],
          correctiveActions: randomActions[Math.floor(Math.random() * randomActions.length)]
        };
      });
    });

    onChange({
      ...data,
      systems: updatedSystems
    });
  };

  const complianceSummary = useMemo(() => {
    const summary: any[] = [];
    let counter = 1;
    (Object.entries(data.systems || {}) as [string, ELVChecklistRow[]][]).forEach(([systemName, rows]) => {
      rows.forEach(row => {
        if (row.result === 'No') {
          summary.push({
            sNo: counter++,
            infrastructure: systemName,
            compliance: 'No',
            remarks: row.remarks,
            correctiveActions: row.correctiveActions
          });
        }
      });
    });
    return summary;
  }, [data.systems]);

  return (
    <div className="space-y-10 animate-fade-in font-sans max-w-[1200px] mx-auto text-black">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* PERSONNEL & TEST SCHEDULE */}
      <section className="bg-white rounded-lg border border-black shadow-sm overflow-hidden">
        <div className="bg-slate-50 px-6 py-3 border-b border-black">
          <h3 className="font-bold uppercase tracking-wider text-sm">Personnel & Test Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                className="w-full text-sm font-medium border border-black rounded p-2 outline-none focus:ring-1 focus:ring-slate-400"
              />
            </div>
          ))}
        </div>
      </section>

      {/* SYSTEM CHECKLISTS */}
      <div className="space-y-4 pt-4 border-t border-black">
        <div className="flex justify-between items-center border-b-2 border-black pb-2">
          <h2 className="text-xl font-black uppercase tracking-[0.2em]">Full Standard Verification Checklist</h2>
          {(user?.role === UserRole.DEVELOPER || user?.email === 'saran.senthilnathan2002@gmail.com' || user?.email === 'noor.asad@technavious.com') && !readOnly && (
            <button 
              onClick={autoFillChecklist}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg font-bold text-[10px] uppercase tracking-widest shadow-md hover:bg-purple-700 transition-all flex items-center gap-2"
            >
              ⚡ Developer: Auto Fill
            </button>
          )}
        </div>
        
        {(Object.entries(data.systems || {}) as [string, ELVChecklistRow[]][]).map(([systemName, rows]) => (
          <ChecklistTable 
            key={systemName} 
            systemName={systemName} 
            rows={rows} 
            readOnly={readOnly} 
            updateChecklistRow={updateChecklistRow} 
          />
        ))}

        {/* INFRASTRUCTURE COMPLIANCE SUMMARY (Derived) */}
        <section className="bg-white rounded-lg border border-black shadow-sm overflow-hidden">
          <div className="bg-slate-50 px-4 py-3 border-b border-black">
            <h3 className="font-bold text-slate-800 uppercase tracking-tight">Infrastructure Compliance Summary</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-black">
                  <th className="px-3 py-2 border-r border-black w-16 text-center">S. No</th>
                  <th className="px-3 py-2 border-r border-black">Infrastructure</th>
                  <th className="px-3 py-2 border-r border-black w-24 text-center">Compliance</th>
                  <th className="px-3 py-2 border-r border-black">Remarks</th>
                  <th className="px-3 py-2">Corrective Actions</th>
                </tr>
              </thead>
              <tbody>
                {complianceSummary.map(row => (
                  <tr key={`${row.infrastructure}-${row.sNo}`} className="border-b border-black last:border-b-0">
                    <td className="px-3 py-2 border-r border-black text-center">{row.sNo}</td>
                    <td className="px-3 py-2 border-r border-black font-medium">{row.infrastructure}</td>
                    <td className="px-3 py-2 border-r border-black text-center font-bold text-red-600">{row.compliance}</td>
                    <td className="px-3 py-2 border-r border-black italic">{row.remarks}</td>
                    <td className="px-3 py-2 font-medium">{row.correctiveActions}</td>
                  </tr>
                ))}
                {complianceSummary.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-slate-400 font-medium italic">
                      All items compliant. No "No" results found in checklists.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* NEW: GAP ANALYSIS - SAFETY AND SECURITY INFRASTRUCTURE */}
        <section className="bg-white rounded-lg border border-black shadow-sm overflow-hidden mb-8">
          <div className="bg-[#1E293B] px-4 py-3 border-b border-black flex justify-between items-center">
            <h3 className="font-bold text-white uppercase tracking-tight">GAP ANALYSIS – SAFETY AND SECURITY INFRASTRUCTURE</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#F1F5F9] text-slate-800 font-bold border-b border-black">
                  <th className="px-3 py-3 border-r border-black w-[12px] text-center">No</th>
                  <th className="px-3 py-3 border-r border-black w-[28px]">Standard</th>
                  <th className="px-3 py-3 border-r border-black w-[28px]">Section</th>
                  <th className="px-3 py-3 border-r border-black w-[48px]">Standard Requirement</th>
                  <th className="px-3 py-3 border-r border-black w-[32px]">System</th>
                  <th className="px-3 py-3 border-r border-black">Current Implementation</th>
                  <th className="px-3 py-3 border-r border-black w-[28px]">Compliance</th>
                  <th className="px-3 py-3">Corrective Actions</th>
                  {!readOnly && <th className="px-3 py-3 w-[10px] text-center">Del</th>}
                </tr>
              </thead>
              <tbody>
{((data.gapAnalysisRows || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                {(data.gapAnalysisRows || []).map((row, idx) => (
                  <tr key={row.id} className="border-b border-black last:border-b-0 hover:bg-slate-50">
                    <td className="px-3 py-3 border-r border-black text-center bg-[#F8FAFC] font-bold">{row.no}</td>
                    <td className="px-3 py-3 border-r border-black font-medium text-slate-500">{row.standard}</td>
                    <td className="p-0 border-r border-black">
                      <input 
                        value={row.section} 
                        onChange={e => updateGapAnalysisRow(row.id, 'section', e.target.value)}
                        disabled={readOnly}
                        className="w-full h-full px-3 py-3 bg-transparent outline-none"
                        placeholder="Table Ref..."
                      />
                    </td>
                    <td className="p-0 border-r border-black">
                      <textarea 
                        value={row.requirement} 
                        onChange={e => updateGapAnalysisRow(row.id, 'requirement', e.target.value)}
                        disabled={readOnly}
                        className="w-full min-h-[60px] p-3 bg-transparent outline-none resize-none overflow-hidden"
                        placeholder="Requirement..."
                      />
                    </td>
                    <td className="p-0 border-r border-black">
                      <input 
                        value={row.system} 
                        onChange={e => updateGapAnalysisRow(row.id, 'system', e.target.value)}
                        disabled={readOnly}
                        className="w-full h-full px-3 py-3 bg-transparent outline-none"
                        placeholder="Category..."
                      />
                    </td>
                    <td className="p-0 border-r border-black">
                      <textarea 
                        value={row.implementation} 
                        onChange={e => updateGapAnalysisRow(row.id, 'implementation', e.target.value)}
                        disabled={readOnly}
                        className="w-full min-h-[60px] p-3 bg-transparent outline-none resize-none overflow-hidden italic"
                        placeholder="Observed State..."
                      />
                    </td>
                    <td className="p-0 border-r border-black text-center">
                      <select 
                        value={row.compliance}
                        onChange={e => updateGapAnalysisRow(row.id, 'compliance', e.target.value)}
                        disabled={readOnly}
                        className={`w-full h-full px-2 bg-transparent outline-none font-bold text-center cursor-pointer
                          ${row.compliance === 'Yes' ? 'text-green-600' : row.compliance === 'No' ? 'text-red-600' : 'text-slate-500'}`}
                      >
                        <option value="-">-</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                        <option value="N/A">N/A</option>
                      </select>
                    </td>
                    <td className="p-0">
                      <textarea 
                        value={row.correctiveActions} 
                        onChange={e => updateGapAnalysisRow(row.id, 'correctiveActions', e.target.value)}
                        disabled={readOnly}
                        className="w-full min-h-[60px] p-3 bg-transparent outline-none resize-none overflow-hidden"
                        placeholder="Remediation steps..."
                      />
                    </td>
                    {!readOnly && (
                      <td className="px-3 py-3 text-center align-middle">
                        <button onClick={() => deleteGapAnalysisRow(row.id)} className="text-slate-300 hover:text-red-600 transition-colors">🗑️</button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!readOnly && (
            <div className="p-6 bg-slate-50 border-t border-black flex justify-center">
              <button 
                onClick={addGapAnalysisRow}
                className="px-8 py-3 bg-[#2563EB] text-white rounded-xl font-bold uppercase text-xs tracking-widest shadow-lg hover:scale-105 active:scale-95 transition-all"
              >
                + ADD NEW ANALYSIS ROW
              </button>
            </div>
          )}
        </section>

        {/* EXECUTIVE SUMMARY TABLE */}
        <section className="bg-white rounded-[2rem] border border-slate-200 shadow-2xl p-10 space-y-10 mt-12 mb-8">
           <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
              <span className="text-2xl">📋</span>
              <h3 className="font-black text-slate-800 tracking-widest uppercase text-sm">Executive ELV Gap Assessment Summary</h3>
           </div>
           
           <ObservationsRecommendationsTable 
             data={data.observationsAndRecommendations || []}
             onChange={(val) => updateField('observationsAndRecommendations', val)}
             readOnly={readOnly}
           />
        </section>
      </div>
    </div>
  );
};

const createRows = (system: string, items: { no: string, desc: string, isHeader?: boolean }[]) => {
  return items.map(item => ({
    id: `${system}-${item.no}`,
    no: item.no,
    description: item.desc,
    result: '' as any,
    remarks: '',
    correctiveActions: '',
    isHeader: item.isHeader
  }));
};

const createGapRow = (no: number, section: string, req: string, sys: string, impl: string) => ({
  id: `gap-init-${no}`,
  no,
  standard: "TIA-942",
  section,
  requirement: req,
  system: sys,
  implementation: impl,
  compliance: '-' as any,
  correctiveActions: ""
});

export const INITIAL_ELV_GAP_DATA: ELVGapAssessmentReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  observationsAndRecommendations: [],
  systems: {
    "Addressable Fire Alarm System": createRows("FAS", [
      { no: "1", desc: "Control Panel Status", isHeader: true },
      { no: "1.1", desc: "The fire alarm control panel (FACP) should be in normal condition (no fault indications)." },
      { no: "1.2", desc: "Indicators for Power ON (mains + battery backup) must be healthy." },
      { no: "1.3", desc: "No trouble, supervisory, or disabled zones should be displayed." },
      { no: "2", desc: "Power Supply Health", isHeader: true },
      { no: "2.1", desc: "Main power supply and battery backup should be functional." },
      { no: "2.2", desc: "Batteries must be tested regularly for capacity and charge/discharge condition." },
      { no: "2.3", desc: "Charger status (no fault) must be monitored." },
      { no: "3", desc: "Field Device Condition", isHeader: true },
      { no: "3.1", desc: "Random check of Smoke detectors, manual call points (MCP), and sounders must be functional" },
      { no: "3.2", desc: "No contamination, dust, or paint covering detectors." },
      { no: "4", desc: "Alarm Notification", isHeader: true },
      { no: "4.1", desc: "Sounders, hooters, and visual indicators (strobes) must activate properly during testing." },
      { no: "4.2", desc: "PA/voice evacuation integration (if available) should be tested." },
      { no: "5", desc: "Integration", isHeader: true },
      { no: "5.1", desc: "Integration with BMS, suppression system, and access control should be checked." },
      { no: "5.2", desc: "Fire panel must correctly send signals to all connected systems." },
      { no: "6", desc: "Event & Fault Logging", isHeader: true },
      { no: "6.1", desc: "System must record all fire, fault, and supervisory signals in its event log." },
      { no: "7", desc: "Preventive Maintenance & Testing", isHeader: true },
      { no: "7.1", desc: "Routine inspections (daily, weekly, monthly, quarterly, annually as per NFPA 72 / IS 2189)." },
      { no: "7.2", desc: "Functional testing of detectors and MCPs." }
    ]),
    "Public Address System": createRows("PA", [
      { no: "1", desc: "Power Supply Status", isHeader: true },
      { no: "1.1", desc: "Main power and UPS/backup power should be available." },
      { no: "1.3", desc: "Amplifiers should have no fault indications." },
      { no: "2", desc: "Equipment Healthiness", isHeader: true },
      { no: "2.1", desc: "Central rack (controller, audio matrix, amplifiers) should be operational without fault alarms." },
      { no: "2.2", desc: "No overheating or loose connections in amplifiers and racks." },
      { no: "3", desc: "Mic & Paging Console", isHeader: true },
      { no: "3.1", desc: "Microphones (desktop, gooseneck, and handheld) should be functional without distortion." },
      { no: "3.2", desc: "Priority paging console must override background music during announcements." },
      { no: "4", desc: "Speaker Condition", isHeader: true },
      { no: "4.1", desc: "All speakers (wall-mounted, ceiling, horn, column) should be audible and distortion-free." },
      { no: "4.2", desc: "Balanced sound coverage in all designated areas (no dead zones)." },
      { no: "5", desc: "Integration", isHeader: true },
      { no: "5.1", desc: "PA system must integrate properly with Fire Alarm System for emergency evacuation." },
      { no: "5.2", desc: "Automatic pre-recorded announcements should trigger during fire alarms." },
      { no: "6", desc: "Preventive Maintenance & Testing", isHeader: true },
      { no: "6.1", desc: "Daily: Check system ON status, fault indicators, and console health." },
      { no: "6.2", desc: "Weekly: Test microphones and random speaker zones." },
      { no: "6.3", desc: "Monthly: Full zone paging test with emergency message." }
    ]),
    "VESDA System": createRows("VESDA", [
      { no: "1", desc: "Power Supply Status", isHeader: true },
      { no: "1.1", desc: "Mains power availability." },
      { no: "1.2", desc: "Battery backup condition (voltage, charging, and discharging cycles)." },
      { no: "2", desc: "Airflow Integrity", isHeader: true },
      { no: "2.1", desc: "Sampling pipe-No leaks (or) breakages" },
      { no: "2.2", desc: "No Airflow fault alarms (high/low flow conditions)" },
      { no: "3", desc: "False Alarms", isHeader: true },
      { no: "3.1", desc: "No false alarms or nuisance signals." },
      { no: "3.2", desc: "All pre-set alarm thresholds (Alert, Action, Fire 1, Fire 2) correctly configured and operational." },
      { no: "4", desc: "Network", isHeader: true },
      { no: "4.1", desc: "VESDA panel communication with Fire Alarm Control Panel (FACP)." },
      { no: "4.2", desc: "Network/monitoring software connection (if used)." },
      { no: "5", desc: "Maintenance & Testing", isHeader: true },
      { no: "5.1", desc: "Regular cleaning and preventive maintenance carried out." },
      { no: "5.2", desc: "Last service/test date within schedule carried out" }
    ]),
    "WLD (Water Leakage Detection  System)": createRows("WLD", [
      { no: "1", desc: "Panel Status", isHeader: true },
      { no: "1.1", desc: "WLD Control Panel should be ON and functional." },
      { no: "1.2", desc: "Both primary power supply and UPS/backup power supply should be healthy." },
      { no: "1.3", desc: "No fault or trouble indication on the panel display." },
      { no: "2", desc: "Cables", isHeader: true },
      { no: "2.1", desc: "Sensing cables (for zone-type or addressable systems) must be intact, clean, and dry." },
      { no: "2.2", desc: "Leader and jumper cables should be free from physical damage." },
      { no: "3", desc: "Alarm & Monitoring", isHeader: true },
      { no: "3.1", desc: "Alarm indication (visual and audible) should work." },
      { no: "3.2", desc: "System should be integrated with BMS / Fire Panel for remote monitoring." },
      { no: "4", desc: "Maintenance", isHeader: true },
      { no: "4.1", desc: "Periodic functional testing by simulating water presence on the sensing cable or sensor." },
      { no: "4.2", desc: "Regular preventive maintenance to clean sensing cables and check connectors." }
    ]),
    "RRS": createRows("RRS", [
      { no: "1", desc: "Control Panel Status", isHeader: true },
      { no: "1.1", desc: "Check for normal operation status (no fault/alarm indications)." },
      { no: "2", desc: "Transducers", isHeader: true },
      { no: "2.1", desc: "Confirm all ultrasonic devices are active and emitting signals." },
      { no: "2.2", desc: "No damage or loose connections." },
      { no: "3", desc: "Self Testing", isHeader: true },
      { no: "3.1", desc: "System self-test features (if available) working properly." },
      { no: "4", desc: "Maintenance", isHeader: true },
      { no: "4.1", desc: "Records maintained in O&M logbook." }
    ]),
    "Fire Extinguisher": createRows("FE", [
      { no: "1", desc: "Physical Conditon", isHeader: true },
      { no: "1.1", desc: "Extinguisher body free from dents, corrosion, cracks, or leakage" },
      { no: "1.2", desc: "Hose/nozzle intact, not blocked or cracked" },
      { no: "1.3", desc: "Operating instructions legible and facing outward" },
      { no: "2", desc: "Pressure Status", isHeader: true },
      { no: "2.1", desc: "Pressure gauge needle in the green/operable zone" },
      { no: "2.2", desc: "No signs of pressure loss (for stored-pressure types)" },
      { no: "3", desc: "Safety Seal & Pin", isHeader: true },
      { no: "3.1", desc: "Safety pin in place and sealed" },
      { no: "3.2", desc: "Tamper seal intact (not broken or missing)" },
      { no: "4", desc: "Accessibility & Location", isHeader: true },
      { no: "4.1", desc: "Easily accessible and unobstructed" },
      { no: "4.2", desc: "Mounted at correct height" },
      { no: "4.3", desc: "Fire extinguisher signage visible" },
      { no: "5", desc: "Maintenance, Expiry & Compliance", isHeader: true },
      { no: "5.1", desc: "Annual servicing done by authorized agency" },
      { no: "5.2", desc: "Monthly visual inspection completed and recorded" },
      { no: "5.3", desc: "Service tag updated with date and signature" },
      { no: "5.4", desc: "Extinguisher not expired" },
      { no: "5.5", desc: "Refilling date valid" }
    ]),
    "Access Control System": createRows("ACS", [
      { no: "1", desc: "System Hardware Health", isHeader: true },
      { no: "1.1", desc: "Door controllers powered ON and functioning" },
      { no: "1.2", desc: "Power supplies healthy (no alarms / LED normal)" },
      { no: "1.3", desc: "Backup batteries present and in good condition" },
      { no: "1.4", desc: "System connected with UPS" },
      { no: "1.5", desc: "Cabinet locks secured and tamper-proof" },
      { no: "2", desc: "Reader & Door Device health", isHeader: true },
      { no: "2.1", desc: "Card readers (RFID/Biometric) responsive" },
      { no: "2.2", desc: "LED indicators functioning properly" },
      { no: "2.3", desc: "Door contacts (magnetic sensors) working" },
      { no: "2.4", desc: "Exit push buttons / REX sensors operational" },
      { no: "2.5", desc: "Electric locks / maglocks energize & release correctly" },
      { no: "2.6", desc: "Door closer operation smooth (no slamming)" },
      { no: "3", desc: "Network & Communication", isHeader: true },
      { no: "3.1", desc: "Controllers communicating with ACS server" },
      { no: "3.2", desc: "Network switches and ports healthy" },
      { no: "3.3", desc: "Time synchronization (NTP) accurate" },
      { no: "3.4", desc: "Controller firmware up to date" },
      { no: "4", desc: "Software & Database Health", isHeader: true },
      { no: "4.1", desc: "Access control software running without errors" },
      { no: "4.2", desc: "License validity checked" },
      { no: "4.3", desc: "Access levels configured correctly" },
      { no: "4.4", desc: "Anti-passback rules functioning (if enabled)" },
      { no: "4.5", desc: "Event logs recording accurately" },
      { no: "4.6", desc: "Alarm notifications received at monitoring station" },
      { no: "5", desc: "Credential Management", isHeader: true },
      { no: "5.1", desc: "Active cards/badges issued as per approval" },
      { no: "5.2", desc: "Deactivated cards removed immediately" },
      { no: "5.3", desc: "Biometric enrolment authorized and documented" },
      { no: "5.4", desc: "Visitor cards time-bound and auto-expiry enabled" },
      { no: "6", desc: "Testing & Functional Verification", isHeader: true },
      { no: "6.1", desc: "Authorized access grants entry correctly" },
      { no: "6.2", desc: "Unauthorized access denied and logged" },
      { no: "6.3", desc: "Door forced open alarm working" },
      { no: "6.4", desc: "Door held open alarm working" },
      { no: "6.5", desc: "Emergency unlock/fire alarm integration verified" }
    ]),
    "CCTV": createRows("CCTV", [
      { no: "1", desc: "Camera Health, Coverage & Performance", isHeader: true },
      { no: "1.1", desc: "All cameras are physically intact (no damage / tampering)" },
      { no: "1.2", desc: "Camera housings, Lenses are clean and dust-free" },
      { no: "1.3", desc: "No blind spots in critical areas" },
      { no: "1.4", desc: "Live video is clear" },
      { no: "1.5", desc: "Infrared (IR) illumination functioning" },
      { no: "1.6", desc: "Motion detection working (if applicable)" },
      { no: "1.7", desc: "No blind spots in critical areas" },
      { no: "2", desc: "Recording System", isHeader: true },
      { no: "2.1", desc: "NVR/DVR powered ON and stable" },
      { no: "2.2", desc: "Recording status active for all cameras" },
      { no: "2.3", desc: "No recording gaps or missing footage" },
      { no: "2.4", desc: "Time & date synchronization correct" },
      { no: "2.5", desc: "Hard disk health status normal" },
      { no: "2.6", desc: "Storage meets defined retention period (e.g., 30 / 60 / 90 days)" },
      { no: "2.7", desc: "Old footage auto-deleted as per policy" },
      { no: "3", desc: "Network & Connectivity", isHeader: true },
      { no: "3.1", desc: "Cameras reachable on network" },
      { no: "3.2", desc: "Network switches healthy" },
      { no: "3.3", desc: "No packet loss or latency issues" },
      { no: "4", desc: "Power, Redundancy, Access Control", isHeader: true },
      { no: "4.1", desc: "PoE switches functioning properly" },
      { no: "4.2", desc: "UPS backup available and tested" },
      { no: "4.3", desc: "Authorized users list reviewed" },
      { no: "5", desc: "Monitoring & Operations", isHeader: true },
      { no: "5.1", desc: "CCTV monitors functional" },
      { no: "5.2", desc: "No dead screens" },
      { no: "5.3", desc: "SOPs available for monitoring & incident handling" },
      { no: "5.4", desc: "Incident playback tested" },
      { no: "6", desc: "Maintenance & Documentation", isHeader: true },
      { no: "6.1", desc: "Preventive maintenance carried out as per schedule" },
      { no: "6.2", desc: "AMC / warranty valid" },
      { no: "6.3", desc: "Firmware up to date" },
      { no: "6.4", desc: "Asset inventory updated" },
      { no: "6.5", desc: "Maintenance logs maintained" }
    ]),
    "GBFSS": createRows("GBFSS", [
      { no: "1", desc: "General System Status", isHeader: true },
      { no: "1.1", desc: "Detection system is powered ON and healthy" },
      { no: "1.2", desc: "No fault / trouble / supervisory alarms present" },
      { no: "1.3", desc: "System status displayed correctly on Fire Alarm Control Panel (FACP)" },
      { no: "1.4", desc: "Detectors mounted as per approved drawings" },
      { no: "1.5", desc: "Detector LED indications functioning" },
      { no: "2", desc: "Cross Zone / Double - Knock Logic", isHeader: true },
      { no: "2.1", desc: "Detection logic configured as per design (Zone-1 & Zone-2)" },
      { no: "2.2", desc: "Cross-zone dependency tested and verified" },
      { no: "2.3", desc: "No unintended single-zone discharge" },
      { no: "3", desc: "Interface with GBFSS Control Panel", isHeader: true },
      { no: "3.1", desc: "Detection signals correctly received by GBFSS panel" },
      { no: "3.2", desc: "Time delay initiated correctly" },
      { no: "3.3", desc: "Manual abort enabled during discharge countdown" },
      { no: "3.4", desc: "Audio-visual alarms activated upon detection" },
      { no: "3.5", desc: "Alarm sound levels adequate inside protected area" },
      { no: "3.6", desc: "Alarm reset functionality working" },
      { no: "4", desc: "Power Supply & Cabling", isHeader: true },
      { no: "4.1", desc: "Primary power supply healthy" },
      { no: "4.2", desc: "Battery backup available and charged" },
      { no: "4.3", desc: "Field cabling intact and fire-rated" },
      { no: "4.4", desc: "No loose terminations" },
      { no: "5", desc: "Integration & Monitoring", isHeader: true },
      { no: "5.1", desc: "Detection alarms reported to BMS / DCIM / EMS" },
      { no: "5.2", desc: "Alarms transmitted to security control room" },
      { no: "5.3", desc: "Remote monitoring signals received correctly" },
      { no: "6", desc: "Interlocks & Shutdowns", isHeader: true },
      { no: "6.1", desc: "HVAC shutdown interlock functional" },
      { no: "6.2", desc: "Dampers closure verified" },
      { no: "6.3", desc: "Door hold-open release working" },
      { no: "6.4", desc: "Integration with BMS verified" },
      { no: "7", desc: "Testing & Maintenance", isHeader: true },
      { no: "7.1", desc: "Detector functional testing completed as per schedule" },
      { no: "7.2", desc: "Smoke / aerosol test conducted without discharge" },
      { no: "7.3", desc: "Test records maintained and signed" },
      { no: "8", desc: "System Documentation & Compliance", isHeader: true },
      { no: "8.1", desc: "Cause & Effect matrix available and approved" },
      { no: "8.2", desc: "OEM manuals and test certificates available" },
      { no: "8.3", desc: "Approved system design drawings (As-built)" },
      { no: "8.4", desc: "Room integrity test (Door Fan Test) report available & valid" },
      { no: "8.5", desc: "Hazard classification and gas concentration calculations approved" },
      { no: "9", desc: "Cylinders & Storage Area", isHeader: true },
      { no: "9.1", desc: "Cylinders secured properly with brackets/chains" },
      { no: "9.2", desc: "Cylinder quantity as per design" },
      { no: "9.3", desc: "Cylinder pressure within normal range" },
      { no: "9.4", desc: "Pressure gauges intact and readable" },
      { no: "9.5", desc: "Hydrostatic test date valid" },
      { no: "9.6", desc: "Cylinder labels and gas identification visible" },
      { no: "9.7", desc: "No physical damage, corrosion, or leakage" },
      { no: "9.8", desc: "Storage room clean, dry, and ventilated" },
      { no: "10", desc: "Release Mechanism & Control Valves", isHeader: true },
      { no: "10.1", desc: "Solenoid valves physically secure" },
      { no: "10.2", desc: "Manual release station accessible and labeled" },
      { no: "10.3", desc: "Manual abort switch installed and functional" },
      { no: "10.4", desc: "Control valves free from obstruction" },
      { no: "11", desc: "Piping & Nozzles", isHeader: true },
      { no: "11.1", desc: "Piping properly supported and painted" },
      { no: "11.2", desc: "No visible leakage or corrosion" },
      { no: "11.3", desc: "Pipe sizes as per approved drawings" },
      { no: "11.4", desc: "Nozzle orientation and coverage correct" },
      { no: "11.5", desc: "Discharge paths unobstructed" }
    ]),
    "BMS (Building Management System)": createRows("BMS", [
      { no: "1", desc: "System Architecture & Server Health", isHeader: true },
      { no: "1.1", desc: "BMS servers (Primary / Secondary) are operational" },
      { no: "1.2", desc: "Redundancy (Failover / Hot-standby) tested and working" },
      { no: "1.3", desc: "Server CPU, RAM, disk usage within acceptable limits" },
      { no: "1.4", desc: "Time synchronization (NTP) enabled and correct" },
      { no: "1.5", desc: "Antivirus and OS security patches up to date" },
      { no: "1.6", desc: "System backups scheduled and verified" },
      { no: "2", desc: "Network & Communication Health", isHeader: true },
      { no: "2.1", desc: "BMS network switches operational" },
      { no: "2.2", desc: "IP addressing properly documented" },
      { no: "2.3", desc: "Field controllers online and communicating" },
      { no: "2.4", desc: "Protocols functioning correctly (BACnet / Modbus / SNMP / OPC)" },
      { no: "2.5", desc: "Firewall rules allow required BMS communication" },
      { no: "2.6", desc: "LAN/Fiber connectivity healthy and redundant" },
      { no: "3", desc: "Field Controllers & Panels", isHeader: true },
      { no: "3.1", desc: "DDC / PLC controllers powered and healthy" },
      { no: "3.2", desc: "Panel power supplies and fuses intact" },
      { no: "3.3", desc: "Controller firmware up to date" },
      { no: "3.4", desc: "Panels properly labeled and locked" },
      { no: "3.5", desc: "Earth grounding properly connected" },
      { no: "3.6", desc: "No overheating or physical damage" },
      { no: "4", desc: "Sensors & Field Devices", isHeader: true },
      { no: "4.1", desc: "Temperature sensors accurate and calibrated" },
      { no: "4.2", desc: "Humidity sensors accurate and calibrated" },
      { no: "4.3", desc: "Pressure sensors functioning correctly" },
      { no: "4.4", desc: "Energy meters integrated and logging data" },
      { no: "4.5", desc: "Actuators (valves, dampers) responding properly" },
      { no: "5", desc: "Equipment Monitoring & Control", isHeader: true },
      { no: "5.1", desc: "HVAC units visible and controllable" },
      { no: "5.2", desc: "Chillers / AHUs / CRACs monitored" },
      { no: "5.3", desc: "Pumps and fans start/stop via BMS" },
      { no: "5.4", desc: "Electrical systems (UPS, DG, PDU) integrated" },
      { no: "5.5", desc: "Fire alarm interface status visible (monitoring only)" },
      { no: "5.6", desc: "Setpoints configured as per design" },
      { no: "5.7", desc: "Manual override functions working" },
      { no: "6", desc: "Alarm Management", isHeader: true },
      { no: "6.1", desc: "Alarm priorities correctly configured" },
      { no: "6.2", desc: "Critical alarms tested and verified" },
      { no: "6.3", desc: "Alarm notifications (SMS / Email / BMS pop-up) working" },
      { no: "6.4", desc: "Alarm acknowledgment and reset working" },
      { no: "6.5", desc: "Alarm history retained as per policy" },
      { no: "7", desc: "Graphics & User interface", isHeader: true },
      { no: "7.1", desc: "Graphics match site as-built drawings" },
      { no: "7.2", desc: "Equipment status changes correctly reflected" },
      { no: "7.3", desc: "Navigation between screens smooth" },
      { no: "7.4", desc: "Operator permissions configured correctly" },
      { no: "7.5", desc: "Trend and alarm views accessible" },
      { no: "8", desc: "Trending, Reports & Analytics", isHeader: true },
      { no: "8.1", desc: "Trends enabled for critical parameters" },
      { no: "8.2", desc: "Trend interval and storage optimized" },
      { no: "8.3", desc: "Historical data retrievable" },
      { no: "8.4", desc: "Energy consumption reports generated" },
      { no: "8.5", desc: "Export of reports functioning" },
      { no: "8.6", desc: "System uptime and performance reports available" },
      { no: "9", desc: "Integration with other systems", isHeader: true },
      { no: "9.1", desc: "DCIM / CEO integration healthy (if applicable)" },
      { no: "9.2", desc: "Access Control interface status visible" },
      { no: "9.3", desc: "Fire Alarm system monitoring interface healthy" },
      { no: "9.4", desc: "Third-party system tags updating correctly" },
      { no: "10", desc: "Documentation & Compliance", isHeader: true },
      { no: "10.1", desc: "BMS architecture diagrams available" },
      { no: "10.2", desc: "IO list updated and approved" },
      { no: "10.3", desc: "Cause & Effect matrix available" },
      { no: "10.4", desc: "Maintenance logs maintained" },
      { no: "10.5", desc: "SOPs for operation and alarms available" },
      { no: "11", desc: "Preventive Maintenance & Testing", isHeader: true },
      { no: "11.1", desc: "Daily system health check performed" },
      { no: "11.2", desc: "Weekly alarm verification completed" },
      { no: "11.3", desc: "Monthly sensor accuracy check conducted" },
      { no: "11.4", desc: "Annual BMS audit completed" },
      { no: "11.5", desc: "Vendor CEO active" }
    ])
  },
  gapAnalysisRows: [
    createGapRow(1, "Table 1", "Site access must be restricted...", "Physical Security", "Observed security fencing..."),
    createGapRow(2, "Table 1", "Visitor entry logs must be automated...", "Access Control", "Manual logs in use..."),
    createGapRow(3, "Table 2", "Camera coverage at entry lobby...", "CCTV", "2 cameras present..."),
    createGapRow(4, "Table 2", "Motion sensors at parking area...", "Detection", "Sensors not present..."),
    createGapRow(5, "Table 3", "Emergency lighting backup time...", "Lighting", "Backup for 30 mins...")
  ]
};
