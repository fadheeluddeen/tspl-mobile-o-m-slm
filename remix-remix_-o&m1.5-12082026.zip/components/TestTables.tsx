import React, { useState, useEffect } from 'react';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import { ObservationRecommendationRow } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

// --- TYPES ---

export interface ReadingWithAudit {
  observationsAndRecommendations?: ObservationRecommendationRow[];
}

export interface EquipmentRow {
  id: string;
  name: string;
  make: string;
  model: string;
  serialNo: string;
  calDate: string;
  expDate: string;
}

export interface BatteryRow {
  id: string;
  batteryNo: number;
  measuredIr: string;
  irFail: string;
  irWarn: string;
  measuredVolts: string;
  voltThresh: string;
  remarks: string;
  isOverridden?: boolean;
}

export interface BatteryString {
  id: string;
  name: string;
  rows: BatteryRow[];
}

export interface UpsUnit {
  id: string;
  location: string;
  name: string;
  strings: BatteryString[];
}

// --- CONSTANTS ---

export const INITIAL_EQUIPMENT: EquipmentRow[] = [
    { id: 'eq1', name: 'Battery Impedance Tester', make: 'Megger', model: 'BITE3', serialNo: 'N/A', calDate: 'N/A', expDate: 'N/A' },
    { id: 'eq2', name: 'Digital Multimeter', make: 'Fluke', model: '87V', serialNo: 'N/A', calDate: 'N/A', expDate: 'N/A' },
    { id: 'eq3', name: 'Insulated Torque Wrench', make: 'Wiha', model: 'T-Handle', serialNo: 'N/A', calDate: 'N/A', expDate: 'N/A' },
    { id: 'eq4', name: 'Infrared Thermometer', make: 'Fluke', model: '62 Max', serialNo: 'N/A', calDate: 'N/A', expDate: 'N/A' },
];

export const INITIAL_OBSERVATIONS = [
    { id: '1', observation: '', recommendation: '' }
];

export const INITIAL_UPS_DATA: UpsUnit[] = [
    {
        id: 'ups1',
        location: '',
        name: 'UPS-1',
        strings: [
            {
                id: 'str1',
                name: 'STRING 1',
                rows: [
                    { id: 'r1', batteryNo: 1, measuredIr: '', irFail: '', irWarn: '', measuredVolts: '', voltThresh: '', remarks: '' }
                ]
            }
        ]
    }
];

// --- LOGIC HELPER: CALCULATE REMARKS ---

export const calculateBatteryStatus = (row: BatteryRow): string => {
    const mIr = row.measuredIr === '' ? NaN : parseFloat(row.measuredIr);
    const tIrFail = row.irFail === '' ? NaN : parseFloat(row.irFail);
    const tIrWarn = row.irWarn === '' ? NaN : parseFloat(row.irWarn);
    const mVolt = row.measuredVolts === '' ? NaN : parseFloat(row.measuredVolts);
    const tVolt = row.voltThresh === '' ? NaN : parseFloat(row.voltThresh);

    if (isNaN(mIr) && isNaN(mVolt)) return '...';

    // 1. CRITICAL SAFETY RULE: Voltage Override
    if (!isNaN(mVolt) && !isNaN(tVolt)) {
        if (mVolt < tVolt) return 'Fail';
    }

    // 2. IR Fail Condition
    if (!isNaN(mIr) && !isNaN(tIrFail)) {
        if (mIr >= tIrFail) return 'Fail';
    }

    // 3. IR Warning Condition
    if (!isNaN(mIr) && !isNaN(tIrWarn)) {
        if (mIr >= tIrWarn) return 'Warning';
    }

    // 4. Pass Condition
    if (!isNaN(mIr) || !isNaN(mVolt)) {
        return 'Pass';
    }

    return '...';
};

export const getRemarksColor = (remarks: string): string => {
    const r = remarks.toLowerCase();
    if (r === 'fail') return 'text-red-600 font-bold bg-red-50';
    if (r === 'warning') return 'text-amber-600 font-bold bg-amber-50';
    if (r === 'pass') return 'text-green-600 font-bold bg-green-50';
    return 'text-slate-400';
};

// --- COMPONENT: EQUIPMENT TABLE ---

interface EquipmentTableProps {
    data: EquipmentRow[];
    onChange: (d: EquipmentRow[]) => void;
    readOnly?: boolean;
}

export const EquipmentTable: React.FC<EquipmentTableProps> = ({ data, onChange, readOnly = false }) => {
    const safeData = Array.isArray(data) ? data : [];
    const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

    const updateRow = (idx: number, field: keyof EquipmentRow, val: string) => {
        if (readOnly) return;
        const newData = [...safeData];
        newData[idx] = { ...newData[idx], [field]: val };
        onChange(newData);
    };

    const deleteRow = (idx: number) => {
        if (readOnly) return;
        
        confirmDelete({
            message: "Are you sure you want to delete this equipment?",
            onConfirm: () => {
                const newData = safeData.filter((_, i) => i !== idx);
                onChange(newData);
            }
        });
    };

    const addRow = () => {
        if (readOnly) return;
        const newRow: EquipmentRow = {
            id: `eq-${Date.now()}`,
            name: '',
            make: '',
            model: '',
            serialNo: 'N/A',
            calDate: 'N/A',
            expDate: 'N/A'
        };
        onChange([...safeData, newRow]);
    };

    return (
        <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden mt-8">
            <ConfirmModal 
                isOpen={modalConfig.isOpen}
                onClose={closeModal}
                onConfirm={modalConfig.onConfirm}
                title={modalConfig.title}
                message={modalConfig.message}
                isDeleting={isDeleting}
            />
            <ToastContainer toast={toast} onClose={hideToast} />
            
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <span className="text-slate-400">🔧</span>
                    <h3 className="font-bold text-slate-800">Required Equipment (Typical)</h3>
                </div>
                {!readOnly && (
                    <button 
                        onClick={addRow}
                        className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 px-2 py-1 rounded transition-colors"
                    >
                        + Add Equipment
                    </button>
                )}
            </div>
            <div className="overflow-x-auto w-full">
                <table className="w-full text-sm text-left table-auto border-collapse">
                    <thead>
                        <tr className="bg-orange-500 text-white">
                            <th className="px-4 py-3 font-semibold min-w-[120px] whitespace-nowrap">Equipment Name</th>
                            <th className="px-4 py-3 font-semibold min-w-[80px] whitespace-nowrap">Make</th>
                            <th className="px-4 py-3 font-semibold min-w-[80px] whitespace-nowrap">Model</th>
                            <th className="px-4 py-3 font-semibold text-slate-100 min-w-[80px] whitespace-nowrap">Serial No</th>
                            <th className="px-4 py-3 font-semibold text-slate-100 min-w-[100px] whitespace-nowrap">Calibration Date</th>
                            <th className="px-4 py-3 font-semibold text-slate-100 min-w-[100px] whitespace-nowrap">Expiry Date</th>
                            {!readOnly && <th className="px-2 py-3 w-10"></th>}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
{(safeData).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                        {safeData.map((row, idx) => (
                            <tr key={row.id} className="hover:bg-slate-50 group">
                                <td className="px-4 py-2 font-medium text-slate-700">
                                    <input 
                                        value={row.name || ''} 
                                        onChange={e => updateRow(idx, 'name', e.target.value)} 
                                        className="w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-orange-500 outline-none transition-colors" 
                                        placeholder="Enter equipment name..."
                                        disabled={readOnly}
                                    />
                                </td>
                                <td className="px-4 py-2">
                                    <input value={row.make || ''} onChange={e => updateRow(idx, 'make', e.target.value)} className="w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-orange-500 outline-none transition-colors" disabled={readOnly} />
                                </td>
                                <td className="px-4 py-2">
                                    <input value={row.model || ''} onChange={e => updateRow(idx, 'model', e.target.value)} className="w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-orange-500 outline-none transition-colors" disabled={readOnly} />
                                </td>
                                <td className="px-4 py-2 text-slate-400 italic">
                                     <input value={row.serialNo || ''} onChange={e => updateRow(idx, 'serialNo', e.target.value)} className="w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-orange-500 outline-none transition-colors" disabled={readOnly} />
                                </td>
                                <td className="px-4 py-2 text-slate-400 italic">
                                     <input value={row.calDate || ''} onChange={e => updateRow(idx, 'calDate', e.target.value)} className="w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-orange-500 outline-none transition-colors" disabled={readOnly} />
                                </td>
                                <td className="px-4 py-2 text-slate-400 italic">
                                     <input value={row.expDate || ''} onChange={e => updateRow(idx, 'expDate', e.target.value)} className="w-full bg-transparent border-b border-transparent hover:border-slate-300 focus:border-orange-500 outline-none transition-colors" disabled={readOnly} />
                                </td>
                                {!readOnly && (
                                    <td className="px-2 py-2 text-center">
                                        <button 
                                            onClick={() => deleteRow(idx)}
                                            className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                            title="Delete Row"
                                        >
                                            🗑️
                                        </button>
                                    </td>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
                {safeData.length === 0 && !readOnly && (
                    <div className="p-8 text-center text-slate-400 italic bg-slate-50">
                        No equipment defined. 
                        <button onClick={addRow} className="ml-2 text-indigo-600 hover:underline font-medium">Add Equipment</button>
                    </div>
                )}
            </div>
        </div>
    );
};

// --- COMPONENT: TECHNICAL AUDIT SUMMARY ---

interface TechnicalAuditSummaryProps {
    data: ObservationRecommendationRow[];
    onChange: (d: ObservationRecommendationRow[]) => void;
    readOnly?: boolean;
    title?: string;
}

export const TechnicalAuditSummary: React.FC<TechnicalAuditSummaryProps> = ({ 
    data, 
    onChange, 
    readOnly = false,
    title = "Audit Summary & Findings"
}) => {
    return (
        <div className="mt-8">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <span className="text-xl">📝</span>
                        <h4 className="font-black text-slate-800 uppercase text-sm tracking-tight">{title}</h4>
                    </div>
                </div>
                <div className="p-6">
                    <ObservationsRecommendationsTable 
                        observationsAndRecommendations={data}
                        onChange={onChange}
                        readOnly={readOnly}
                    />
                </div>
            </div>
        </div>
    );
};

// --- COMPONENT: MEASUREMENT TEMPLATE ---

interface MeasurementTemplateProps {
    units: UpsUnit[];
    onChange: (u: UpsUnit[]) => void;
    title?: string;
    readOnly?: boolean;
}

export const MeasurementTemplate: React.FC<MeasurementTemplateProps> = ({ units, onChange, title = "Measurement Values (Template)", readOnly = false }) => {
    const safeUnits = Array.isArray(units) ? units : [];
    const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

    // UPS Actions
    const addUps = () => {
        if (readOnly) return;
        onChange([...safeUnits, {
            id: `ups-${Date.now()}`, name: `UPS-${safeUnits.length + 1}`, location: '',
            strings: [{ id: `str-${Date.now()}`, name: 'STRING 1', rows: [{ id: `row-${Date.now()}`, batteryNo: 1, measuredIr: '', irFail: '', irWarn: '', measuredVolts: '', voltThresh: '', remarks: '' }] }]
        }]);
    };
    const deleteUps = (idx: number) => {
        if (readOnly) return;
        
        confirmDelete({
            message: "Are you sure you want to delete this Entire UPS and all its data?",
            onConfirm: () => {
                onChange(safeUnits.filter((_, i) => i !== idx));
            }
        });
    };
    const updateUps = (idx: number, field: keyof UpsUnit, val: string) => {
        if (readOnly) return;
        const n = [...safeUnits]; n[idx] = { ...n[idx], [field]: val }; onChange(n);
    };

    // String Actions
    const addString = (upsIdx: number) => {
        if (readOnly) return;
        const n = [...safeUnits];
        const newStringNo = n[upsIdx].strings.length + 1;
        n[upsIdx].strings.push({
            id: `str-${Date.now()}`, name: `STRING ${newStringNo}`,
            rows: [{ id: `row-${Date.now()}`, batteryNo: 1, measuredIr: '', irFail: '', irWarn: '', measuredVolts: '', voltThresh: '', remarks: '' }]
        });
        onChange(n);
    };
    const deleteString = (upsIdx: number, strIdx: number) => {
        if (readOnly) return;
        
        confirmDelete({
            message: "Are you sure you want to delete this string and its battery rows?",
            onConfirm: () => {
                const n = [...safeUnits];
                n[upsIdx].strings = n[upsIdx].strings.filter((_, i) => i !== strIdx);
                onChange(n);
            }
        });
    };

    // Row Actions & Logic
    const addRow = (upsIdx: number, strIdx: number) => {
        if (readOnly) return;
        const n = [...safeUnits];
        const rows = n[upsIdx].strings[strIdx].rows;
        const lastNo = rows.length > 0 ? rows[rows.length - 1].batteryNo : 0;
        rows.push({ id: `row-${Date.now()}`, batteryNo: lastNo + 1, measuredIr: '', irFail: '', irWarn: '', measuredVolts: '', voltThresh: '', remarks: '' });
        onChange(n);
    };

    const deleteRow = (upsIdx: number, strIdx: number, rowIdx: number) => {
        if (readOnly) return;
        
        confirmDelete({
            message: "Are you sure you want to delete this battery row?",
            onConfirm: () => {
                const n = [...safeUnits];
                n[upsIdx].strings[strIdx].rows = n[upsIdx].strings[strIdx].rows.filter((_, i) => i !== rowIdx);
                onChange(n);
            }
        });
    };

    const updateRowField = (upsIdx: number, strIdx: number, rowIdx: number, field: keyof BatteryRow, value: string) => {
        if (readOnly) return;
        const newUnits = [...safeUnits];
        const row = newUnits[upsIdx].strings[strIdx].rows[rowIdx];
        
        // Update the value
        // @ts-ignore
        row[field] = value;

        // If user manually edits remarks, set flag
        if (field === 'remarks') {
            row.isOverridden = true;
        }

        // Logic Check: If we changed a numeric input, Recalculate Remarks automatically
        // (Override the override if inputs change, or respect override? Usually, input change triggers recalc)
        if (['measuredIr', 'irFail', 'irWarn', 'measuredVolts', 'voltThresh'].includes(field)) {
             row.remarks = calculateBatteryStatus(row);
             row.isOverridden = false; // Reset manual override on data change
        }

        onChange(newUnits);
    };

    return (
        <div className="mt-8 space-y-4">
            <ConfirmModal 
                isOpen={modalConfig.isOpen}
                onClose={closeModal}
                onConfirm={modalConfig.onConfirm}
                title={modalConfig.title}
                message={modalConfig.message}
                isDeleting={isDeleting}
            />
            <ToastContainer toast={toast} onClose={hideToast} />
            
            <div className="flex justify-between items-center">
                 <div className="flex items-center gap-2">
                    <span className="text-slate-400">⚡</span>
                    <h3 className="font-bold text-slate-800 uppercase">{title}</h3>
                 </div>
                 {!readOnly && (
                    <button onClick={addUps} className="px-3 py-1.5 bg-orange-100 text-orange-700 text-sm font-semibold rounded hover:bg-orange-200 transition-colors">
                        + Add UPS / String
                    </button>
                 )}
            </div>

            {safeUnits.map((ups, upsIdx) => (
                <div key={ups.id} className="border border-slate-300 rounded-lg overflow-hidden bg-white shadow-sm">
                    {/* UPS Header */}
                    <div className="grid grid-cols-2 bg-orange-500 text-white divide-x divide-orange-400/50">
                        <div className="px-4 py-2 font-bold uppercase text-sm">UPS & Battery Details</div>
                        <div className="px-4 py-2 font-mono text-center text-sm">---</div>
                    </div>
                    <div className="grid grid-cols-2 divide-x divide-slate-200 border-b border-slate-200">
                        <div className="px-4 py-2 text-sm font-semibold text-slate-600 bg-slate-50">Location</div>
                        <div className="p-0">
                            <input 
                                value={ups.location || ''} 
                                onChange={e => updateUps(upsIdx, 'location', e.target.value)}
                                className="w-full px-4 py-2 text-sm outline-none focus:bg-blue-50" 
                                placeholder="Enter Location..."
                                disabled={readOnly}
                            />
                        </div>
                    </div>
                    <div className="grid grid-cols-2 divide-x divide-slate-200 border-b border-slate-200">
                        <div className="px-4 py-2 text-sm font-semibold text-slate-600 bg-slate-50">UPS</div>
                        <div className="p-0">
                            <input 
                                value={ups.name || ''} 
                                onChange={e => updateUps(upsIdx, 'name', e.target.value)}
                                className="w-full px-4 py-2 text-sm font-bold text-slate-800 outline-none focus:bg-blue-50" 
                                disabled={readOnly}
                            />
                        </div>
                    </div>

                    {/* Strings */}
                    {ups.strings.map((str, strIdx) => (
                        <div key={str.id} className="border-t border-slate-200">
                            <div className="bg-orange-400 text-white px-4 py-2 flex justify-between items-center">
                                <span className="font-bold text-sm uppercase">{str.name}</span>
                                {!readOnly && (
                                    <button onClick={() => deleteString(upsIdx, strIdx)} className="text-white hover:text-red-200 transition-colors" title="Delete String">🗑️</button>
                                )}
                            </div>
                            
                            <div className="overflow-x-auto w-full">
                                <table className="w-full text-center text-xs table-auto border-collapse">
                                    <thead>
                                        <tr className="bg-orange-200 text-orange-900 font-semibold border-b border-orange-300">
                                            <th className="py-3 px-1 border-r border-orange-300/50 min-w-[60px] whitespace-nowrap">Battery no</th>
                                            <th className="py-3 px-1 border-r border-orange-300/50 min-w-[100px] whitespace-nowrap">Measured IR (mΩ)</th>
                                            <th className="py-3 px-1 border-r border-orange-300/50 min-w-[100px] whitespace-nowrap">IR Threshold (fail)</th>
                                            <th className="py-3 px-1 border-r border-orange-300/50 min-w-[100px] whitespace-nowrap">IR Threshold (warn)</th>
                                            <th className="py-3 px-1 border-r border-orange-300/50 min-w-[100px] whitespace-nowrap">Measured Voltage (V)</th>
                                            <th className="py-3 px-1 border-r border-orange-300/50 min-w-[100px] whitespace-nowrap">Voltage Threshold</th>
                                            <th className="py-3 px-1 min-w-[100px] whitespace-nowrap">Remarks</th>
                                            {!readOnly && <th className="w-8"></th>}
                                        </tr>
                                    </thead>
                                <tbody className="divide-y divide-slate-100">
{(str.rows).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                                    {str.rows.map((row, rowIdx) => {
                                        // Config Validation Check for this row
                                        const configError = parseFloat(row.irFail) <= parseFloat(row.irWarn);

                                        return (
                                        <tr key={row.id} className="hover:bg-slate-50 group">
                                            <td className="py-2 bg-orange-50/50 font-bold text-slate-700">{row.batteryNo}</td>
                                            
                                            {/* Measured IR */}
                                            <td className="py-2 border-l border-slate-100 p-0">
                                                <input 
                                                    type="number" step="0.01"
                                                    value={row.measuredIr || ''}
                                                    onChange={(e) => updateRowField(upsIdx, strIdx, rowIdx, 'measuredIr', e.target.value)}
                                                    className="w-full text-center py-1 bg-transparent focus:bg-blue-50 outline-none" 
                                                    placeholder="-" 
                                                    disabled={readOnly}
                                                />
                                            </td>

                                            {/* IR Fail Threshold */}
                                            <td className="py-2 border-l border-slate-100 p-0 relative">
                                                 <input 
                                                    type="number" step="0.01"
                                                    value={row.irFail || ''}
                                                    onChange={(e) => updateRowField(upsIdx, strIdx, rowIdx, 'irFail', e.target.value)}
                                                    className={`w-full text-center py-1 bg-transparent focus:bg-blue-50 outline-none ${configError ? 'text-red-600 bg-red-50' : ''}`}
                                                    placeholder="Fail > Warn" 
                                                    disabled={readOnly}
                                                />
                                            </td>

                                            {/* IR Warn Threshold */}
                                            <td className="py-2 border-l border-slate-100 p-0">
                                                <input 
                                                    type="number" step="0.01"
                                                    value={row.irWarn || ''}
                                                    onChange={(e) => updateRowField(upsIdx, strIdx, rowIdx, 'irWarn', e.target.value)}
                                                    className={`w-full text-center py-1 bg-transparent focus:bg-blue-50 outline-none ${configError ? 'text-red-600 bg-red-50' : ''}`}
                                                    placeholder="Warn < Fail" 
                                                    disabled={readOnly}
                                                />
                                            </td>

                                            {/* Measured Voltage */}
                                            <td className="py-2 border-l border-slate-100 p-0">
                                                 <input 
                                                    type="number" step="0.01"
                                                    value={row.measuredVolts || ''}
                                                    onChange={(e) => updateRowField(upsIdx, strIdx, rowIdx, 'measuredVolts', e.target.value)}
                                                    className="w-full text-center py-1 bg-transparent focus:bg-blue-50 outline-none" 
                                                    placeholder="-" 
                                                    disabled={readOnly}
                                                />
                                            </td>

                                            {/* Voltage Threshold */}
                                            <td className="py-2 border-l border-slate-100 p-0">
                                                 <input 
                                                    type="number" step="0.01"
                                                    value={row.voltThresh || ''}
                                                    onChange={(e) => updateRowField(upsIdx, strIdx, rowIdx, 'voltThresh', e.target.value)}
                                                    className="w-full text-center py-1 bg-transparent focus:bg-blue-50 outline-none" 
                                                    placeholder="Min V" 
                                                    disabled={readOnly}
                                                />
                                            </td>

                                            {/* Remarks (Auto-Calc) */}
                                            <td className={`py-2 border-l border-slate-100 p-0 ${getRemarksColor(row.remarks)}`}>
                                                 <input 
                                                    value={row.remarks || ''}
                                                    onChange={(e) => updateRowField(upsIdx, strIdx, rowIdx, 'remarks', e.target.value)}
                                                    className={`w-full text-center py-1 bg-transparent outline-none font-bold ${getRemarksColor(row.remarks)}`} 
                                                    placeholder="..." 
                                                    disabled={readOnly}
                                                />
                                            </td>

                                            {!readOnly && (
                                                <td className="py-2 text-right px-2">
                                                    <button onClick={() => deleteRow(upsIdx, strIdx, rowIdx)} className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500">×</button>
                                                </td>
                                            )}
                                        </tr>
                                    )})}
                                    </tbody>
                                </table>
                            </div>
                            
                            {!readOnly && (
                                <div className="bg-slate-50 border-t border-slate-200 py-2 text-center">
                                    <button onClick={() => addRow(upsIdx, strIdx)} className="text-xs font-semibold text-slate-500 hover:text-orange-600 transition-colors">
                                        + Add Row
                                    </button>
                                </div>
                            )}
                        </div>
                    ))}

                    <div className="bg-slate-50 p-2 flex justify-between items-center border-t border-slate-300">
                         {!readOnly && (
                             <button onClick={() => addString(upsIdx)} className="px-3 py-1 border border-slate-300 rounded bg-white text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors">
                                + Add String
                             </button>
                         )}
                         {!readOnly && (
                             <button onClick={() => deleteUps(upsIdx)} className="text-xs text-red-400 hover:text-red-600 flex items-center gap-1 transition-colors">
                                 🗑️ Delete UPS
                             </button>
                         )}
                    </div>
                </div>
            ))}
        </div>
    );
};