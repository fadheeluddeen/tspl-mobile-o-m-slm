
import React, { useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { Download, Upload, Camera } from 'lucide-react';
import { LightningArrestorReading, LAEquipmentRow, LAReadingRow, LiveCaptureConfig } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { exportLightningArrestorToExcel } from '../utils/excelExport';
import { readSingleInstrumentDisplay } from '../services/geminiClient';

// Icons
const HammerIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 12-8.5 8.5c-.83.83-2.17.83-3 0 0 0 0 0 0 0a2.12 2.12 0 0 1 0-3L12 9"/><path d="M17.64 15 22 10.64"/><path d="m20.91 11.7-1.25-1.25c-.6-.6-.9-1.4-.9-2.25V5c0-1.1.9-2 2-2h1c.55 0 1 .45 1 1v1c0 .55-.45 1-1 1h-1c-.55 0-1 .45-1 1v2.75c0 .55.45 1 1 1h1.25c.55 0 1 .45 1 1v1.25c0 .55-.45 1-1 1h-1.25c-.55 0-1-.45-1-1Z"/><path d="m15 12-3-3"/><path d="m7 21 3-3"/></svg>
);

const ZapIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-500"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
);

const Trash2Icon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

interface LightningArrestorTablesProps {
  data: LightningArrestorReading;
  onChange: (data: LightningArrestorReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

export const LightningArrestorTables: React.FC<LightningArrestorTablesProps> = ({ data, onChange, readOnly = false, aiEnabled = false, liveCaptureConfig }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast, showToast } = useConfirmDelete();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const safeEquipmentList = Array.isArray(data?.equipmentList) ? data.equipmentList : [];
  const safeLaReadings = Array.isArray(data?.laReadings) ? data.laReadings : [];

  const [liveCapture, setLiveCapture] = useState<{
    pitIndex: number;
    phase: 'camera' | 'reading' | 'review';
    readValue: string;
    error: string;
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const startLiveCapture = async (pitIndex: number) => {
    if (pitIndex >= safeLaReadings.length) return;
    setLiveCapture({ pitIndex, phase: 'camera', readValue: '', error: '' });
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      }, 100);
    } catch (err) {
      console.error('Camera error:', err);
      setLiveCapture(prev => prev ? { ...prev, error: 'Camera not available. Enter values manually below.', phase: 'review' } : null);
    }
  };

  const handleCancelCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    let width = video.videoWidth;
    let height = video.videoHeight;
    const maxDim = 1280;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.floor(height * (maxDim / width));
        width = maxDim;
      } else {
        width = Math.floor(width * (maxDim / height));
        height = maxDim;
      }
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);
    
    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);

    try {
      const val = await readSingleInstrumentDisplay(
        base64,
        'Grounding Value',
        'Ω',
        liveCaptureConfig?.fields?.[0]?.readingGuidance
      );
      setLiveCapture(prev => prev ? { ...prev, phase: 'review', readValue: val, error: '' } : null);
    } catch (err: any) {
      setLiveCapture(prev => prev ? { ...prev, phase: 'review', readValue: '', error: 'Could not read value. Please enter manually.' } : null);
    }
  };

  const confirmCaptureValue = () => {
    if (!liveCapture) return;
    const newList = [...safeLaReadings];
    const row = newList[liveCapture.pitIndex];
    
    const valStr = liveCapture.readValue.trim();
    row.groundingValue = valStr;
    
    const av = parseFloat(row.acceptValue);
    const gv = parseFloat(valStr);
    
    if (!isNaN(gv) && !isNaN(av)) {
      row.result = gv <= av ? 'Pass' : 'Fail';
    } else {
      row.result = '...';
    }

    updateField('laReadings', newList);
    
    if (liveCapture.pitIndex + 1 < safeLaReadings.length) {
      startLiveCapture(liveCapture.pitIndex + 1);
    } else {
      handleCancelCapture();
    }
  };

  const updateField = (field: keyof LightningArrestorReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const handleExportExcel = () => {
    exportLightningArrestorToExcel(data, `Lightning_Protection_${new Date().toISOString().split('T')[0]}.xlsx`);
    showToast('Exported Grounding Resistance table to Excel!', 'success');
  };

  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result as ArrayBuffer;
        if (!buffer) return;
        const wb = XLSX.read(buffer, { type: 'array' });
        const sheetName = wb.SheetNames[0];
        if (!sheetName) {
          showToast('No worksheet found in Excel file.', 'error');
          return;
        }
        const sheet = wb.Sheets[sheetName];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        if (!rows || rows.length < 2) {
          showToast('Excel file is empty or missing data rows.', 'error');
          return;
        }

        let headerRowIndex = -1;
        let colMap: { [key: string]: number } = {};

        for (let i = 0; i < Math.min(rows.length, 10); i++) {
          const row = rows[i] || [];
          const normRow = row.map((cell: any) => String(cell || '').trim().toLowerCase());

          const pitIdx = normRow.findIndex((c: string) => c.includes('earth pit') || c.includes('pit name'));
          const locIdx = normRow.findIndex((c: string) => c.includes('location'));
          const gvIdx = normRow.findIndex((c: string) => c.includes('grounding value') || c.includes('grounding'));

          if (pitIdx !== -1 || locIdx !== -1 || gvIdx !== -1) {
            headerRowIndex = i;
            normRow.forEach((colName: string, cIdx: number) => {
              if (colName.includes('earth pit') || colName.includes('pit name')) colMap['pitName'] = cIdx;
              else if (colName.includes('location')) colMap['location'] = cIdx;
              else if (colName.includes('conductor')) colMap['conductorType'] = cIdx;
              else if (colName.includes('grounding')) colMap['groundingValue'] = cIdx;
              else if (colName.includes('accept')) colMap['acceptValue'] = cIdx;
              else if (colName.includes('remark')) colMap['remarks'] = cIdx;
            });
            break;
          }
        }

        if (headerRowIndex === -1) {
          headerRowIndex = 0;
          const normRow = (rows[0] || []).map((cell: any) => String(cell || '').trim().toLowerCase());
          normRow.forEach((colName: string, cIdx: number) => {
            if (colName.includes('earth pit') || colName.includes('pit name')) colMap['pitName'] = cIdx;
            else if (colName.includes('location')) colMap['location'] = cIdx;
            else if (colName.includes('conductor')) colMap['conductorType'] = cIdx;
            else if (colName.includes('grounding')) colMap['groundingValue'] = cIdx;
            else if (colName.includes('accept')) colMap['acceptValue'] = cIdx;
            else if (colName.includes('remark')) colMap['remarks'] = cIdx;
          });
        }

        const importedReadings: LAReadingRow[] = [];

        for (let i = headerRowIndex + 1; i < rows.length; i++) {
          const row = rows[i];
          if (!row || row.length === 0) continue;

          const getVal = (key: string): string => {
            const idx = colMap[key];
            if (idx !== undefined && row[idx] !== undefined && row[idx] !== null) {
              return String(row[idx]).trim();
            }
            return '';
          };

          const pitName = getVal('pitName');
          const location = getVal('location');
          const conductorType = getVal('conductorType');
          const groundingValue = getVal('groundingValue');
          const acceptValue = getVal('acceptValue') || '10';
          const remarks = getVal('remarks');

          if (!pitName && !location && !conductorType && !groundingValue && !remarks) {
            continue;
          }

          const gv = parseFloat(groundingValue);
          const av = parseFloat(acceptValue);
          let result = '...';
          if (!isNaN(gv) && !isNaN(av)) {
            result = gv <= av ? 'Pass' : 'Fail';
          }

          importedReadings.push({
            id: `la-rd-${Date.now()}-${i}`,
            pitName,
            location,
            conductorType,
            groundingValue,
            acceptValue,
            remarks,
            result
          });
        }

        if (importedReadings.length === 0) {
          showToast('No valid earth pit reading rows found in Excel.', 'error');
          return;
        }

        updateField('laReadings', importedReadings);
        showToast(`Successfully imported ${importedReadings.length} earth pit reading(s)!`, 'success');
      } catch (err) {
        console.error('Error importing Excel:', err);
        showToast('Failed to parse Excel file. Please check format.', 'error');
      } finally {
        if (e.target) e.target.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const addEquipment = () => {
    const newList = [...safeEquipmentList];
    newList.push({
      id: `la-eq-${Date.now()}`,
      name: '',
      make: '',
      serial: '',
      model: '',
      calDate: '',
      dueDate: ''
    });
    updateField('equipmentList', newList);
  };

  const addEarthPit = () => {
    const newList = [...safeLaReadings];
    newList.push({
      id: `la-rd-${Date.now()}`,
      pitName: '',
      location: '',
      conductorType: '',
      groundingValue: '',
      acceptValue: '10',
      remarks: '',
      result: '...'
    });
    updateField('laReadings', newList);
  };

  const updateEquipmentRow = (id: string, field: keyof LAEquipmentRow, value: string) => {
    const newList = safeEquipmentList.map(item => item.id === id ? { ...item, [field]: value } : item);
    updateField('equipmentList', newList);
  };

  const updateReadingRow = (id: string, field: keyof LAReadingRow, value: string) => {
    const newList = safeLaReadings.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value };
        // Recalculate result
        const gv = parseFloat(updated.groundingValue);
        const av = parseFloat(updated.acceptValue);
        if (!isNaN(gv) && !isNaN(av)) {
          updated.result = gv <= av ? 'Pass' : 'Fail';
        } else {
          updated.result = '...';
        }
        return updated;
      }
      return item;
    });
    updateField('laReadings', newList);
  };

  const deleteRow = (field: 'equipmentList' | 'laReadings', id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: `Are you sure you want to delete this ${field === 'equipmentList' ? 'equipment' : 'earth pit reading'} record?`,
      onConfirm: () => {
        const newList = (data[field] as any[]).filter(item => item.id !== id);
        updateField(field, newList);
      }
    });
  };

  return (
    <div className="space-y-12 animate-fade-in pb-10">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* Header Controls */}
      <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-100 text-orange-600 rounded-lg">
            <ZapIcon />
          </div>
          <div>
            <h3 className="font-bold text-slate-800 uppercase text-sm tracking-tight">Diagnostic Status</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase">IEC 62305-1 Standard Compliance</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs font-bold text-slate-500 uppercase">Overall Result:</label>
          <select 
            value={data?.status || 'PENDING'}
            onChange={e => updateField('status', e.target.value)}
            disabled={readOnly}
            className={`text-xs font-bold px-3 py-1.5 rounded-lg border focus:ring-2 outline-none transition-all appearance-none
              ${data?.status === 'PASS' ? 'bg-green-50 border-green-200 text-green-700' : 
                data?.status === 'FAIL' ? 'bg-red-50 border-red-200 text-red-700' : 
                'bg-slate-50 border-slate-200 text-slate-600'}`}
          >
            <option value="PENDING">PENDING</option>
            <option value="PASS">PASS</option>
            <option value="FAIL">FAIL</option>
          </select>
        </div>
      </div>

      {/* 1. TEST PERSONNEL & SCHEDULE */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#FB923C] px-6 py-3 text-white">
          <h3 className="text-center font-bold uppercase tracking-wider text-sm">Personnel & Test Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Prepared By</label>
            <input 
              value={data?.preparedBy || ''} 
              onChange={e => updateField('preparedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tested By</label>
            <input 
              value={data?.testedBy || ''} 
              onChange={e => updateField('testedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tester Email</label>
            <input 
              value={data?.testerEmail || ''} 
              onChange={e => updateField('testerEmail', e.target.value)}
              placeholder="Email"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Witnessed By</label>
            <input 
              value={data?.witnessedBy || ''} 
              onChange={e => updateField('witnessedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Test Date</label>
            <input 
              type="date"
              value={data?.testDate || ''} 
              onChange={e => updateField('testDate', e.target.value)}
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
        </div>
      </section>

      {/* Table A: Equipment Used */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white flex justify-between items-center">
          <div className="flex items-center gap-2">
            <HammerIcon />
            <h3 className="font-bold uppercase tracking-wider text-sm">Table: Equipment's Used for Audit</h3>
          </div>
          {!readOnly && (
            <button onClick={addEquipment} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[10px] font-bold uppercase transition-colors">+ Add Equipment</button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="bg-orange-50 text-orange-800 border-b border-orange-100">
                <th className="px-4 py-3 font-bold w-12 text-center">Sr.No.</th>
                <th className="px-4 py-3 font-bold">Equipment's Used for Audit</th>
                <th className="px-4 py-3 font-bold">Make</th>
                <th className="px-4 py-3 font-bold">Serial no</th>
                <th className="px-4 py-3 font-bold">Model no</th>
                <th className="px-4 py-3 font-bold">Calibration date</th>
                <th className="px-4 py-3 font-bold">Calibration due date</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
{(safeEquipmentList).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {safeEquipmentList.map((row, idx) => (
                <tr key={row.id} className="hover:bg-slate-50 group">
                  <td className="px-4 py-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                  <td className="p-0 border-r border-slate-50"><input value={row.name || ''} onChange={e => updateEquipmentRow(row.id, 'name', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="e.g. Earth Tester" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.make || ''} onChange={e => updateEquipmentRow(row.id, 'make', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Make" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.serial || ''} onChange={e => updateEquipmentRow(row.id, 'serial', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Serial" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.model || ''} onChange={e => updateEquipmentRow(row.id, 'model', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Model" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input type="date" value={row.calDate || ''} onChange={e => updateEquipmentRow(row.id, 'calDate', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input type="date" value={row.dueDate || ''} onChange={e => updateEquipmentRow(row.id, 'dueDate', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="text-center">
                      <button onClick={() => deleteRow('equipmentList', row.id)} className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><Trash2Icon /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {safeEquipmentList.length === 0 && (
            <div className="py-10 text-center text-slate-400 italic">No equipment listed for this audit.</div>
          )}
        </div>
      </section>

      {/* Table B: Grounding Resistance Measurements */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImportExcel} 
          accept=".xlsx,.xls" 
          className="hidden" 
        />
        <div className="bg-[#FB923C] px-6 py-3 text-white flex justify-between items-center">
          <div className="flex items-center gap-2">
            <ZapIcon />
            <h3 className="font-bold uppercase tracking-wider text-sm">Table: Grounding Resistance Measurements</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportExcel}
              className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[10px] font-bold uppercase transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3 h-3" /> Export Excel
            </button>
            {!readOnly && (
              <>
                {aiEnabled && (
                  <button
                    onClick={() => startLiveCapture(0)}
                    className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[10px] font-bold uppercase transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <Camera className="w-3 h-3" /> Live Capture
                  </button>
                )}
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[10px] font-bold uppercase transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Upload className="w-3 h-3" /> Import Excel
                </button>
                <button onClick={addEarthPit} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[10px] font-bold uppercase transition-colors">+ Add Earth Pit</button>
              </>
            )}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="bg-orange-50 text-orange-800 border-b border-orange-100 text-center">
                <th className="px-4 py-3 font-bold w-12 border-r border-orange-100">Sr.no</th>
                <th className="px-4 py-3 font-bold border-r border-orange-100 text-left">Earth pit names</th>
                <th className="px-4 py-3 font-bold border-r border-orange-100 text-left">Arrester Location</th>
                <th className="px-4 py-3 font-bold border-r border-orange-100 text-left">Conductor Size & Type</th>
                <th className="px-4 py-3 font-bold border-r border-orange-100">Grounding Value (Ω)</th>
                <th className="px-4 py-3 font-bold border-r border-orange-100">Accept Value (Ω)</th>
                <th className="px-4 py-3 font-bold border-r border-orange-100 text-left">Remarks</th>
                <th className="px-4 py-3 font-bold border-r border-orange-100">Result</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
{(safeLaReadings).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {safeLaReadings.map((row, idx) => (
                <tr key={row.id} className="hover:bg-slate-50 group">
                  <td className="px-4 py-3 text-center text-slate-400 font-mono border-r border-slate-50">{idx + 1}</td>
                  <td className="p-0 border-r border-slate-50"><input value={row.pitName || ''} onChange={e => updateReadingRow(row.id, 'pitName', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="EP No 35" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.location || ''} onChange={e => updateReadingRow(row.id, 'location', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Location" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.conductorType || ''} onChange={e => updateReadingRow(row.id, 'conductorType', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="e.g. 25*3 GI" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input type="number" step="0.01" value={row.groundingValue || ''} onChange={e => updateReadingRow(row.id, 'groundingValue', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 text-center font-bold" placeholder="0.00" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input type="number" step="0.01" value={row.acceptValue || ''} onChange={e => updateReadingRow(row.id, 'acceptValue', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 text-center text-slate-500" placeholder="10" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.remarks || ''} onChange={e => updateReadingRow(row.id, 'remarks', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Notes" disabled={readOnly} /></td>
                  <td className="px-4 py-3 text-center border-r border-slate-50">
                    <span className={`px-2 py-0.5 rounded font-black text-[9px] uppercase tracking-wider
                      ${row.result === 'Pass' ? 'bg-green-100 text-green-700' : 
                        row.result === 'Fail' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-400'}`}>
                      {row.result}
                    </span>
                  </td>
                  {!readOnly && (
                    <td className="text-center">
                      <button onClick={() => deleteRow('laReadings', row.id)} className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><Trash2Icon /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {safeLaReadings.length === 0 && (
            <div className="py-10 text-center text-slate-400 italic">No grounding measurements recorded.</div>
          )}
        </div>
      </section>

      {/* Observation Summary */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Test Observations</label>
          <textarea 
            value={data?.remarks || ''}
            onChange={e => updateField('remarks', e.target.value)}
            disabled={readOnly}
            placeholder="Describe overall health and observations..."
            className="w-full h-32 p-4 border border-slate-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none text-sm shadow-sm"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Professional Recommendations</label>
          <textarea 
            value={data?.recommendations || ''}
            onChange={e => updateField('recommendations', e.target.value)}
            disabled={readOnly}
            placeholder="Action items and improvements..."
            className="w-full h-32 p-4 border border-slate-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none text-sm shadow-sm"
          />
        </div>
      </section>

      {liveCapture && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-[#FB923C] px-6 py-4 rounded-t-2xl flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Live Capture</h3>
                <p className="text-orange-100 text-sm">
                  Reading Pit {liveCapture.pitIndex + 1} of {safeLaReadings.length}
                </p>
              </div>
              <button onClick={handleCancelCapture} className="text-white/80 hover:text-white text-2xl font-bold">×</button>
            </div>
            
            <div className="p-6 space-y-4">
              {liveCapture.phase === 'camera' && (
                <>
                  <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
                  <button onClick={capturePhoto} className="w-full py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2">
                    <Camera className="w-5 h-5" /> Capture Reading
                  </button>
                </>
              )}

              {liveCapture.phase === 'reading' && (
                <div className="flex flex-col items-center justify-center py-12 space-y-4">
                  <div className="w-12 h-12 border-4 border-orange-200 border-t-orange-600 rounded-full animate-spin"></div>
                  <p className="text-slate-600 font-medium">Extracting grounding value...</p>
                </div>
              )}

              {liveCapture.phase === 'review' && (
                <div className="space-y-6">
                  {liveCapture.error && (
                    <div className="p-4 bg-red-50 text-red-700 rounded-lg text-sm border border-red-100">
                      {liveCapture.error}
                    </div>
                  )}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Grounding Value (Ω)</label>
                      <input
                        type="text"
                        value={liveCapture.readValue}
                        onChange={e => setLiveCapture({ ...liveCapture, readValue: e.target.value })}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-lg text-slate-800"
                        placeholder="Enter Ω value..."
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <button onClick={() => startLiveCapture(liveCapture.pitIndex)} className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors">
                      Retry
                    </button>
                    <button onClick={confirmCaptureValue} className="flex-1 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl transition-colors">
                      Confirm & Next
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export const INITIAL_LA_DATA: LightningArrestorReading = {
  preparedBy: '',
  testedBy: '',
  testerEmail: '',
  witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  equipmentList: [],
  laReadings: [],
  remarks: '',
  recommendations: '',
  status: 'PENDING'
};
