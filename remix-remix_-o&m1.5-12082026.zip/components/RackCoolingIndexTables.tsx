import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  RackCoolingIndexReading, 
  RCICacGroup, 
  RCITemperatureRow,
  ObservationRecommendationRow,
  RCIAuditToolRow,
  LiveCaptureConfig
} from '../types';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { FileSpreadsheet, Upload, Camera, RefreshCw, Check, X, AlertCircle } from 'lucide-react';
import { exportRCICACToExcel } from '../utils/excelExport';
import { parseRCICACExcel } from '../utils/excelImport';
import { readRciDisplay } from '../services/geminiClient';

export interface RackCoolingIndexTablesProps {
  data: RackCoolingIndexReading;
  onChange: (data: RackCoolingIndexReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

// --- Icons ---
const TrashIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 hover:text-red-500 transition-colors"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

const PlusIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
);

const ThermostatIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z"/></svg>
);

const DuplicateIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 hover:text-blue-500 transition-colors"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
);

// --- Portfolio Calculations ---
const n = (v: string) => parseFloat(v) || 0;

const getAvgTemp = (v1: string, v2: string, v3: string) => {
  const vals = [v1, v2, v3].filter(v => v.trim() !== "" && !isNaN(parseFloat(v)));
  if (vals.length === 0) return "";
  const numericVals = vals.map(v => parseFloat(v));
  return (numericVals.reduce((a, b) => a + b, 0) / numericVals.length).toFixed(2);
};

const CAPTURE_STEPS = [
  {
    stepIndex: 0,
    title: 'Front End Temp — 15U',
    location: 'Front 15U',
    isGrouped: false,
    tempKey: 'front15U' as keyof RCITemperatureRow,
    rhKey: null,
    guidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text.'
  },
  {
    stepIndex: 1,
    title: 'Front End Temp & RH% — 22U',
    location: 'Front 22U',
    isGrouped: true,
    tempKey: 'front22U' as keyof RCITemperatureRow,
    rhKey: 'rhFront' as keyof RCITemperatureRow,
    guidance: 'Read BOTH the temperature value and relative humidity (%RH) value shown on the FLUKE 971 display. Preserve decimals. Ignore dew point, min/max/hold annunciators, battery icon, and mode/range text.'
  },
  {
    stepIndex: 2,
    title: 'Front End Temp — 35U',
    location: 'Front 35U',
    isGrouped: false,
    tempKey: 'front35U' as keyof RCITemperatureRow,
    rhKey: null,
    guidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text.'
  },
  {
    stepIndex: 3,
    title: 'Rear End Temp — 15U',
    location: 'Rear 15U',
    isGrouped: false,
    tempKey: 'rear15U' as keyof RCITemperatureRow,
    rhKey: null,
    guidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text.'
  },
  {
    stepIndex: 4,
    title: 'Rear End Temp & RH% — 22U',
    location: 'Rear 22U',
    isGrouped: true,
    tempKey: 'rear22U' as keyof RCITemperatureRow,
    rhKey: 'rhRear' as keyof RCITemperatureRow,
    guidance: 'Read BOTH the temperature value and relative humidity (%RH) value shown on the FLUKE 971 display. Preserve decimals. Ignore dew point, min/max/hold annunciators, battery icon, and mode/range text.'
  },
  {
    stepIndex: 5,
    title: 'Rear End Temp — 35U',
    location: 'Rear 35U',
    isGrouped: false,
    tempKey: 'rear35U' as keyof RCITemperatureRow,
    rhKey: null,
    guidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text.'
  }
];

// --- Portfolio View Components ---
interface PortfolioProps {
  currentCac: RCICacGroup;
  canEdit: boolean;
  readOnly: boolean;
  updateCurrentCac: (updates: Partial<RCICacGroup>) => void;
  confirmDelete: (options: { message: string; onConfirm: () => void; title?: string }) => void;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

const TemperaturePortfolio: React.FC<PortfolioProps> = ({ 
  currentCac, 
  canEdit, 
  readOnly, 
  updateCurrentCac, 
  confirmDelete,
  aiEnabled = true,
  liveCaptureConfig
}) => {
  const rows = currentCac?.temperatureRows || [];
  const isLiveCaptureAllowed = aiEnabled !== false;

  const [liveCapture, setLiveCapture] = useState<{
    active: boolean;
    rowIndex: number;
    stepIndex: number;
    phase: 'camera' | 'reading' | 'review';
    readValues: { temp: string; rh: string };
    error: string;
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera error:', err);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        error: 'Camera not available or access denied. Enter values manually below.'
      } : null);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (liveCapture?.active && liveCapture?.phase === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [liveCapture?.active, liveCapture?.phase, liveCapture?.rowIndex, liveCapture?.stepIndex]);

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    let width = video.videoWidth || 640;
    let height = video.videoHeight || 480;
    const MAX_DIM = 1280;

    if (width > MAX_DIM || height > MAX_DIM) {
      if (width > height) {
        height = Math.round((height * MAX_DIM) / width);
        width = MAX_DIM;
      } else {
        width = Math.round((width * MAX_DIM) / height);
        height = MAX_DIM;
      }
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    const currentStep = CAPTURE_STEPS[liveCapture.stepIndex];

    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);

    try {
      const res = await readRciDisplay(base64, currentStep.isGrouped, currentStep.guidance);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        readValues: { temp: res.temp || '', rh: res.rh || '' },
        error: ''
      } : null);
    } catch (err: any) {
      console.error('RCI Live Capture Error:', err);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        readValues: { temp: '', rh: '' },
        error: `Optical extraction failed (${err?.message || 'Unknown error'}). Please enter values manually.`
      } : null);
    }
  };

  const createNewRow = (sNo: string): RCITemperatureRow => ({
    id: `t-${Date.now()}-${Math.random()}`,
    sNo,
    cacRef: currentCac.cacName,
    rackRef: '',
    front15U: '',
    front22U: '',
    front35U: '',
    rear15U: '',
    rear22U: '',
    rear35U: '',
    rhFront: '',
    rhRear: '',
    inletTempResult: '',
    excessInletTemp: '',
    deficitInletTemp: ''
  });

  const updateRowWithCalculations = (rowId: string, updates: Partial<RCITemperatureRow>) => {
    const updatedRows = rows.map(r => {
      if (r.id !== rowId) return r;
      const newR = { ...r, ...updates };

      const avgF = getAvgTemp(newR.front15U, newR.front22U, newR.front35U);
      const avgR = getAvgTemp(newR.rear15U, newR.rear22U, newR.rear35U);
      const avgFVal = avgF !== "" ? parseFloat(avgF) : null;

      let inletResult = "";
      let excessInletTempCalc = "";
      let deficitInletTempCalc = "";

      if (avgFVal !== null) {
        if (avgFVal >= 18 && avgFVal <= 27) {
          inletResult = "PASS";
        } else if (avgFVal < 18) {
          inletResult = "FAIL";
          deficitInletTempCalc = (18 - avgFVal).toFixed(2);
        } else if (avgFVal > 27) {
          inletResult = "FAIL";
          excessInletTempCalc = (avgFVal - 27).toFixed(2);
        }
      }

      return {
        ...newR,
        inletTempResult: inletResult,
        excessInletTemp: excessInletTempCalc,
        deficitInletTemp: deficitInletTempCalc
      };
    });

    updateCurrentCac({ temperatureRows: updatedRows });
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const { rowIndex, stepIndex, readValues } = liveCapture;
    const step = CAPTURE_STEPS[stepIndex];
    const targetRow = rows[rowIndex];

    if (targetRow) {
      const updates: Partial<RCITemperatureRow> = {};
      if (step.tempKey) updates[step.tempKey] = readValues.temp;
      if (step.rhKey) updates[step.rhKey] = readValues.rh;

      updateRowWithCalculations(targetRow.id, updates);
    }

    if (stepIndex < CAPTURE_STEPS.length - 1) {
      setLiveCapture(prev => prev ? {
        ...prev,
        stepIndex: stepIndex + 1,
        phase: 'camera',
        readValues: { temp: '', rh: '' },
        error: ''
      } : null);
    } else {
      const nextRowIdx = rowIndex + 1;
      if (nextRowIdx < rows.length) {
        setLiveCapture(prev => prev ? {
          ...prev,
          rowIndex: nextRowIdx,
          stepIndex: 0,
          phase: 'camera',
          readValues: { temp: '', rh: '' },
          error: ''
        } : null);
      } else {
        stopCamera();
        setLiveCapture(null);
      }
    }
  };

  const openLiveCapture = (startRowIndex: number = 0) => {
    let currentRows = rows;
    if (currentRows.length === 0) {
      const initialRow = createNewRow('1');
      currentRows = [initialRow];
      updateCurrentCac({ temperatureRows: currentRows });
    }

    let targetIdx = startRowIndex;
    if (targetIdx < 0 || targetIdx >= currentRows.length) targetIdx = 0;

    setLiveCapture({
      active: true,
      rowIndex: targetIdx,
      stepIndex: 0,
      phase: 'camera',
      readValues: { temp: '', rh: '' },
      error: ''
    });
  };

  const closeLiveCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const addRow = () => {
    const newRow = createNewRow((rows.length + 1).toString());
    const updatedRows = [...rows, newRow];
    updateCurrentCac({ temperatureRows: updatedRows });
  };

  const insertRowAbove = (index: number) => {
    const newRow = createNewRow('');
    const updatedRows = [...rows];
    updatedRows.splice(index, 0, newRow);
    updateCurrentCac({ temperatureRows: updatedRows });
  };

  const insertRowBelow = (index: number) => {
    const newRow = createNewRow('');
    const updatedRows = [...rows];
    updatedRows.splice(index + 1, 0, newRow);
    updateCurrentCac({ temperatureRows: updatedRows });
  };

  const updateRow = (id: string, f: keyof RCITemperatureRow, v: string) => {
    updateRowWithCalculations(id, { [f]: v });
  };
  
  const deleteRow = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this temperature measurement row?",
      onConfirm: () => {
        const filtered = rows.filter(r => r.id !== id);
        updateCurrentCac({ temperatureRows: filtered });
      }
    });
  };

  const duplicateRowAt = (index: number, row: RCITemperatureRow) => {
    const newRow = { 
      ...row, 
      id: `t-${Date.now()}-${Math.random()}`,
      sNo: '' 
    };
    const updatedRows = [...rows];
    updatedRows.splice(index + 1, 0, newRow);
    updateCurrentCac({ temperatureRows: updatedRows });
  };

  const handleImportExcel = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const result = parseRCICACExcel(evt.target?.result);
        if (result && result.length > 0) {
          updateCurrentCac({ temperatureRows: result });
        } else {
          alert("Could not parse file. Ensure headers match the original export template.");
        }
      };
      reader.readAsBinaryString(file);
    };
    input.click();
  };

  return (
    <div className="bg-white rounded-xl border border-blue-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
      <canvas ref={canvasRef} className="hidden" />

      {/* Live Capture Modal */}
      {liveCapture?.active && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-xl w-full text-white overflow-hidden shadow-2xl my-8">
            {/* Modal Header */}
            <div className="bg-slate-800/80 px-6 py-4 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-violet-600/30 text-violet-400 rounded-xl border border-violet-500/30">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-sm uppercase tracking-wider text-white">
                    Fluke 971 Live Capture
                  </h3>
                  <p className="text-xs text-slate-400 font-medium">
                    {currentCac.cacName || 'CAC'} &bull; {rows[liveCapture.rowIndex]?.rackRef ? `Rack ${rows[liveCapture.rowIndex].rackRef}` : `Row ${liveCapture.rowIndex + 1} of ${rows.length}`}
                  </p>
                </div>
              </div>
              <button
                onClick={closeLiveCapture}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-xl transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Progress Bar */}
            <div className="px-6 py-3 bg-slate-800/40 border-b border-slate-700/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-violet-400">
                  Step {liveCapture.stepIndex + 1} of {CAPTURE_STEPS.length}: {CAPTURE_STEPS[liveCapture.stepIndex].title}
                </span>
                <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  Rack {liveCapture.rowIndex + 1} / {rows.length}
                </span>
              </div>
              <div className="grid grid-cols-6 gap-1.5">
                {CAPTURE_STEPS.map((s, idx) => {
                  const isDone = idx < liveCapture.stepIndex;
                  const isCurrent = idx === liveCapture.stepIndex;
                  return (
                    <button
                      key={idx}
                      onClick={() => setLiveCapture(prev => prev ? { ...prev, stepIndex: idx, phase: 'camera', readValues: { temp: '', rh: '' }, error: '' } : null)}
                      className={`h-2 rounded-full transition-all ${
                        isCurrent
                          ? 'bg-violet-500 ring-2 ring-violet-400/50 scale-105'
                          : isDone
                          ? 'bg-emerald-500'
                          : 'bg-slate-700'
                      }`}
                      title={s.title}
                    />
                  );
                })}
              </div>
            </div>

            {/* Main Content */}
            <div className="p-6 space-y-5">
              {liveCapture.error && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{liveCapture.error}</span>
                </div>
              )}

              {/* Phase 1: Camera Feed */}
              {liveCapture.phase === 'camera' && (
                <div className="space-y-4">
                  <div className="relative rounded-2xl overflow-hidden bg-black aspect-video border border-slate-700 shadow-inner flex items-center justify-center">
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover"
                      playsInline
                      muted
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 text-center">
                      <p className="text-xs font-semibold text-white/90">
                        Point camera at FLUKE 971 display for <span className="text-violet-300 font-bold">{CAPTURE_STEPS[liveCapture.stepIndex].location}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={capturePhoto}
                      className="flex-1 py-3 px-4 bg-violet-600 hover:bg-violet-500 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm"
                    >
                      <Camera className="w-4 h-4" /> Capture Reading
                    </button>
                    <button
                      onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'review' } : null)}
                      className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl border border-slate-700 transition-all text-xs"
                    >
                      Manual Entry
                    </button>
                  </div>
                </div>
              )}

              {/* Phase 2: Processing AI */}
              {liveCapture.phase === 'reading' && (
                <div className="py-12 flex flex-col items-center justify-center space-y-4 text-center">
                  <RefreshCw className="w-10 h-10 text-violet-400 animate-spin" />
                  <div>
                    <p className="font-bold text-sm text-white">Extracting Readings via Gemini AI...</p>
                    <p className="text-xs text-slate-400 mt-1">Reading FLUKE 971 display for {CAPTURE_STEPS[liveCapture.stepIndex].location}</p>
                  </div>
                </div>
              )}

              {/* Phase 3: Review & Manual Edit */}
              {liveCapture.phase === 'review' && (
                <div className="space-y-5">
                  <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                        Target Point: {CAPTURE_STEPS[liveCapture.stepIndex].title}
                      </span>
                      <button
                        onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'camera', error: '' } : null)}
                        className="text-xs text-violet-400 hover:text-violet-300 font-semibold flex items-center gap-1"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> Retake Photo
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Temperature Input */}
                      <div>
                        <label className="block text-xs font-bold text-slate-400 mb-1">
                          Temperature (°C / °F)
                        </label>
                        <input
                          type="text"
                          value={liveCapture.readValues.temp}
                          onChange={e => setLiveCapture(prev => prev ? { ...prev, readValues: { ...prev.readValues, temp: e.target.value } } : null)}
                          placeholder="e.g. 23.5"
                          className="w-full bg-slate-900 border-2 border-violet-500/50 focus:border-violet-400 rounded-xl px-4 py-3 text-white text-lg font-mono font-bold outline-none transition-all"
                        />
                      </div>

                      {/* Relative Humidity Input (only for 22U grouped steps) */}
                      {CAPTURE_STEPS[liveCapture.stepIndex].isGrouped && (
                        <div>
                          <label className="block text-xs font-bold text-slate-400 mb-1">
                            Relative Humidity (RH %)
                          </label>
                          <input
                            type="text"
                            value={liveCapture.readValues.rh}
                            onChange={e => setLiveCapture(prev => prev ? { ...prev, readValues: { ...prev.readValues, rh: e.target.value } } : null)}
                            placeholder="e.g. 48.2"
                            className="w-full bg-slate-900 border-2 border-emerald-500/50 focus:border-emerald-400 rounded-xl px-4 py-3 text-white text-lg font-mono font-bold outline-none transition-all"
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={handleConfirmReading}
                      className="flex-1 py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm"
                    >
                      <Check className="w-4 h-4" />
                      {liveCapture.stepIndex < CAPTURE_STEPS.length - 1
                        ? 'Confirm & Next Step'
                        : liveCapture.rowIndex < rows.length - 1
                        ? 'Confirm & Next Rack'
                        : 'Confirm & Complete'}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer (Current Rack Readings Progress) */}
            {rows[liveCapture.rowIndex] && (
              <div className="px-6 py-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>Front: {rows[liveCapture.rowIndex].front15U || '-'}/{rows[liveCapture.rowIndex].front22U || '-'}/{rows[liveCapture.rowIndex].front35U || '-'} (RH: {rows[liveCapture.rowIndex].rhFront || '-'})</span>
                <span>Rear: {rows[liveCapture.rowIndex].rear15U || '-'}/{rows[liveCapture.rowIndex].rear22U || '-'}/{rows[liveCapture.rowIndex].rear35U || '-'} (RH: {rows[liveCapture.rowIndex].rhRear || '-'})</span>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="bg-[#EFF6FF] px-6 py-4 border-b border-blue-100 flex justify-between items-center">
         <div className="flex items-center gap-2">
            <ThermostatIcon />
            <h3 className="font-black text-blue-800 text-xs uppercase tracking-widest">Temperature Measurement Portfolio</h3>
         </div>
         <div className="flex items-center gap-2">
           {canEdit && isLiveCaptureAllowed && (
             <button
               onClick={() => openLiveCapture(0)}
               className="px-3 py-1 bg-violet-600 text-white rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1 shadow-sm hover:bg-violet-700 transition-all"
               title="Live Camera Capture with Fluke 971"
             >
               <Camera className="w-3.5 h-3.5" /> Live Capture
             </button>
           )}
           <button
             onClick={() => exportRCICACToExcel(currentCac, `${currentCac.cacName || 'CAC'}_Temperature_Study_${new Date().toISOString().split('T')[0]}.xlsx`)}
             className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1 shadow-sm hover:bg-emerald-700 transition-all"
           >
             <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
           </button>
           {canEdit && (
             <>
               <button
                 onClick={handleImportExcel}
                 className="px-3 py-1 bg-indigo-600 text-white rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1 shadow-sm hover:bg-indigo-700 transition-all"
               >
                 <Upload className="w-3.5 h-3.5" /> Import Excel
               </button>
               <button 
                onClick={addRow} 
                className="px-3 py-1 bg-blue-600 text-white rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1 shadow-sm hover:bg-blue-700 transition-all"
               >
                 <PlusIcon /> Add Row
               </button>
             </>
           )}
         </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-center text-[10px] border-collapse table-auto">
          <thead>
            <tr className="bg-blue-200 text-blue-900 font-black uppercase">
              <th colSpan={18} className="py-2 border-b border-blue-300 whitespace-nowrap">
                {canEdit ? (
                  <input
                    value={currentCac.cacName}
                    onChange={(e) => updateCurrentCac({ cacName: e.target.value })}
                    className="bg-transparent text-center outline-none border-b border-transparent hover:border-blue-400 focus:border-blue-600 transition-colors placeholder-blue-400"
                    placeholder="Enter CAC Unit Name"
                  />
                ) : (
                  currentCac.cacName
                )}
              </th>
            </tr>
            <tr className="bg-blue-600 text-white font-black uppercase divide-x divide-white/10">
              <th rowSpan={2} className="py-4 px-2 w-12 border-b border-white/10 whitespace-nowrap">S.No</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 whitespace-nowrap">CAC Ref</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 whitespace-nowrap">Rack Reference</th>
              <th colSpan={3} className="py-2 border-b border-white/10 whitespace-nowrap">Front End Temp (F or C)</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 bg-blue-700 whitespace-nowrap">Avg Temp</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 whitespace-nowrap">RH %</th>
              <th colSpan={3} className="py-2 border-b border-white/10 whitespace-nowrap">Rear End Temp (F or C)</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 bg-blue-700 whitespace-nowrap">Avg Temp</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 whitespace-nowrap">RH %</th>
              <th rowSpan={2} className="py-4 px-2 w-16 border-b border-white/10 whitespace-nowrap">Delta T (F or C)</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 whitespace-nowrap">Inlet Temp Result (18-27)</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 whitespace-nowrap">Excess Inlet Temp</th>
              <th rowSpan={2} className="py-4 px-2 border-b border-white/10 whitespace-nowrap">Deficit Inlet Temp</th>
              {canEdit && <th rowSpan={2} className="w-28 border-b border-white/10 whitespace-nowrap">Actions</th>}
            </tr>
            <tr className="bg-blue-500 text-white/90 font-bold uppercase text-[9px] divide-x divide-white/10">
              <th className="py-1.5 whitespace-nowrap">15U</th><th className="py-1.5 whitespace-nowrap">22U</th><th className="py-1.5 whitespace-nowrap">35U</th>
              <th className="py-1.5 whitespace-nowrap">15U</th><th className="py-1.5 whitespace-nowrap">22U</th><th className="py-1.5 whitespace-nowrap">35U</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-blue-50">
            {rows.map((row, idx) => {
              const avgF = getAvgTemp(row.front15U, row.front22U, row.front35U);
              const avgR = getAvgTemp(row.rear15U, row.rear22U, row.rear35U);
              const delta = (avgF !== "" && avgR !== "") ? Math.abs(parseFloat(avgR) - parseFloat(avgF)).toFixed(2) : "";
              
              let inletResult = "";
              let inletColorClass = "bg-blue-900 text-white";
              const avgFVal = avgF !== "" ? parseFloat(avgF) : null;
              
              let excessInletTempCalc = "";
              let deficitInletTempCalc = "";

              if (avgFVal !== null) {
                if (avgFVal >= 18 && avgFVal <= 27) {
                  inletResult = "PASS";
                  inletColorClass = "bg-green-500 text-white";
                } else if (avgFVal < 18) {
                  inletResult = "FAIL";
                  inletColorClass = "bg-orange-500 text-white";
                  deficitInletTempCalc = (18 - avgFVal).toFixed(2);
                } else if (avgFVal > 27) {
                  inletResult = "FAIL";
                  inletColorClass = "bg-red-600 text-white";
                  excessInletTempCalc = (avgFVal - 27).toFixed(2);
                }
              }

              return (
                <tr key={row.id} className="hover:bg-blue-50 transition-colors divide-x divide-blue-50">
                  <td className="p-0 font-bold text-slate-400">
                    <input 
                      value={row.sNo || (idx + 1).toString()} 
                      onChange={e => updateRow(row.id, 'sNo', e.target.value)} 
                      disabled={readOnly} 
                      className="w-full h-full p-3 bg-transparent text-center outline-none" 
                    />
                  </td>
                  <td className="p-0"><input value={row.cacRef} onChange={e => updateRow(row.id, 'cacRef', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" /></td>
                  <td className="p-0 font-bold"><input value={row.rackRef} onChange={e => updateRow(row.id, 'rackRef', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" /></td>
                  <td className="p-0"><input value={row.front15U} onChange={e => updateRow(row.id, 'front15U', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0.0" /></td>
                  <td className="p-0"><input value={row.front22U} onChange={e => updateRow(row.id, 'front22U', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0.0" /></td>
                  <td className="p-0"><input value={row.front35U} onChange={e => updateRow(row.id, 'front35U', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0.0" /></td>
                  <td className="py-3 bg-blue-50 font-black text-blue-700">{avgF || "-"}</td>
                  <td className="p-0"><input value={row.rhFront} onChange={e => updateRow(row.id, 'rhFront', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0%" /></td>
                  <td className="p-0"><input value={row.rear15U} onChange={e => updateRow(row.id, 'rear15U', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0.0" /></td>
                  <td className="p-0"><input value={row.rear22U} onChange={e => updateRow(row.id, 'rear22U', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0.0" /></td>
                  <td className="p-0"><input value={row.rear35U} onChange={e => updateRow(row.id, 'rear35U', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0.0" /></td>
                  <td className="py-3 bg-blue-50 font-black text-blue-700">{avgR || "-"}</td>
                  <td className="p-0"><input value={row.rhRear} onChange={e => updateRow(row.id, 'rhRear', e.target.value)} disabled={readOnly} className="w-full h-full p-3 bg-transparent text-center outline-none" placeholder="0%" /></td>
                  <td className={`py-3 font-black ${
                    delta === "" ? "bg-blue-900 text-white" : 
                    parseFloat(delta) < 5 ? "bg-yellow-400 text-black" : 
                    parseFloat(delta) > 15 ? "bg-red-600 text-white" : 
                    "bg-blue-900 text-white"
                  }`}>{delta || "-"}</td>
                  <td className={`py-3 font-black ${inletColorClass}`}>{inletResult || "-"}</td>
                  <td className={`py-3 font-black ${excessInletTempCalc ? 'bg-red-50 text-red-600' : 'text-slate-400'}`}>{excessInletTempCalc || "-"}</td>
                  <td className={`py-3 font-black ${deficitInletTempCalc ? 'bg-orange-50 text-orange-600' : 'text-slate-400'}`}>{deficitInletTempCalc || "-"}</td>
                  {canEdit && (
                    <td className="p-0">
                      <div className="flex items-center justify-center gap-1 px-1">
                        {isLiveCaptureAllowed && (
                          <button
                            onClick={() => openLiveCapture(idx)}
                            className="p-1 text-slate-400 hover:text-violet-600 hover:bg-violet-50 rounded transition-all"
                            title="Live Capture for this Rack"
                          >
                            <Camera className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button 
                          onClick={() => insertRowAbove(idx)} 
                          className="p-1 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-all" 
                          title="Insert Row Above"
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="18 15 12 9 6 15" />
                            <line x1="12" y1="9" x2="12" y2="21" />
                            <path d="M5 3h14" />
                          </svg>
                        </button>
                        <button 
                          onClick={() => insertRowBelow(idx)} 
                          className="p-1 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-all" 
                          title="Insert Row Below"
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="6 9 12 15 18 9" />
                            <line x1="12" y1="15" x2="12" y2="3" />
                            <path d="M5 21h14" />
                          </svg>
                        </button>
                        <button onClick={() => duplicateRowAt(idx, row)} className="p-1" title="Duplicate Row"><DuplicateIcon /></button>
                        <button onClick={() => deleteRow(row.id)} className="p-1" title="Delete Row"><TrashIcon /></button>
                      </div>
                    </td>
                  )}
                </tr>
              );
            })}
            {rows.length === 0 && (
              <tr><td colSpan={18} className="py-12 text-slate-300 font-bold uppercase tracking-widest text-[10px] italic text-center">No temperature data recorded for this CAC.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const RackCoolingIndexTables: React.FC<RackCoolingIndexTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = true,
  liveCaptureConfig
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();
  const [activeCacIndex, setActiveCacIndex] = useState<number>(0);
  const [showAddUnitModal, setShowAddUnitModal] = useState(false);
  const [customCacName, setCustomCacName] = useState('');
  const [cacPrefix, setCacPrefix] = useState('CAC');

  const canEdit = !readOnly;
  const currentGroups = data.dc1Groups || [];
  const currentCac = currentGroups[activeCacIndex];

  // --- State Updates ---
  const updateGroups = (newGroups: RCICacGroup[]) => {
    if (!canEdit) return;
    onChange({
      ...data,
      dc1Groups: newGroups
    });
  };

  const updateCurrentCac = (updates: Partial<RCICacGroup>) => {
    const newGroups = [...currentGroups];
    newGroups[activeCacIndex] = { ...newGroups[activeCacIndex], ...updates };
    updateGroups(newGroups);
  };

  const handleAddCac = (name: string) => {
    if (!name.trim()) return;
    const isExisting = currentGroups.some(g => g.cacName.toLowerCase() === name.trim().toLowerCase());
    if (isExisting) {
      alert(`Unit "${name}" already exists.`);
      return;
    }

    const newCac: RCICacGroup = {
      id: `cac-${Date.now()}`,
      cacName: name.trim(),
      temperatureRows: []
    };
    updateGroups([...currentGroups, newCac]);
    setActiveCacIndex(currentGroups.length);
    setShowAddUnitModal(false);
    setCustomCacName('');
  };

  const handleRemoveCac = () => {
    if (!currentCac || !canEdit) return;
    
    confirmDelete({
      message: `Are you sure you want to remove ${currentCac.cacName} and all associated measurement data?`,
      onConfirm: () => {
        const newGroups = currentGroups.filter((_, i) => i !== activeCacIndex);
        updateGroups(newGroups);
        setActiveCacIndex(0);
      }
    });
  };

  const handleMoveUp = () => {
    if (activeCacIndex > 0) {
      const newGroups = [...currentGroups];
      [newGroups[activeCacIndex - 1], newGroups[activeCacIndex]] = [newGroups[activeCacIndex], newGroups[activeCacIndex - 1]];
      updateGroups(newGroups);
      setActiveCacIndex(activeCacIndex - 1);
    }
  };

  const handleMoveDown = () => {
    if (activeCacIndex < currentGroups.length - 1) {
      const newGroups = [...currentGroups];
      [newGroups[activeCacIndex + 1], newGroups[activeCacIndex]] = [newGroups[activeCacIndex], newGroups[activeCacIndex + 1]];
      updateGroups(newGroups);
      setActiveCacIndex(activeCacIndex + 1);
    }
  };

  return (
    <div className="space-y-10 animate-fade-in pb-20 font-sans">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* 1. Personnel Header (Orange Theme) */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white text-xs font-black uppercase tracking-widest text-center">Personnel & Execution Metadata</div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">{f.replace(/([A-Z])/g, ' $1')}</label>
               <input 
                 type={f === 'testDate' ? 'date' : 'text'}
                 value={(data as any)[f] || ''} 
                 onChange={e => !readOnly && onChange({ ...data, [f]: e.target.value })}
                 disabled={readOnly}
                 className="w-full text-xs font-bold p-2 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-orange-50 outline-none transition-all"
               />
            </div>
          ))}
        </div>
      </section>

      {/* 1.5 Tools used for audit */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
        <div className="bg-[#475569] px-6 py-3 text-white text-xs font-black uppercase tracking-widest text-center">
          🧰 Tools used for audit
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Calibration Date</label>
            <input 
              type="date"
              value={data.toolCalibrationDate || ''} 
              onChange={e => !readOnly && onChange({ ...data, toolCalibrationDate: e.target.value })}
              disabled={readOnly}
              className="w-full text-xs font-bold p-2 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-slate-100 outline-none transition-all cursor-pointer"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Expiry Date</label>
            <input 
              type="date"
              value={data.toolExpiryDate || ''} 
              onChange={e => !readOnly && onChange({ ...data, toolExpiryDate: e.target.value })}
              disabled={readOnly}
              className="w-full text-xs font-bold p-2 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-slate-100 outline-none transition-all cursor-pointer"
            />
          </div>
        </div>
      </section>

      {/* 2. DC & CAC Unit Management */}
      <div className="space-y-6">
        {/* DC TABS */}
        <div className="flex gap-4">
           <div 
            className="flex-1 py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-lg border-b-8 bg-[#B71C1C] text-white border-red-900 text-center"
           >
            DC-1 Infrastructure
           </div>
        </div>

        {/* CAC Unit Selection Bar */}
        <div className="p-4 rounded-2xl flex items-center justify-between shadow-xl animate-fade-in bg-[#B71C1C]">
           <div className="flex items-center gap-6">
              <div className="flex flex-col">
                <span className="text-[10px] font-black text-white/50 uppercase tracking-[0.3em]">Active Group</span>
                <div className="flex items-center gap-3">
                  <span className="text-3xl text-white">❄️</span>
                  {currentGroups.length > 0 ? (
                    <div className="flex flex-col gap-1">
                      <select 
                        value={activeCacIndex}
                        onChange={(e) => setActiveCacIndex(parseInt(e.target.value))}
                        className="bg-white/10 border border-white/20 rounded-xl px-4 py-2 font-black text-xl text-white outline-none focus:ring-4 focus:ring-white/10 cursor-pointer"
                      >
                        {currentGroups.map((group, idx) => (
                          <option key={group.id} value={idx} className="text-slate-800">{group.cacName}</option>
                        ))}
                      </select>
                      {canEdit && currentCac && (
                         <input
                           type="text"
                           value={currentCac.cacName}
                           onChange={(e) => updateCurrentCac({ cacName: e.target.value })}
                           placeholder="Rename Unit..."
                           title="Rename Unit"
                           className="bg-black/20 text-white placeholder:text-white/50 border border-transparent hover:border-white/30 focus:border-white/50 rounded px-2 py-1 text-xs outline-none transition-all"
                         />
                       )}
                    </div>
                  ) : (
                    <span className="text-white/40 font-bold italic">No Units Registered</span>
                  )}
                </div>
              </div>
              
              {currentCac && canEdit && (
                <div className="flex gap-2">
                  <button 
                    onClick={handleMoveUp} 
                    disabled={activeCacIndex === 0}
                    className={`px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${activeCacIndex === 0 ? 'bg-white/5 text-white/30 border-white/10 cursor-not-allowed' : 'bg-white/10 text-white hover:bg-white/20 border-white/20'}`}
                    title="Move Unit Up (Left)"
                  >
                    ↑
                  </button>
                  <button 
                    onClick={handleMoveDown} 
                    disabled={activeCacIndex === currentGroups.length - 1}
                    className={`px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${activeCacIndex === currentGroups.length - 1 ? 'bg-white/5 text-white/30 border-white/10 cursor-not-allowed' : 'bg-white/10 text-white hover:bg-white/20 border-white/20'}`}
                    title="Move Unit Down (Right)"
                  >
                    ↓
                  </button>
                  <button onClick={handleRemoveCac} className="px-4 py-2 bg-red-900/40 text-red-100 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500 transition-all border border-red-800 ml-4">
                    Delete {currentCac.cacName}
                  </button>
                </div>
              )}
           </div>

           <div className="relative">
              {canEdit && (
                <button 
                  onClick={() => setShowAddUnitModal(!showAddUnitModal)}
                  className="px-8 py-3 bg-white text-slate-800 rounded-xl font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3"
                >
                  <PlusIcon /> Add Unit
                </button>
              )}

              {showAddUnitModal && (
                <div className="absolute right-0 mt-4 w-72 bg-white rounded-[2rem] shadow-2xl z-[100] border border-slate-100 overflow-hidden animate-bounce-in origin-top-right">
                  <div className="bg-slate-900 p-6 text-white text-center">
                    <h4 className="font-black text-xs uppercase tracking-widest">Add New CAC Unit</h4>
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Unit Name</label>
                      <input 
                        type="text"
                        placeholder="e.g. CAC-16"
                        value={customCacName}
                        onChange={e => setCustomCacName(e.target.value)}
                        className="w-full p-3 bg-slate-50 border-none rounded-xl text-xs font-bold focus:ring-2 focus:ring-blue-100 outline-none"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleAddCac(customCacName);
                          }
                        }}
                      />
                    </div>
                    <button 
                      onClick={() => handleAddCac(customCacName)}
                      className="w-full py-3 bg-blue-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-blue-700 transition-all"
                    >
                      Initialize Unit
                    </button>
                    
                    <div className="pt-4 border-t border-slate-50">
                       <div className="flex justify-between items-center mb-2">
                         <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter">Quick Select</p>
                         <div className="flex items-center gap-1">
                           <span className="text-[9px] text-slate-400 font-bold uppercase">Prefix:</span>
                           <input
                             type="text"
                             value={cacPrefix}
                             onChange={(e) => setCacPrefix(e.target.value)}
                             className="w-16 p-1 bg-slate-100 border-none rounded text-[9px] font-bold text-slate-700 outline-none text-center"
                             placeholder="e.g. CAC"
                           />
                         </div>
                       </div>
                       <div className="mt-2 grid grid-cols-5 gap-1 max-h-48 overflow-y-auto pr-1">
                          {Array.from({ length: 50 }).map((_, i) => {
                            const numStr = (i + 1).toString().padStart(2, '0');
                            const name = cacPrefix ? `${cacPrefix}-${numStr}` : numStr;
                            const isExisting = currentGroups.some(g => g.cacName === name);
                            return (
                              <button 
                                key={i}
                                disabled={isExisting}
                                onClick={() => handleAddCac(name)}
                                className={`p-1.5 rounded-lg text-[9px] font-black transition-all
                                  ${isExisting ? 'bg-slate-50 text-slate-200' : 'bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white'}`}
                              >
                                {i + 1}
                              </button>
                            );
                          })}
                       </div>
                    </div>
                  </div>
                </div>
              )}
           </div>
        </div>

          {/* Measurement Portfolios Grid */}
        {currentCac ? (
          <div className="space-y-10">
            <TemperaturePortfolio 
              currentCac={currentCac} 
              canEdit={canEdit} 
              readOnly={readOnly} 
              updateCurrentCac={updateCurrentCac}
              confirmDelete={confirmDelete}
              aiEnabled={aiEnabled}
              liveCaptureConfig={liveCaptureConfig}
            />
          </div>
        ) : (
          <div className="py-24 text-center border-4 border-dashed border-slate-100 rounded-[3rem] bg-slate-50/50 flex flex-col items-center gap-6">
             <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-4xl shadow-inner text-slate-200">📊</div>
             <div>
                <p className="text-slate-400 font-black uppercase tracking-[0.3em] text-sm">No Units Configured in DC-1</p>
                <p className="text-slate-300 text-xs mt-2 italic font-medium">Click "Add Unit" to initialize infrastructure measurement blocks.</p>
             </div>
          </div>
        )}
      </div>

      {/* Global RCI Calculation Context from all CACs combined */}
      {(() => {
        const allRows = currentGroups.flatMap(g => g.temperatureRows);
        let sumExcess = 0;
        let sumDeficit = 0;
        let countAbove27 = 0;
        let countBelow18 = 0;
        let countAbove15Delta = 0;
        let countBelow5Delta = 0;
        let activeMeasurements = 0;

        allRows.forEach(row => {
          const avgF = getAvgTemp(row.front15U, row.front22U, row.front35U);
          const avgR = getAvgTemp(row.rear15U, row.rear22U, row.rear35U);
          
          if (avgF !== "") {
            activeMeasurements++;
            const temp = parseFloat(avgF);
            if (temp > 27) {
              sumExcess += (temp - 27);
              countAbove27++;
            } else if (temp < 18) {
              sumDeficit += (18 - temp);
              countBelow18++;
            }
          }

          if (avgF !== "" && avgR !== "") {
            const delta = Math.abs(parseFloat(avgR) - parseFloat(avgF));
            if (delta > 15) {
              countAbove15Delta++;
            } else if (delta < 5) {
              countBelow5Delta++;
            }
          }
        });

        // RCI Formula where N is the total number of racks (neither high nor low but Total)
        const N = activeMeasurements || 1;
        
        let rciHi = (1 - (sumExcess / (N * 5))) * 100;
        let rciLo = (1 - (sumDeficit / (N * 3))) * 100;

        const overallRci = (rciHi + rciLo) / 2;

        const getRciRating = (val: number) => {
          if (val === 100) return "Excellent";
          if (val >= 96) return "Good";
          if (val >= 91) return "Fair";
          return "Poor";
        };

        const rciHiRating = getRciRating(rciHi);
        const rciLoRating = getRciRating(rciLo);
        const overallRciRating = getRciRating(overallRci);

        return activeMeasurements > 0 ? (
          <div className="space-y-6 pt-6 border-t-4 border-slate-100">
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-blue-100 text-blue-700 rounded-xl flex items-center justify-center text-xl shadow-inner">🌐</div>
                <div>
                   <h3 className="font-black text-slate-800 tracking-widest uppercase">Global RCI Assessment</h3>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Combined calculation across all {(currentGroups.length)} CAC Units</p>
                </div>
             </div>
             
            {/* Results Table 1 */}
            <div className="bg-white rounded-xl border border-blue-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
              <table className="w-full text-sm border-collapse text-left">
                <thead>
                  <tr className="bg-[#0f172a] text-white">
                    <th className="py-3 px-6 border-b border-slate-700 font-bold uppercase tracking-wider text-xs">Parameter</th>
                    <th className="py-3 px-6 border-b border-slate-700 font-bold uppercase tracking-wider text-xs w-48 text-center">Result</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black border-b border-black">
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">Total No. of Racks (N)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{activeMeasurements}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">Summation of excess temperature (T<sub>i</sub> − T<sub>r, Hi</sub>)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{sumExcess.toFixed(2)}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">No. of Racks above 27 deg C (N<sub>hi</sub>)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{countAbove27}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">Summation of deficit temperature (T<sub>r, Lo</sub> − T<sub>i</sub>)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{sumDeficit.toFixed(2)}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">No. of Racks below 18 deg C (N<sub>lo</sub>)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{countBelow18}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">No. of Racks above 15 deg C Delta T</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{countAbove15Delta}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">No. of Racks below 5 deg C Delta T</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{countBelow5Delta}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Results Table 2 */}
            <div className="bg-white rounded-xl border border-blue-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
              <table className="w-full text-sm border-collapse text-left">
                <thead>
                  <tr className="bg-[#0f172a] text-white">
                    <th className="py-3 px-6 border-b border-slate-700 font-bold uppercase tracking-wider text-xs">Parameter</th>
                    <th className="py-3 px-6 border-b border-slate-700 font-bold uppercase tracking-wider text-xs w-48 text-center">Result</th>
                    <th className="py-3 px-6 border-b border-slate-700 font-bold uppercase tracking-wider text-xs w-48 text-center">RCI Rating</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black border-b border-black">
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">RCI Hi — High Side (Over-Temperature)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{rciHi.toFixed(1)}%</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{rciHiRating}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">RCI Lo — Low Side (Under-Temperature)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{rciLo.toFixed(1)}%</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{rciLoRating}</td>
                  </tr>
                  <tr className="bg-[#bae6fd]">
                    <td className="py-3 px-6 text-slate-800 font-medium">Overall RCI ((RCI Hi + RCI Lo)/2)</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{overallRci.toFixed(1)}%</td>
                    <td className="py-3 px-6 text-center font-bold text-slate-900 border-l border-black">{overallRciRating}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : null;
      })()}

      {/* 3. Global Summary (Observations & Recommendations) */}
      <section className="bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl p-10 space-y-10 animate-fade-in-up">
         <div className="flex items-center gap-4 border-b border-slate-100 pb-6">
            <div className="w-12 h-12 bg-slate-50 text-[#B71C1C] rounded-2xl flex items-center justify-center text-2xl shadow-inner">📋</div>
            <div>
               <h3 className="font-black text-slate-800 tracking-widest uppercase">Professional Findings Summary</h3>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Global Overview for DC-1</p>
            </div>
         </div>
         
         <ObservationsRecommendationsTable 
           data={data.observationsAndRecommendations || []}
           onChange={(val) => !readOnly && onChange({ ...data, observationsAndRecommendations: val })}
           readOnly={readOnly}
         />
      </section>

    </div>
  );
};

export const INITIAL_RCI_DATA: RackCoolingIndexReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  toolCalibrationDate: '',
  toolExpiryDate: '',
  status: 'PENDING',
  equipmentList: [],
  dc1Groups: [],
  observationsAndRecommendations: []
};
