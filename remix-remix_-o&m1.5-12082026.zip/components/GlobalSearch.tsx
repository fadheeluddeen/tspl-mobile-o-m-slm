
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Building2, FileText, X } from 'lucide-react';
import { Project, TestAssignment, UserRole } from '../types';
import { ProjectService, ExecutionService } from '../services/mockDatabase';
import { useAuth } from '../context/AuthContext';

export const GlobalSearch: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);
    const [query, setQuery] = useState('');
    const [projects, setProjects] = useState<Project[]>([]);
    const [assignments, setAssignments] = useState<TestAssignment[]>([]);
    const [loading, setLoading] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useEffect(() => {
        if (isOpen && projects.length === 0) {
            fetchData();
        }
    }, [isOpen]);

    const fetchData = async () => {
        setLoading(true);
        try {
            const [projData, assignData] = await Promise.all([
                ProjectService.fetchProjects(),
                ExecutionService.fetchAssignmentsByEngineer('') // Fetch all for search
            ]);
            setProjects(projData || []);
            setAssignments(assignData || []);
        } catch (error) {
            console.error("Search data fetch failed:", error);
        } finally {
            setLoading(false);
        }
    };

    const filteredProjects = query.trim() === '' ? [] : projects.filter(p => 
        p.name.toLowerCase().includes(query.toLowerCase()) || 
        p.clientName.toLowerCase().includes(query.toLowerCase())
    );

    const filteredAssignments = query.trim() === '' ? [] : assignments.filter(a => 
        a.testName.toLowerCase().includes(query.toLowerCase()) ||
        a.projectName?.toLowerCase().includes(query.toLowerCase())
    );

    const handleSelect = (type: 'PROJECT' | 'TEST', id: string) => {
        setQuery('');
        setIsOpen(false);
        if (type === 'PROJECT') {
            const rolePath = (user?.role === UserRole.ENGINEER) ? '/engineer' : '/pm';
            navigate(`${rolePath}?projectId=${id}`);
        } else {
            navigate(`/execute/${id}`);
        }
    };

    return (
        <div className="relative w-full px-6 mb-6" ref={containerRef}>
            <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search size={16} className="text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                </div>
                <input
                    type="text"
                    value={query}
                    onChange={(e) => {
                        setQuery(e.target.value);
                        setIsOpen(true);
                    }}
                    onFocus={() => setIsOpen(true)}
                    placeholder="Search projects or tests..."
                    className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-xs font-medium rounded-xl focus:ring-4 focus:ring-indigo-50/50 focus:border-indigo-500 block pl-10 pr-10 py-2.5 outline-none transition-all placeholder:text-slate-400"
                />
                {query && (
                    <button 
                        onClick={() => setQuery('')}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                    >
                        <X size={14} />
                    </button>
                )}
            </div>

            {isOpen && query.trim() !== '' && (
                <div className="absolute left-6 right-6 mt-2 bg-white rounded-2xl border border-slate-200 shadow-2xl z-50 overflow-hidden max-h-[400px] flex flex-col">
                    <div className="overflow-y-auto p-2 space-y-1">
                        {loading && (
                            <div className="p-4 text-center text-xs text-slate-400 font-bold uppercase tracking-widest animate-pulse">
                                Searching Data Lake...
                            </div>
                        )}

                        {!loading && filteredProjects.length === 0 && filteredAssignments.length === 0 && (
                            <div className="p-4 text-center text-xs text-slate-400 font-medium">
                                No results found for "{query}"
                            </div>
                        )}

                        {filteredProjects.length > 0 && (
                            <div className="pb-2">
                                <div className="px-3 py-2 text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50/50 rounded-lg mb-1">Projects</div>
                                {filteredProjects.map(p => (
                                    <button
                                        key={p.id}
                                        onClick={() => handleSelect('PROJECT', p.id)}
                                        className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-indigo-50 rounded-xl transition-all text-left group"
                                    >
                                        <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all">
                                            <Building2 size={16} />
                                        </div>
                                        <div className="min-w-0">
                                            <p className="text-xs font-bold text-slate-800 truncate">{p.name}</p>
                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-tighter truncate">{p.clientName}</p>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        )}

                        {filteredAssignments.length > 0 && (
                            <div className="pt-1">
                                <div className="px-3 py-2 text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50/50 rounded-lg mb-1">Test Protocols</div>
                                {filteredAssignments.map(a => (
                                    <button
                                        key={a.id}
                                        onClick={() => handleSelect('TEST', a.id)}
                                        className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-emerald-50 rounded-xl transition-all text-left group"
                                    >
                                        <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-all">
                                            <FileText size={16} />
                                        </div>
                                        <div className="min-w-0">
                                            <p className="text-xs font-bold text-slate-800 truncate">{a.testName}</p>
                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-tighter truncate">{a.projectName || 'Active Project'}</p>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                    <div className="bg-slate-50 p-2 text-center border-t border-slate-100">
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                            {filteredProjects.length + filteredAssignments.length} matches found
                        </p>
                    </div>
                </div>
            )}
        </div>
    );
};
