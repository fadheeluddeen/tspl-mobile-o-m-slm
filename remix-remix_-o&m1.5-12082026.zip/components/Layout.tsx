
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { useNavigate, useLocation } from 'react-router-dom';
import { SystemService } from '../services/mockDatabase';
import { 
  LayoutDashboard, 
  Users, 
  Lock, 
  FileText, 
  Library, 
  Building2, 
  BookOpen, 
  LogOut,
  ChevronRight,
  Zap,
  Pin,
  FileCheck
} from 'lucide-react';
import { GlobalSearch } from './GlobalSearch';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [selectedCell, setSelectedCell] = useState<{
    tableIdx: number;
    rowIdx: number;
    cellIdx: number;
    cellEl: HTMLTableCellElement;
    inputEl: HTMLElement;
  } | null>(null);

  const applySavedFormats = () => {
    const tables = document.querySelectorAll('main table');
    tables.forEach((table, tIdx) => {
      const rows = table.querySelectorAll('tr');
      rows.forEach((row, rIdx) => {
        const cells = row.querySelectorAll('td, th');
        cells.forEach((cell, cIdx) => {
          const storageKey = `cell_format_${location.pathname}_t${tIdx}_r${rIdx}_c${cIdx}`;
          const saved = localStorage.getItem(storageKey);
          if (saved) {
            try {
              const format = JSON.parse(saved);
              const htmlCell = cell as HTMLElement;
              
              if (format.align) {
                htmlCell.style.textAlign = format.align;
                const inps = htmlCell.querySelectorAll('input, select, textarea');
                inps.forEach(i => {
                  (i as HTMLElement).style.textAlign = format.align;
                });
              }
              if (format.valign) {
                htmlCell.style.verticalAlign = format.valign;
                const inps = htmlCell.querySelectorAll('input, select, textarea');
                inps.forEach(i => {
                  (i as HTMLElement).style.verticalAlign = format.valign;
                });
              }
              if (format.colSpan !== undefined && format.colSpan !== (cell as HTMLTableCellElement).colSpan) {
                (cell as HTMLTableCellElement).colSpan = format.colSpan;
              }
              if (format.rowSpan !== undefined && format.rowSpan !== (cell as HTMLTableCellElement).rowSpan) {
                (cell as HTMLTableCellElement).rowSpan = format.rowSpan;
              }
            } catch (e) {
              console.error(e);
            }
          }
        });
      });
    });
  };

  useEffect(() => {
    applySavedFormats();

    const observer = new MutationObserver(() => {
      applySavedFormats();
    });

    const mainElement = document.querySelector('main');
    if (mainElement) {
      observer.observe(mainElement, {
        childList: true,
        subtree: true
      });
    }

    return () => {
      observer.disconnect();
    };
  }, [location.pathname]);

  useEffect(() => {
    const handleFocus = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA')) {
        const cell = target.closest('td, th') as HTMLTableCellElement;
        if (cell) {
          const row = cell.closest('tr');
          const table = cell.closest('table');
          if (row && table) {
            const tables = Array.from(document.querySelectorAll('main table'));
            const tIdx = tables.indexOf(table);
            
            const rows = Array.from(table.querySelectorAll('tr'));
            const rIdx = rows.indexOf(row);
            
            const cells = Array.from(row.querySelectorAll('td, th'));
            const cIdx = cells.indexOf(cell);

            if (tIdx !== -1 && rIdx !== -1 && cIdx !== -1) {
              setSelectedCell({
                tableIdx: tIdx,
                rowIdx: rIdx,
                cellIdx: cIdx,
                cellEl: cell,
                inputEl: target
              });
            }
          }
        }
      }
    };

    document.addEventListener('focusin', handleFocus);
    return () => {
      document.removeEventListener('focusin', handleFocus);
    };
  }, [location.pathname]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        return;
      }

      const active = document.activeElement as HTMLElement;
      if (!active) return;

      const cell = active.closest('td, th') as HTMLTableCellElement;
      if (!cell) return;

      const row = cell.closest('tr') as HTMLTableRowElement;
      const table = cell.closest('table') as HTMLTableElement;
      if (!row || !table) return;

      // Ensure we only handle arrow key navigation inside spreadsheet/testing input fields
      const isInput = active.tagName === 'INPUT' || active.tagName === 'SELECT' || active.tagName === 'TEXTAREA';
      if (!isInput) return;

      const rowIndex = Array.from(table.rows).indexOf(row);
      const cellIndex = Array.from(row.cells).indexOf(cell);

      let targetCell: HTMLTableCellElement | null = null;

      if (e.key === 'ArrowUp') {
        const targetRow = table.rows[rowIndex - 1];
        if (targetRow) {
          targetCell = targetRow.cells[Math.min(cellIndex, targetRow.cells.length - 1)];
        }
      } else if (e.key === 'ArrowDown') {
        const targetRow = table.rows[rowIndex + 1];
        if (targetRow) {
          targetCell = targetRow.cells[Math.min(cellIndex, targetRow.cells.length - 1)];
        }
      } else if (e.key === 'ArrowLeft') {
        targetCell = row.cells[cellIndex - 1] || null;
      } else if (e.key === 'ArrowRight') {
        targetCell = row.cells[cellIndex + 1] || null;
      }

      if (targetCell) {
        const focusable = targetCell.querySelector('input, select, textarea') as HTMLElement;
        if (focusable) {
          e.preventDefault();
          focusable.focus();
          if (focusable instanceof HTMLInputElement && (focusable.type === 'text' || focusable.type === 'number')) {
            focusable.select();
          }
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown, true);
    return () => {
      document.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [location.pathname]);

  const getStorageKey = () => {
    if (!selectedCell) return '';
    return `cell_format_${location.pathname}_t${selectedCell.tableIdx}_r${selectedCell.rowIdx}_c${selectedCell.cellIdx}`;
  };

  const getActiveStyle = (prop: string) => {
    const key = getStorageKey();
    if (!key) return null;
    try {
      const config = JSON.parse(localStorage.getItem(key) || '{}');
      return config[prop];
    } catch {
      return null;
    }
  };

  const updateActiveStyle = (prop: string, value: any) => {
    const key = getStorageKey();
    if (!key) return;
    try {
      const config = JSON.parse(localStorage.getItem(key) || '{}');
      config[prop] = value;
      localStorage.setItem(key, JSON.stringify(config));
      applySavedFormats();
    } catch (e) {
      console.error(e);
    }
  };

  const handleAlign = (value: 'left' | 'center' | 'right') => {
    updateActiveStyle('align', value);
  };

  const handleValign = (value: 'top' | 'middle' | 'bottom') => {
    updateActiveStyle('valign', value);
  };

  const handleColSpan = (direction: number) => {
    const current = getActiveStyle('colSpan') || 1;
    const nextVal = Math.max(1, current + direction);
    updateActiveStyle('colSpan', nextVal);
  };

  const handleRowSpan = (direction: number) => {
    const current = getActiveStyle('rowSpan') || 1;
    const nextVal = Math.max(1, current + direction);
    updateActiveStyle('rowSpan', nextVal);
  };

  if (!user) return <>{children}</>;

  const NavItem = ({ to, label, icon: Icon, color }: { to: string; label: string; icon: any; color?: string }) => {
    const isActive = location.pathname === to || (to !== '/' && location.pathname.startsWith(to));
    return (
      <button
        onClick={() => navigate(to)}
        className={`w-full flex items-center px-6 py-3.5 text-sm font-semibold transition-all group relative ${
          isActive 
            ? 'bg-blue-50/50 text-blue-600' 
            : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
        }`}
      >
        {isActive && (
          <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-600 rounded-r-full" />
        )}
        <div className={`mr-4 transition-transform group-hover:scale-110 ${isActive ? 'text-blue-600' : color || 'text-slate-400'}`}>
          <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
        </div>
        <span className="flex-1 text-left">{label}</span>
        {isActive && <ChevronRight size={14} className="text-blue-400" />}
      </button>
    );
  };

  const handleLogout = async () => {
    if (user) {
      await SystemService.createAuditLog({
        userEmail: user.email,
        userName: user.displayName,
        userRole: user.role,
        module: 'AUTH',
        action: 'USER_SIGNOUT',
        status: 'SUCCESS',
        details: 'User initiated sign-out'
      });
    }
    await logout();
  };

  const getSafeDisplayName = () => {
    if (user.displayName && user.displayName !== 'User' && user.displayName !== 'Unknown User') {
      return user.displayName;
    }
    return user.email ? user.email.split('@')[0] : 'User';
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-slate-200 flex-shrink-0 flex flex-col fixed h-full z-20 shadow-sm">
        {/* Logo Section */}
        <div className="p-8 flex flex-col gap-6">
          <div className="w-full">
            <img 
              src="https://lh3.googleusercontent.com/d/17LiSObruHI6XOCX_5g6D20KRspHCyozg" 
              alt="Technavious Logo" 
              className="w-full h-auto object-contain max-h-12"
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            O & M Portal
          </h1>
        </div>

        <GlobalSearch />

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-2 scrollbar-thin scrollbar-thumb-slate-200">
          
          {user.role === UserRole.ADMIN && (
            <div className="flex flex-col gap-1">
              <div className="px-6 py-4 text-[11px] font-black text-slate-400 uppercase tracking-[0.15em]">Administration</div>
              <NavItem to="/dashboard" label="Global Overview" icon={LayoutDashboard} color="text-indigo-500" />
              <NavItem to="/admin/dashboard" label="Adoption Growth" icon={Zap} color="text-emerald-500" />
              <NavItem to="/admin" label="Control Panel" icon={Zap} color="text-amber-500" />
              <NavItem to="/admin/users" label="User Management" icon={Users} color="text-purple-500" />
              <NavItem to="/admin/privileges" label="Privileges" icon={Lock} color="text-rose-500" />
              <NavItem to="/admin/audit" label="Audit Logs" icon={FileText} color="text-orange-500" />
              <NavItem to="/admin/library" label="Test Library (Admin)" icon={Library} color="text-emerald-500" />
              <NavItem to="/admin/projects" label="All Projects" icon={Building2} color="text-blue-500" />
              <NavItem to="/execute/pinned" label="Pinned Tests" icon={Pin} color="text-amber-500" />
              <NavItem to="/execute/reports" label="Approved Reports" icon={FileCheck} color="text-emerald-500" />
              <NavItem to="/help/manual" label="User Manual" icon={BookOpen} color="text-sky-500" />
            </div>
          )}

          {user.role === UserRole.DEVELOPER && (
            <div className="flex flex-col gap-1">
              <div className="px-6 py-4 text-[11px] font-black text-slate-400 uppercase tracking-[0.15em]">Development</div>
              <NavItem to="/developer" label="Test Library" icon={Library} color="text-emerald-500" />
              <NavItem to="/developer/preview" label="Preview Engine" icon={Zap} color="text-amber-500" />
            </div>
          )}

          {user.role === UserRole.PROJECT_MANAGER && (
            <div className="flex flex-col gap-1">
              <div className="px-6 py-4 text-[11px] font-black text-slate-400 uppercase tracking-[0.15em]">Management</div>
              <NavItem to="/dashboard" label="Operational Overview" icon={LayoutDashboard} color="text-emerald-500" />
              <NavItem to="/pm/dashboard" label="Executive Metrics" icon={Zap} color="text-indigo-500" />
              <NavItem to="/pm" label="Projects" icon={Building2} color="text-blue-500" />
              <NavItem to="/execute/pinned" label="Pinned Tests" icon={Pin} color="text-amber-500" />
              <NavItem to="/execute/reports" label="Approved Reports" icon={FileCheck} color="text-emerald-500" />
              <NavItem to="/help/manual" label="User Manual" icon={BookOpen} color="text-sky-500" />
            </div>
          )}

          {user.role === UserRole.ENGINEER && (
            <div className="flex flex-col gap-1">
              <div className="px-6 py-4 text-[11px] font-black text-slate-400 uppercase tracking-[0.15em]">Execution</div>
              <NavItem to="/dashboard" label="My Status" icon={LayoutDashboard} color="text-indigo-500" />
              <NavItem to="/engineer" label="My Assignments" icon={FileText} color="text-orange-500" />
              <NavItem to="/execute/pinned" label="Pinned Tests" icon={Pin} color="text-amber-500" />
              <NavItem to="/execute/reports" label="Approved Reports" icon={FileCheck} color="text-emerald-500" />
              <NavItem to="/help/manual" label="User Manual" icon={BookOpen} color="text-sky-500" />
            </div>
          )}

        </nav>

        {/* User Profile Section */}
        <div className="p-6 border-t border-slate-100 bg-slate-50/30">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center text-slate-900 font-black text-lg">
              {getSafeDisplayName().charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-slate-900 truncate leading-tight">{getSafeDisplayName()}</p>
              <p className="text-[11px] text-slate-500 truncate mb-1.5">{user.email}</p>
              <div className="flex">
                <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest
                  ${user.role === UserRole.ADMIN ? 'bg-purple-100 text-purple-700' :
                    user.role === UserRole.DEVELOPER ? 'bg-amber-100 text-amber-700' :
                    user.role === UserRole.PROJECT_MANAGER ? 'bg-emerald-100 text-emerald-700' :
                    'bg-blue-100 text-blue-700'}`}>
                  {(user.role || '').replace('_', ' ')}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full px-4 py-3 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-xl transition-all flex items-center justify-center gap-2 border border-transparent hover:border-rose-100"
          >
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 p-4 md:p-10 overflow-y-auto min-h-screen w-full max-w-full box-border">
        <div className="w-full max-w-full mx-auto box-border">
          {children}
        </div>
      </main>

      {/* Global Formatting Toolbar */}
      {selectedCell && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 md:translate-x-0 md:left-auto md:right-6 bg-white/95 backdrop-blur-md text-slate-800 px-6 py-4 rounded-2xl shadow-2xl border border-orange-200 flex flex-wrap items-center gap-6 z-50 max-w-[90vw] md:max-w-4xl animate-fade-in animate-slide-up select-none">
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-orange-500 uppercase tracking-widest leading-3 mb-0.5">Format Active Cell</span>
            <span className="text-xs font-black text-slate-700 truncate max-w-[150px]">
              Table {selectedCell.tableIdx + 1} ➔ Row {selectedCell.rowIdx + 1}, Col {selectedCell.cellIdx + 1}
            </span>
          </div>

          <div className="hidden sm:block h-8 w-[1px] bg-slate-200" />

          {/* Horizontal Alignment */}
          <div className="flex flex-col gap-1">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Horizontal</span>
            <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200/55">
              {(['left', 'center', 'right'] as const).map(dir => (
                <button
                  key={dir}
                  type="button"
                  onClick={() => handleAlign(dir)}
                  className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all uppercase tracking-wider ${
                    getActiveStyle('align') === dir 
                      ? 'bg-[#FB923C] text-white shadow-sm font-black' 
                      : 'text-slate-500 hover:text-slate-800 hover:bg-slate-200/50'
                  }`}
                >
                  {dir}
                </button>
              ))}
            </div>
          </div>

          <div className="hidden sm:block h-8 w-[1px] bg-slate-200" />

          {/* Vertical Alignment */}
          <div className="flex flex-col gap-1">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Vertical</span>
            <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200/55">
              {(['top', 'middle', 'bottom'] as const).map(vdir => (
                <button
                  key={vdir}
                  type="button"
                  onClick={() => handleValign(vdir)}
                  className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all uppercase tracking-wider ${
                    getActiveStyle('valign') === vdir 
                      ? 'bg-[#1E293B] text-white shadow-sm font-black' 
                      : 'text-slate-500 hover:text-slate-800 hover:bg-slate-200/50'
                  }`}
                >
                  {vdir}
                </button>
              ))}
            </div>
          </div>

          <div className="hidden sm:block h-8 w-[1px] bg-slate-200" />

          {/* Merge Cells / Spans */}
          <div className="flex items-center gap-4">
            {/* Column Span */}
            <div className="flex flex-col gap-1 items-center">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Col Merge</span>
              <div className="flex items-center gap-2 bg-slate-100 p-0.5 rounded-lg border border-slate-200/55 overflow-hidden">
                <button 
                  type="button"
                  onClick={() => handleColSpan(-1)}
                  className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200/50 rounded transition-colors"
                  title="Decrease column merge span"
                >
                  -
                </button>
                <span className="text-xs font-black font-mono px-1 w-4 text-center">{getActiveStyle('colSpan') || 1}</span>
                <button 
                  type="button"
                  onClick={() => handleColSpan(1)}
                  className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200/50 rounded transition-colors"
                  title="Increase column merge span"
                >
                  +
                </button>
              </div>
            </div>

            {/* Row Span */}
            <div className="flex flex-col gap-1 items-center">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Row Merge</span>
              <div className="flex items-center gap-2 bg-slate-100 p-0.5 rounded-lg border border-slate-200/55 overflow-hidden">
                <button 
                  type="button"
                  onClick={() => handleRowSpan(-1)}
                  className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200/50 rounded transition-colors"
                  title="Decrease row merge span"
                >
                  -
                </button>
                <span className="text-xs font-black font-mono px-1 w-4 text-center">{getActiveStyle('rowSpan') || 1}</span>
                <button 
                  type="button"
                  onClick={() => handleRowSpan(1)}
                  className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200/50 rounded transition-colors"
                  title="Increase row merge span"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          <div className="h-8 w-[1px] bg-slate-200" />

          <button 
            type="button"
            onClick={() => setSelectedCell(null)}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 rounded-xl text-xs font-black transition-all"
          >
            Dismiss
          </button>
        </div>
      )}
    </div>
  );
};

export default Layout;
