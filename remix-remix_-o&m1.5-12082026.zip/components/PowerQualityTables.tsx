
import { 
  PowerQualityReading, 
  PQAnalysisGroup, 
  ThermographyToolRow,
  PQHarmonicPhase 
} from '../types';
import React from 'react';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

// Icons
const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

const UploadIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400 group-hover:text-blue-500 transition-colors"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
);

const ActivityIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#B71C1C]"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
);

interface PowerQualityTablesProps {
  data: PowerQualityReading;
  onChange: (data: PowerQualityReading) => void;
  readOnly?: boolean;
}

interface MetricCardProps {
  title: string;
  metricKey: keyof PQAnalysisGroup;
  group: PQAnalysisGroup;
  icon: string;
  customContent?: React.ReactNode;
  updateGroup: (groupId: string, updates: Partial<PQAnalysisGroup>) => void;
  readOnly: boolean;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, metricKey, group, icon, customContent, updateGroup, readOnly }) => {
  const metric = group[metricKey] as any;
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => updateGroup(group.id, { [metricKey]: { ...metric, imageUrl: ev.target?.result as string } });
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-8 space-y-6 animate-in fade-in zoom-in-95 duration-500">
      <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
         <span className="text-xl">{icon}</span>
         <h4 className="font-black text-[#B71C1C] uppercase text-xs tracking-widest">{title}</h4>
      </div>

      {/* TREND VISUALIZER */}
      <div className="aspect-video bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 relative group flex items-center justify-center overflow-hidden transition-all hover:border-blue-300">
         {metric.imageUrl ? (
           <>
              <img src={metric.imageUrl} className="w-full h-full object-cover" />
              {!readOnly && (
                <button 
                  onClick={() => updateGroup(group.id, { [metricKey]: { ...metric, imageUrl: '' } })}
                  className="absolute inset-0 bg-black/60 text-white font-black text-[10px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center uppercase tracking-widest"
                >
                  Remove Screenshot
                </button>
              )}
           </>
         ) : (
           <div className="flex flex-col items-center gap-2">
              <UploadIcon />
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Upload Trend Screenshot</span>
              {!readOnly && <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleImageUpload} />}
           </div>
         )}
      </div>

      {/* DATA TABLE */}
      <div className="overflow-x-auto rounded-xl border border-slate-200">
         {customContent || (
           <table className="w-full text-center text-[11px] border-collapse table-auto">
             <thead className="bg-slate-100 text-slate-600 font-bold uppercase tracking-tighter">
                <tr>
                  <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">Average Measurement</th>
                  <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">Standard Limits</th>
                  <th className="py-2.5 whitespace-nowrap">Remarks (Pass/Fail)</th>
                </tr>
             </thead>
             <tbody>
                <tr>
                  <td className="p-0 border-r border-slate-200"><input value={metric.average} onChange={e => updateGroup(group.id, { [metricKey]: { ...metric, average: e.target.value } })} className="w-full py-3 text-center outline-none font-bold text-slate-800" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-200">
                    <input 
                      value={metric.limits} 
                      onChange={e => updateGroup(group.id, { [metricKey]: { ...metric, limits: e.target.value } })} 
                      className="w-full py-3 text-center outline-none italic text-slate-400 font-medium" 
                      placeholder="Enter Limits"
                      disabled={readOnly} 
                    />
                  </td>
                  <td className={`p-0 transition-all ${metric.remark === 'Pass' ? 'bg-emerald-50' : metric.remark === 'Fail' ? 'bg-red-50' : ''}`}>
                     <select 
                      value={metric.remark} 
                      onChange={e => updateGroup(group.id, { [metricKey]: { ...metric, remark: e.target.value } })}
                      className={`w-full py-3 bg-transparent outline-none font-black text-center uppercase tracking-widest cursor-pointer ${metric.remark === 'Pass' ? 'text-emerald-700' : metric.remark === 'Fail' ? 'text-red-700' : ''}`}
                      disabled={readOnly}
                     >
                       <option value="">-</option>
                       <option value="Pass">Pass</option>
                       <option value="Fail">Fail</option>
                     </select>
                  </td>
                </tr>
             </tbody>
           </table>
         )}
      </div>
    </div>
  );
};

export const PowerQualityTables: React.FC<PowerQualityTablesProps> = ({ data, onChange, readOnly = false }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

  const updateField = (field: keyof PowerQualityReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addTool = () => {
    const list = [...(data.equipmentList || [])];
    list.push({ id: `tool-${Date.now()}`, instrumentName: '', make: '', model: '', serialNumber: '', calibrationIssue: '', calibrationExpiry: '' });
    updateField('equipmentList', list);
  };

  const createInitialGroup = (type: 'MLTP' | 'CHILLER' | 'UPS'): PQAnalysisGroup => {
    const initialPhase = (): PQHarmonicPhase => ({ max: '', min: '', avg: '' });
    return {
      id: `${type.toLowerCase()}-${Date.now()}`,
      title: `${type}-01`,
      type,
      dateFrom: '',
      dateTo: '',
      frequency: { average: '', limits: '', remark: '', imageUrl: '' },
      voltage: { ry: '', yb: '', br: '', rn: '', yn: '', bn: '', limits: '', remark: '', imageUrl: '' },
      current: { r: '', y: '', b: '', note: '', imageUrl: '' },
      activePower: { average: '', remark: '', note: '', imageUrl: '' },
      apparentPower: { average: '', remark: '', note: '', imageUrl: '' },
      reactivePower: { average: '', remark: '', note: '', imageUrl: '' },
      powerFactor: { average: '', limits: '', remark: '', imageUrl: '' },
      thdv: { r: initialPhase(), y: initialPhase(), b: initialPhase(), limits: '', remark: '', imageUrl: '' },
      thdi: { r: initialPhase(), y: initialPhase(), b: initialPhase(), limits: '', remark: '', imageUrl: '' },
      voltageUnbalance: { average: '', limits: '', remark: '', imageUrl: '' },
      currentUnbalance: { average: '', limits: '', remark: '', imageUrl: '' },
    };
  };

  const addGroup = (type: 'MLTP' | 'CHILLER' | 'UPS') => {
    const groups = [...(data.analysisGroups || [])];
    groups.push(createInitialGroup(type));
    updateField('analysisGroups', groups);
  };

  const updateGroup = (groupId: string, updates: Partial<PQAnalysisGroup>) => {
    const groups = data.analysisGroups.map(g => g.id === groupId ? { ...g, ...updates } : g);
    updateField('analysisGroups', groups);
  };

  const deleteGroup = (groupId: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this Entire Power Quality Analysis Group and all its recorded trends?",
      onConfirm: () => {
        updateField('analysisGroups', data.analysisGroups.filter(g => g.id !== groupId));
      }
    });
  };

  return (
    <div className="space-y-10 animate-fade-in pb-24">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* PERSONNEL DATA GRID */}
      <section className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="bg-[#F97316] px-8 py-3 flex justify-between items-center text-white">
           <h3 className="font-black uppercase text-xs tracking-widest">PQ Personnel & Test Schedule</h3>
           <ActivityIcon />
        </div>
        <div className="p-8 grid grid-cols-1 md:grid-cols-5 gap-8">
           {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
             <div key={f} className="space-y-2">
               <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">{f.replace(/([A-Z])/g, ' $1')}</label>
               <input 
                 type={f === 'testDate' ? 'date' : 'text'}
                 value={(data as any)[f]}
                 onChange={e => updateField(f as any, e.target.value)}
                 disabled={readOnly}
                 className="w-full text-sm font-bold text-slate-800 border-b-2 border-slate-100 focus:border-orange-500 outline-none p-2 transition-all"
               />
             </div>
           ))}
        </div>
      </section>

      {/* INSTRUMENT CALIBRATION */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-8 py-4 flex justify-between items-center text-white">
          <h3 className="font-black text-xs uppercase tracking-widest">Instrument Calibration Detail</h3>
          {!readOnly && <button onClick={addTool} className="px-4 py-1.5 bg-white text-orange-600 rounded-lg font-black text-[10px] uppercase shadow-md transition-all active:scale-95">+ Add Instrument</button>}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[10px] text-left border-collapse table-auto">
            <thead className="bg-orange-50 text-orange-900 font-black uppercase tracking-tighter">
              <tr>
                <th className="px-6 py-3 border-r border-orange-100 whitespace-nowrap">Sr. No</th>
                <th className="px-6 py-3 border-r border-orange-100 whitespace-nowrap">Instrument Name</th>
                <th className="px-6 py-3 border-r border-orange-100 whitespace-nowrap">Make</th>
                <th className="px-6 py-3 border-r border-orange-100 whitespace-nowrap">Model</th>
                <th className="px-6 py-3 border-r border-orange-100 whitespace-nowrap">Serial No</th>
                <th colSpan={2} className="px-6 py-3 text-center whitespace-nowrap">Calibration (Issue / Expiry)</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
{(data.equipmentList).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {data.equipmentList.map((tool, idx) => (
                <tr key={tool.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-2.5 text-slate-400 font-mono">{idx + 1}</td>
                  <td className="p-0 border-r border-slate-100"><input value={tool.instrumentName} onChange={e => updateField('equipmentList', data.equipmentList.map(t => t.id === tool.id ? { ...t, instrumentName: e.target.value } : t))} className="w-full px-6 py-2.5 bg-transparent outline-none font-bold" /></td>
                  <td className="p-0 border-r border-slate-100"><input value={tool.make} onChange={e => updateField('equipmentList', data.equipmentList.map(t => t.id === tool.id ? { ...t, make: e.target.value } : t))} className="w-full px-6 py-2.5 bg-transparent outline-none" /></td>
                  <td className="p-0 border-r border-slate-100"><input value={tool.model} onChange={e => updateField('equipmentList', data.equipmentList.map(t => t.id === tool.id ? { ...t, model: e.target.value } : t))} className="w-full px-6 py-2.5 bg-transparent outline-none" /></td>
                  <td className="p-0 border-r border-slate-100"><input value={tool.serialNumber} onChange={e => updateField('equipmentList', data.equipmentList.map(t => t.id === tool.id ? { ...t, serialNumber: e.target.value } : t))} className="w-full px-6 py-2.5 bg-transparent outline-none font-mono" /></td>
                  <td className="p-0 border-r border-slate-100"><input type="date" value={tool.calibrationIssue} onChange={e => updateField('equipmentList', data.equipmentList.map(t => t.id === tool.id ? { ...t, calibrationIssue: e.target.value } : t))} className="w-full px-4 py-2.5 bg-transparent outline-none" /></td>
                  <td className="p-0 border-r border-slate-100"><input type="date" value={tool.calibrationExpiry} onChange={e => updateField('equipmentList', data.equipmentList.map(t => t.id === tool.id ? { ...t, calibrationExpiry: e.target.value } : t))} className="w-full px-4 py-2.5 bg-transparent outline-none text-red-600 font-bold" /></td>
            {!readOnly && (
              <td className="px-2 text-center">
                <button 
                  onClick={() => {
                    confirmDelete({
                      message: "Are you sure you want to delete this instrument detailed record?",
                      onConfirm: () => {
                        updateField('equipmentList', data.equipmentList.filter(t => t.id !== tool.id));
                      }
                    });
                  }} 
                  className="text-slate-300 hover:text-red-600 transition-colors"
                >
                  <TrashIcon />
                </button>
              </td>
            )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* HEADER CONTROLS (MOVED BELOW INSTRUMENT CALIBRATION) */}
      <div className="bg-slate-900 rounded-3xl p-6 flex flex-wrap gap-4 justify-center md:justify-end shadow-2xl">
         <button onClick={() => addGroup('MLTP')} className="px-6 py-3 bg-[#B71C1C] text-white rounded-xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all">+ Add MLTP Group</button>
         <button onClick={() => addGroup('CHILLER')} className="px-6 py-3 bg-[#1E40AF] text-white rounded-xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all">+ Add CHILLER Group</button>
         <button onClick={() => addGroup('UPS')} className="px-6 py-3 bg-[#D97706] text-white rounded-xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all">+ Add UPS Group</button>
      </div>

      {/* ANALYSIS GROUPS */}
      <div className="space-y-16">
        {data.analysisGroups.map((group) => (
          <div key={group.id} className="space-y-8 animate-in slide-in-from-bottom-4 duration-700">
             {/* GROUP HEADER */}
             <div className="bg-slate-900 rounded-3xl p-8 flex flex-col md:flex-row justify-between items-center gap-6 shadow-2xl">
                <div className="flex items-center gap-6">
                   <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl shadow-lg
                     ${group.type === 'MLTP' ? 'bg-[#B71C1C]' : group.type === 'CHILLER' ? 'bg-[#1E40AF]' : 'bg-[#D97706]'}`}>
                      {group.type === 'MLTP' ? '⚡' : group.type === 'CHILLER' ? '❄️' : '🔋'}
                   </div>
                   <div className="space-y-1">
                      <input 
                        value={group.title} 
                        onChange={e => updateGroup(group.id, { title: e.target.value.toUpperCase() })} 
                        className="bg-transparent border-none outline-none font-black text-2xl text-white tracking-widest w-full focus:ring-0" 
                        disabled={readOnly}
                      />
                      <div className="flex items-center gap-4 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                         <span>Monitoring Period:</span>
                         <input type="date" value={group.dateFrom} onChange={e => updateGroup(group.id, { dateFrom: e.target.value })} className="bg-slate-800 rounded px-2 py-0.5 border-none outline-none focus:ring-1 focus:ring-blue-500" disabled={readOnly} />
                         <span>to</span>
                         <input type="date" value={group.dateTo} onChange={e => updateGroup(group.id, { dateTo: e.target.value })} className="bg-slate-800 rounded px-2 py-0.5 border-none outline-none focus:ring-1 focus:ring-blue-500" disabled={readOnly} />
                      </div>
                   </div>
                </div>
                {!readOnly && (
                   <button onClick={() => deleteGroup(group.id)} className="p-3 bg-red-900/30 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all">
                      <TrashIcon />
                   </button>
                )}
             </div>

             {/* 11 METRIC GRID */}
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <MetricCard updateGroup={updateGroup} readOnly={readOnly} title="1. Power Frequency" metricKey="frequency" group={group} icon="📊" />

                <MetricCard 
                  updateGroup={updateGroup} readOnly={readOnly}
                  title={group.type === 'CHILLER' ? "2. Phase to Neutral Voltage" : "2. Phase to Phase Voltage"} 
                  metricKey="voltage" 
                  group={group} 
                  icon="⚡"
                  customContent={
                    <div className="overflow-x-auto">
                      <table className="w-full text-center text-[10px] border-collapse table-auto">
                        <thead className="bg-slate-100 text-slate-600 font-bold uppercase tracking-tighter">
                          <tr>
                            {group.type === 'CHILLER' ? (
                              <>
                                <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">RN Phase</th>
                                <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">YN Phase</th>
                                <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">BN Phase</th>
                              </>
                            ) : (
                              <>
                                <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">RY Phase</th>
                                <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">YB Phase</th>
                                <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">BR Phase</th>
                              </>
                            )}
                            <th className="py-2.5 border-r border-slate-200 whitespace-nowrap">Limits</th>
                            <th className="py-2.5 whitespace-nowrap">Remark</th>
                          </tr>
                        </thead>
                      <tbody>
                        <tr>
                          {group.type === 'CHILLER' ? (
                            <>
                              <td className="p-0 border-r border-slate-100"><input value={group.voltage.rn} onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, rn: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0.0 V" /></td>
                              <td className="p-0 border-r border-slate-100"><input value={group.voltage.yn} onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, yn: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0.0 V" /></td>
                              <td className="p-0 border-r border-slate-100"><input value={group.voltage.bn} onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, bn: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0.0 V" /></td>
                            </>
                          ) : (
                            <>
                              <td className="p-0 border-r border-slate-100"><input value={group.voltage.ry} onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, ry: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0.0 V" /></td>
                              <td className="p-0 border-r border-slate-100"><input value={group.voltage.yb} onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, yb: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0.0 V" /></td>
                              <td className="p-0 border-r border-slate-100"><input value={group.voltage.br} onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, br: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0.0 V" /></td>
                            </>
                          )}
                          <td className="p-0 border-r border-slate-100">
                            <input 
                              value={group.voltage.limits} 
                              onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, limits: e.target.value } })} 
                              className="w-full py-3 text-center outline-none italic text-slate-400" 
                              placeholder="Limits"
                              disabled={readOnly} 
                            />
                          </td>
                          <td className={`p-0 transition-all ${group.voltage.remark === 'Pass' ? 'bg-emerald-50' : group.voltage.remark === 'Fail' ? 'bg-red-50' : ''}`}>
                            <select value={group.voltage.remark} onChange={e => updateGroup(group.id, { voltage: { ...group.voltage, remark: e.target.value } })} className={`w-full py-3 bg-transparent outline-none font-black text-center uppercase ${group.voltage.remark === 'Pass' ? 'text-emerald-700' : group.voltage.remark === 'Fail' ? 'text-red-700' : ''}`} disabled={readOnly}>
                              <option value="">-</option><option value="Pass">Pass</option><option value="Fail">Fail</option>
                            </select>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                    </div>
                  }
                />

                <MetricCard 
                  updateGroup={updateGroup} readOnly={readOnly}
                  title="3. Current Trend in Ampere" 
                  metricKey="current" 
                  group={group} 
                  icon="📐"
                  customContent={
                    <div className="overflow-x-auto">
                      <table className="w-full text-center text-[10px] border-collapse table-auto">
                        <thead className="bg-slate-100 text-slate-600 font-bold uppercase">
                            <tr className="divide-x divide-slate-200">
                              <th className="py-2.5 whitespace-nowrap">R Phase</th><th className="py-2.5 whitespace-nowrap">Y Phase</th><th className="py-2.5 whitespace-nowrap">B Phase</th>
                            </tr>
                        </thead>
                       <tbody className="divide-y divide-slate-100">
                          <tr className="divide-x divide-slate-100">
                             <td className="p-0"><input value={group.current.r} onChange={e => updateGroup(group.id, { current: { ...group.current, r: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0 A" /></td>
                             <td className="p-0"><input value={group.current.y} onChange={e => updateGroup(group.id, { current: { ...group.current, y: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0 A" /></td>
                             <td className="p-0"><input value={group.current.b} onChange={e => updateGroup(group.id, { current: { ...group.current, b: e.target.value } })} className="w-full py-3 text-center outline-none font-bold" disabled={readOnly} placeholder="0 A" /></td>
                          </tr>
                          <tr><td colSpan={3} className="p-0"><input value={group.current.note} onChange={e => updateGroup(group.id, { current: { ...group.current, note: e.target.value } })} className="w-full px-4 py-2.5 text-left text-slate-400 italic outline-none text-[9px]" placeholder="Add load notes..." disabled={readOnly} /></td></tr>
                       </tbody>
                    </table>
                    </div>
                  }
                />

                <MetricCard updateGroup={updateGroup} readOnly={readOnly} title="4. Actual Power Trend in KW" metricKey="activePower" group={group} icon="🔥" />
                <MetricCard updateGroup={updateGroup} readOnly={readOnly} title="5. Apparent Power Trend in KVA" metricKey="apparentPower" group={group} icon="🔋" />
                <MetricCard updateGroup={updateGroup} readOnly={readOnly} title="6. Reactive Power Trend in KVAR" metricKey="reactivePower" group={group} icon="🌀" />
                <MetricCard updateGroup={updateGroup} readOnly={readOnly} title="7. Power Factor Trend" metricKey="powerFactor" group={group} icon="⚖️" />

                <MetricCard 
                  updateGroup={updateGroup} readOnly={readOnly}
                  title="8. THDv Trend" 
                  metricKey="thdv" 
                  group={group} 
                  icon="〰️"
                  customContent={
                    <div className="overflow-x-auto">
                      <table className="w-full text-center text-[9px] border-collapse table-auto">
                        <thead className="bg-slate-100 text-slate-500 font-black uppercase">
                            <tr className="divide-x divide-slate-200 border-b border-slate-200">
                              <th className="py-2 w-12 bg-slate-200 text-slate-800 whitespace-nowrap">Phase</th>
                              <th className="py-2 whitespace-nowrap">Max %</th>
                              <th className="py-2 whitespace-nowrap">Min %</th>
                              <th className="py-2 whitespace-nowrap">Avg %</th>
                              <th className="py-2 w-24 whitespace-nowrap">Limits</th>
                              <th className="py-2 whitespace-nowrap">Remark</th>
                            </tr>
                        </thead>
                       <tbody className="divide-y divide-slate-100">
                          {(['r', 'y', 'b'] as const).map(p => (
                            <tr key={p} className="divide-x divide-slate-100">
                               <td className="py-2 bg-slate-50 font-black uppercase">{p}</td>
                               <td className="p-0"><input value={group.thdv[p].max} onChange={e => updateGroup(group.id, { thdv: { ...group.thdv, [p]: { ...group.thdv[p], max: e.target.value } } })} className="w-full py-2 text-center outline-none font-bold" disabled={readOnly} /></td>
                               <td className="p-0"><input value={group.thdv[p].min} onChange={e => updateGroup(group.id, { thdv: { ...group.thdv, [p]: { ...group.thdv[p], min: e.target.value } } })} className="w-full py-2 text-center outline-none font-bold" disabled={readOnly} /></td>
                               <td className="p-0"><input value={group.thdv[p].avg} onChange={e => updateGroup(group.id, { thdv: { ...group.thdv, [p]: { ...group.thdv[p], avg: e.target.value } } })} className="w-full py-2 text-center outline-none font-black text-blue-600" disabled={readOnly} /></td>
                               {p === 'r' && (
                                 <td rowSpan={3} className="p-0 border-r border-slate-100 bg-slate-50">
                                   <input 
                                     value={group.thdv.limits} 
                                     onChange={e => updateGroup(group.id, { thdv: { ...group.thdv, limits: e.target.value } })}
                                     className="w-full h-full py-4 text-center bg-transparent outline-none italic text-slate-400 font-bold"
                                     placeholder="Limits..."
                                     disabled={readOnly}
                                   />
                                 </td>
                               )}
                               {p === 'r' && (
                                 <td rowSpan={3} className={`p-0 transition-all ${group.thdv.remark === 'Pass' ? 'bg-emerald-50' : group.thdv.remark === 'Fail' ? 'bg-red-50' : ''}`}>
                                   <select value={group.thdv.remark} onChange={e => updateGroup(group.id, { thdv: { ...group.thdv, remark: e.target.value } })} className={`w-full h-full bg-transparent outline-none font-black text-center uppercase tracking-widest ${group.thdv.remark === 'Pass' ? 'text-emerald-700' : group.thdv.remark === 'Fail' ? 'text-red-700' : ''}`} disabled={readOnly}>
                                      <option value="">-</option><option value="Pass">Pass</option><option value="Fail">Fail</option>
                                   </select>
                                 </td>
                               )}
                            </tr>
                          ))}
                       </tbody>
                    </table>
                    </div>
                  }
                />

                <MetricCard 
                  updateGroup={updateGroup} readOnly={readOnly}
                  title="9. THDi Trend" 
                  metricKey="thdi" 
                  group={group} 
                  icon="📶"
                  customContent={
                    <div className="overflow-x-auto">
                      <table className="w-full text-center text-[9px] border-collapse table-auto">
                        <thead className="bg-slate-100 text-slate-500 font-black uppercase">
                            <tr className="divide-x divide-slate-200 border-b border-slate-200">
                              <th className="py-2 w-12 bg-slate-200 text-slate-800 whitespace-nowrap">Phase</th>
                              <th className="py-2 whitespace-nowrap">Max %</th>
                              <th className="py-2 whitespace-nowrap">Min %</th>
                              <th className="py-2 whitespace-nowrap">Avg %</th>
                              <th className="py-2 w-24 whitespace-nowrap">Limits</th>
                              <th className="py-2 whitespace-nowrap">Remark</th>
                            </tr>
                        </thead>
                       <tbody className="divide-y divide-slate-100">
                          {(['r', 'y', 'b'] as const).map(p => (
                            <tr key={p} className="divide-x divide-slate-100">
                               <td className="py-2 bg-slate-50 font-black uppercase">{p}</td>
                               <td className="p-0"><input value={group.thdi[p].max} onChange={e => updateGroup(group.id, { thdi: { ...group.thdi, [p]: { ...group.thdi[p], max: e.target.value } } })} className="w-full py-2 text-center outline-none font-bold" disabled={readOnly} /></td>
                               <td className="p-0"><input value={group.thdi[p].min} onChange={e => updateGroup(group.id, { thdi: { ...group.thdi, [p]: { ...group.thdi[p], min: e.target.value } } })} className="w-full py-2 text-center outline-none font-bold" disabled={readOnly} /></td>
                               <td className="p-0"><input value={group.thdi[p].avg} onChange={e => updateGroup(group.id, { thdi: { ...group.thdi, [p]: { ...group.thdi[p], avg: e.target.value } } })} className="w-full py-2 text-center outline-none font-black text-blue-600" disabled={readOnly} /></td>
                               {p === 'r' && (
                                 <td rowSpan={3} className="p-0 border-r border-slate-100 bg-slate-50">
                                   <input 
                                     value={group.thdi.limits} 
                                     onChange={e => updateGroup(group.id, { thdi: { ...group.thdi, limits: e.target.value } })}
                                     className="w-full h-full py-4 text-center bg-transparent outline-none italic text-slate-400 font-bold"
                                     placeholder="Limits..."
                                     disabled={readOnly}
                                   />
                                 </td>
                               )}
                               {p === 'r' && (
                                 <td rowSpan={3} className={`p-0 transition-all ${group.thdi.remark === 'Pass' ? 'bg-emerald-50' : group.thdi.remark === 'Fail' ? 'bg-red-50' : ''}`}>
                                   <select value={group.thdi.remark} onChange={e => updateGroup(group.id, { thdi: { ...group.thdi, remark: e.target.value } })} className={`w-full h-full bg-transparent outline-none font-black text-center uppercase tracking-widest ${group.thdi.remark === 'Pass' ? 'text-emerald-700' : group.thdi.remark === 'Fail' ? 'text-red-700' : ''}`} disabled={readOnly}>
                                      <option value="">-</option><option value="Pass">Pass</option><option value="Fail">Fail</option>
                                   </select>
                                 </td>
                               )}
                            </tr>
                          ))}
                       </tbody>
                    </table>
                    </div>
                  }
                />

                <MetricCard updateGroup={updateGroup} readOnly={readOnly} title="10. Unbalance Voltage Trend" metricKey="voltageUnbalance" group={group} icon="💠" />
                <MetricCard updateGroup={updateGroup} readOnly={readOnly} title="11. Unbalance Current Trend" metricKey="currentUnbalance" group={group} icon="💠" />
             </div>
          </div>
        ))}

        {data.analysisGroups.length === 0 && (
          <div className="py-32 text-center border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50">
             <span className="text-5xl block mb-6 grayscale opacity-50">📈</span>
             <p className="text-slate-400 font-black uppercase tracking-widest text-[11px]">No active analysis groups defined</p>
          </div>
        )}
      </div>

      {/* SUMMARY */}
      <section className="bg-white rounded-[2rem] border border-slate-200 shadow-2xl p-10 space-y-10">
         <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
            <span className="text-2xl">📋</span>
            <h3 className="font-black text-slate-800 tracking-widest uppercase">Executive Summary</h3>
         </div>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-4">
               <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">OVERALL OBSERVATIONS</label>
               <textarea 
                value={data.observations}
                onChange={e => updateField('observations', e.target.value)}
                disabled={readOnly}
                placeholder="Enter detailed observations..."
                className="w-full h-48 p-6 bg-slate-50 border border-slate-200 rounded-3xl focus:ring-8 focus:ring-blue-50 outline-none text-sm transition-all italic resize-none"
               />
            </div>
            <div className="space-y-4">
               <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">RECOMMENDATIONS</label>
               <textarea 
                value={data.recommendations}
                onChange={e => updateField('recommendations', e.target.value)}
                disabled={readOnly}
                placeholder="Enter professional recommendations..."
                className="w-full h-48 p-6 bg-slate-50 border border-slate-200 rounded-3xl focus:ring-8 focus:ring-blue-50 outline-none text-sm transition-all italic resize-none"
               />
            </div>
         </div>
      </section>

    </div>
  );
};

export const INITIAL_POWER_QUALITY_DATA: PowerQualityReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  equipmentList: [],
  analysisGroups: [],
  observations: '',
  recommendations: ''
};
