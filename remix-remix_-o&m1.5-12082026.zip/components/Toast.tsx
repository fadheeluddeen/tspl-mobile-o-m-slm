
import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, XCircle, X } from 'lucide-react';

interface ToastProps {
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-3 px-6 py-4 rounded-2xl shadow-2xl border ${
        type === 'success' 
          ? 'bg-white border-emerald-100 text-emerald-900 shadow-emerald-100/50' 
          : 'bg-white border-red-100 text-red-900 shadow-red-100/50'
      }`}
    >
      <div className={`p-1.5 rounded-lg ${type === 'success' ? 'bg-emerald-50 text-emerald-500' : 'bg-red-50 text-red-500'}`}>
        {type === 'success' ? (
          <CheckCircle size={20} weight="bold" />
        ) : (
          <XCircle size={20} weight="bold" />
        )}
      </div>
      
      <div className="flex flex-col min-w-[150px]">
        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-0.5">
          {type === 'success' ? 'Success Notification' : 'Error Occurred'}
        </p>
        <span className="font-bold text-sm tracking-tight">{message}</span>
      </div>

      <button 
        onClick={onClose}
        className="ml-4 p-1 hover:bg-slate-50 rounded-full transition-colors text-slate-300 hover:text-slate-500"
      >
        <X size={16} />
      </button>

      {/* Progress Bar */}
      <motion.div 
        initial={{ width: '100%' }}
        animate={{ width: '0%' }}
        transition={{ duration: 3, ease: 'linear' }}
        className={`absolute bottom-0 left-0 h-1 rounded-full ${type === 'success' ? 'bg-emerald-500' : 'bg-red-500'}`}
      />
    </motion.div>
  );
};

export const ToastContainer: React.FC<{ toast: { message: string, type: 'success' | 'error' } | null, onClose: () => void }> = ({ toast, onClose }) => {
  return (
    <AnimatePresence>
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={onClose} 
        />
      )}
    </AnimatePresence>
  );
};

export default Toast;
