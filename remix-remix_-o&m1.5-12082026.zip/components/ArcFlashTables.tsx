
import React from 'react';
import { ArcFlashReading, ArcFlashPPE, GloveClassReading, ArcFlashWorkingDistance, ArcFlashStudyResult } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

// Icons as pure SVGs
const FlameIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>
);
const ShieldIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
);
const GridIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-500"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
);
const TableIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-500"><path d="M3 3h18v18H3zM3 9h18M3 15h18M9 3v18M15 3v18"/></svg>
);
const Trash2Icon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

interface ArcFlashTablesProps {
  data: ArcFlashReading;
  onChange: (data: ArcFlashReading) => void;
  readOnly?: boolean;
}

export const ArcFlashTables: React.FC<ArcFlashTablesProps> = ({ data, onChange, readOnly = false }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

  const updateField = (field: keyof ArcFlashReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addRow = (field: keyof ArcFlashReading, template: any) => {
    const list = [...((data[field] as any[]) || [])];
    list.push({ ...template, id: `af-${Date.now()}` });
    updateField(field, list);
  };

  const deleteRow = (field: keyof ArcFlashReading, id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this row?",
      onConfirm: () => {
        const list = ((data[field] as any[]) || []).filter(item => item.id !== id);
        updateField(field, list);
      }
    });
  };

  const updateRow = (field: keyof ArcFlashReading, id: string, rowKey: string, value: any) => {
    const list = ((data[field] as any[]) || []).map(item => item.id === id ? { ...item, [rowKey]: value } : item);
    updateField(field, list);
  };

  const SectionHeader = ({ icon: Icon, title }: { icon: any; title: string }) => (
    <div className="flex items-center gap-3 py-3 px-1 border-b border-[#D1D5DB] mb-4">
      <Icon />
      <h3 className="font-bold text-slate-800 uppercase tracking-tight">{title}</h3>
    </div>
  );

  return (
    <div className="space-y-12 animate-fade-in pb-20">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* 1. Execution Summary Header */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#FB923C] px-6 py-3 text-white">
          <h3 className="text-center font-bold uppercase tracking-wider text-sm">Personnel & Test Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Prepared By</label>
            <input 
              value={data?.preparedBy || ''} 
              onChange={e => updateField('preparedBy', e.target.value)}
              disabled={readOnly}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tested By</label>
            <input 
              value={data?.testedBy || ''} 
              onChange={e => updateField('testedBy', e.target.value)}
              disabled={readOnly}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tester Email</label>
            <input 
              value={data?.testerEmail || ''} 
              onChange={e => updateField('testerEmail', e.target.value)}
              disabled={readOnly}
              placeholder="Email"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Witnessed By</label>
            <input 
              value={data?.witnessedBy || ''} 
              onChange={e => updateField('witnessedBy', e.target.value)}
              disabled={readOnly}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Test Date</label>
            <input 
              type="date"
              value={data?.testDate || ''} 
              onChange={e => updateField('testDate', e.target.value)}
              disabled={readOnly}
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
        </div>
      </section>

      {/* Table A: Arc Flash PPE Categories */}
      <section>
        <SectionHeader icon={ShieldIcon} title="Table A: Arc Flash PPE Categories" />
        <div className="bg-white rounded-xl border border-[#D1D5DB] shadow-sm overflow-hidden overflow-x-auto">
          <table className="w-full text-sm border-collapse table-auto">
            <thead>
              <tr className="bg-[#FFBD88] text-slate-900 border-b border-[#D1D5DB]">
                <th className="px-4 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">PPE cat.</th>
                <th className="px-4 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">Min. incident energy cal/cm²</th>
                <th className="px-4 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">Arc rated clothing</th>
                {!readOnly && <th className="w-12"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D1D5DB]">
{((data?.ppeCategories || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data?.ppeCategories || []).map(row => (
                <tr key={row.id} className="hover:bg-slate-50 group transition-colors">
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.category} onChange={e => updateRow('ppeCategories', row.id, 'category', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.minEnergy} onChange={e => updateRow('ppeCategories', row.id, 'minEnergy', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.clothing} onChange={e => updateRow('ppeCategories', row.id, 'clothing', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="text-center">
                      <button onClick={() => deleteRow('ppeCategories', row.id)} className="text-slate-400 hover:text-red-500 transition-colors"><Trash2Icon /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!readOnly && (
            <button onClick={() => addRow('ppeCategories', { category: '', minEnergy: '', clothing: '' })} className="w-full py-3 bg-slate-50 text-slate-500 text-xs font-bold hover:bg-slate-100 border-t border-[#D1D5DB] transition-colors tracking-widest uppercase">+ Add New Row</button>
          )}
        </div>
      </section>

      {/* Table B: Glove Class Specifications */}
      <section>
        <SectionHeader icon={FlameIcon} title="Table B: Glove Class Specifications" />
        <div className="bg-white rounded-xl border border-[#D1D5DB] shadow-sm overflow-hidden overflow-x-auto">
          <table className="w-full text-xs min-w-[800px] border-collapse table-auto">
            <thead>
              <tr className="bg-[#FFBD88] text-slate-900 border-b border-[#D1D5DB]">
                <th className="px-3 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">Class of glove</th>
                <th className="px-3 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">AC proof-test voltage, RMS, V</th>
                <th className="px-3 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">Maximum AC use voltage, AC RMS, V</th>
                <th className="px-3 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">DC proof-test voltage, avg V</th>
                <th className="px-3 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">Maximum DC use voltage, avg V</th>
                {!readOnly && <th className="w-12"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D1D5DB]">
{((data?.gloveClasses || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data?.gloveClasses || []).map(row => (
                <tr key={row.id} className="hover:bg-slate-50 group transition-colors">
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.class} onChange={e => updateRow('gloveClasses', row.id, 'class', e.target.value)} className="w-full px-3 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.acProof} onChange={e => updateRow('gloveClasses', row.id, 'acProof', e.target.value)} className="w-full px-3 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.maxAc} onChange={e => updateRow('gloveClasses', row.id, 'maxAc', e.target.value)} className="w-full px-3 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.dcProof} onChange={e => updateRow('gloveClasses', row.id, 'dcProof', e.target.value)} className="w-full px-3 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.maxDc} onChange={e => updateRow('gloveClasses', row.id, 'maxDc', e.target.value)} className="w-full px-3 py-3 bg-transparent outline-none" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="text-center">
                      <button onClick={() => deleteRow('gloveClasses', row.id)} className="text-slate-400 hover:text-red-500 transition-colors"><Trash2Icon /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!readOnly && (
            <button onClick={() => addRow('gloveClasses', { class: '', acProof: '', maxAc: '', dcProof: '', maxDc: '' })} className="w-full py-3 bg-slate-50 text-slate-500 text-xs font-bold hover:bg-slate-100 border-t border-[#D1D5DB] transition-colors tracking-widest uppercase">+ Add New Row</button>
          )}
        </div>
      </section>

      {/* Table C: Working Distances by Equipment Class */}
      <section>
        <SectionHeader icon={GridIcon} title="Table C: Working Distances by Equipment Class" />
        <div className="bg-white rounded-xl border border-[#D1D5DB] shadow-sm overflow-hidden overflow-x-auto">
          <table className="w-full text-sm text-center border-collapse table-auto">
            <thead>
              <tr className="bg-[#FFBD88] text-slate-900 border-b border-[#D1D5DB]">
                <th rowSpan={2} className="px-4 py-3 text-left font-bold border-r border-[#D1D5DB] whitespace-nowrap">Equipment Class</th>
                <th colSpan={2} className="px-4 py-2 font-bold border-r border-[#D1D5DB] whitespace-nowrap">Working Distance</th>
                <th rowSpan={2} className="px-4 py-3 font-bold border-r border-[#D1D5DB] whitespace-nowrap">Typical Conductor or Bus gap (mm)</th>
                {!readOnly && <th rowSpan={2} className="w-12"></th>}
              </tr>
              <tr className="bg-[#FFDAB9] text-slate-700 text-xs font-bold border-b border-[#D1D5DB]">
                <th className="px-4 py-2 border-r border-[#D1D5DB] whitespace-nowrap">mm</th>
                <th className="px-4 py-2 border-r border-[#D1D5DB] whitespace-nowrap">Inch</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D1D5DB]">
{((data?.workingDistances || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data?.workingDistances || []).map(row => (
                <tr key={row.id} className="hover:bg-slate-50 group transition-colors">
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.equipClass} onChange={e => updateRow('workingDistances', row.id, 'equipClass', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none text-left" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.mm} onChange={e => updateRow('workingDistances', row.id, 'mm', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.inch} onChange={e => updateRow('workingDistances', row.id, 'inch', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.busGap} onChange={e => updateRow('workingDistances', row.id, 'busGap', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="text-center">
                      <button onClick={() => deleteRow('workingDistances', row.id)} className="text-slate-400 hover:text-red-500 transition-colors"><Trash2Icon /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!readOnly && (
            <button onClick={() => addRow('workingDistances', { equipClass: '', mm: '', inch: '', busGap: '' })} className="w-full py-3 bg-slate-50 text-slate-500 text-xs font-bold hover:bg-slate-100 border-t border-[#D1D5DB] transition-colors tracking-widest uppercase">+ Add New Row</button>
          )}
        </div>
      </section>

      {/* Table D: Arc Flash Study Result */}
      <section>
        <SectionHeader icon={TableIcon} title="Table D: Arc Flash Study Result" />
        <div className="bg-white rounded-xl border border-[#D1D5DB] shadow-sm overflow-hidden overflow-x-auto">
          <table className="w-full text-[11px] text-center min-w-[1100px] border-collapse table-auto">
            <thead>
              <tr className="bg-[#FFBD88] text-slate-900 border-b border-[#D1D5DB]">
                <th colSpan={3} className="px-2 py-3 font-bold border-r border-[#D1D5DB] whitespace-nowrap">Bus</th>
                <th colSpan={2} className="px-2 py-3 font-bold border-r border-[#D1D5DB] whitespace-nowrap">Total Fault Current (kA)</th>
                <th colSpan={4} className="px-2 py-3 font-bold border-r border-[#D1D5DB] whitespace-nowrap">Arc-Flash Analysis Results</th>
                {!readOnly && <th rowSpan={2} className="w-12"></th>}
              </tr>
              <tr className="bg-[#FFDAB9] text-slate-700 font-bold uppercase tracking-tighter border-b border-[#D1D5DB]">
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">ID</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">Nom. kV</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">Type</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">Bolted</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">Arcing</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">FCT (cycles)</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">Incident Energy (cal/cm²)</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">AFB (m)</th>
                <th className="px-2 py-3 border-r border-[#D1D5DB] whitespace-nowrap">Energy Level</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D1D5DB]">
{((data?.studyResults || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data?.studyResults || []).map(row => (
                <tr key={row.id} className="hover:bg-slate-50 group transition-colors">
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.busId} onChange={e => updateRow('studyResults', row.id, 'busId', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.nomKv} onChange={e => updateRow('studyResults', row.id, 'nomKv', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.type} onChange={e => updateRow('studyResults', row.id, 'type', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.bolted} onChange={e => updateRow('studyResults', row.id, 'bolted', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.arcing} onChange={e => updateRow('studyResults', row.id, 'arcing', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.fct} onChange={e => updateRow('studyResults', row.id, 'fct', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.energy} onChange={e => updateRow('studyResults', row.id, 'energy', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB]"><input value={row.afb} onChange={e => updateRow('studyResults', row.id, 'afb', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-[#D1D5DB] font-bold"><input value={row.level} onChange={e => updateRow('studyResults', row.id, 'level', e.target.value)} className="w-full px-2 py-3 bg-transparent outline-none text-center" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="text-center">
                      <button onClick={() => deleteRow('studyResults', row.id)} className="text-slate-400 hover:text-red-500 transition-colors"><Trash2Icon /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {!readOnly && (
            <button onClick={() => addRow('studyResults', { busId: '', nomKv: '', type: '', bolted: '', arcing: '', fct: '', energy: '', afb: '', level: '' })} className="w-full py-3 bg-slate-50 text-slate-500 text-xs font-bold hover:bg-slate-100 border-t border-[#D1D5DB] transition-colors tracking-widest uppercase">+ Add New Row</button>
          )}
        </div>
      </section>

      {/* 3. Observation & Recommendation Boxes */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block px-1">Observations</label>
          <textarea 
            value={data?.observations || ''}
            onChange={e => updateField('observations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter detailed test observations..."
            className="w-full h-48 p-4 border border-[#D1D5DB] rounded-xl focus:ring-2 focus:ring-[#FB923C] focus:border-[#FB923C] outline-none text-sm leading-relaxed shadow-sm bg-white"
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block px-1">Recommendations</label>
          <textarea 
            value={data?.recommendations || ''}
            onChange={e => updateField('recommendations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter recommendations..."
            className="w-full h-48 p-4 border border-[#D1D5DB] rounded-xl focus:ring-2 focus:ring-[#FB923C] focus:border-[#FB923C] outline-none text-sm leading-relaxed shadow-sm bg-white"
          />
        </div>
      </section>

    </div>
  );
};

export const INITIAL_ARC_FLASH_DATA: ArcFlashReading = {
  preparedBy: '',
  testedBy: '',
  testerEmail: '',
  witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  ppeCategories: [],
  gloveClasses: [],
  workingDistances: [],
  studyResults: [],
  observations: '',
  recommendations: ''
};
