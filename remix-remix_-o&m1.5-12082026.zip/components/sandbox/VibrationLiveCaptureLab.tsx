import React from 'react';
import { 
  VibrationAnalysisReading, 
  VibrationToolRow, 
  AbbreviationRow, 
  VibrationSummaryGroup, 
  VibrationSummaryRow,
  ObservationRecommendationRow 
} from '../../types';
import { ObservationsRecommendationsTable } from '../ObservationsRecommendationsTable';
import ConfirmModal from '../ConfirmModal';
import { ToastContainer } from '../Toast';
import { useConfirmDelete } from '../../hooks/useConfirmDelete';
import { FileSpreadsheet, Upload, Camera } from 'lucide-react';
import { exportVibrationGroupToExcel } from '../../utils/excelExport';
import { parseVibrationGroupExcel } from '../../utils/excelImport';
import { readVibrationDisplay } from '../../services/geminiClient';

const LIVE_CAPTURE_ENABLED = true; // Always on in the sandbox — no flag needed here

const AXES = ['vertical', 'horizontal', 'axial'] as const;
const AXIS_LABELS = ['Vertical', 'Horizontal', 'Axial'];

const Trash2Icon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

const ToolIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
);

const InfoIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
);

const ChartBarIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-600"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
);

interface VibrationLiveCaptureLabProps {
  data: VibrationAnalysisReading;
  onChange: (data: VibrationAnalysisReading) => void;
  readOnly?: boolean;
}

export const VibrationLiveCaptureLab: React.FC<VibrationLiveCaptureLabProps> = ({ data, onChange, readOnly = false }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();
  
  const [selectedCell, setSelectedCell] = React.useState<{
    rowId: string;
    field: string;
    tableType: 'tools' | 'summary';
    groupId?: string;
  } | null>(null);

  const [liveCapture, setLiveCapture] = React.useState<{
    active: boolean;
    groupId: string;
    rowIndex: number;
    axisIndex: number;
    rows: VibrationSummaryRow[];
    phase: 'camera' | 'reading' | 'review';
    readValues: { vertical: string; horizontal: string; axial: string };
    error: string;
  } | null>(null);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? { ...prev, error: 'Camera not available. Enter values manually below.', phase: 'review' } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');
    
    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);
    
    try {
      const axisKey = AXES[liveCapture.axisIndex];
      const value = await readVibrationDisplay(base64, AXIS_LABELS[liveCapture.axisIndex]);
      setLiveCapture(prev => prev ? { ...prev, phase: 'review', readValues: { ...prev.readValues, [axisKey]: value }, error: '' } : null);
    } catch (err: any) {
      console.error('Live Capture error:', err);
      setLiveCapture(prev => prev ? { 
        ...prev, 
        phase: 'review', 
        readValues: { vertical: '', horizontal: '', axial: '' },
        error: `Error: ${err?.message || JSON.stringify(err)}`
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const { groupId, rowIndex, axisIndex, rows, readValues } = liveCapture;
    const row = rows[rowIndex];
    if (!row) return;
    
    const axisKey = AXES[axisIndex];
    const value = readValues[axisKey];
    if (value) {
      updateSummaryRow(groupId, row.id, axisKey, value);
    }
    
    if (axisIndex < 2) {
      setLiveCapture(prev => prev ? {
        ...prev,
        axisIndex: axisIndex + 1,
        phase: 'camera',
        readValues: { vertical: '', horizontal: '', axial: '' },
        error: ''
      } : null);
    } else {
      const nextIndex = rowIndex + 1;
      if (nextIndex < rows.length) {
        setLiveCapture(prev => prev ? {
          ...prev,
          rowIndex: nextIndex,
          axisIndex: 0,
          phase: 'camera',
          readValues: { vertical: '', horizontal: '', axial: '' },
          error: ''
        } : null);
      } else {
        stopCamera();
        setLiveCapture(null);
        alert('All rows captured successfully!');
      }
    }
  };

  const handleCancelCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const openLiveCapture = (groupId: string, rows: VibrationSummaryRow[]) => {
    let startIndex = rows.findIndex(r => !r.vertical && !r.horizontal && !r.axial);
    if (startIndex === -1) startIndex = 0;
    
    setLiveCapture({
      active: true,
      groupId,
      rowIndex: startIndex,
      axisIndex: 0,
      rows,
      phase: 'camera',
      readValues: { vertical: '', horizontal: '', axial: '' },
      error: ''
    });
  };

  React.useEffect(() => {
    if (liveCapture?.phase === 'camera') {
      startCamera();
    }
    return () => {
      if (liveCapture?.phase === 'camera') {
        stopCamera();
      }
    };
  }, [liveCapture?.phase, liveCapture?.rowIndex]);

  React.useEffect(() => {
    return () => stopCamera();
  }, []);

  const isCellCovered = (
    rows: any[],
    rowIndex: number,
    colIndex: number,
    columns: string[]
  ): boolean => {
    for (let c = 0; c < colIndex; c++) {
      const key = columns[c];
      const cellStyle = rows[rowIndex]?.cellStyles?.[key];
      const cs = cellStyle?.colSpan || 1;
      if (c + cs > colIndex) {
        return true;
      }
    }
    for (let r = 0; r < rowIndex; r++) {
      const prevRow = rows[r];
      for (let c = 0; c < columns.length; c++) {
        const key = columns[c];
        const cellStyle = prevRow?.cellStyles?.[key];
        const rs = cellStyle?.rowSpan || 1;
        const cs = cellStyle?.colSpan || 1;
        const coversRow = r + rs > rowIndex;
        const coversCol = c <= colIndex && c + cs > colIndex;
        if (coversRow && coversCol) {
          return true;
        }
      }
    }
    return false;
  };

  const updateField = (field: keyof VibrationAnalysisReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addRow = (field: keyof VibrationAnalysisReading, template: any) => {
    const list = [...((data[field] as any[]) || [])];
    list.push({ ...template, id: `va-${Date.now()}` });
    updateField(field, list);
  };

  const deleteRow = (field: keyof VibrationAnalysisReading, id: string) => {
    if (readOnly) return;
    confirmDelete({
      message: "Are you sure you want to delete this row?",
      onConfirm: () => {
        const list = ((data[field] as any[]) || []).filter(item => item.id !== id);
        updateField(field, list);
      }
    });
  };

  const updateRow = (field: keyof VibrationAnalysisReading, id: string, rowKey: string, value: any) => {
    const list = ((data[field] as any[]) || []).map(item => item.id === id ? { ...item, [rowKey]: value } : item);
    updateField(field, list);
  };

  const addSummaryGroup = () => {
    const groups = [...(data.summaryGroups || [])];
    groups.push({
      id: `group-${Date.now()}`,
      groupName: 'NEW SECTION',
      rows: []
    });
    updateField('summaryGroups', groups);
  };

  const deleteSummaryGroup = (groupId: string) => {
    if (readOnly) return;
    confirmDelete({
      message: "Are you sure you want to delete this Entire Summary Table and all its measurement records?",
      onConfirm: () => {
        const groups = (data.summaryGroups || []).filter(g => g.id !== groupId);
        updateField('summaryGroups', groups);
      }
    });
  };

  const updateSummaryGroup = (groupId: string, groupName: string) => {
    const groups = (data.summaryGroups || []).map(g => g.id === groupId ? { ...g, groupName } : g);
    updateField('summaryGroups', groups);
  };

  const addSummaryRow = (groupId: string) => {
    const groups = (data.summaryGroups || []).map(g => {
      if (g.id === groupId) {
        return {
          ...g,
          rows: [...g.rows, {
            id: `row-${Date.now()}`,
            equipmentId: '',
            classDetails: '',
            vertical: '',
            horizontal: '',
            axial: '',
            maxValue: '',
            condition: 'GOOD'
          }]
        };
      }
      return g;
    });
    updateField('summaryGroups', groups);
  };

  const deleteSummaryRow = (groupId: string, rowId: string) => {
    if (readOnly) return;
    confirmDelete({
      message: "Are you sure you want to delete this equipment measurement row?",
      onConfirm: () => {
        const groups = (data.summaryGroups || []).map(g => {
          if (g.id === groupId) {
            return { ...g, rows: g.rows.filter(r => r.id !== rowId) };
          }
          return g;
        });
        updateField('summaryGroups', groups);
      }
    });
  };

  const calculateCondition = (isoClass: string, maxValueStr: string): string => {
    const maxValue = parseFloat(maxValueStr);
    if (isNaN(maxValue)) return '';
    if (isoClass === 'Class I') {
      if (maxValue <= 0.71) return 'GOOD';
      if (maxValue <= 1.8) return 'Satisfactory';
      if (maxValue <= 4.5) return 'Unsatisfactory';
      return 'Unacceptable';
    } else if (isoClass === 'Class II') {
      if (maxValue <= 1.12) return 'GOOD';
      if (maxValue <= 2.8) return 'Satisfactory';
      if (maxValue <= 7.1) return 'Unsatisfactory';
      return 'Unacceptable';
    } else if (isoClass === 'Class III') {
      if (maxValue <= 1.8) return 'GOOD';
      if (maxValue <= 4.5) return 'Satisfactory';
      if (maxValue <= 11.2) return 'Unsatisfactory';
      return 'Unacceptable';
    } else if (isoClass === 'Class IV') {
      if (maxValue <= 2.8) return 'GOOD';
      if (maxValue <= 7.1) return 'Satisfactory';
      if (maxValue <= 18) return 'Unsatisfactory';
      return 'Unacceptable';
    }
    return '';
  };

  const updateSummaryRow = (groupId: string, rowId: string, key: keyof VibrationSummaryRow, value: string) => {
    const groups = (data.summaryGroups || []).map(g => {
      if (g.id === groupId) {
        return {
          ...g,
          rows: g.rows.map(r => {
            if (r.id === rowId) {
              const updatedRow = { ...r, [key]: value };
              if (['vertical', 'horizontal', 'axial'].includes(key)) {
                const v = parseFloat(updatedRow.vertical) || 0;
                const h = parseFloat(updatedRow.horizontal) || 0;
                const a = parseFloat(updatedRow.axial) || 0;
                const max = Math.max(v, h, a);
                updatedRow.maxValue = max > 0 ? max.toString() : '';
              }
              if (['classDetails', 'vertical', 'horizontal', 'axial', 'maxValue'].includes(key)) {
                updatedRow.condition = calculateCondition(updatedRow.classDetails, updatedRow.maxValue) || updatedRow.condition;
              }
              return updatedRow;
            }
            return r;
          })
        };
      }
      return g;
    });
    updateField('summaryGroups', groups);
  };

  const SectionHeader = ({ icon: Icon, title }: { icon: any; title: string }) => (
    <div className="flex items-center gap-3 py-3 px-1 border-b border-[#D1D5DB] mb-4">
      <Icon />
      <h3 className="font-bold text-slate-800 uppercase tracking-tight">{title}</h3>
    </div>
  );

  const handleImportGroupExcel = (groupId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const result = parseVibrationGroupExcel(evt.target?.result);
        if (result && result.length > 0) {
          const updatedGroups = (data.summaryGroups || []).map(g => 
            g.id === groupId ? { ...g, rows: result } : g
          );
          updateField('summaryGroups', updatedGroups);
        } else {
          alert("Could not parse file. Ensure headers match the original export template.");
        }
      };
      reader.readAsBinaryString(file);
    };
    input.click();
  };

  return (
    <div className="space-y-12 animate-fade-in pb-20 relative">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />

      <section>
        <div className="flex justify-between items-center mb-4">
          <SectionHeader icon={ChartBarIcon} title="VIBRATION MEASUREMENT SUMMARY (SANDBOX)" />
          {!readOnly && (
            <button 
              onClick={addSummaryGroup}
              className="px-6 py-2.5 bg-[#FB923C] text-white rounded-xl text-xs font-bold hover:bg-orange-600 transition-all flex items-center gap-2 shadow-md"
            >
              <span className="text-lg">+</span> Add Summary Table
            </button>
          )}
        </div>

        <div className="space-y-8">
          {(data?.summaryGroups || []).map((group) => (
            <div key={group.id} className="bg-white rounded-2xl border-2 border-[#FB923C] shadow-lg overflow-hidden">
              <div className="bg-[#FB923C] px-6 py-3 text-white flex justify-between items-center">
                <div className="flex-1 text-center">
                  <h3 className="font-black uppercase tracking-widest text-sm">VIBRATION MEASUREMENT SUMMARY</h3>
                </div>
                <div className="flex items-center gap-2">
                  {LIVE_CAPTURE_ENABLED && !readOnly && (
                    <button
                      onClick={() => openLiveCapture(group.id, group.rows)}
                      className="p-1.5 bg-violet-500/80 hover:bg-violet-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                      title="Live Capture — photograph meter readings"
                    >
                      <Camera className="w-3.5 h-3.5" /> Live Capture
                    </button>
                  )}
                  <button
                    onClick={() => exportVibrationGroupToExcel(group, `${group.groupName || 'Vibration_Analysis'}_Report_${new Date().toISOString().split('T')[0]}.xlsx`)}
                    className="p-1.5 bg-emerald-500/80 hover:bg-emerald-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                    title="Export to Excel"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" /> Export
                  </button>
                  {!readOnly && (
                    <>
                      <button
                        onClick={() => handleImportGroupExcel(group.id)}
                        className="p-1.5 bg-indigo-500/80 hover:bg-indigo-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                        title="Import from Excel"
                      >
                        <Upload className="w-3.5 h-3.5" /> Import
                      </button>
                      <button 
                        onClick={() => addSummaryRow(group.id)}
                        className="p-1.5 bg-white/20 hover:bg-white/30 rounded transition-colors flex items-center justify-center w-7 h-7"
                        title="Add Row"
                      >
                        <span className="text-sm font-bold leading-none">+</span>
                      </button>
                      <button 
                        onClick={() => deleteSummaryGroup(group.id)}
                        className="p-1.5 bg-white/20 hover:bg-red-500/50 rounded transition-colors flex items-center justify-center w-7 h-7"
                        title="Delete Table"
                      >
                        <Trash2Icon />
                      </button>
                    </>
                  )}
                </div>
              </div>

              <div className="bg-slate-50 border-b border-[#D1D5DB] px-6 py-2">
                <input 
                  value={group.groupName}
                  onChange={e => updateSummaryGroup(group.id, e.target.value)}
                  disabled={readOnly}
                  className="w-full bg-transparent text-center font-black text-[#1E293B] uppercase tracking-widest text-xs outline-none focus:text-orange-600"
                  placeholder="GROUP NAME (e.g. OLD DC)"
                />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="bg-[#1E293B] text-white text-[10px] font-black uppercase tracking-wider border-b border-[#D1D5DB]">
                      <th rowSpan={2} className="px-2 py-4 text-center border-r border-slate-700 w-[15%]">Equipment ID</th>
                      <th rowSpan={2} className="px-2 py-4 text-center border-r border-slate-700 w-[15%]">Class Details</th>
                      <th colSpan={4} className="px-2 py-2 text-center border-r border-slate-700">Measured Vibration (mm/s)</th>
                      <th rowSpan={2} className="px-2 py-4 text-center">Vibration Condition</th>
                      {!readOnly && <th rowSpan={2} className="w-10"></th>}
                    </tr>
                    <tr className="bg-[#1E293B] text-white text-[9px] font-black uppercase tracking-wider border-b border-[#D1D5DB]">
                      <th className="px-2 py-2 text-center border-r border-slate-700">Vertical</th>
                      <th className="px-2 py-2 text-center border-r border-slate-700">Horizontal</th>
                      <th className="px-2 py-2 text-center border-r border-slate-700">Axial</th>
                      <th className="px-2 py-2 text-center border-r border-slate-700">Max Value (mm/s)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D1D5DB]">
                    {group.rows.map((row, rIdx, rList) => {
                      const summaryKeys = ['equipmentId', 'classDetails', 'vertical', 'horizontal', 'axial', 'maxValue', 'condition'];
                      return (
                        <tr key={row.id} className="bg-blue-50/30 hover:bg-blue-50/60 transition-colors border-b border-blue-100">
                          {summaryKeys.map((colKey, colIdx) => {
                            if (isCellCovered(rList, rIdx, colIdx, summaryKeys)) {
                              return null;
                            }
                            const styles = row.cellStyles?.[colKey] || {};
                            const colSpan = styles.colSpan || 1;
                            const rowSpan = styles.rowSpan || 1;
                            const alignmentClass = styles.align === 'center' ? 'text-center' : styles.align === 'right' ? 'text-right' : 'text-left';
                            const verticalClass = styles.valign === 'top' ? 'align-top' : styles.valign === 'bottom' ? 'align-bottom' : 'align-middle';

                            if (colKey === 'classDetails') {
                              return (
                                <td key={colKey} colSpan={colSpan} rowSpan={rowSpan} className={`p-0 border-r border-[#D1D5DB] ${verticalClass}`}>
                                  <select
                                    value={row.classDetails}
                                    onChange={e => updateSummaryRow(group.id, row.id, 'classDetails', e.target.value)}
                                    disabled={readOnly}
                                    className={`w-full px-4 py-3 bg-transparent outline-none text-slate-700 text-sm appearance-none cursor-pointer ${alignmentClass}`}
                                  >
                                    <option value="">Select Class</option>
                                    <option value="Class I">Class I</option>
                                    <option value="Class II">Class II</option>
                                    <option value="Class III">Class III</option>
                                    <option value="Class IV">Class IV</option>
                                  </select>
                                </td>
                              );
                            }
                            if (colKey === 'condition') {
                              return (
                                <td key={colKey} colSpan={colSpan} rowSpan={rowSpan} className={`p-0 ${verticalClass}`}>
                                  <select
                                    value={row.condition || 'GOOD'}
                                    onChange={e => updateSummaryRow(group.id, row.id, 'condition', e.target.value)}
                                    disabled={readOnly}
                                    className={`w-full px-4 py-3 bg-transparent outline-none font-bold text-sm appearance-none cursor-pointer ${alignmentClass} ${
                                      (row.condition || 'GOOD') === 'GOOD' ? 'text-green-600' :
                                      row.condition === 'Satisfactory' ? 'text-blue-600' :
                                      row.condition === 'Unsatisfactory' ? 'text-orange-600' :
                                      row.condition === 'Unacceptable' ? 'text-red-600' : 'text-slate-700'
                                    }`}
                                  >
                                    <option value="">Select Condition</option>
                                    <option value="GOOD">GOOD</option>
                                    <option value="Satisfactory">Satisfactory</option>
                                    <option value="Unsatisfactory">Unsatisfactory</option>
                                    <option value="Unacceptable">Unacceptable</option>
                                  </select>
                                </td>
                              );
                            }
                            const isNumeric = ['vertical', 'horizontal', 'axial', 'maxValue'].includes(colKey);
                            const fontClass = isNumeric ? 'font-mono text-slate-600' : 'font-medium text-slate-800';
                            const finalAlignClass = isNumeric && !styles.align ? 'text-center' : alignmentClass;

                            return (
                              <td key={colKey} colSpan={colSpan} rowSpan={rowSpan} className={`p-0 border-r border-[#D1D5DB] ${verticalClass}`}>
                                <input
                                  value={row[colKey as keyof VibrationSummaryRow] as string || ''}
                                  onChange={e => updateSummaryRow(group.id, row.id, colKey as keyof VibrationSummaryRow, e.target.value)}
                                  disabled={readOnly}
                                  className={`w-full px-4 py-3 bg-transparent outline-none text-sm ${fontClass} ${finalAlignClass}`}
                                  placeholder={colKey === 'equipmentId' ? 'PAC 01' : ''}
                                />
                              </td>
                            );
                          })}
                          {!readOnly && (
                            <td className="text-center px-2">
                              <button onClick={() => deleteSummaryRow(group.id, row.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                                <Trash2Icon />
                              </button>
                            </td>
                          )}
                        </tr>
                      );
                    })}
                    {group.rows.length === 0 && (
                      <tr>
                        <td colSpan={readOnly ? 7 : 8} className="px-6 py-8 text-center text-slate-400 italic text-xs">
                          No rows added to this summary group.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
          {(data?.summaryGroups || []).length === 0 && (
            <div className="py-20 text-center border-2 border-dashed border-slate-200 rounded-3xl">
              <p className="text-slate-400 text-sm italic">No summary tables added yet. Click "Add Summary Table" to begin.</p>
            </div>
          )}
        </div>
      </section>

      {/* Live Capture Modal */}
      {liveCapture && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-violet-600 px-6 py-4 rounded-t-2xl flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Live Capture (Sandbox)</h3>
                <p className="text-violet-200 text-sm">
                  Reading {liveCapture.rowIndex + 1} of {liveCapture.rows.length} — {liveCapture.rows[liveCapture.rowIndex]?.equipmentId || 'Unknown'} — {AXIS_LABELS[liveCapture.axisIndex]}
                </p>
              </div>
              <button onClick={handleCancelCapture} className="text-white/80 hover:text-white text-2xl font-bold">×</button>
            </div>
            <div className="p-6 space-y-4">
              {liveCapture.phase === 'camera' && (
                <>
                  <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
                  <button onClick={capturePhoto} className="w-full py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2">
                    <Camera className="w-5 h-5" /> Capture Reading
                  </button>
                </>
              )}
              {liveCapture.phase === 'reading' && (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-violet-200 border-t-violet-600 mx-auto mb-4" />
                  <p className="text-slate-600 font-medium">Reading display...</p>
                  <p className="text-slate-400 text-sm mt-1">Analysing the photo</p>
                </div>
              )}
              {liveCapture.phase === 'review' && (
                <>
                  {liveCapture.error && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-amber-800 text-sm">
                      {liveCapture.error}
                    </div>
                  )}
                  <div className="bg-slate-50 rounded-xl p-4">
                    <h4 className="font-bold text-slate-700 mb-3">
                      Values for {liveCapture.rows[liveCapture.rowIndex]?.equipmentId} — {AXIS_LABELS[liveCapture.axisIndex]} ({liveCapture.axisIndex + 1} of 3) — confirm or correct:
                    </h4>
                    <div className="grid grid-cols-1 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">{AXIS_LABELS[liveCapture.axisIndex]} (mm/s)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues[AXES[liveCapture.axisIndex]]}
                          onChange={(e) => setLiveCapture(prev => prev ? { ...prev, readValues: { ...prev.readValues, [AXES[prev.axisIndex]]: e.target.value } } : null)}
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-center font-mono text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="0.00"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={handleConfirmReading} className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors">
                      ✓ Confirm & Next
                    </button>
                    <button onClick={handleCancelCapture} className="px-6 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl transition-colors">
                      Cancel
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
