
import React from 'react';
import { CouponTestReading, CouponToolRow, CouponLocation, CorrosionReadingRow, ObservationRecommendationRow } from '../types';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { FileSpreadsheet, Upload } from 'lucide-react';
import { exportCouponLocationToExcel, parseCouponLocationExcel } from '../utils/excelCoupon';

interface CouponTestTablesProps {
  data: CouponTestReading;
  onChange: (data: CouponTestReading) => void;
  readOnly?: boolean;
}

export const CouponTestTables: React.FC<CouponTestTablesProps> = ({ data, onChange, readOnly = false }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

  const updateField = (field: keyof CouponTestReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addTool = () => {
    const tools = [...(data.toolsUsed || [])];
    tools.push({ id: `tool-${Date.now()}`, name: '', make: '', parameter: '' });
    updateField('toolsUsed', tools);
  };

  const updateTool = (id: string, field: keyof CouponToolRow, value: string) => {
    const tools = data.toolsUsed.map(t => t.id === id ? { ...t, [field]: value } : t);
    updateField('toolsUsed', tools);
  };

  const deleteTool = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this tool record from the audit list?",
      onConfirm: () => {
        updateField('toolsUsed', data.toolsUsed.filter(t => t.id !== id));
      }
    });
  };

  const createInitialCorrosionRows = (): CorrosionReadingRow[] => [
    { id: `cu-${Date.now()}`, couponType: 'Copper (Cu)', oxide: '', chloride: '', sulfide: '', other: '', totalAngstroms: 0, isaLevel: '', remarks: '' },
    { id: `ag-${Date.now() + 1}`, couponType: 'Silver (Ag)', oxide: '', chloride: '', sulfide: '', other: '', totalAngstroms: 0, isaLevel: '', remarks: '' }
  ];

  const addLocation = () => {
    const locs = [...(data.locations || [])];
    locs.push({
      id: `loc-${Date.now()}`,
      locationName: '',
      results: createInitialCorrosionRows(),
      graphImage: ''
    });
    updateField('locations', locs);
  };

  const updateLocationField = (id: string, field: keyof CouponLocation, value: any) => {
    const locs = data.locations.map(l => l.id === id ? { ...l, [field]: value } : l);
    updateField('locations', locs);
  };

  const deleteLocation = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this entire test location and all its corrosion results?",
      onConfirm: () => {
        updateField('locations', data.locations.filter(l => l.id !== id));
      }
    });
  };

  const updateCorrosionReading = (locId: string, rowId: string, field: keyof CorrosionReadingRow, value: string) => {
    const locs = data.locations.map(l => {
      if (l.id === locId) {
        const newResults = l.results.map(r => {
          if (r.id === rowId) {
            const updated: any = { ...r, [field]: value };
            // Calculate Total Angstroms
            const total = (parseFloat(updated.oxide) || 0) + 
                          (parseFloat(updated.chloride) || 0) + 
                          (parseFloat(updated.sulfide) || 0) + 
                          (parseFloat(updated.other) || 0);
            updated.totalAngstroms = total;
            return updated as CorrosionReadingRow;
          }
          return r;
        });
        return { ...l, results: newResults };
      }
      return l;
    });
    updateField('locations', locs);
  };

  const handleImageUpload = (locId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => updateLocationField(locId, 'graphImage', ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleImportExcel = (locationId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async (evt) => {
        if (!evt.target?.result) return;
        const result = await parseCouponLocationExcel(evt.target.result as ArrayBuffer);
        if (result && result.results.length > 0) {
          const newLocs = (data.locations || []).map(loc => {
            if (loc.id === locationId) {
              return {
                ...loc,
                results: result.results.length > 0 ? result.results : loc.results,
                graphImage: result.graphImage || loc.graphImage
              };
            }
            return loc;
          });
          updateField('locations', newLocs);
        } else {
          alert("Could not parse file. Ensure headers match the original export template.");
        }
      };
      reader.readAsArrayBuffer(file);
    };
    input.click();
  };

  return (
    <div className="space-y-10 animate-fade-in pb-20 text-slate-800">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* 2. Header Metadata */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#1e3a8a] px-6 py-3 text-white">
          <h3 className="text-center font-bold uppercase tracking-widest text-xs">Personnel & Test Schedule</h3>
        </div>
        <div className="p-8 grid grid-cols-1 md:grid-cols-5 gap-8">
          {[
            { label: 'Prepared By', field: 'preparedBy', type: 'text' },
            { label: 'Tested By', field: 'testedBy', type: 'text' },
            { label: 'Tester Email', field: 'testerEmail', type: 'email' },
            { label: 'Witnessed By', field: 'witnessedBy', type: 'text' },
            { label: 'Test Date', field: 'testDate', type: 'date' }
          ].map(f => (
            <div key={f.field} className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">{f.label}</label>
              <input 
                type={f.type}
                value={(data as any)[f.field] || ''} 
                onChange={e => updateField(f.field as any, e.target.value)}
                disabled={readOnly}
                className="w-full text-sm font-bold text-slate-700 bg-slate-50 border border-slate-100 rounded-xl p-3 outline-none focus:ring-4 focus:ring-blue-50 focus:border-[#1e3a8a] transition-all"
              />
            </div>
          ))}
        </div>
      </section>

      {/* 3. Tools Used */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#dc2626] px-6 py-4 flex justify-between items-center text-white">
           <div className="flex items-center gap-3">
              <span className="text-xl">🛠️</span>
              <h3 className="font-black uppercase tracking-widest text-sm">4. TOOLS USED FOR AUDIT</h3>
           </div>
           {!readOnly && (
             <button onClick={addTool} className="px-5 py-2 bg-white/20 hover:bg-white/30 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all border border-white/40">+ ADD TOOL</button>
           )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-400 font-black uppercase tracking-tighter border-b border-slate-100">
                <th className="px-6 py-3 w-20 text-center">Sr. No</th>
                <th className="px-6 py-3">Equipment's used for audit</th>
                <th className="px-6 py-3">Make</th>
                <th className="px-6 py-3">Parameter measured</th>
                {!readOnly && <th className="w-12"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.toolsUsed || []).map((tool, idx) => (
                <tr key={tool.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 text-center text-slate-400 font-mono font-bold">{idx + 1}</td>
                  <td className="p-0"><input value={tool.name} onChange={e => updateTool(tool.id, 'name', e.target.value)} disabled={readOnly} className="w-full px-6 py-4 bg-transparent outline-none font-medium" placeholder="Instrument name..." /></td>
                  <td className="p-0"><input value={tool.make} onChange={e => updateTool(tool.id, 'make', e.target.value)} disabled={readOnly} className="w-full px-6 py-4 bg-transparent outline-none" placeholder="Manufacturer..." /></td>
                  <td className="p-0"><input value={tool.parameter} onChange={e => updateTool(tool.id, 'parameter', e.target.value)} disabled={readOnly} className="w-full px-6 py-4 bg-transparent outline-none" placeholder="e.g. Corrosion film..." /></td>
                  {!readOnly && <td className="text-center px-4"><button onClick={() => deleteTool(tool.id)} className="text-slate-300 hover:text-red-500 transition-colors">🗑️</button></td>}
                </tr>
              ))}
              {(data.toolsUsed || []).length === 0 && (
                <tr><td colSpan={5} className="py-10 text-center text-slate-300 italic font-medium">No tools listed. Click "+ ADD TOOL" to initialize.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* 8. Test Results (Locations) */}
      <section className="space-y-12">
        <div className="flex justify-between items-center px-1">
          <h3 className="font-black text-slate-800 tracking-widest text-lg uppercase">8. TEST RESULTS</h3>
          {!readOnly && (
            <button 
              onClick={addLocation}
              className="px-8 py-3 bg-[#1e3a8a] text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-blue-800 transition-all active:scale-95"
            >
              + ADD EXTRA LOCATION
            </button>
          )}
        </div>

        {(data.locations || []).map((loc, locIdx) => (
          <div key={loc.id} className="bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl overflow-hidden animate-fade-in-up border-l-8 border-l-[#1e3a8a]">
            {/* Location Header */}
            <div className="bg-slate-50 px-10 py-8 border-b border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6">
              <div className="flex-1 w-full space-y-2">
                 <label className="text-[10px] font-black text-blue-600 uppercase tracking-widest ml-1">LOCATION NAME / DESCRIPTION</label>
                 <input 
                  value={loc.locationName} 
                  onChange={e => updateLocationField(loc.id, 'locationName', e.target.value)}
                  className="w-full bg-transparent font-black text-2xl text-slate-800 outline-none border-b-2 border-slate-200 focus:border-blue-600 transition-all py-1"
                  placeholder="e.g. Datahall 1 (Cold Aisle Containment)"
                  disabled={readOnly}
                 />
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => exportCouponLocationToExcel(loc, `${loc.locationName || 'Coupon'}_Test_${new Date().toISOString().split('T')[0]}.xlsx`)}
                  className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl hover:bg-emerald-500 hover:text-white transition-all shadow-sm flex items-center gap-2 font-bold text-xs uppercase tracking-widest"
                >
                  <FileSpreadsheet className="w-4 h-4" /> Export
                </button>
                {!readOnly && (
                  <button
                    onClick={() => handleImportExcel(loc.id)}
                    className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl hover:bg-indigo-500 hover:text-white transition-all shadow-sm flex items-center gap-2 font-bold text-xs uppercase tracking-widest"
                  >
                    <Upload className="w-4 h-4" /> Import
                  </button>
                )}
                {!readOnly && (
                  <button onClick={() => deleteLocation(loc.id)} className="p-4 bg-red-50 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all shadow-sm">🗑️</button>
                )}
              </div>
            </div>

            <div className="p-10 space-y-12">
              {/* Part A: Table */}
              <div className="space-y-4">
                 <h4 className="font-black text-[#1e3a8a] uppercase text-sm tracking-widest flex items-center gap-2">
                   <span className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></span>
                   8.{(locIdx * 2) + 1} Corrosion film thickness
                 </h4>
                 <div className="overflow-x-auto rounded-3xl border border-slate-200 shadow-sm">
                    <table className="w-full text-center text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#1e3a8a] text-white font-black uppercase divide-x divide-white/10">
                          <th rowSpan={2} className="py-4 w-40">Type of coupon</th>
                          <th colSpan={4} className="py-2 bg-blue-800/50">Composition of Corrosion</th>
                          <th rowSpan={2} className="py-4 w-32">Total (Å)</th>
                          <th colSpan={2} className="py-2 bg-blue-800/50">ISA Classification</th>
                        </tr>
                        <tr className="bg-[#1e3a8a]/90 text-blue-100 font-bold text-[10px] divide-x divide-white/10 border-t border-white/10">
                          <th className="py-2">Oxide</th>
                          <th className="py-2">Chloride</th>
                          <th className="py-2">Sulfide</th>
                          <th className="py-2">Other</th>
                          <th className="py-2">Level</th>
                          <th className="py-2">Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
{(loc.results).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                        {loc.results.map(row => (
                          <tr key={row.id} className="divide-x divide-slate-100 hover:bg-blue-50/20 transition-colors">
                            <td className="py-4 px-6 font-black text-slate-700 bg-slate-50/50 text-left uppercase tracking-tighter">{row.couponType}</td>
                            <td className="p-0"><input type="number" value={row.oxide} onChange={e => updateCorrosionReading(loc.id, row.id, 'oxide', e.target.value)} disabled={readOnly} className="w-full py-4 text-center bg-transparent outline-none font-medium" placeholder="0" /></td>
                            <td className="p-0"><input type="number" value={row.chloride} onChange={e => updateCorrosionReading(loc.id, row.id, 'chloride', e.target.value)} disabled={readOnly} className="w-full py-4 text-center bg-transparent outline-none font-medium" placeholder="0" /></td>
                            <td className="p-0"><input type="number" value={row.sulfide} onChange={e => updateCorrosionReading(loc.id, row.id, 'sulfide', e.target.value)} disabled={readOnly} className="w-full py-4 text-center bg-transparent outline-none font-medium" placeholder="0" /></td>
                            <td className="p-0"><input type="number" value={row.other} onChange={e => updateCorrosionReading(loc.id, row.id, 'other', e.target.value)} disabled={readOnly} className="w-full py-4 text-center bg-transparent outline-none font-medium" placeholder="0" /></td>
                            <td className="py-4 font-black text-emerald-600 bg-emerald-50 text-sm">{row.totalAngstroms.toFixed(2)}</td>
                            <td className="p-0"><input value={row.isaLevel} onChange={e => updateCorrosionReading(loc.id, row.id, 'isaLevel', e.target.value)} disabled={readOnly} className="w-full py-4 text-center bg-transparent outline-none font-bold text-slate-800" placeholder="e.g. G1" /></td>
                            <td className="p-0"><input value={row.remarks} onChange={e => updateCorrosionReading(loc.id, row.id, 'remarks', e.target.value)} disabled={readOnly} className="w-full py-4 px-4 text-center bg-transparent outline-none italic text-slate-500" placeholder="Condition..." /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                 </div>
              </div>

              {/* Part B: Graphical Representation */}
              <div className="space-y-4">
                 <h4 className="font-black text-[#1e3a8a] uppercase text-sm tracking-widest flex items-center gap-2">
                   <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                   8.{(locIdx * 2) + 2} Graphical Representation of corrosion film thickness
                 </h4>
                 <div className="relative group border-4 border-dashed border-slate-100 rounded-[2rem] h-[400px] flex flex-col items-center justify-center transition-all hover:bg-slate-50 hover:border-blue-200 overflow-hidden">
                    {loc.graphImage ? (
                      <>
                        <img src={loc.graphImage} className="w-full h-full object-contain p-4" alt="Corrosion Graph" />
                        {!readOnly && (
                           <button 
                            onClick={() => updateLocationField(loc.id, 'graphImage', '')}
                            className="absolute top-6 right-6 p-4 bg-red-600 text-white rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity shadow-xl font-bold"
                           >
                            REMOVE GRAPH
                           </button>
                        )}
                      </>
                    ) : (
                      <div className="flex flex-col items-center gap-6">
                         <div className="w-24 h-24 bg-blue-50 rounded-[2rem] flex items-center justify-center text-4xl shadow-inner">📊</div>
                         <div className="text-center">
                            <p className="text-lg font-black text-slate-700">Drop graph file here</p>
                            <p className="text-sm font-medium text-slate-400 mt-1 uppercase tracking-widest">Supports PNG, JPG (Max 5MB)</p>
                         </div>
                         {!readOnly && (
                           <label className="px-10 py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest cursor-pointer shadow-xl hover:bg-blue-700 active:scale-95 transition-all">
                              Select from files
                              <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(loc.id, e)} />
                           </label>
                         )}
                      </div>
                    )}
                 </div>
              </div>
            </div>
          </div>
        ))}

        {data.locations.length === 0 && (
          <div className="py-24 text-center border-4 border-dashed border-slate-100 rounded-[3rem] bg-slate-50/30">
             <span className="text-6xl block mb-6 grayscale opacity-30">📍</span>
             <p className="text-slate-400 font-black uppercase tracking-[0.3em] text-sm">No measurement locations added</p>
             {!readOnly && (
               <button onClick={addLocation} className="mt-8 px-10 py-4 bg-slate-900 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">+ Initialize Location Block</button>
             )}
          </div>
        )}
      </section>

      {/* 9 & 10: Observations & Recommendations */}
      <section className="bg-white rounded-[3rem] border border-slate-200 shadow-2xl p-12 space-y-12 animate-fade-in-up">
         <div className="flex items-center gap-4 border-b border-slate-100 pb-6">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-2xl">📋</div>
            <h3 className="font-black text-slate-800 tracking-[0.2em] uppercase">Audit Summary & Findings</h3>
         </div>
         
         <ObservationsRecommendationsTable 
           data={data.observationsAndRecommendations || []}
           onChange={(val) => updateField('observationsAndRecommendations', val)}
           readOnly={readOnly}
         />
      </section>

    </div>
  );
};

export const INITIAL_COUPON_DATA: CouponTestReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  toolsUsed: [],
  locations: [],
  observationsAndRecommendations: []
};
