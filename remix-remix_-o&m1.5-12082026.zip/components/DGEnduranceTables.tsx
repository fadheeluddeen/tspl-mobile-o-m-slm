
import React, { useRef, useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { Download, Upload, Camera } from 'lucide-react';
import { exportDGEnduranceToExcel } from '../utils/excelExport';
import { DGEnduranceReading, DGUnit, DGLoadReadingRow, DGFuelSummaryRow, SPOFEquipmentRow, LiveCaptureConfig } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { readSingleInstrumentDisplay } from '../services/geminiClient';

const calculateFuelRow = (row: DGFuelSummaryRow): DGFuelSummaryRow => {
  const kwhInitial = parseFloat(row.kwhInitial) || 0;
  const kwhFinal = parseFloat(row.kwhFinal) || 0;
  const kwhUnits = (kwhFinal - kwhInitial).toString();

  const fuelInitial = parseFloat(row.fuelInitial) || 0;
  const fuelFinal = parseFloat(row.fuelFinal) || 0;
  const fuelConsum = (fuelFinal - fuelInitial).toString();

  const unitsNum = parseFloat(kwhUnits);
  const consumNum = parseFloat(fuelConsum);
  const efficiency = consumNum > 0 ? (unitsNum / consumNum).toFixed(2) : '0.00';

  return {
    ...row,
    kwhUnits,
    fuelConsum,
    efficiency
  };
};

interface DGEnduranceTablesProps {
  data: DGEnduranceReading;
  onChange: (data: DGEnduranceReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

interface DGEnduranceCaptureStep {
  unitId: string;
  unitName: string;
  tableKey: 'T1' | 'T3' | 'T4' | 'T5';
  tableName: string;
  loadKey?: string;
  loadLabel: string;
  paramId?: string;
  paramName?: string;
  fieldKey: string;
  fieldLabel: string;
  unit?: string;
  readingGuidance: string;
}

const isMechanicalParam = (paramName: string) => {
  const p = (paramName || '').toLowerCase();
  return p.includes('speed') || p.includes('pressure') || p.includes('temp') || p.includes('battery');
};

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 hover:text-red-500 transition-colors"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

export const DGEnduranceTables: React.FC<DGEnduranceTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = true,
  liveCaptureConfig
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast, showToast } = useConfirmDelete();

  // Scope selection state
  const [scopeModalOpen, setScopeModalOpen] = useState(false);
  const [selectedUnitScope, setSelectedUnitScope] = useState<string>('ALL');
  const [selectedTableScope, setSelectedTableScope] = useState<string>('ALL');

  // Live capture wizard state
  const [liveCapture, setLiveCapture] = useState<{
    queue: DGEnduranceCaptureStep[];
    stepIndex: number;
    phase: 'camera' | 'reading' | 'review';
    readValue: string;
    error: string;
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: any) {
      console.error('Camera error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? {
          ...prev,
          phase: 'review',
          readValue: '',
          error: 'Camera permission denied or unavailable. Please enter value manually below.'
        } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;
    const currentStep = liveCapture.queue[liveCapture.stepIndex];
    if (!currentStep) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;

    let width = video.videoWidth || 640;
    let height = video.videoHeight || 480;
    const maxDim = 1280;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.floor(height * (maxDim / width));
        width = maxDim;
      } else {
        width = Math.floor(width * (maxDim / height));
        height = maxDim;
      }
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);

    try {
      const val = await readSingleInstrumentDisplay(
        base64,
        currentStep.fieldLabel,
        currentStep.unit || '',
        currentStep.readingGuidance
      );
      setLiveCapture(prev => prev ? { ...prev, phase: 'review', readValue: val, error: '' } : null);
    } catch (err: any) {
      console.error('Gemini OCR Error:', err);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        readValue: '',
        error: `Could not read display automatically (${err?.message || 'Error'}). Please enter value manually.`
      } : null);
    }
  };

  const confirmCaptureValue = () => {
    if (!liveCapture) return;
    const currentStep = liveCapture.queue[liveCapture.stepIndex];
    if (!currentStep) return;

    const valStr = liveCapture.readValue.trim();

    const newUnits = (data.dgUnits || []).map(unit => {
      if (unit.id !== currentStep.unitId) return unit;

      if (currentStep.tableKey === 'T1' && currentStep.paramId && currentStep.loadKey) {
        const newReadings = unit.loadReadings.map(row => {
          if (row.id === currentStep.paramId) {
            return { ...row, [currentStep.loadKey!]: valStr };
          }
          return row;
        });
        return { ...unit, loadReadings: newReadings };
      }

      if (currentStep.tableKey === 'T3' && currentStep.loadKey && currentStep.fieldKey) {
        const newNoise = unit.noiseLevels.map(row => {
          if (row.load === currentStep.loadKey) {
            return { ...row, [currentStep.fieldKey]: valStr };
          }
          return row;
        });
        return { ...unit, noiseLevels: newNoise };
      }

      if (currentStep.tableKey === 'T4' && currentStep.loadKey && currentStep.fieldKey) {
        const newVib = unit.vibrationLevels.map(row => {
          if (row.load === currentStep.loadKey) {
            return { ...row, [currentStep.fieldKey]: valStr };
          }
          return row;
        });
        return { ...unit, vibrationLevels: newVib };
      }

      if (currentStep.tableKey === 'T5' && currentStep.paramId && currentStep.fieldKey) {
        const newFuel = unit.fuelSummary.map(row => {
          if (row.id === currentStep.paramId) {
            const updatedRow = { ...row, [currentStep.fieldKey]: valStr };
            return calculateFuelRow(updatedRow);
          }
          return row;
        });
        return { ...unit, fuelSummary: newFuel };
      }

      return unit;
    });

    updateField('dgUnits', newUnits);

    const nextIndex = liveCapture.stepIndex + 1;
    if (nextIndex < liveCapture.queue.length) {
      setLiveCapture(prev => prev ? {
        ...prev,
        stepIndex: nextIndex,
        phase: 'camera',
        readValue: '',
        error: ''
      } : null);
    } else {
      stopCamera();
      setLiveCapture(null);
      showToast('Live capture sequence completed successfully!', 'success');
    }
  };

  const skipCaptureStep = () => {
    if (!liveCapture) return;
    const nextIndex = liveCapture.stepIndex + 1;
    if (nextIndex < liveCapture.queue.length) {
      setLiveCapture(prev => prev ? {
        ...prev,
        stepIndex: nextIndex,
        phase: 'camera',
        readValue: '',
        error: ''
      } : null);
    } else {
      stopCamera();
      setLiveCapture(null);
    }
  };

  const handleCancelCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  useEffect(() => {
    if (liveCapture?.phase === 'camera') {
      startCamera();
    }
    return () => {
      if (liveCapture?.phase === 'camera') {
        stopCamera();
      }
    };
  }, [liveCapture?.phase, liveCapture?.stepIndex]);

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const buildStepQueue = (unitId: string, scopeKey: string): DGEnduranceCaptureStep[] => {
    const targetUnits = unitId === 'ALL' 
      ? data.dgUnits 
      : data.dgUnits.filter(u => u.id === unitId);

    const steps: DGEnduranceCaptureStep[] = [];

    targetUnits.forEach(unit => {
      // Scope: T1
      if (scopeKey === 'ALL' || scopeKey.startsWith('T1')) {
        const loadKeysToInclude: { key: 'v0' | 'v25' | 'v50' | 'v75' | 'v100'; label: string }[] = [];
        if (scopeKey === 'T1_0' || scopeKey === 'ALL' || scopeKey === 'T1') loadKeysToInclude.push({ key: 'v0', label: '0% Load' });
        if (scopeKey === 'T1_25' || scopeKey === 'ALL' || scopeKey === 'T1') loadKeysToInclude.push({ key: 'v25', label: '25% Load' });
        if (scopeKey === 'T1_50' || scopeKey === 'ALL' || scopeKey === 'T1') loadKeysToInclude.push({ key: 'v50', label: '50% Load' });
        if (scopeKey === 'T1_75' || scopeKey === 'ALL' || scopeKey === 'T1') loadKeysToInclude.push({ key: 'v75', label: '75% Load' });
        if (scopeKey === 'T1_100' || scopeKey === 'ALL' || scopeKey === 'T1') loadKeysToInclude.push({ key: 'v100', label: '100% Load' });

        unit.loadReadings.forEach(row => {
          const isMech = isMechanicalParam(row.parameter);
          const guidance = isMech
            ? 'Read from the DG panel/gauge display — read the single labelled value in its shown unit. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values. One value per photo.'
            : 'Read from the Power Quality Analyzer / Clamp Meter (MECO 1080) — read the single labelled value in its shown unit. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values. One value per photo.';

          loadKeysToInclude.forEach(lk => {
            steps.push({
              unitId: unit.id,
              unitName: unit.unitName,
              tableKey: 'T1',
              tableName: 'T1 Parameter Matrix',
              loadKey: lk.key,
              loadLabel: lk.label,
              paramId: row.id,
              paramName: row.parameter,
              fieldKey: lk.key,
              fieldLabel: `${row.parameter} @ ${lk.label}`,
              unit: row.unit,
              readingGuidance: guidance
            });
          });
        });
      }

      // Scope: T3 Noise
      if (scopeKey === 'ALL' || scopeKey === 'T3') {
        const noiseGuidance = 'Read from the Sound Level Meter (WINTACT WT85B) — the dB(A) value. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.';
        unit.noiseLevels.forEach(row => {
          steps.push({
            unitId: unit.id,
            unitName: unit.unitName,
            tableKey: 'T3',
            tableName: 'T3 Noise Level Measurement',
            loadKey: row.load,
            loadLabel: `${row.load} Load`,
            fieldKey: 'open',
            fieldLabel: `Doors Open Noise @ ${row.load} Load`,
            unit: 'dB',
            readingGuidance: noiseGuidance
          });
          steps.push({
            unitId: unit.id,
            unitName: unit.unitName,
            tableKey: 'T3',
            tableName: 'T3 Noise Level Measurement',
            loadKey: row.load,
            loadLabel: `${row.load} Load`,
            fieldKey: 'closed',
            fieldLabel: `Doors Closed Noise @ ${row.load} Load`,
            unit: 'dB',
            readingGuidance: noiseGuidance
          });
        });
      }

      // Scope: T4 Vibration
      if (scopeKey === 'ALL' || scopeKey === 'T4') {
        const vibGuidance = 'Read from the Vibration Meter (WINTACT WT63B) — the overall velocity/vibration value in the shown unit. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.';
        const points = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'] as const;
        unit.vibrationLevels.forEach(row => {
          points.forEach(pk => {
            steps.push({
              unitId: unit.id,
              unitName: unit.unitName,
              tableKey: 'T4',
              tableName: 'T4 Vibration Level Measurement',
              loadKey: row.load,
              loadLabel: `${row.load} Load`,
              fieldKey: pk,
              fieldLabel: `Vibration Point ${pk.toUpperCase()} @ ${row.load} Load`,
              unit: 'm/s²',
              readingGuidance: vibGuidance
            });
          });
        });
      }

      // Scope: T5 Fuel
      if (scopeKey === 'ALL' || scopeKey === 'T5') {
        unit.fuelSummary.forEach(row => {
          const kwhGuidance = 'Read the numeric totalizer/gauge value shown on the meter for initial kWh. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.';
          const fuelGuidance = 'Read the numeric fuel level gauge value shown for initial fuel in litres. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.';

          steps.push({
            unitId: unit.id,
            unitName: unit.unitName,
            tableKey: 'T5',
            tableName: 'T5 Fuel Consumption Summary',
            paramId: row.id,
            loadLabel: row.percentLoad && row.percentLoad !== '---' ? `${row.percentLoad} Load` : `Entry #${row.srNo}`,
            fieldKey: 'kwhInitial',
            fieldLabel: `kWh Generated Initial (${row.percentLoad || 'Entry ' + row.srNo})`,
            unit: 'kWh',
            readingGuidance: kwhGuidance
          });

          steps.push({
            unitId: unit.id,
            unitName: unit.unitName,
            tableKey: 'T5',
            tableName: 'T5 Fuel Consumption Summary',
            paramId: row.id,
            loadLabel: row.percentLoad && row.percentLoad !== '---' ? `${row.percentLoad} Load` : `Entry #${row.srNo}`,
            fieldKey: 'kwhFinal',
            fieldLabel: `kWh Generated Final (${row.percentLoad || 'Entry ' + row.srNo})`,
            unit: 'kWh',
            readingGuidance: kwhGuidance
          });

          steps.push({
            unitId: unit.id,
            unitName: unit.unitName,
            tableKey: 'T5',
            tableName: 'T5 Fuel Consumption Summary',
            paramId: row.id,
            loadLabel: row.percentLoad && row.percentLoad !== '---' ? `${row.percentLoad} Load` : `Entry #${row.srNo}`,
            fieldKey: 'fuelInitial',
            fieldLabel: `Fuel in Litres Initial (${row.percentLoad || 'Entry ' + row.srNo})`,
            unit: 'Litres',
            readingGuidance: fuelGuidance
          });

          steps.push({
            unitId: unit.id,
            unitName: unit.unitName,
            tableKey: 'T5',
            tableName: 'T5 Fuel Consumption Summary',
            paramId: row.id,
            loadLabel: row.percentLoad && row.percentLoad !== '---' ? `${row.percentLoad} Load` : `Entry #${row.srNo}`,
            fieldKey: 'fuelFinal',
            fieldLabel: `Fuel in Litres Final (${row.percentLoad || 'Entry ' + row.srNo})`,
            unit: 'Litres',
            readingGuidance: fuelGuidance
          });
        });
      }
    });

    return steps;
  };

  const startScopeCapture = (unitId: string, scopeKey: string) => {
    const queue = buildStepQueue(unitId, scopeKey);
    if (queue.length === 0) {
      showToast('No instrument-read cells available for the selected scope.', 'error');
      return;
    }

    setScopeModalOpen(false);
    setLiveCapture({
      queue,
      stepIndex: 0,
      phase: 'camera',
      readValue: '',
      error: ''
    });
  };

  const handleExportExcel = () => {
    exportDGEnduranceToExcel(data, `DG_Endurance_Test_${new Date().toISOString().split('T')[0]}.xlsx`);
    showToast('Exported DG Endurance tables to Excel!', 'success');
  };

  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const dataContent = evt.target?.result;
        const workbook = XLSX.read(dataContent, { type: 'binary' });
        
        let newDgUnits = [...(data.dgUnits || [])];

        workbook.SheetNames.forEach(sheetName => {
          const match = sheetName.match(/^DG(\d+) - (.*)$/);
          if (!match) return;
          const uIdx = parseInt(match[1]) - 1;
          const tableType = match[2];
          
          if (!newDgUnits[uIdx]) {
            newDgUnits[uIdx] = {
              id: `dg-imported-${Date.now()}-${uIdx}`,
              unitName: `DC-01 DG-${(uIdx + 1).toString().padStart(2, '0')}`,
              standardInfo: { description: '---', standardNumber: '---', author: '---', category: '---', subcategory: '---', performedDate: '---' },
              equipmentDetails: { make: '---', model: '---', nomenclature: '---', engineNumber: '---', alternatorSerial: '---', location: '---' },
              loadReadings: [],
              transientSummary: [],
              noiseLevels: [],
              vibrationLevels: [],
              fuelSummary: []
            };
          }

          const worksheet = workbook.Sheets[sheetName];
          const rows: any[] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          if (rows.length === 0) return;

          let headerRowIndex = -1;
          for (let i = 0; i < Math.min(10, rows.length); i++) {
            if (rows[i] && rows[i].length > 0) {
              headerRowIndex = i;
              break;
            }
          }
          if (headerRowIndex === -1) return;

          const headers = rows[headerRowIndex].map((h: any) => String(h || '').trim());
          const unit = newDgUnits[uIdx];

          if (tableType === 'Parameters') {
            const pIdx = headers.indexOf('Parameter');
            const uIdxHead = headers.indexOf('Unit');
            const remIdx = headers.indexOf('Remarks');
            
            const v0Idx = headers.findIndex(h => h === '0' || h === '0%');
            const v25Idx = headers.findIndex(h => h === '25' || h === '25%');
            const v50Idx = headers.findIndex(h => h === '50' || h === '50%');
            const v75Idx = headers.findIndex(h => h === '75' || h === '75%');
            const v100Idx = headers.findIndex(h => h === '100' || h === '100%');

            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const paramName = pIdx >= 0 ? String(rowData[pIdx] || '') : '';
              if (!paramName) continue;
              
              const existingRow = unit.loadReadings.find(r => r.parameter === paramName);
              if (existingRow) {
                if (uIdxHead >= 0) existingRow.unit = String(rowData[uIdxHead] ?? existingRow.unit);
                if (v0Idx >= 0) existingRow.v0 = String(rowData[v0Idx] ?? existingRow.v0);
                if (v25Idx >= 0) existingRow.v25 = String(rowData[v25Idx] ?? existingRow.v25);
                if (v50Idx >= 0) existingRow.v50 = String(rowData[v50Idx] ?? existingRow.v50);
                if (v75Idx >= 0) existingRow.v75 = String(rowData[v75Idx] ?? existingRow.v75);
                if (v100Idx >= 0) existingRow.v100 = String(rowData[v100Idx] ?? existingRow.v100);
                if (remIdx >= 0) existingRow.remarks = String(rowData[remIdx] ?? existingRow.remarks);
              } else {
                unit.loadReadings.push({
                  id: `row-${Math.random()}`,
                  parameter: paramName,
                  unit: uIdxHead >= 0 ? String(rowData[uIdxHead] || '') : '',
                  v0: v0Idx >= 0 ? String(rowData[v0Idx] || '') : '',
                  v25: v25Idx >= 0 ? String(rowData[v25Idx] || '') : '',
                  v50: v50Idx >= 0 ? String(rowData[v50Idx] || '') : '',
                  v75: v75Idx >= 0 ? String(rowData[v75Idx] || '') : '',
                  v100: v100Idx >= 0 ? String(rowData[v100Idx] || '') : '',
                  remarks: remIdx >= 0 ? String(rowData[remIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Transient Load') {
            const sIdx = headers.indexOf('Sr No');
            const lIdx = headers.indexOf('Transient Load');
            const rIdx = headers.indexOf('Result');
            
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const loadName = lIdx >= 0 ? String(rowData[lIdx] || '') : '';
              if (!loadName) continue;

              const existingRow = unit.transientSummary.find(r => r.load === loadName);
              if (existingRow) {
                if (sIdx >= 0) existingRow.srNo = String(rowData[sIdx] ?? existingRow.srNo);
                if (rIdx >= 0) existingRow.result = String(rowData[rIdx] ?? existingRow.result);
              } else {
                unit.transientSummary.push({
                  id: `row-${Math.random()}`,
                  srNo: sIdx >= 0 ? String(rowData[sIdx] || '') : '',
                  load: loadName,
                  result: rIdx >= 0 ? String(rowData[rIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Noise Level') {
            const lIdx = headers.indexOf('Load in %');
            const oIdx = headers.indexOf('Doors Open');
            const cIdx = headers.indexOf('Doors Closed');
            
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const loadName = lIdx >= 0 ? String(rowData[lIdx] || '') : '';
              if (!loadName) continue;

              const existingRow = unit.noiseLevels.find(r => r.load === loadName);
              if (existingRow) {
                if (oIdx >= 0) existingRow.open = String(rowData[oIdx] ?? existingRow.open);
                if (cIdx >= 0) existingRow.closed = String(rowData[cIdx] ?? existingRow.closed);
              } else {
                unit.noiseLevels.push({
                  load: loadName,
                  open: oIdx >= 0 ? String(rowData[oIdx] || '') : '',
                  closed: cIdx >= 0 ? String(rowData[cIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Vibration') {
            const lIdx = headers.indexOf('Load %');
            const aIdx = headers.indexOf('A');
            const bIdx = headers.indexOf('B');
            const cIdx = headers.indexOf('C');
            const dIdx = headers.indexOf('D');
            const eIdx = headers.indexOf('E');
            const fIdx = headers.indexOf('F');
            const gIdx = headers.indexOf('G');
            const hIdx = headers.indexOf('H');
            
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const loadName = lIdx >= 0 ? String(rowData[lIdx] || '') : '';
              if (!loadName) continue;

              const existingRow = unit.vibrationLevels.find(r => r.load === loadName);
              if (existingRow) {
                if (aIdx >= 0) existingRow.a = String(rowData[aIdx] ?? existingRow.a);
                if (bIdx >= 0) existingRow.b = String(rowData[bIdx] ?? existingRow.b);
                if (cIdx >= 0) existingRow.c = String(rowData[cIdx] ?? existingRow.c);
                if (dIdx >= 0) existingRow.d = String(rowData[dIdx] ?? existingRow.d);
                if (eIdx >= 0) existingRow.e = String(rowData[eIdx] ?? existingRow.e);
                if (fIdx >= 0) existingRow.f = String(rowData[fIdx] ?? existingRow.f);
                if (gIdx >= 0) existingRow.g = String(rowData[gIdx] ?? existingRow.g);
                if (hIdx >= 0) existingRow.h = String(rowData[hIdx] ?? existingRow.h);
              } else {
                unit.vibrationLevels.push({
                  load: loadName,
                  a: aIdx >= 0 ? String(rowData[aIdx] || '') : '',
                  b: bIdx >= 0 ? String(rowData[bIdx] || '') : '',
                  c: cIdx >= 0 ? String(rowData[cIdx] || '') : '',
                  d: dIdx >= 0 ? String(rowData[dIdx] || '') : '',
                  e: eIdx >= 0 ? String(rowData[eIdx] || '') : '',
                  f: fIdx >= 0 ? String(rowData[fIdx] || '') : '',
                  g: gIdx >= 0 ? String(rowData[gIdx] || '') : '',
                  h: hIdx >= 0 ? String(rowData[hIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Fuel Consum' || tableType === 'Fuel Consumption') {
            const sIdx = headers.indexOf('Sr No');
            const pLIdx = headers.indexOf('% LOAD');
            const tIdx = headers.indexOf('TIME');
            const kiIdx = headers.indexOf('kWh Generated Initial');
            const kfIdx = headers.indexOf('kWh Generated Final');
            const fiIdx = headers.indexOf('Fuel in Litres Initial');
            const ffIdx = headers.indexOf('Fuel in Litres Final');
            const stdIdx = headers.indexOf('OEM Std (L/H)');
            
            unit.fuelSummary = []; // clear to replace or we can try to merge by srNo
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const srNo = sIdx >= 0 ? String(rowData[sIdx] || '') : '';
              if (!srNo && !rowData[kiIdx]) continue;
              
              const rowObj = {
                id: `f-${Date.now()}-${i}`,
                srNo: srNo,
                percentLoad: pLIdx >= 0 ? String(rowData[pLIdx] ?? '---') : '---',
                time: tIdx >= 0 ? String(rowData[tIdx] ?? '---') : '---',
                kwhInitial: kiIdx >= 0 ? String(rowData[kiIdx] ?? '0') : '0',
                kwhFinal: kfIdx >= 0 ? String(rowData[kfIdx] ?? '0') : '0',
                kwhUnits: '0',
                fuelInitial: fiIdx >= 0 ? String(rowData[fiIdx] ?? '0') : '0',
                fuelFinal: ffIdx >= 0 ? String(rowData[ffIdx] ?? '0') : '0',
                fuelConsum: '0',
                oemStd: stdIdx >= 0 ? String(rowData[stdIdx] ?? '---') : '---',
                efficiency: '0.00'
              };
              unit.fuelSummary.push(calculateFuelRow(rowObj));
            }
          }
        });
        
        updateField('dgUnits', newDgUnits);
        showToast("DG Endurance data imported successfully!", "success");
      } catch (err) {
        console.error(err);
        showToast("Failed to parse Excel file.", "error");
      }
    };
    reader.readAsBinaryString(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const fileInputRef = useRef<HTMLInputElement>(null);


  const updateField = (field: keyof DGEnduranceReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const updateDGUnit = (unitId: string, updates: Partial<DGUnit>) => {
    if (readOnly) return;
    const newUnits = data.dgUnits.map(u => u.id === unitId ? { ...u, ...updates } : u);
    updateField('dgUnits', newUnits);
  };

  const addDGUnit = () => {
    const newId = `dg-${Date.now()}`;
    const newUnit: DGUnit = {
      id: newId,
      unitName: `DC-01 DG-${(data.dgUnits.length + 1).toString().padStart(2, '0')}`,
      standardInfo: { 
        description: '---', 
        standardNumber: '---', 
        author: 'Technavious Solutions', 
        category: 'Load Test - Test Report', 
        subcategory: 'Routine Test for DG', 
        performedDate: '---' 
      },
      equipmentDetails: { 
        make: '---', 
        model: '---', 
        nomenclature: '---', 
        engineNumber: '---', 
        alternatorSerial: '---', 
        location: '---' 
      },
      loadReadings: INITIAL_LOAD_PARAMS.map(p => ({ ...p, id: `row-${Math.random()}` })),
      transientSummary: [
        { id: '1', srNo: '1', load: '0% to 36%', result: 'PASS/FAIL' },
        { id: '2', srNo: '2', load: '36% to 61%', result: 'PASS/FAIL' },
        { id: '3', srNo: '3', load: '61% to 88 %', result: 'PASS/FAIL' },
        { id: '4', srNo: '4', load: '88% to 100 %', result: 'PASS/FAIL' },
      ],
      noiseLevels: [
        { load: '25%', open: '0.0', closed: '0.0' },
        { load: '50%', open: '0.0', closed: '0.0' },
        { load: '75%', open: '0.0', closed: '0.0' },
        { load: '100%', open: '0.0', closed: '0.0' },
      ],
      vibrationLevels: [
        { load: '25%', a: '0.0', b: '0.0', c: '0.0', d: '0.0', e: '0.0', f: '0.0', g: '0.0', h: '0.0' },
        { load: '50%', a: '0.0', b: '0.0', c: '0.0', d: '0.0', e: '0.0', f: '0.0', g: '0.0', h: '0.0' },
        { load: '75%', a: '0.0', b: '0.0', c: '0.0', d: '0.0', e: '0.0', f: '0.0', g: '0.0', h: '0.0' },
        { load: '100%', a: '0.0', b: '0.0', c: '0.0', d: '0.0', e: '0.0', f: '0.0', g: '0.0', h: '0.0' },
      ],
      fuelSummary: [
        { id: `f-${Date.now()}`, srNo: '1', percentLoad: '---', time: '---', kwhInitial: '0', kwhFinal: '0', kwhUnits: '0', fuelInitial: '0', fuelFinal: '0', fuelConsum: '0', oemStd: '---', efficiency: '0.00' }
      ]
    };
    updateField('dgUnits', [...data.dgUnits, newUnit]);
  };

  const addFuelEntry = (unitId: string) => {
    const unit = data.dgUnits.find(u => u.id === unitId);
    if (!unit) return;
    const newEntry: DGFuelSummaryRow = {
      id: `f-${Date.now()}`,
      srNo: (unit.fuelSummary.length + 1).toString(),
      percentLoad: '---',
      time: '---',
      kwhInitial: '0',
      kwhFinal: '0',
      kwhUnits: '0',
      fuelInitial: '0',
      fuelFinal: '0',
      fuelConsum: '0',
      oemStd: '---',
      efficiency: '0.00'
    };
    updateDGUnit(unitId, { fuelSummary: [...unit.fuelSummary, newEntry] });
  };

  return (
    <div className="space-y-12 animate-fade-in font-sans pb-20 text-slate-800">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />

      <div className="flex justify-end gap-3 px-2">
        {aiEnabled && !readOnly && (
          <button
            onClick={() => setScopeModalOpen(true)}
            className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white text-sm font-bold rounded-lg transition-colors flex items-center gap-2 shadow-sm"
          >
            <Camera className="w-4 h-4" /> Live Capture
          </button>
        )}
        {!readOnly && (
          <>
            <input 
              type="file" 
              accept=".xlsx, .xls" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleImportExcel} 
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-bold rounded-lg transition-colors flex items-center gap-2"
            >
              <Upload className="w-4 h-4" /> Import Excel
            </button>
          </>
        )}
        <button
          onClick={handleExportExcel}
          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold rounded-lg transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4" /> Export Excel
        </button>
      </div>
      
      {/* PERSONNEL DETAILS (Orange Header) */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white">
          <h3 className="text-center font-bold uppercase tracking-wider text-xs">Test Personnel & Schedule</h3>
        </div>
        <div className="p-8 grid grid-cols-1 md:grid-cols-5 gap-8">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f]} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                className="w-full text-sm font-bold text-slate-700 bg-slate-50 border border-slate-100 rounded-xl p-3 outline-none focus:ring-4 focus:ring-orange-50 focus:border-orange-500 transition-all"
              />
            </div>
          ))}
        </div>
      </section>

      {/* ON SITE DESCRIPTION (Orange Row Headers) */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <span className="text-xl">📋</span>
          <h3 className="font-black text-slate-900 uppercase tracking-widest text-sm">On Site Test Description</h3>
        </div>
        <div className="overflow-x-auto p-4 bg-slate-50/50">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
             <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 italic text-[10px] text-slate-400 font-bold uppercase tracking-widest">Verification Checklist for Formal DG Testing Phases</div>
             <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-[#F97316] text-white font-black uppercase tracking-tighter">
                    <th className="px-6 py-3 w-20 text-center border-r border-white/10">Sr. No.</th>
                    <th className="px-6 py-3 border-r border-white/10">Test Description</th>
                    <th className="px-6 py-3 w-32 text-center">Result</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-bold">
{(data.onSiteTests).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                  {data.onSiteTests.map((row) => (
                    <tr key={row.id}>
                      <td className="px-6 py-4 text-center border-r border-slate-100 text-slate-400 font-mono">{row.srNo}</td>
                      <td className="px-6 py-4 border-r border-slate-100 text-slate-700">{row.description}</td>
                      <td className="px-6 py-4 text-center">
                        <button 
                          onClick={() => !readOnly && updateField('onSiteTests', data.onSiteTests.map(r => r.id === row.id ? { ...r, result: !r.result } : r))}
                          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${row.result ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-100' : 'bg-slate-100 text-slate-300'}`}
                        >
                          {row.result ? '✓' : ''}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
             </table>
          </div>
        </div>
      </section>

      {/* EQUIPMENT DETAIL (Orange Header) */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 flex justify-between items-center bg-white border-b border-slate-100">
           <div className="flex items-center gap-3">
              <span className="text-xl">🛠️</span>
              <h3 className="font-black text-slate-800 uppercase tracking-widest text-sm">Testing & Commissioning Equipment</h3>
           </div>
           {!readOnly && (
             <button onClick={() => updateField('equipmentList', [...data.equipmentList, { id: Date.now().toString(), name: '', make: '', model: '', serialNo: '', calDate: '', expDate: '' }])} className="px-4 py-2 border-2 border-orange-500 text-orange-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-50 transition-all">+ Add Equipment</button>
           )}
        </div>
        <div className="overflow-x-auto p-4 bg-slate-50/50">
           <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 italic text-[10px] text-slate-400 font-bold uppercase tracking-widest">Standardized Instrumentation Calibration Tracking</div>
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#F97316] text-white font-black uppercase tracking-tighter divide-x divide-white/10">
                    <th className="px-6 py-3">Equipment Name</th>
                    <th className="px-6 py-3">Model</th>
                    <th className="px-6 py-3">Serial No.</th>
                    <th colSpan={2} className="px-6 py-3 text-center">Calibration Date</th>
                  </tr>
                  <tr className="bg-[#FFBD88] text-white font-black uppercase tracking-widest text-[9px] border-t border-white/10 divide-x divide-white/10">
                    <th colSpan={3}></th>
                    <th className="py-2 text-center">Issue</th>
                    <th className="py-2 text-center">Expiry</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
{(data.equipmentList).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                  {data.equipmentList.map((eq) => (
                    <tr key={eq.id} className="divide-x divide-slate-100 font-bold hover:bg-slate-50 transition-colors">
                      <td className="p-0"><input value={eq.name} onChange={e => updateField('equipmentList', data.equipmentList.map(item => item.id === eq.id ? { ...item, name: e.target.value } : item))} className="w-full px-6 py-4 bg-transparent outline-none text-slate-700" placeholder="Equipment Name..." disabled={readOnly} /></td>
                      <td className="p-0"><input value={eq.model} onChange={e => updateField('equipmentList', data.equipmentList.map(item => item.id === eq.id ? { ...item, model: e.target.value } : item))} className="w-full px-6 py-4 bg-transparent outline-none text-slate-700" placeholder="Model..." disabled={readOnly} /></td>
                      <td className="p-0"><input value={eq.serialNo} onChange={e => updateField('equipmentList', data.equipmentList.map(item => item.id === eq.id ? { ...item, serialNo: e.target.value } : item))} className="w-full px-6 py-4 bg-transparent outline-none text-slate-700" placeholder="Serial number..." disabled={readOnly} /></td>
                      <td className="p-0"><input type="text" value={eq.calDate} onChange={e => updateField('equipmentList', data.equipmentList.map(item => item.id === eq.id ? { ...item, calDate: e.target.value } : item))} className="w-full px-6 py-4 bg-transparent outline-none text-center text-slate-500" placeholder="YYYY-MM-DD" disabled={readOnly} /></td>
                      <td className="p-0"><input type="text" value={eq.expDate} onChange={e => updateField('equipmentList', data.equipmentList.map(item => item.id === eq.id ? { ...item, expDate: e.target.value } : item))} className="w-full px-6 py-4 bg-transparent outline-none text-center text-slate-500" placeholder="YYYY-MM-DD" disabled={readOnly} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
           </div>
        </div>
      </section>

      {/* DG REPEATABLE SECTIONS */}
      {data.dgUnits.map((unit) => (
        <div key={unit.id} className="space-y-8 p-10 bg-[#0F172A] rounded-[3rem] shadow-2xl animate-fade-in-up border-4 border-slate-800">
           <div className="flex justify-between items-center border-b border-slate-700 pb-8">
              <div className="flex items-center gap-6">
                 <div className="w-16 h-16 bg-[#DC2626] rounded-2xl flex items-center justify-center shadow-lg shadow-red-900/20">
                    <span className="text-white text-3xl">⚡</span>
                 </div>
                 <div>
                    <input 
                      value={unit.unitName} 
                      onChange={e => updateDGUnit(unit.id, { unitName: e.target.value })}
                      className="bg-transparent text-white font-black text-4xl tracking-tighter outline-none focus:border-b-2 border-red-500 w-full"
                    />
                    <p className="text-red-500 font-bold text-xs uppercase tracking-[0.4em] mt-1">Diesel Generator Endurance Block</p>
                 </div>
              </div>
              <div className="flex gap-4">
                 <div className="flex bg-slate-800 rounded-xl px-4 py-2 gap-4 border border-slate-700">
                   <input type="text" className="bg-transparent text-slate-300 font-mono text-xs outline-none" placeholder="dd-mm-yyyy" />
                   <span className="text-slate-600">-</span>
                   <input type="text" className="bg-transparent text-slate-300 font-mono text-xs outline-none" placeholder="dd-mm-yyyy" />
                 </div>
                 {!readOnly && (
                   <button 
                    onClick={() => {
                      confirmDelete({
                        message: "Are you sure you want to delete this Entire DG Unit and its records?",
                        onConfirm: () => {
                          updateField('dgUnits', data.dgUnits.filter(u => u.id !== unit.id));
                        }
                      });
                    }} 
                    className="w-12 h-12 bg-red-900/30 text-red-500 rounded-2xl flex items-center justify-center hover:bg-red-500 hover:text-white transition-all text-xl"
                   >
                     🗑️
                   </button>
                 )}
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Standard Information Table */}
              <div className="space-y-4">
                 <h4 className="text-red-500 font-black uppercase text-[11px] tracking-widest flex items-center gap-2"><span>ⓘ</span> STANDARD INFORMATION</h4>
                 <div className="bg-white rounded-2xl overflow-hidden shadow-xl border border-slate-100">
                    <table className="w-full text-xs">
                       <tbody className="divide-y divide-slate-100 font-bold text-slate-800">
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Standard Number</td>
                            <td className="p-0"><input value={unit.standardInfo.standardNumber} onChange={e => updateDGUnit(unit.id, { standardInfo: { ...unit.standardInfo, standardNumber: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Author</td>
                            <td className="p-0"><input value={unit.standardInfo.author} onChange={e => updateDGUnit(unit.id, { standardInfo: { ...unit.standardInfo, author: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Performed Date</td>
                            <td className="p-0"><input value={unit.standardInfo.performedDate} onChange={e => updateDGUnit(unit.id, { standardInfo: { ...unit.standardInfo, performedDate: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none font-mono" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Category</td>
                            <td className="p-0"><input value={unit.standardInfo.category} onChange={e => updateDGUnit(unit.id, { standardInfo: { ...unit.standardInfo, category: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Subcategory</td>
                            <td className="p-0"><input value={unit.standardInfo.subcategory} onChange={e => updateDGUnit(unit.id, { standardInfo: { ...unit.standardInfo, subcategory: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Description</td>
                            <td className="p-0"><input value={unit.standardInfo.description} onChange={e => updateDGUnit(unit.id, { standardInfo: { ...unit.standardInfo, description: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                       </tbody>
                    </table>
                 </div>
              </div>

              {/* Equipment Details Table */}
              <div className="space-y-4">
                 <h4 className="text-red-500 font-black uppercase text-[11px] tracking-widest flex items-center gap-2"><span>🔨</span> EQUIPMENT DETAILS</h4>
                 <div className="bg-white rounded-2xl overflow-hidden shadow-xl border border-slate-100">
                    <table className="w-full text-xs">
                       <tbody className="divide-y divide-slate-100 font-bold text-slate-800">
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Nomenclature</td>
                            <td className="p-0"><input value={unit.equipmentDetails.nomenclature} onChange={e => updateDGUnit(unit.id, { equipmentDetails: { ...unit.equipmentDetails, nomenclature: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Engine Number</td>
                            <td className="p-0"><input value={unit.equipmentDetails.engineNumber} onChange={e => updateDGUnit(unit.id, { equipmentDetails: { ...unit.equipmentDetails, engineNumber: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none font-mono" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Make</td>
                            <td className="p-0"><input value={unit.equipmentDetails.make} onChange={e => updateDGUnit(unit.id, { equipmentDetails: { ...unit.equipmentDetails, make: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Alternator Serial</td>
                            <td className="p-0"><input value={unit.equipmentDetails.alternatorSerial} onChange={e => updateDGUnit(unit.id, { equipmentDetails: { ...unit.equipmentDetails, alternatorSerial: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none font-mono" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Location</td>
                            <td className="p-0"><input value={unit.equipmentDetails.location} onChange={e => updateDGUnit(unit.id, { equipmentDetails: { ...unit.equipmentDetails, location: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                          <tr className="divide-x divide-slate-100 hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 w-1/3 bg-slate-50/50 font-bold text-slate-500 uppercase tracking-tight">Model</td>
                            <td className="p-0"><input value={unit.equipmentDetails.model} onChange={e => updateDGUnit(unit.id, { equipmentDetails: { ...unit.equipmentDetails, model: e.target.value } })} className="w-full px-6 py-4 bg-transparent outline-none" disabled={readOnly} /></td>
                          </tr>
                       </tbody>
                    </table>
                 </div>
              </div>
           </div>

           {/* Load Readings Table */}
           <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-red-500 font-black uppercase text-[11px] tracking-widest flex items-center gap-2"><span>📈</span> PART LOAD AND FULL LOAD TEST READINGS</h4>
                {aiEnabled && !readOnly && (
                  <button
                    onClick={() => startScopeCapture(unit.id, 'T1')}
                    className="px-3 py-1 bg-violet-600/20 text-violet-300 hover:bg-violet-600 hover:text-white rounded-lg font-bold text-[10px] uppercase tracking-wider transition-all flex items-center gap-1.5"
                  >
                    <Camera className="w-3 h-3" /> Live Capture T1
                  </button>
                )}
              </div>
              <div className="bg-white rounded-2xl overflow-hidden shadow-2xl">
                 <table className="w-full text-left text-[10px] border-collapse">
                    <thead>
                       <tr className="bg-[#F97316] text-white font-black uppercase tracking-tighter divide-x divide-white/10">
                          <th rowSpan={2} className="px-6 py-4">Parameters</th>
                          <th rowSpan={2} className="px-6 py-4 text-center">Units</th>
                          <th colSpan={5} className="py-2 text-center border-b border-white/10">Load Percentage</th>
                          <th rowSpan={2} className="px-6 py-4">Remarks</th>
                       </tr>
                       <tr className="bg-[#F97316] text-white/80 font-black uppercase tracking-widest text-[9px] divide-x divide-white/10">
                          <th className="py-2 text-center">0</th><th className="py-2 text-center">25</th><th className="py-2 text-center">50</th><th className="py-2 text-center">75</th><th className="py-2 text-center">100</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-bold">
{(unit.loadReadings).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                       {unit.loadReadings.map((row) => (
                         <tr key={row.id} className="hover:bg-slate-50 transition-colors divide-x divide-slate-100">
                            <td className="px-6 py-3.5 text-slate-800 font-black">{row.parameter}</td>
                            <td className="px-6 py-3.5 text-center text-slate-400">{row.unit}</td>
                            {['v0', 'v25', 'v50', 'v75', 'v100'].map(lk => (
                              <td key={lk} className="p-0">
                                <input value={(row as any)[lk]} onChange={e => updateDGUnit(unit.id, { loadReadings: unit.loadReadings.map(r => r.id === row.id ? { ...r, [lk]: e.target.value } : r) })} className="w-full py-3.5 text-center bg-transparent outline-none text-slate-400 placeholder:text-slate-200" placeholder="---" disabled={readOnly} />
                              </td>
                            ))}
                            <td className="p-0 relative group">
                              <input value={row.remarks} onChange={e => updateDGUnit(unit.id, { loadReadings: unit.loadReadings.map(r => r.id === row.id ? { ...r, remarks: e.target.value } : r) })} className="w-full px-4 py-3.5 bg-transparent outline-none italic text-slate-400 placeholder:text-slate-200" placeholder="Enter analysis remarks..." disabled={readOnly} />
                            </td>
                         </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>

           {/* TRANSIENT & NOISE GRID */}
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                 <h4 className="text-red-500 font-black uppercase text-[11px] tracking-widest flex items-center gap-2"><span>⚡</span> Transient Load Test Summary</h4>
                 <div className="bg-white rounded-2xl overflow-hidden shadow-xl">
                    <table className="w-full text-center text-[10px]">
                       <thead className="bg-[#F97316] text-white font-black uppercase">
                          <tr className="divide-x divide-white/10">
                             <th className="py-3 w-16">SR NO</th><th className="py-3">TRANSIENT LOAD</th><th className="py-3 w-32">RESULT</th>
                          </tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100 font-black">
{(unit.transientSummary).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                          {unit.transientSummary.map((row) => (
                             <tr key={row.id} className="divide-x divide-slate-100">
                                <td className="py-4 text-slate-400 font-mono">{row.srNo}</td>
                                <td className="py-4 text-slate-800 uppercase tracking-tighter">{row.load}</td>
                                <td className="p-0"><input value={row.result} onChange={e => updateDGUnit(unit.id, { transientSummary: unit.transientSummary.map(r => r.id === row.id ? { ...r, result: e.target.value } : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} /></td>
                             </tr>
                          ))}
                       </tbody>
                    </table>
                 </div>
              </div>
              <div className="space-y-4">
                 <div className="flex justify-between items-center">
                   <h4 className="text-red-500 font-black uppercase text-[11px] tracking-widest flex items-center gap-2"><span>🔊</span> Noise Level Measurement (DBS)</h4>
                   {aiEnabled && !readOnly && (
                     <button
                       onClick={() => startScopeCapture(unit.id, 'T3')}
                       className="px-2.5 py-1 bg-violet-600/20 text-violet-300 hover:bg-violet-600 hover:text-white rounded-lg font-bold text-[10px] uppercase tracking-wider transition-all flex items-center gap-1"
                     >
                       <Camera className="w-3 h-3" /> Capture T3
                     </button>
                   )}
                 </div>
                 <div className="bg-white rounded-2xl overflow-hidden shadow-xl">
                    <table className="w-full text-center text-[10px]">
                       <thead className="bg-[#F97316] text-white font-black uppercase">
                          <tr className="divide-x divide-white/10">
                             <th className="py-3">LOAD IN %</th><th className="py-3">DOORS OPEN</th><th className="py-3">DOORS CLOSED</th>
                          </tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100 font-black">
{(unit.noiseLevels).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                          {unit.noiseLevels.map((row) => (
                             <tr key={row.load} className="divide-x divide-slate-100">
                                <td className="py-4 text-slate-800">{row.load}</td>
                                <td className="p-0"><input value={row.open} onChange={e => updateDGUnit(unit.id, { noiseLevels: unit.noiseLevels.map(r => r.load === row.load ? { ...r, open: e.target.value } : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} /></td>
                                <td className="p-0"><input value={row.closed} onChange={e => updateDGUnit(unit.id, { noiseLevels: unit.noiseLevels.map(r => r.load === row.load ? { ...r, closed: e.target.value } : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} /></td>
                             </tr>
                          ))}
                       </tbody>
                    </table>
                 </div>
              </div>
           </div>

           {/* VIBRATION TABLE */}
           <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-red-500 font-black uppercase text-[11px] tracking-widest flex items-center gap-2"><span>〰️</span> Vibration Measurement Values (M/S²)</h4>
                {aiEnabled && !readOnly && (
                  <button
                    onClick={() => startScopeCapture(unit.id, 'T4')}
                    className="px-3 py-1 bg-violet-600/20 text-violet-300 hover:bg-violet-600 hover:text-white rounded-lg font-bold text-[10px] uppercase tracking-wider transition-all flex items-center gap-1.5"
                  >
                    <Camera className="w-3 h-3" /> Live Capture T4
                  </button>
                )}
              </div>
              <div className="bg-white rounded-2xl overflow-hidden shadow-2xl">
                 <table className="w-full text-center text-[9px]">
                    <thead className="bg-[#F97316] text-white font-black uppercase">
                       <tr className="divide-x divide-white/10">
                          <th className="py-3 w-20">LOAD %</th>
                          {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map(l => <th key={l} className="py-3">{l}</th>)}
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-bold">
{(unit.vibrationLevels).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                       {unit.vibrationLevels.map((row) => (
                         <tr key={row.load} className="divide-x divide-slate-100">
                            <td className="py-4 text-slate-800 font-black">{row.load}</td>
                            {['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map(k => (
                              <td key={k} className="p-0">
                                <input value={(row as any)[k]} onChange={e => updateDGUnit(unit.id, { vibrationLevels: unit.vibrationLevels.map(r => r.load === row.load ? { ...r, [k]: e.target.value } : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} />
                              </td>
                            ))}
                         </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>

           {/* FUEL CONSUMPTION SUMMARY */}
           <div className="space-y-4 pt-4">
              <div className="flex justify-between items-center">
                 <h4 className="text-red-500 font-black uppercase text-[11px] tracking-widest flex items-center gap-2"><span>⛽</span> FUEL CONSUMPTION SUMMARY</h4>
                 <div className="flex items-center gap-2">
                   {aiEnabled && !readOnly && (
                     <button
                       onClick={() => startScopeCapture(unit.id, 'T5')}
                       className="px-3 py-1 bg-violet-600/20 text-violet-300 hover:bg-violet-600 hover:text-white rounded-lg font-bold text-[10px] uppercase tracking-wider transition-all flex items-center gap-1.5"
                     >
                       <Camera className="w-3 h-3" /> Live Capture T5
                     </button>
                   )}
                   {!readOnly && (
                     <button onClick={() => addFuelEntry(unit.id)} className="px-5 py-2.5 border-2 border-red-500 text-red-500 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-50 transition-all bg-white shadow-xl">+ Add Fuel Entry</button>
                   )}
                 </div>
              </div>
              <div className="bg-white rounded-[2rem] border border-slate-200 shadow-2xl overflow-hidden">
                <div className="overflow-x-auto">
                   <div className="bg-white rounded-3xl overflow-hidden border border-slate-200">
                      <table className="w-full text-center border-collapse text-[9px]">
                        <thead>
                          <tr className="bg-[#F97316] text-white font-black uppercase divide-x divide-white/10 border-b border-orange-600">
                            <th rowSpan={2} className="py-4 w-16">SR.NO</th>
                            <th rowSpan={2} className="py-4 w-16">% LOAD</th>
                            <th rowSpan={2} className="py-4 w-16">TIME</th>
                            <th colSpan={3} className="py-2 bg-orange-600/30">KWH GENERATED</th>
                            <th colSpan={3} className="py-2 bg-orange-600/30">FUEL (LITRES)</th>
                            <th rowSpan={2} className="py-4 w-24">OEM STD (L/H)</th>
                            <th rowSpan={2} className="py-4 w-24">EFFICIENCY (KWH/L)</th>
                            {!readOnly && <th rowSpan={2} className="w-8"></th>}
                          </tr>
                          <tr className="bg-[#FFBD88] text-white font-black uppercase text-[8px] divide-x divide-white/10">
                            <th className="py-2">INITIAL</th><th className="py-2">FINAL</th><th className="py-2 text-blue-100">UNITS</th>
                            <th className="py-2">INITIAL</th><th className="py-2">FINAL</th><th className="py-2 text-red-100">CONSUM.</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-bold">
{(unit.fuelSummary).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                          {unit.fuelSummary.map((row) => (
                            <tr key={row.id} className="divide-x divide-slate-50 hover:bg-slate-50 transition-colors">
                              <td className="py-4 text-slate-800 font-black">{row.srNo}</td>
                              <td className="p-0"><input value={row.percentLoad} onChange={e => updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.map(r => r.id === row.id ? { ...r, percentLoad: e.target.value } : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" placeholder="---" disabled={readOnly} /></td>
                              <td className="p-0"><input value={row.time} onChange={e => updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.map(r => r.id === row.id ? { ...r, time: e.target.value } : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" placeholder="---" disabled={readOnly} /></td>
                              <td className="p-0"><input value={row.kwhInitial} onChange={e => updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.map(r => r.id === row.id ? calculateFuelRow({ ...r, kwhInitial: e.target.value }) : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} /></td>
                              <td className="p-0"><input value={row.kwhFinal} onChange={e => updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.map(r => r.id === row.id ? calculateFuelRow({ ...r, kwhFinal: e.target.value }) : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} /></td>
                              <td className="p-0 bg-blue-50/30"><input value={row.kwhUnits} className="w-full py-4 text-center bg-transparent outline-none font-black text-blue-600" disabled={true} readOnly={true} /></td>
                              <td className="p-0"><input value={row.fuelInitial} onChange={e => updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.map(r => r.id === row.id ? calculateFuelRow({ ...r, fuelInitial: e.target.value }) : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} /></td>
                              <td className="p-0"><input value={row.fuelFinal} onChange={e => updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.map(r => r.id === row.id ? calculateFuelRow({ ...r, fuelFinal: e.target.value }) : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" disabled={readOnly} /></td>
                              <td className="p-0 bg-red-50/30"><input value={row.fuelConsum} className="w-full py-4 text-center bg-transparent outline-none font-black text-red-600" disabled={true} readOnly={true} /></td>
                              <td className="p-0"><input value={row.oemStd} onChange={e => updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.map(r => r.id === row.id ? { ...r, oemStd: e.target.value } : r) })} className="w-full py-4 text-center bg-transparent outline-none text-slate-400" placeholder="---" disabled={readOnly} /></td>
                              <td className="p-0 bg-slate-900 text-white"><input value={row.efficiency} className="w-full py-4 text-center bg-transparent outline-none font-black" disabled={true} readOnly={true} /></td>
                              {!readOnly && (
                                <td className="px-2">
                                  <button 
                                    onClick={() => {
                                      confirmDelete({
                                        message: "Are you sure you want to delete this fuel summary row?",
                                        onConfirm: () => {
                                          updateDGUnit(unit.id, { fuelSummary: unit.fuelSummary.filter(r => r.id !== row.id) });
                                        }
                                      });
                                    }} 
                                    className="text-slate-300 hover:text-red-500 text-xl"
                                  >
                                    ×
                                  </button>
                                </td>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                   </div>
                </div>
                <div className="px-8 py-4 bg-slate-50 border-t border-slate-100 flex flex-wrap gap-x-8 gap-y-2">
                   <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Formula:</span>
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">Units = Final - Initial</span>
                   </div>
                   <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-red-600 uppercase tracking-wider">Consumption = Final - Initial</span>
                   </div>
                </div>
              </div>
           </div>
        </div>
      ))}

      {/* DG ADD BUTTON */}
      {!readOnly && (
        <div className="flex justify-center">
           <button onClick={addDGUnit} className="px-12 py-5 bg-slate-900 text-white rounded-[2rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl hover:scale-105 transition-all active:scale-95 flex items-center gap-4">
              <span className="text-2xl leading-none">+</span> Initialize Next DG Unit
           </button>
        </div>
      )}

      {/* ASSESSMENT SUMMARY */}
      <section className="bg-white rounded-[2rem] border border-slate-200 shadow-2xl p-10 space-y-10">
         <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
            <span className="text-2xl">🛡️</span>
            <h3 className="font-black text-slate-800 tracking-widest uppercase text-sm">Assessment Summary</h3>
         </div>
         <div className="space-y-10">
            <div className="space-y-4">
               <label className="text-[10px] font-black text-[#DC2626] uppercase tracking-[0.2em] block px-1 flex items-center gap-2"><span>📈</span> Recommendations</label>
               <textarea 
                value={data.recommendations || ''}
                onChange={e => updateField('recommendations', e.target.value)}
                disabled={readOnly}
                placeholder="Strategic recommendations for these DG units..."
                className="w-full h-48 p-8 bg-slate-50 border border-slate-100 rounded-[2rem] focus:ring-8 focus:ring-blue-50 outline-none text-sm transition-all italic resize-none"
               />
            </div>
            <div className="space-y-4">
               <label className="text-[10px] font-black text-[#1E40AF] uppercase tracking-[0.2em] block px-1 flex items-center gap-2"><span>ⓘ</span> Observations</label>
               <textarea 
                value={data.observations || ''}
                onChange={e => updateField('observations', e.target.value)}
                disabled={readOnly}
                placeholder="Record specific technical observations and data findings..."
                className="w-full h-48 p-8 bg-slate-50 border border-slate-100 rounded-[2rem] focus:ring-8 focus:ring-blue-50 outline-none text-sm transition-all italic resize-none"
               />
            </div>
         </div>
      </section>

      {/* SCOPE SELECTION MODAL */}
      {scopeModalOpen && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-fade-in">
            <div className="bg-slate-900 text-white p-6 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-violet-600 rounded-xl flex items-center justify-center">
                  <Camera className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Live Capture Wizard</h3>
                  <p className="text-slate-400 text-xs">Configure scope & target parameters</p>
                </div>
              </div>
              <button 
                onClick={() => setScopeModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold px-2"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Select DG Unit</label>
                <select
                  value={selectedUnitScope}
                  onChange={e => setSelectedUnitScope(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-violet-500"
                >
                  <option value="ALL">All DG Units ({data.dgUnits.length})</option>
                  {data.dgUnits.map((u, idx) => (
                    <option key={u.id} value={u.id}>{u.unitName || `DG Unit ${idx + 1}`}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Select Test Scope</label>
                <select
                  value={selectedTableScope}
                  onChange={e => setSelectedTableScope(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-violet-500"
                >
                  <option value="ALL">⚡ Full Test (All Tables & Loads)</option>
                  <option value="T1">📈 T1: Parameter Matrix (All Loads 0%-100%)</option>
                  <option value="T1_0">📈 T1: 0% Load Parameters</option>
                  <option value="T1_25">📈 T1: 25% Load Parameters</option>
                  <option value="T1_50">📈 T1: 50% Load Parameters</option>
                  <option value="T1_75">📈 T1: 75% Load Parameters</option>
                  <option value="T1_100">📈 T1: 100% Load Parameters</option>
                  <option value="T3">🔊 T3: Noise Level Measurement (dB)</option>
                  <option value="T4">〰️ T4: Vibration Level Measurement (m/s²)</option>
                  <option value="T5">⛽ T5: Fuel Consumption Summary</option>
                </select>
              </div>

              <div className="bg-violet-50 rounded-xl p-4 border border-violet-100 text-xs text-violet-800 space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-violet-600" /> Instrument Guidance Included
                </p>
                <p className="text-violet-600/80">
                  The wizard will prompt you to capture each instrument display step-by-step using Gemini OCR. Values will be directly saved into the test report.
                </p>
              </div>
            </div>

            <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button
                onClick={() => setScopeModalOpen(false)}
                className="px-5 py-2.5 text-slate-600 hover:bg-slate-200 font-bold text-sm rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => startScopeCapture(selectedUnitScope, selectedTableScope)}
                className="px-6 py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-sm rounded-xl transition-colors shadow-lg flex items-center gap-2"
              >
                <Camera className="w-4 h-4" /> Start Capture Wizard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LIVE CAPTURE WIZARD MODAL */}
      {liveCapture && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl text-white animate-fade-in flex flex-col max-h-[90vh]">
            
            {/* Header */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex justify-between items-center">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 bg-violet-600/30 text-violet-400 text-[10px] font-mono font-bold uppercase rounded-full border border-violet-500/30">
                    Step {liveCapture.stepIndex + 1} of {liveCapture.queue.length}
                  </span>
                  <span className="text-slate-400 text-xs font-bold uppercase tracking-wider">
                    {liveCapture.queue[liveCapture.stepIndex]?.unitName}
                  </span>
                </div>
                <h3 className="font-black text-lg text-white mt-1">
                  {liveCapture.queue[liveCapture.stepIndex]?.fieldLabel}
                </h3>
              </div>
              <button 
                onClick={handleCancelCapture}
                className="text-slate-400 hover:text-white text-xl font-bold px-3 py-1 rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            {/* Instrument Guidance Banner */}
            <div className="bg-slate-800/60 px-6 py-3 border-b border-slate-800 text-xs text-slate-300 flex items-start gap-2">
              <span className="text-violet-400 font-bold shrink-0">💡 Note:</span>
              <p>{liveCapture.queue[liveCapture.stepIndex]?.readingGuidance}</p>
            </div>

            {/* Main Stage */}
            <div className="p-6 flex-1 overflow-y-auto space-y-6">
              
              {/* Phase: Camera */}
              {liveCapture.phase === 'camera' && (
                <div className="space-y-4">
                  <div className="relative aspect-video bg-black rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center group shadow-inner">
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      playsInline 
                      muted 
                      className="w-full h-full object-cover" 
                    />
                    <canvas ref={canvasRef} className="hidden" />

                    <div className="absolute top-4 left-4 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 text-xs font-mono font-bold text-violet-300">
                      Target Unit: {liveCapture.queue[liveCapture.stepIndex]?.unit || 'Value'}
                    </div>

                    <div className="absolute bottom-4 inset-x-4 flex justify-between items-center bg-slate-950/70 backdrop-blur-md p-3 rounded-xl border border-white/10">
                      <span className="text-xs font-bold text-slate-300">Position display in frame</span>
                      <button
                        onClick={capturePhoto}
                        className="px-6 py-2.5 bg-violet-600 hover:bg-violet-500 text-white font-black text-xs uppercase tracking-wider rounded-lg shadow-lg transition-transform active:scale-95 flex items-center gap-2"
                      >
                        <Camera className="w-4 h-4" /> Capture Photo
                      </button>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <button
                      onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'review', readValue: '', error: '' } : null)}
                      className="text-slate-400 hover:text-white underline font-bold"
                    >
                      Enter value manually instead
                    </button>
                    <button
                      onClick={skipCaptureStep}
                      className="text-slate-500 hover:text-slate-300 font-bold"
                    >
                      Skip Cell →
                    </button>
                  </div>
                </div>
              )}

              {/* Phase: Reading */}
              {liveCapture.phase === 'reading' && (
                <div className="py-16 text-center space-y-4">
                  <div className="w-16 h-16 border-4 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto" />
                  <div>
                    <h4 className="font-bold text-lg text-white">Analyzing Instrument Display...</h4>
                    <p className="text-slate-400 text-xs mt-1">Reading digits via Gemini Vision AI</p>
                  </div>
                </div>
              )}

              {/* Phase: Review */}
              {liveCapture.phase === 'review' && (
                <div className="space-y-6">
                  {liveCapture.error && (
                    <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs font-bold">
                      ⚠️ {liveCapture.error}
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-wider block">
                      Extracted / Final Value ({liveCapture.queue[liveCapture.stepIndex]?.unit || 'Numeric'})
                    </label>
                    <div className="flex gap-3">
                      <input
                        type="text"
                        value={liveCapture.readValue}
                        onChange={e => setLiveCapture(prev => prev ? { ...prev, readValue: e.target.value } : null)}
                        placeholder="e.g. 415.2"
                        className="flex-1 bg-slate-950 border border-slate-700 rounded-xl p-4 text-2xl font-mono font-black text-white outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/30"
                        autoFocus
                      />
                      <span className="self-center font-bold text-slate-400 text-sm">
                        {liveCapture.queue[liveCapture.stepIndex]?.unit}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
                    <button
                      onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'camera', readValue: '', error: '' } : null)}
                      className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition-colors flex items-center gap-2"
                    >
                      <Camera className="w-4 h-4" /> Retake Photo
                    </button>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={skipCaptureStep}
                        className="px-4 py-2.5 text-slate-400 hover:text-white font-bold text-xs rounded-xl transition-colors"
                      >
                        Skip
                      </button>
                      <button
                        onClick={confirmCaptureValue}
                        className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors shadow-lg"
                      >
                        ✓ Confirm & Next
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
      )}

    </div>
  );
};

const INITIAL_LOAD_PARAMS = [
  { parameter: "Voltage (R-Y)", unit: "Volts", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Voltage (Y-B)", unit: "Volts", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Voltage (B-R)", unit: "Volts", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Voltage (R-N)", unit: "Volts", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Voltage (Y-N)", unit: "Volts", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Voltage (B-N)", unit: "Volts", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Current - R Phase", unit: "Amps", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Current - Y Phase", unit: "Amps", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Current - B Phase", unit: "Amps", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Power factor", unit: "%", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Frequency", unit: "Hz", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Battery Voltage", unit: "V", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Total active power", unit: "KW", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Total apparent power", unit: "KVA", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Speed", unit: "RPM", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Lube oil Pressure", unit: "Kpa", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Coolant Temp", unit: "°C", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" },
  { parameter: "Oil Temp", unit: "°C", v0: "---", v25: "---", v50: "---", v75: "---", v100: "---", remarks: "" }
];

export const INITIAL_DG_ENDURANCE_DATA: DGEnduranceReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  onSiteTests: [
    { id: '1', srNo: '1', description: 'Part Load & Full Load Test (25%, 50%, 75%, 100%, 110%)', result: true },
    { id: '2', srNo: '2', description: 'Step / Transient Load Test (0% to 36%, 36% to 61%) (61% to 88%, 88% to 100%) (0% to 50%, 50% to 100%)', result: true },
    { id: '3', srNo: '3', description: 'Noise Level Measurement Test', result: true },
    { id: '4', srNo: '4', description: 'Vibration Test', result: true },
    { id: '5', srNo: '5', description: 'Fuel Consumption Test', result: true },
  ],
  equipmentList: [
    { id: '1', name: 'Digital clamp meter', make: '---', model: '-1080-TRMS', serialNo: '23070822', calDate: '2025-05-10', expDate: '2026-05-09' },
    { id: '2', name: 'Thermal gun', make: '---', model: 'TIC 23', serialNo: '2022030006417', calDate: '2025-02-05', expDate: '2026-04-04' },
    { id: '3', name: 'DB meter', make: '---', model: 'WT85B', serialNo: 'H22693476', calDate: '2025-04-22', expDate: '2026-04-21' },
    { id: '4', name: 'Vibration meter', make: '---', model: 'WT63B', serialNo: 'H22690512', calDate: '2025-04-23', expDate: '2026-04-22' },
    { id: '5', name: 'Power quality analyzer', make: '---', model: '1775', serialNo: '6649115', calDate: '2025-03-11', expDate: '2026-03-10' },
    { id: '6', name: 'Load bank', make: '---', model: 'Resistive load bank', serialNo: 'Serial number...', calDate: 'Not applicable', expDate: 'Expiry Date' },
  ],
  dgUnits: [],
  observations: '',
  recommendations: ''
};
