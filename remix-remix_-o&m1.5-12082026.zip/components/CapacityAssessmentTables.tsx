
import React from 'react';
import { CapacityAssessmentReading, CapacityToolRow, PahuTable, PacTable, PahuEntry, PacEntry, ObservationRecommendationRow, LiveCaptureConfig } from '../types';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { FileSpreadsheet, Upload, Camera } from 'lucide-react';
import { exportPahuTableToExcel, exportPacTableToExcel, parsePahuTableExcel, parsePacTableExcel } from '../utils/excelCapacity';
import { readPahuDisplay } from '../services/geminiClient';

// Icons
const DuplicateIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
);

const TrashIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

interface CapacityAssessmentTablesProps {
  data: CapacityAssessmentReading;
  onChange: (data: CapacityAssessmentReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

export const CapacityAssessmentTables: React.FC<CapacityAssessmentTablesProps> = ({
  data,
  onChange,
  readOnly = false,
  aiEnabled = false,
  liveCaptureConfig
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

  const [liveCapture, setLiveCapture] = React.useState<{
    active: boolean;
    tableId: string;
    rowIndex: number;
    stepIndex: number;
    phase: 'camera' | 'reading' | 'review';
    value: string;
    error: string;
  } | null>(null);

  const videoRef = React.useRef<HTMLVideoElement | null>(null);
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null);
  const streamRef = React.useRef<MediaStream | null>(null);

  const getPahuCaptureSteps = React.useCallback(() => {
    const pahuTableConfig = liveCaptureConfig?.tables?.find(t => t.tableKey === 'pahuTables');
    if (pahuTableConfig && pahuTableConfig.fields && pahuTableConfig.fields.length > 0) {
      return pahuTableConfig.fields.map(f => {
        let instrument = 'Test Instrument';
        if (f.key === 'measuredAirflow') instrument = 'Volume Flow Hood (testo 420)';
        else if (f.key === 'measuredSaTemp' || f.key === 'measuredRaTemp') instrument = 'Temperature Humidity Meter (FLUKE 971)';
        else if (f.key === 'measuredWaterFlowRate') instrument = 'Ultrasonic Flow Meter (EIS TUF-2000H)';

        return {
          key: f.key,
          label: f.label.replace(/\s*\([^)]*\)/g, '').trim(),
          instrument,
          unit: f.unit || '',
          guidance: f.readingGuidance
        };
      });
    }
    return [
      {
        key: 'measuredAirflow',
        label: 'Airflow',
        instrument: 'Volume Flow Hood (testo 420)',
        unit: 'CFM',
        guidance: 'Read ONLY the airflow value in its shown unit (CFM or m³/h) from the Volume Flow Hood display (testo 420). Ignore velocity and temperature. Preserve decimals.'
      },
      {
        key: 'measuredSaTemp',
        label: 'SA Temp',
        instrument: 'Temperature Humidity Meter (FLUKE 971)',
        unit: '°C',
        guidance: 'Read ONLY the Supply Air (SA) temperature value in °C from the Temperature Humidity Meter (FLUKE 971). Ignore relative humidity and dew point. Preserve decimals.'
      },
      {
        key: 'measuredRaTemp',
        label: 'RA Temp',
        instrument: 'Temperature Humidity Meter (FLUKE 971)',
        unit: '°C',
        guidance: 'Read ONLY the Return Air (RA) temperature value in °C from the Temperature Humidity Meter (FLUKE 971). Ignore relative humidity and dew point. Preserve decimals.'
      },
      {
        key: 'measuredWaterFlowRate',
        label: 'Water Flow',
        instrument: 'Ultrasonic Flow Meter (EIS TUF-2000H)',
        unit: 'GPM',
        guidance: 'Read ONLY the water flow rate value in its shown unit (GPM, m³/h, or L/min) from the Ultrasonic Flow Meter (EIS TUF-2000H). Ignore flow velocity and totalizer. Preserve decimals.'
      }
    ];
  }, [liveCaptureConfig]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera access error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? {
          ...prev,
          phase: 'review',
          error: 'Camera access unavailable. Enter value manually below.'
        } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  React.useEffect(() => {
    if (liveCapture?.active && liveCapture.phase === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [liveCapture?.active, liveCapture?.phase, liveCapture?.rowIndex, liveCapture?.stepIndex]);

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    let width = video.videoWidth || 1280;
    let height = video.videoHeight || 720;
    const maxDim = 1280;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);

    const steps = getPahuCaptureSteps();
    const currentStep = steps[liveCapture.stepIndex];

    try {
      const readVal = await readPahuDisplay(base64, currentStep.label, currentStep.guidance);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        value: readVal,
        error: readVal ? '' : 'Could not read value clearly. Please verify or enter manually.'
      } : null);
    } catch (err: any) {
      console.error('Gemini extraction error:', err);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        value: '',
        error: 'Failed to extract value. Please enter manually.'
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const steps = getPahuCaptureSteps();
    const { tableId, rowIndex, stepIndex, value } = liveCapture;

    const stepKey = steps[stepIndex].key;

    const targetTable = data.pahuTables.find(t => t.id === tableId);
    if (targetTable && targetTable.entries[rowIndex]) {
      const updatedTables = data.pahuTables.map(t => {
        if (t.id === tableId) {
          const newEntries = t.entries.map((ent, idx) => {
            if (idx === rowIndex) {
              return {
                ...ent,
                [stepKey]: value
              };
            }
            return ent;
          });
          return { ...t, entries: newEntries };
        }
        return t;
      });
      updateField('pahuTables', updatedTables);
    }

    if (stepIndex < steps.length - 1) {
      setLiveCapture(prev => prev ? {
        ...prev,
        stepIndex: stepIndex + 1,
        phase: 'camera',
        value: '',
        error: ''
      } : null);
    } else {
      if (targetTable && rowIndex < targetTable.entries.length - 1) {
        setLiveCapture(prev => prev ? {
          ...prev,
          rowIndex: rowIndex + 1,
          stepIndex: 0,
          phase: 'camera',
          value: '',
          error: ''
        } : null);
      } else {
        stopCamera();
        setLiveCapture(null);
      }
    }
  };

  const openLiveCapture = (tableId: string, rowIdx = 0, stepIdx = 0) => {
    setLiveCapture({
      active: true,
      tableId,
      rowIndex: rowIdx,
      stepIndex: stepIdx,
      phase: 'camera',
      value: '',
      error: ''
    });
  };


  const updateField = (field: keyof CapacityAssessmentReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };


  // Formula as per screenshot: =1.06*Airflow*(RA-SA)*1.8/12000
  const calcTR = (cfm: string, ra: string, sa: string) => {
    const cfmVal = parseFloat(cfm);
    const raVal = parseFloat(ra);
    const saVal = parseFloat(sa);
    if (isNaN(cfmVal) || isNaN(raVal) || isNaN(saVal)) return 0;
    const val = (1.06 * cfmVal * (raVal - saVal) * 1.8) / 12000;
    return val;
  };

  const calcCop = (tra: number, kw: string) => {
    const kwVal = parseFloat(kw);
    if (isNaN(tra) || isNaN(kwVal) || kwVal === 0) return 0;
    return (tra * 3.517) / kwVal;
  };

  const addTool = () => {
    const tools = [...(data.toolsUsed || [])];
    tools.push({ id: `tool-${Date.now()}`, instrumentName: '', make: '', model: '', serialNumber: '', calibrationIssue: '', calibrationExpiry: '' });
    updateField('toolsUsed', tools);
  };

  const addPahuTable = () => {
    const tables = [...(data.pahuTables || [])];
    tables.push({
      id: `pahu-tbl-${Date.now()}`,
      tableNumber: '6.1',
      title: `PAHU Capacity assessment`,
      entries: []
    });
    updateField('pahuTables', tables);
  };

  const addPacTable = () => {
    const tables = [...(data.pacTables || [])];
    tables.push({
      id: `pac-tbl-${Date.now()}`,
      tableNumber: '6.2',
      title: `PAC capacity assessment`,
      entries: []
    });
    updateField('pacTables', tables);
  };

  const handleImportPahuExcel = (tableId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async (evt) => {
        if (!evt.target?.result) return;
        const result = await parsePahuTableExcel(evt.target.result as ArrayBuffer);
        if (result && result.length > 0) {
          const updatedTables = data.pahuTables.map(t => 
            t.id === tableId ? { ...t, entries: result } : t
          );
          updateField('pahuTables', updatedTables);
        } else {
          alert("Could not parse file. Ensure headers match the original export template.");
        }
      };
      reader.readAsArrayBuffer(file);
    };
    input.click();
  };

  const handleImportPacExcel = (tableId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async (evt) => {
        if (!evt.target?.result) return;
        const result = await parsePacTableExcel(evt.target.result as ArrayBuffer);
        if (result && result.length > 0) {
          const updatedTables = data.pacTables.map(t => 
            t.id === tableId ? { ...t, entries: result } : t
          );
          updateField('pacTables', updatedTables);
        } else {
          alert("Could not parse file. Ensure headers match the original export template.");
        }
      };
      reader.readAsArrayBuffer(file);
    };
    input.click();
  };

  const addPahuEntry = (tableId: string) => {
    const tables = data.pahuTables.map(t => {
      if (t.id === tableId) {
        return {
          ...t,
          entries: [...t.entries, {
            id: `pahu-ent-${Date.now()}`,
            equipmentId: '', modelNo: '', serialNo: '',
            designAirflow: '', designRaTemp: '', designSaTemp: '', designPower: '', designWaterFlowRate: '', designCoolingTonnage: '',
            measuredAirflow: '', measuredSaTemp: '', measuredRaTemp: '', measuredFanSpeed: '', measuredCoolingTonnage: '', measuredPower: '',
            measuredChwIn: '', measuredChwOut: '', measuredValveOpening: '', measuredWaterFlowRate: '', measuredWaterCoolingTonnage: ''
          }]
        };
      }
      return t;
    });
    updateField('pahuTables', tables);
  };

  const insertPahuEntry = (tableId: string, idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const tables = data.pahuTables.map(t => {
      if (t.id === tableId) {
        const newEntries = [...t.entries];
        const newEntry = {
          id: `pahu-ent-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          equipmentId: '', modelNo: '', serialNo: '',
          designAirflow: '', designRaTemp: '', designSaTemp: '', designPower: '', designWaterFlowRate: '', designCoolingTonnage: '',
          measuredAirflow: '', measuredSaTemp: '', measuredRaTemp: '', measuredFanSpeed: '', measuredCoolingTonnage: '', measuredPower: '',
          measuredChwIn: '', measuredChwOut: '', measuredValveOpening: '', measuredWaterFlowRate: '', measuredWaterCoolingTonnage: ''
        };
        newEntries.splice(targetIdx, 0, newEntry);
        return { ...t, entries: newEntries };
      }
      return t;
    });
    updateField('pahuTables', tables);
  };

  const duplicatePahuEntry = (tableId: string, idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const tables = data.pahuTables.map(t => {
      if (t.id === tableId) {
        const newEntries = [...t.entries];
        const source = newEntries[idx] || {
          equipmentId: '', modelNo: '', serialNo: '',
          designAirflow: '', designRaTemp: '', designSaTemp: '', designPower: '', designWaterFlowRate: '', designCoolingTonnage: '',
          measuredAirflow: '', measuredSaTemp: '', measuredRaTemp: '', measuredFanSpeed: '', measuredCoolingTonnage: '', measuredPower: '',
          measuredChwIn: '', measuredChwOut: '', measuredValveOpening: '', measuredWaterFlowRate: '', measuredWaterCoolingTonnage: ''
        };
        const newEntry = {
          ...source,
          id: `pahu-ent-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`
        };
        newEntries.splice(targetIdx, 0, newEntry);
        return { ...t, entries: newEntries };
      }
      return t;
    });
    updateField('pahuTables', tables);
  };

  const addPacEntry = (tableId: string) => {
    const tables = data.pacTables.map(t => {
      if (t.id === tableId) {
        return {
          ...t,
          entries: [...t.entries, {
            id: `pac-ent-${Date.now()}`,
            equipmentId: '', modelNo: '', serialNo: '',
            designAirflow: '', designRaTemp: '', designSaTemp: '', designPower: '', designCoolingTonnage: '',
            fanSpeed: '',
            measuredAirflow: '', measuredRaTemp: '', measuredSaTemp: '', measuredPower: '',
            measuredCoolingTonnage: '', measuredFanSpeed: ''
          }]
        };
      }
      return t;
    });
    updateField('pacTables', tables);
  };

  const insertPacEntry = (tableId: string, idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const tables = data.pacTables.map(t => {
      if (t.id === tableId) {
        const newEntries = [...t.entries];
        const newEntry = {
          id: `pac-ent-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          equipmentId: '', modelNo: '', serialNo: '',
          designAirflow: '', designRaTemp: '', designSaTemp: '', designPower: '', designCoolingTonnage: '',
          fanSpeed: '',
          measuredAirflow: '', measuredRaTemp: '', measuredSaTemp: '', measuredPower: '',
          measuredCoolingTonnage: '', measuredFanSpeed: ''
        };
        newEntries.splice(targetIdx, 0, newEntry);
        return { ...t, entries: newEntries };
      }
      return t;
    });
    updateField('pacTables', tables);
  };

  const duplicatePacEntry = (tableId: string, idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const tables = data.pacTables.map(t => {
      if (t.id === tableId) {
        const newEntries = [...t.entries];
        const source = newEntries[idx] || {
          equipmentId: '', modelNo: '', serialNo: '',
          designAirflow: '', designRaTemp: '', designSaTemp: '', designPower: '', designCoolingTonnage: '',
          fanSpeed: '',
          measuredAirflow: '', measuredRaTemp: '', measuredSaTemp: '', measuredPower: '',
          measuredCoolingTonnage: '', measuredFanSpeed: ''
        };
        const newEntry = {
          ...source,
          id: `pac-ent-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`
        };
        newEntries.splice(targetIdx, 0, newEntry);
        return { ...t, entries: newEntries };
      }
      return t;
    });
    updateField('pacTables', tables);
  };

  const return_confirmDelete = (type: 'ROW' | 'TABLE', id: string, targetType: 'PAHU' | 'PAC' | 'TOOL', parentId?: string) => {
    confirmDelete({
      message: `Are you sure you want to delete this ${type === 'TABLE' ? 'Entire Table' : targetType.toLowerCase()}?`,
      onConfirm: () => {
        if (type === 'TABLE') {
          if (targetType === 'PAHU') updateField('pahuTables', data.pahuTables.filter(t => t.id !== id));
          if (targetType === 'PAC') updateField('pacTables', data.pacTables.filter(t => t.id !== id));
        } else {
          if (targetType === 'TOOL') updateField('toolsUsed', data.toolsUsed.filter(t => t.id !== id));
          if (targetType === 'PAHU' && parentId) {
            updateField('pahuTables', data.pahuTables.map(t => t.id === parentId ? { ...t, entries: t.entries.filter(e => e.id !== id) } : t));
          }
          if (targetType === 'PAC' && parentId) {
            updateField('pacTables', data.pacTables.map(t => t.id === parentId ? { ...t, entries: t.entries.filter(e => e.id !== id) } : t));
          }
        }
      }
    });
  };

  return (
    <div className="space-y-10 animate-fade-in pb-20">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* PERSONNEL DATA */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white text-xs font-black uppercase tracking-widest text-center">Personnel & Test Schedule</div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                className="w-full text-xs font-bold p-2 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-orange-50 outline-none"
              />
            </div>
          ))}
          
          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">IT Load (kW)</label>
            <input 
              type="number"
              value={data.itLoad || ''} 
              onChange={e => updateField('itLoad', e.target.value)}
              disabled={readOnly}
              className="w-full text-xs font-bold p-2 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-orange-50 outline-none"
              placeholder="Enter IT Load"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Measured PUE</label>
            <div className="w-full text-xs font-bold p-2 bg-slate-100 text-slate-600 rounded-lg">
              {(() => {
                const pacUtilityLoad = (data.pacTables || []).reduce((sum, t) => sum + t.entries.reduce((s, ent) => s + (parseFloat(ent.measuredPower) || 0), 0), 0);
                const itLoad = parseFloat(data.itLoad || '0');
                if (itLoad > 0) {
                  return ((itLoad + pacUtilityLoad) / itLoad).toFixed(2);
                }
                return '-';
              })()}
            </div>
          </div>
        </div>
      </section>

      {/* TOOLS USED */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 flex justify-between items-center border-b border-slate-100 bg-slate-50/50">
          <h3 className="font-black text-slate-800 text-xs uppercase tracking-widest flex items-center gap-2">
            <span>🛠️</span> TOOLS USED:
          </h3>
          {!readOnly && (
            <button onClick={addTool} className="px-4 py-1.5 bg-[#EF4444] text-white rounded-lg font-black text-[10px] uppercase shadow-md hover:bg-red-700 transition-all">+ Add Tool</button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px]">
            <thead>
              <tr className="bg-[#F97316] text-white font-black uppercase divide-x divide-white/10">
                <th className="px-4 py-3 w-12 text-center">SR. NO</th>
                <th className="px-4 py-3">INSTRUMENT NAME</th>
                <th className="px-4 py-3">MAKE</th>
                <th className="px-4 py-3">MODEL</th>
                <th className="px-4 py-3">SERIAL NUMBER</th>
                <th colSpan={2} className="px-4 py-3 text-center">CALIBRATION DATE</th>
                {!readOnly && <th className="px-4 py-3 w-12 text-center">DELETE</th>}
              </tr>
              <tr className="bg-[#FFBD88] text-white font-black text-[9px] uppercase divide-x divide-white/10 border-t border-white/10">
                <th colSpan={5}></th>
                <th className="py-2 text-center">ISSUE</th>
                <th className="py-2 text-center">EXPIRY</th>
                {!readOnly && <th></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.toolsUsed || []).map((tool, i) => (
                <tr key={tool.id} className="hover:bg-slate-50 divide-x divide-slate-50">
                  <td className="px-4 py-3 text-center text-slate-400 font-mono">{i + 1}</td>
                  <td className="p-0">
                    <input 
                      value={tool.instrumentName} 
                      onChange={e => updateField('toolsUsed', data.toolsUsed.map(t => t.id === tool.id ? { ...t, instrumentName: e.target.value } : t))} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="e.g. Anemometer"
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      value={tool.make} 
                      onChange={e => updateField('toolsUsed', data.toolsUsed.map(t => t.id === tool.id ? { ...t, make: e.target.value } : t))} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="e.g. Fluke"
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      value={tool.model} 
                      onChange={e => updateField('toolsUsed', data.toolsUsed.map(t => t.id === tool.id ? { ...t, model: e.target.value } : t))} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="e.g. 922"
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      value={tool.serialNumber} 
                      onChange={e => updateField('toolsUsed', data.toolsUsed.map(t => t.id === tool.id ? { ...t, serialNumber: e.target.value } : t))} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="Serial No."
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      type="date" 
                      value={tool.calibrationIssue} 
                      onChange={e => updateField('toolsUsed', data.toolsUsed.map(t => t.id === tool.id ? { ...t, calibrationIssue: e.target.value } : t))} 
                      className="w-full px-4 py-3 bg-transparent outline-none text-center" 
                      disabled={readOnly} 
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      type="date" 
                      value={tool.calibrationExpiry} 
                      onChange={e => updateField('toolsUsed', data.toolsUsed.map(t => t.id === tool.id ? { ...t, calibrationExpiry: e.target.value } : t))} 
                      className="w-full px-4 py-3 bg-transparent outline-none text-center" 
                      disabled={readOnly} 
                    />
                  </td>
                  {!readOnly && (
                    <td className="text-center">
                      <button 
                        onClick={() => return_confirmDelete('ROW', tool.id, 'TOOL')} 
                        className="text-slate-300 hover:text-red-500 transition-colors"
                      >
                        <TrashIcon />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {(data.toolsUsed || []).length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-8 text-center text-slate-400 italic">No tools added. Click "+ Add Tool" to begin.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Delete Confirmation Modal Placeholder Removed */}

      {/* PAHU TABLES */}
      <div className="space-y-8">
        {data.pahuTables.map(table => (
          <div key={table.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in-down">
            <div className="bg-slate-50 px-6 py-4 flex justify-between items-center border-b border-slate-100">
               <div className="flex items-center gap-3">
                  <input 
                    value={table.tableNumber ? `${table.tableNumber} ${table.title}` : table.title} 
                    onChange={e => {
                      const val = e.target.value;
                      const spaceIndex = val.indexOf(' ');
                      const newNumber = spaceIndex !== -1 ? val.substring(0, spaceIndex) : '';
                      const newTitle = spaceIndex !== -1 ? val.substring(spaceIndex + 1) : val;
                      updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, tableNumber: newNumber, title: newTitle } : t));
                    }}
                    className="bg-transparent font-black text-slate-800 text-sm uppercase outline-none focus:border-b-2 border-blue-500 w-80"
                    disabled={readOnly}
                  />
                  <span className="text-xl">✏️</span>
               </div>
               <div className="flex items-center gap-2">
                 {aiEnabled && !readOnly && table.entries.length > 0 && (
                   <button
                     type="button"
                     onClick={() => openLiveCapture(table.id, 0, 0)}
                     className="p-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider shadow"
                   >
                     <Camera className="w-3.5 h-3.5" /> Live Capture
                   </button>
                 )}
                 <button
                   onClick={() => exportPahuTableToExcel(table, `${table.title?.replace(/\s+/g, '_') || 'PAHU'}_Report_${new Date().toISOString().split('T')[0]}.xlsx`)}
                   className="p-1.5 bg-emerald-500/80 hover:bg-emerald-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                 >
                   <FileSpreadsheet className="w-3.5 h-3.5" /> Export
                 </button>
                 {!readOnly && (
                   <>
                     <button
                       onClick={() => handleImportPahuExcel(table.id)}
                       className="p-1.5 bg-indigo-500/80 hover:bg-indigo-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                     >
                       <Upload className="w-3.5 h-3.5" /> Import
                     </button>
                     <button onClick={() => return_confirmDelete('TABLE', table.id, 'PAHU')} className="p-1.5 bg-slate-200 hover:bg-red-500 text-slate-500 hover:text-white rounded transition-colors flex items-center justify-center w-7 h-7">
                       <TrashIcon />
                     </button>
                   </>
                 )}
               </div>
             </div>

             <div className="overflow-x-auto">
              <table className="w-full text-center border-collapse text-[9px]">
                <thead>
                  <tr className="bg-[#F97316] text-white font-black uppercase divide-x divide-white/10">
                    <th rowSpan={3} className="py-4 w-32 border-b border-white/10">Equipment ID</th>
                    <th rowSpan={3} className="py-4 w-32 border-b border-white/10">Model No</th>
                    <th rowSpan={3} className="py-4 w-32 border-b border-white/10">Serial No</th>
                    <th colSpan={6} className="py-2 bg-[#3B82F6] border-b border-white/10">Design</th>
                    <th colSpan={11} className="py-2 bg-[#10B981] border-b border-white/10">Measured</th>
                    {!readOnly && <th rowSpan={3} className="w-40 bg-slate-50 text-slate-400 font-bold uppercase border-b border-white/10">Actions</th>}
                  </tr>
                  <tr className="bg-[#F97316] text-white font-black uppercase divide-x divide-white/10 border-t border-white/10">
                    <th className="py-2">Airflow</th><th className="py-2">RA Temp</th><th className="py-2">SA Temp</th><th className="py-2">Power</th><th className="py-2">Water Flow</th><th className="py-2 bg-blue-700">Cooling Tonnage</th>
                    <th className="py-2">Airflow</th><th className="py-2">SA Temp</th><th className="py-2">RA Temp</th><th className="py-2">Fan Speed</th><th className="py-2 bg-emerald-700">Cooling Tonnage (Air)</th><th className="py-2">Power</th><th className="py-2">CHW In</th><th className="py-2">CHW Out</th><th className="py-2">Valve Opening</th><th className="py-2">Water Flow</th><th className="py-2 bg-teal-700">Cooling Tonnage (Water)</th>
                  </tr>
                  <tr className="bg-[#F97316]/90 text-white font-black uppercase divide-x divide-white/10 border-t border-white/10 text-[8px]">
                    <th className="py-1">CFM</th><th className="py-1">(°C)</th><th className="py-1">(°C)</th><th className="py-1">kW</th><th className="py-1">GPM</th><th className="py-1 bg-blue-800">TR</th>
                    <th className="py-1">CFM</th><th className="py-1">(°C)</th><th className="py-1">(°C)</th><th className="py-1">%</th><th className="py-1 bg-emerald-800">TR</th><th className="py-1">kW</th><th className="py-1">(°C)</th><th className="py-1">(°C)</th><th className="py-1">%</th><th className="py-1">GPM</th><th className="py-1 bg-teal-800">TR</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
{(table.entries).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                  {table.entries.map((ent, idx) => {
                    const d_tra = calcTR(ent.designAirflow, ent.designRaTemp, ent.designSaTemp);
                    const m_tra = calcTR(ent.measuredAirflow, ent.measuredRaTemp, ent.measuredSaTemp);

                    const gpmVal = parseFloat(ent.measuredWaterFlowRate || '0') || 0;
                    const inVal = parseFloat(ent.measuredChwIn || '0') || 0;
                    const outVal = parseFloat(ent.measuredChwOut || '0') || 0;
                    const deltaC = Math.abs(outVal - inVal);
                    const waterTr = (gpmVal * deltaC * 1.8) / 24;

                    return (
                      <tr key={ent.id} className="hover:bg-slate-50 divide-x divide-slate-100">
                        <td className="p-0 font-bold"><input value={ent.equipmentId || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, equipmentId: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.modelNo || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, modelNo: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.serialNo || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, serialNo: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        {/* Design */}
                        <td className="p-0"><input value={ent.designAirflow || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designAirflow: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.designRaTemp || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designRaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.designSaTemp || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designSaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.designPower || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designPower: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.designWaterFlowRate || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designWaterFlowRate: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="py-2 bg-blue-50 font-black text-blue-700 text-[10px]">{d_tra.toFixed(1)}</td>
                        {/* Measured */}
                        <td className="p-0"><input value={ent.measuredAirflow || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredAirflow: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none font-bold text-blue-600" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredSaTemp || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredSaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredRaTemp || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredRaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredFanSpeed || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredFanSpeed: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="py-2 bg-emerald-50 font-black text-emerald-700 text-[10px]">{m_tra.toFixed(1)}</td>
                        <td className="p-0"><input value={ent.measuredPower || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredPower: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none text-slate-800" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredChwIn || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredChwIn: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredChwOut || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredChwOut: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredValveOpening || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredValveOpening: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredWaterFlowRate || ''} onChange={e => updateField('pahuTables', data.pahuTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredWaterFlowRate: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none text-slate-800" disabled={readOnly} /></td>
                        <td className="py-2 bg-teal-50 font-black text-teal-700 text-[10px]">{waterTr.toFixed(1)}</td>
                        {!readOnly && (
                          <td className="px-2 min-w-[170px]">
                            <div className="flex items-center justify-center gap-1 py-1">
                              {aiEnabled && (
                                <button
                                  type="button"
                                  onClick={() => openLiveCapture(table.id, idx, 0)}
                                  className="w-6 h-6 flex items-center justify-center text-purple-700 bg-purple-50 hover:bg-purple-100 rounded font-bold text-[9px] transition-colors"
                                  title="Live Capture row measurements"
                                >
                                  <Camera className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <button 
                                type="button"
                                onClick={() => insertPahuEntry(table.id, idx, 'above')} 
                                className="w-6 h-6 flex items-center justify-center text-blue-700 bg-blue-50 hover:bg-blue-100 rounded font-bold text-[9px] transition-colors"
                                title="Insert Empty Entry Above"
                              >
                                +↑
                              </button>
                              <button 
                                type="button"
                                onClick={() => insertPahuEntry(table.id, idx, 'below')} 
                                className="w-6 h-6 flex items-center justify-center text-blue-700 bg-blue-50 hover:bg-blue-100 rounded font-bold text-[9px] transition-colors"
                                title="Insert Empty Entry Below"
                              >
                                +↓
                              </button>
                              <button 
                                type="button"
                                onClick={() => duplicatePahuEntry(table.id, idx, 'above')} 
                                className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                                title="Duplicate Entry Above"
                              >
                                ❐↑
                              </button>
                              <button 
                                type="button"
                                onClick={() => duplicatePahuEntry(table.id, idx, 'below')} 
                                className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                                title="Duplicate Entry Below"
                              >
                                ❐↓
                              </button>
                              <button 
                                type="button"
                                onClick={() => return_confirmDelete('ROW', ent.id, 'PAHU', table.id)} 
                                className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                                title="Delete Entry"
                              >
                                ×
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                  {table.entries.length > 0 && (
                    <tr className="bg-slate-100 font-bold divide-x divide-slate-100 border-t-2 border-slate-300">
                      <td colSpan={9} className="py-2 text-right pr-4 uppercase text-slate-800">Total</td>
                      <td className="py-2 text-blue-805">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredAirflow || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredSaTemp || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredRaTemp || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredFanSpeed || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 bg-emerald-100 text-emerald-900">
                        {table.entries.reduce((sum, ent) => sum + calcTR(ent.measuredAirflow, ent.measuredRaTemp, ent.measuredSaTemp), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredPower || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredChwIn || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredChwOut || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredValveOpening || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredWaterFlowRate || '0') || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 bg-teal-100 text-teal-900">
                        {table.entries.reduce((sum, ent) => {
                          const gpm = parseFloat(ent.measuredWaterFlowRate || '0') || 0;
                          const chwIn = parseFloat(ent.measuredChwIn || '0') || 0;
                          const chwOut = parseFloat(ent.measuredChwOut || '0') || 0;
                          return sum + ((gpm * Math.abs(chwOut - chwIn) * 1.8) / 24);
                        }, 0).toFixed(1)}
                      </td>
                      {!readOnly && <td></td>}
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-center">
              {!readOnly && (
                <button onClick={() => addPahuEntry(table.id)} className="px-6 py-2 bg-blue-600 text-white rounded-xl font-black text-[10px] tracking-widest uppercase shadow-lg hover:bg-blue-700">+ Add PAHU Entry</button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* PAC TABLES */}
      <div className="space-y-8">
        {data.pacTables.map(table => (
          <div key={table.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in-down">
            <div className="bg-slate-50 px-6 py-4 flex justify-between items-center border-b border-slate-100">
               <div className="flex items-center gap-3">
                  <input 
                    value={table.tableNumber ? `${table.tableNumber} ${table.title}` : table.title} 
                    onChange={e => {
                      const val = e.target.value;
                      const spaceIndex = val.indexOf(' ');
                      const newNumber = spaceIndex !== -1 ? val.substring(0, spaceIndex) : '';
                      const newTitle = spaceIndex !== -1 ? val.substring(spaceIndex + 1) : val;
                      updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, tableNumber: newNumber, title: newTitle } : t));
                    }}
                    className="bg-transparent font-black text-slate-800 text-sm uppercase outline-none focus:border-b-2 border-blue-500 w-80"
                    disabled={readOnly}
                  />
                  <span className="text-xl">✏️</span>
               </div>
               <div className="flex items-center gap-2">
                 <button
                   onClick={() => exportPacTableToExcel(table, `${table.title?.replace(/\s+/g, '_') || 'PAC'}_Report_${new Date().toISOString().split('T')[0]}.xlsx`)}
                   className="p-1.5 bg-emerald-500/80 hover:bg-emerald-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                 >
                   <FileSpreadsheet className="w-3.5 h-3.5" /> Export
                 </button>
                 {!readOnly && (
                   <>
                     <button
                       onClick={() => handleImportPacExcel(table.id)}
                       className="p-1.5 bg-indigo-500/80 hover:bg-indigo-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                     >
                       <Upload className="w-3.5 h-3.5" /> Import
                     </button>
                     <button onClick={() => return_confirmDelete('TABLE', table.id, 'PAC')} className="p-1.5 bg-slate-200 hover:bg-red-500 text-slate-500 hover:text-white rounded transition-colors flex items-center justify-center w-7 h-7">
                       <TrashIcon />
                     </button>
                   </>
                 )}
               </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-center border-collapse text-[9px]">
                <thead>
                  <tr className="bg-[#F97316] text-white font-black uppercase divide-x divide-white/10">
                    <th rowSpan={3} className="py-4 w-32 border-b border-white/10">Equipment ID</th>
                    <th rowSpan={3} className="py-4 w-32 border-b border-white/10">Model No</th>
                    <th rowSpan={3} className="py-4 w-32 border-b border-white/10">Serial No</th>
                    <th colSpan={5} className="py-2 bg-[#3B82F6] border-b border-white/10">Design</th>
                    <th rowSpan={3} className="py-4 w-16 border-b border-white/10">Fan Speed (%)</th>
                    <th colSpan={5} className="py-2 bg-[#3B82F6] border-b border-white/10">Measured</th>
                    <th rowSpan={3} className="py-4 w-12 border-b border-white/10">COP</th>
                    {!readOnly && <th rowSpan={3} className="w-40 bg-slate-50 text-slate-400 font-bold uppercase border-b border-white/10">Actions</th>}
                  </tr>
                  <tr className="bg-[#F97316] text-white font-black uppercase divide-x divide-white/10 border-t border-white/10">
                    <th className="py-2">Airflow</th><th className="py-2">RA Temp</th><th className="py-2">SA Temp</th><th className="py-2">Power</th><th className="py-2 bg-blue-700">Cooling Tonnage</th>
                    <th className="py-2">Airflow</th><th className="py-2">RA Temp</th><th className="py-2">SA Temp</th><th className="py-2 bg-blue-700">Cooling Tonnage (Air Side)</th><th className="py-2">Power</th>
                  </tr>
                  <tr className="bg-[#F97316]/90 text-white font-black uppercase divide-x divide-white/10 border-t border-white/10 text-[8px]">
                    <th className="py-1">CFM</th><th className="py-1">(°C)</th><th className="py-1">(°C)</th><th className="py-1">kW</th><th className="py-1 bg-blue-800">TR</th>
                    <th className="py-1">CFM</th><th className="py-1">(°C)</th><th className="py-1">(°C)</th><th className="py-1 bg-blue-800">TR</th><th className="py-1">kW</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
{(table.entries).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                  {table.entries.map((ent, idx) => {
                    const d_tra = calcTR(ent.designAirflow, ent.designRaTemp, ent.designSaTemp);
                    const m_tra = calcTR(ent.measuredAirflow, ent.measuredRaTemp, ent.measuredSaTemp);
                    const cop = calcCop(m_tra, ent.measuredPower);
                    return (
                      <tr key={ent.id} className="hover:bg-slate-50 divide-x divide-slate-100">
                        <td className="p-0 font-bold"><input value={ent.equipmentId} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, equipmentId: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.modelNo} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, modelNo: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.serialNo} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, serialNo: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        {/* Design */}
                        <td className="p-0"><input value={ent.designAirflow} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designAirflow: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.designRaTemp} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designRaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.designSaTemp} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designSaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.designPower} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, designPower: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="py-2 bg-blue-50 font-black text-blue-700">{d_tra.toFixed(1)}</td>
                        {/* Fan Speed */}
                        <td className="p-0"><input value={ent.fanSpeed} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, fanSpeed: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none font-bold text-orange-600" disabled={readOnly} /></td>
                        {/* Measured */}
                        <td className="p-0"><input value={ent.measuredAirflow} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredAirflow: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none font-bold text-blue-600" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredRaTemp} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredRaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="p-0"><input value={ent.measuredSaTemp} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredSaTemp: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none" disabled={readOnly} /></td>
                        <td className="py-2 bg-blue-50 font-black text-blue-700">{m_tra.toFixed(1)}</td>
                        <td className="p-0"><input value={ent.measuredPower} onChange={e => updateField('pacTables', data.pacTables.map(t => t.id === table.id ? { ...t, entries: t.entries.map(r => r.id === ent.id ? { ...r, measuredPower: e.target.value } : r) } : t))} className="w-full p-2 bg-transparent text-center outline-none font-bold" disabled={readOnly} /></td>
                        {/* COP */}
                        <td className="py-2 bg-emerald-50 font-black text-emerald-700">{cop.toFixed(2)}</td>
                        {!readOnly && (
                          <td className="px-2 min-w-[145px]">
                            <div className="flex items-center justify-center gap-1 py-1">
                              <button 
                                type="button"
                                onClick={() => insertPacEntry(table.id, idx, 'above')} 
                                className="w-6 h-6 flex items-center justify-center text-blue-700 bg-blue-50 hover:bg-blue-100 rounded font-bold text-[9px] transition-colors"
                                title="Insert Empty Entry Above"
                              >
                                +↑
                              </button>
                              <button 
                                type="button"
                                onClick={() => insertPacEntry(table.id, idx, 'below')} 
                                className="w-6 h-6 flex items-center justify-center text-blue-700 bg-blue-50 hover:bg-blue-100 rounded font-bold text-[9px] transition-colors"
                                title="Insert Empty Entry Below"
                              >
                                +↓
                              </button>
                              <button 
                                type="button"
                                onClick={() => duplicatePacEntry(table.id, idx, 'above')} 
                                className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                                title="Duplicate Entry Above"
                              >
                                ❐↑
                              </button>
                              <button 
                                type="button"
                                onClick={() => duplicatePacEntry(table.id, idx, 'below')} 
                                className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                                title="Duplicate Entry Below"
                              >
                                ❐↓
                              </button>
                              <button 
                                type="button"
                                onClick={() => return_confirmDelete('ROW', ent.id, 'PAC', table.id)} 
                                className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                                title="Delete Entry"
                              >
                                ×
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                  {table.entries.length > 0 && (
                    <tr className="bg-slate-100 font-bold divide-x divide-slate-100 border-t-2 border-slate-300">
                      <td colSpan={9} className="py-2 text-right pr-4 uppercase text-slate-800">Total</td>
                      <td className="py-2 text-blue-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredAirflow) || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredRaTemp) || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredSaTemp) || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 bg-blue-100 text-blue-900">
                        {table.entries.reduce((sum, ent) => sum + calcTR(ent.measuredAirflow, ent.measuredRaTemp, ent.measuredSaTemp), 0).toFixed(1)}
                      </td>
                      <td className="py-2 text-slate-800">
                        {table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredPower) || 0), 0).toFixed(1)}
                      </td>
                      <td className="py-2 bg-emerald-100 text-emerald-800 font-black">
                        {calcCop(
                          table.entries.reduce((sum, ent) => sum + calcTR(ent.measuredAirflow, ent.measuredRaTemp, ent.measuredSaTemp), 0),
                          table.entries.reduce((sum, ent) => sum + (parseFloat(ent.measuredPower) || 0), 0).toString()
                        ).toFixed(2)}
                      </td>
                      {!readOnly && <td></td>}
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-center">
              {!readOnly && (
                <button onClick={() => addPacEntry(table.id)} className="px-6 py-2 bg-blue-600 text-white rounded-xl font-black text-[10px] tracking-widest uppercase shadow-lg hover:bg-blue-700">+ Add PAC Entry</button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {!readOnly && (
          <>
            <button onClick={addPahuTable} className="py-4 border-2 border-dashed border-blue-200 text-blue-600 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-blue-50 transition-all">+ CREATE PAHU TABLE (6.1)</button>
            <button onClick={addPacTable} className="py-4 border-2 border-dashed border-blue-200 text-blue-600 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-blue-50 transition-all">+ CREATE PAC TABLE (6.2)</button>
          </>
        )}
      </div>

      {/* IMPORT TABLE DATA SECTION */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in">
        <div className="bg-[#1E293B] px-6 py-4 flex justify-between items-center">
          <h3 className="font-black text-white text-xs uppercase tracking-widest flex items-center gap-2">
            <span>📥</span> IMPORT TABLE DATA (FOR CFM TEST)
          </h3>
          <div className="flex gap-2">
            <button 
              onClick={() => {
                // The totals are already reactive via useMemo/render logic, 
                // but we can trigger a small "refresh" animation or just a toast
                console.log("Refreshing totals...");
              }}
              className="px-4 py-1.5 bg-slate-700 text-white rounded-lg font-black text-[10px] uppercase hover:bg-slate-600 transition-all flex items-center gap-2"
            >
              <span>🔄</span> Refresh
            </button>
            <button 
              onClick={() => {
                const pahuTotal = data.pahuTables.reduce((sum, t) => 
                  sum + t.entries.reduce((s, e) => s + (parseFloat(e.measuredAirflow) || 0), 0), 0
                );
                const pacTotal = data.pacTables.reduce((sum, t) => 
                  sum + t.entries.reduce((s, e) => s + (parseFloat(e.measuredAirflow) || 0), 0), 0
                );
                const pahuTrTotal = data.pahuTables.reduce((sum, t) => 
                  sum + t.entries.reduce((s, e) => s + calcTR(e.measuredAirflow, e.measuredRaTemp, e.measuredSaTemp), 0), 0
                );
                const pacTrTotal = data.pacTables.reduce((sum, t) => 
                  sum + t.entries.reduce((s, e) => s + calcTR(e.measuredAirflow, e.measuredRaTemp, e.measuredSaTemp), 0), 0
                );
                const exportData = {
                  totalPahuCfm: pahuTotal.toFixed(2),
                  totalPacCfm: pacTotal.toFixed(2),
                  totalPahuTr: pahuTrTotal.toFixed(2),
                  totalPacTr: pacTrTotal.toFixed(2),
                  timestamp: new Date().toISOString()
                };
                const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `CFM_Import_Data_${new Date().toISOString().split('T')[0]}.json`;
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="px-4 py-1.5 bg-[#10B981] text-white rounded-lg font-black text-[10px] uppercase hover:bg-emerald-600 transition-all flex items-center gap-2 shadow-lg shadow-emerald-900/20"
            >
              <span>💾</span> Download Data
            </button>
          </div>
        </div>
        <div className="p-6">
          <div className="max-w-md mx-auto bg-slate-50 rounded-xl border border-slate-100 overflow-hidden">
            <table className="w-full text-left text-[11px]">
              <thead>
                <tr className="bg-slate-200 text-slate-600 font-black uppercase divide-x divide-white/20">
                  <th className="px-4 py-3">CATEGORY</th>
                  <th className="px-4 py-3 text-right">TOTAL CFM VALUE</th>
                  <th className="px-4 py-3 text-right">TOTAL TR VALUE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr className="divide-x divide-slate-200">
                  <td className="px-4 py-4 font-bold text-slate-700">PAHU</td>
                  <td className="px-4 py-4 text-right font-black text-blue-600 text-sm">
                    {data.pahuTables.reduce((sum, t) => 
                      sum + t.entries.reduce((s, e) => s + (parseFloat(e.measuredAirflow) || 0), 0), 0
                    ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-right font-black text-blue-600 text-sm">
                    {data.pahuTables.reduce((sum, t) => 
                      sum + t.entries.reduce((s, e) => s + calcTR(e.measuredAirflow, e.measuredRaTemp, e.measuredSaTemp), 0), 0
                    ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
                <tr className="divide-x divide-slate-200">
                  <td className="px-4 py-4 font-bold text-slate-700">PAC</td>
                  <td className="px-4 py-4 text-right font-black text-orange-600 text-sm">
                    {data.pacTables.reduce((sum, t) => 
                      sum + t.entries.reduce((s, e) => s + (parseFloat(e.measuredAirflow) || 0), 0), 0
                    ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-4 text-right font-black text-orange-600 text-sm">
                    {data.pacTables.reduce((sum, t) => 
                      sum + t.entries.reduce((s, e) => s + calcTR(e.measuredAirflow, e.measuredRaTemp, e.measuredSaTemp), 0), 0
                    ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-[9px] text-slate-400 text-center uppercase font-bold tracking-widest">
            * This data can be uploaded to the CFM Test module for automatic airflow synchronization.
          </p>
        </div>
      </section>

      {/* SUMMARY */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 space-y-8 text-sm">
         <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <span className="text-xl">📋</span>
            <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">OBSERVATIONS & RECOMMENDATIONS</h3>
         </div>
         
         <ObservationsRecommendationsTable 
           data={data.observationsAndRecommendations || []}
           onChange={(val) => updateField('observationsAndRecommendations', val)}
           readOnly={readOnly}
         />
      </section>

      {/* 6.1 PAHU LIVE CAPTURE WIZARD MODAL */}
      {liveCapture?.active && (() => {
        const targetTable = data.pahuTables.find(t => t.id === liveCapture.tableId);
        const targetEntry = targetTable?.entries[liveCapture.rowIndex];
        const steps = getPahuCaptureSteps();
        const currentStep = steps[liveCapture.stepIndex];

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-100">
              {/* Header */}
              <div className="bg-gradient-to-r from-purple-700 to-indigo-800 text-white p-4 flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-2">
                    <Camera className="w-5 h-5 text-purple-200" />
                    <h3 className="font-bold text-base uppercase tracking-wider">6.1 PAHU Live Capture Wizard</h3>
                  </div>
                  <p className="text-xs text-purple-200 mt-0.5">
                    Row {liveCapture.rowIndex + 1} of {targetTable?.entries.length || 1}: <span className="font-semibold text-white">{targetEntry?.equipmentId || `PAHU #${liveCapture.rowIndex + 1}`}</span>
                  </p>
                </div>
                <button
                  onClick={() => { stopCamera(); setLiveCapture(null); }}
                  className="text-purple-200 hover:text-white text-xl font-bold p-1 rounded-lg hover:bg-white/10 transition-colors"
                >
                  ✕
                </button>
              </div>

              {/* Step Bar */}
              <div className="bg-purple-50/80 px-4 py-2.5 border-b border-purple-100 flex items-center justify-between gap-1 text-[11px] font-semibold">
                {steps.map((st, idx) => {
                  const isActive = idx === liveCapture.stepIndex;
                  const isDone = idx < liveCapture.stepIndex;
                  return (
                    <div
                      key={st.key}
                      className={`flex-1 text-center py-1 px-1.5 rounded-md transition-all ${
                        isActive
                          ? 'bg-purple-600 text-white font-bold shadow-sm'
                          : isDone
                          ? 'bg-purple-200/60 text-purple-900'
                          : 'text-slate-400 bg-slate-100'
                      }`}
                    >
                      {st.label}
                    </div>
                  );
                })}
              </div>

              {/* Modal Body */}
              <div className="p-5 space-y-4">
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-xs text-slate-700">
                  <div className="font-bold text-slate-900 uppercase text-[11px] text-purple-900 flex items-center gap-1.5">
                    <span>Instrument:</span>
                    <span className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-[10px]">{currentStep.instrument}</span>
                  </div>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-600">{currentStep.guidance}</p>
                </div>

                <canvas ref={canvasRef} className="hidden" />

                {/* Camera Phase */}
                {liveCapture.phase === 'camera' && (
                  <div className="space-y-4">
                    <div className="relative aspect-video bg-black rounded-xl overflow-hidden shadow-inner flex items-center justify-center border border-slate-800">
                      <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
                      <div className="absolute inset-0 border-2 border-dashed border-purple-400/60 rounded-xl pointer-events-none m-6 flex items-center justify-center">
                        <span className="bg-black/50 text-white text-[10px] px-2 py-1 rounded backdrop-blur">Center display in frame</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={capturePhoto}
                        className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold text-sm tracking-wide shadow-lg flex items-center justify-center gap-2 transition-all"
                      >
                        <Camera className="w-4 h-4" /> Capture Photo
                      </button>
                      <button
                        type="button"
                        onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'review', value: '', error: '' } : null)}
                        className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs transition-colors"
                      >
                        Enter Manually
                      </button>
                    </div>
                  </div>
                )}

                {/* Reading Phase */}
                {liveCapture.phase === 'reading' && (
                  <div className="py-12 text-center space-y-3">
                    <div className="w-10 h-10 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="font-bold text-slate-800 text-sm">Analyzing instrument display with Gemini AI...</p>
                    <p className="text-xs text-slate-500">Extracting {currentStep.label} reading</p>
                  </div>
                )}

                {/* Review Phase */}
                {liveCapture.phase === 'review' && (
                  <div className="space-y-4">
                    {liveCapture.error && (
                      <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs font-medium">
                        ⚠️ {liveCapture.error}
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Captured Value for {currentStep.label} {currentStep.unit ? `(${currentStep.unit})` : ''}
                      </label>
                      <input
                        type="text"
                        value={liveCapture.value}
                        onChange={e => setLiveCapture(prev => prev ? { ...prev, value: e.target.value } : null)}
                        placeholder={`Enter ${currentStep.label}`}
                        className="w-full text-lg font-bold p-3 bg-slate-50 border-2 border-purple-300 focus:border-purple-600 rounded-xl outline-none text-slate-900"
                        autoFocus
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'camera', value: '', error: '' } : null)}
                        className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs transition-colors"
                      >
                        Retake Photo
                      </button>
                      <button
                        type="button"
                        onClick={handleConfirmReading}
                        className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs tracking-wider uppercase shadow-md transition-all"
                      >
                        Confirm &amp; Next →
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};

export const INITIAL_CAPACITY_DATA: CapacityAssessmentReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  toolsUsed: [],
  pahuTables: [],
  pacTables: [],
  observationsAndRecommendations: []
};
