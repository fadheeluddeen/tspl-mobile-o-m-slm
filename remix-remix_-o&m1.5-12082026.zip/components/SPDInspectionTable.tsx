import React from 'react';
import { SPDReading, SPDInspectionRow } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

interface SPDInspectionTableProps {
  data: SPDReading;
  onChange: (data: SPDReading) => void;
  readOnly?: boolean;
}

export const SPDInspectionTable: React.FC<SPDInspectionTableProps> = ({ data, onChange, readOnly = false }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();
  const safeInspections = Array.isArray(data?.inspections) ? data.inspections : [];

  const updateField = (field: keyof SPDReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addRow = () => {
    if (readOnly) return;
    const newRow: SPDInspectionRow = {
      id: `spd-${Date.now()}`,
      location: '',
      panelName: '',
      make: '',
      model: '',
      rating: '',
      remark: ''
    };
    onChange({ ...data, inspections: [...safeInspections, newRow] });
  };

  const deleteRow = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this SPD inspection record?",
      onConfirm: () => {
        onChange({ ...data, inspections: safeInspections.filter(r => r.id !== id) });
      }
    });
  };

  const updateRow = (id: string, field: keyof SPDInspectionRow, value: string) => {
    if (readOnly) return;
    const newInspections = safeInspections.map(r => r.id === id ? { ...r, [field]: value } : r);
    onChange({ ...data, inspections: newInspections });
  };

  return (
    <div className="space-y-10 animate-fade-in">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* 1. TEST PERSONNEL & SCHEDULE */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#FB923C] px-6 py-3 text-white">
          <h3 className="text-center font-bold uppercase tracking-wider text-sm">Test Personnel & Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Prepared By</label>
            <input 
              value={data?.preparedBy || ''} 
              onChange={e => updateField('preparedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tested By</label>
            <input 
              value={data?.testedBy || ''} 
              onChange={e => updateField('testedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tester Email</label>
            <input 
              value={data?.testerEmail || ''} 
              onChange={e => updateField('testerEmail', e.target.value)}
              placeholder="Email"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Witnessed By</label>
            <input 
              value={data?.witnessedBy || ''} 
              onChange={e => updateField('witnessedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Test Date</label>
            <input 
              type="date"
              value={data?.testDate || ''} 
              onChange={e => updateField('testDate', e.target.value)}
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
        </div>
      </section>

      {/* 2. SURGE PROTECTIVE DEVICE INSPECTION */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 flex justify-between items-center border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-blue-500 text-lg">⚡</span>
            <h3 className="font-bold text-slate-800 uppercase tracking-tight text-sm">4. Surge Protective Device Inspection</h3>
          </div>
          {!readOnly && (
            <button 
              onClick={addRow}
              className="px-4 py-1.5 text-xs font-bold text-orange-600 bg-orange-50 rounded-lg hover:bg-orange-100 transition-all border border-orange-100"
            >
              + ADD SPD ROW
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#FB923C] text-white">
                <th className="px-4 py-3 font-bold uppercase tracking-wider border-r border-white/10">SPD Location</th>
                <th className="px-4 py-3 font-bold uppercase tracking-wider border-r border-white/10">Panel Name</th>
                <th className="px-4 py-3 font-bold uppercase tracking-wider border-r border-white/10">Make</th>
                <th className="px-4 py-3 font-bold uppercase tracking-wider border-r border-white/10">Model</th>
                <th className="px-4 py-3 font-bold uppercase tracking-wider border-r border-white/10">Rating</th>
                <th className="px-4 py-3 font-bold uppercase tracking-wider border-r border-white/10">Remark</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {safeInspections.map(row => (
                <tr key={row.id} className="hover:bg-slate-50 group">
                  <td className="p-0 border-r border-slate-100">
                    <input value={row.location || ''} onChange={e => updateRow(row.id, 'location', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Enter Location" disabled={readOnly} />
                  </td>
                  <td className="p-0 border-r border-slate-100">
                    <input value={row.panelName || ''} onChange={e => updateRow(row.id, 'panelName', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Enter Panel Name" disabled={readOnly} />
                  </td>
                  <td className="p-0 border-r border-slate-100">
                    <input value={row.make || ''} onChange={e => updateRow(row.id, 'make', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Enter Make" disabled={readOnly} />
                  </td>
                  <td className="p-0 border-r border-slate-100">
                    <input value={row.model || ''} onChange={e => updateRow(row.id, 'model', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Enter Model" disabled={readOnly} />
                  </td>
                  <td className="p-0 border-r border-slate-100">
                    <input value={row.rating || ''} onChange={e => updateRow(row.id, 'rating', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Enter Rating" disabled={readOnly} />
                  </td>
                  <td className="p-0 border-r border-slate-100">
                    <input value={row.remark || ''} onChange={e => updateRow(row.id, 'remark', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Enter Remark" disabled={readOnly} />
                  </td>
                  {!readOnly && (
                    <td className="text-center px-2">
                      <button onClick={() => deleteRow(row.id)} className="text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">🗑️</button>
                    </td>
                  )}
                </tr>
              ))}
              {safeInspections.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400 italic">
                    No SPD inspections recorded. Click "Add SPD Row" to start.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

// Fixed: Added missing properties to match SPDReading interface
export const INITIAL_SPD_DATA: SPDReading = {
  preparedBy: '',
  testedBy: '',
  testerEmail: '',
  witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  status: 'PENDING',
  inspections: [],
  equipmentList: [],
  observations: '',
  recommendations: ''
};