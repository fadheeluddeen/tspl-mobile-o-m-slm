
import React from 'react';
import { SPOFReading, SPOFDCSection, SPOFInspectionRow, ObservationRecommendationRow } from '../types';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

// ... (rest of imports/icons)
const InfoIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
);
const FileIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-500"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
);
const ShieldIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
);
const TrashIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400 hover:text-red-500 transition-colors"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

interface SPOFTablesProps {
  data: SPOFReading;
  onChange: (data: SPOFReading) => void;
  readOnly?: boolean;
  templateName?: string;
}

export const SPOFTables: React.FC<SPOFTablesProps> = ({ data, onChange, readOnly = false, templateName }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

  const updateField = (field: keyof SPOFReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addDCSection = () => {
    const newList = [...(data.dcSections || [])];
    newList.push({
      id: `dc-${Date.now()}`,
      name: `DC-${newList.length + 1}`,
      rows: []
    });
    updateField('dcSections', newList);
  };

  const deleteDCSection = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this Entire DC Section and its inspection records?",
      onConfirm: () => {
        const newList = (data.dcSections || []).filter(sec => sec.id !== id);
        updateField('dcSections', newList);
      }
    });
  };

  const updateDCSectionName = (id: string, name: string) => {
    const newList = (data.dcSections || []).map(sec => sec.id === id ? { ...sec, name } : sec);
    updateField('dcSections', newList);
  };

  const addInspectionRow = (sectionId: string) => {
    const newList = (data.dcSections || []).map(sec => {
      if (sec.id === sectionId) {
        return {
          ...sec,
          rows: [...(sec.rows || []), {
            id: `row-${Date.now()}`,
            criticalEquipment: '',
            source: '',
            redundant: '',
            remarks: ''
          }]
        };
      }
      return sec;
    });
    updateField('dcSections', newList);
  };

  const deleteInspectionRow = (sectionId: string, rowId: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this equipment list row?",
      onConfirm: () => {
        const newList = (data.dcSections || []).map(sec => {
          if (sec.id === sectionId) {
            return {
              ...sec,
              rows: sec.rows.filter(r => r.id !== rowId)
            };
          }
          return sec;
        });
        updateField('dcSections', newList);
      }
    });
  };

  const insertInspectionRow = (sectionId: string, idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const newList = (data.dcSections || []).map(sec => {
      if (sec.id === sectionId) {
        const newRows = [...(sec.rows || [])];
        const newRow = {
          id: `row-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          criticalEquipment: '',
          source: '',
          redundant: '',
          remarks: ''
        };
        newRows.splice(targetIdx, 0, newRow);
        return {
          ...sec,
          rows: newRows
        };
      }
      return sec;
    });
    updateField('dcSections', newList);
  };

  const duplicateInspectionRow = (sectionId: string, idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const newList = (data.dcSections || []).map(sec => {
      if (sec.id === sectionId) {
        const newRows = [...(sec.rows || [])];
        const source = newRows[idx] || { criticalEquipment: '', source: '', redundant: '', remarks: '' };
        const newRow = {
          ...source,
          id: `row-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        };
        newRows.splice(targetIdx, 0, newRow);
        return {
          ...sec,
          rows: newRows
        };
      }
      return sec;
    });
    updateField('dcSections', newList);
  };

  const updateInspectionRow = (sectionId: string, rowId: string, field: keyof SPOFInspectionRow, value: string) => {
    const newList = (data.dcSections || []).map(sec => {
      if (sec.id === sectionId) {
        return {
          ...sec,
          rows: sec.rows.map(r => r.id === rowId ? { ...r, [field]: value } : r)
        };
      }
      return sec;
    });
    updateField('dcSections', newList);
  };

  return (
    <div className="space-y-10 animate-fade-in pb-20 font-sans">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* Main Header */}
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-4xl font-black text-[#B71C1C] tracking-widest uppercase">Single Point of Failure</h2>
          <p className="text-sm font-black text-slate-400 mt-1 tracking-widest uppercase">ELECTRICAL TESTING + EXECUTION DATA</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest">Status:</label>
          <select 
            value={data.status || 'PENDING'}
            onChange={e => updateField('status', e.target.value)}
            disabled={readOnly}
            className={`px-4 py-2 rounded-xl border-2 font-black text-xs uppercase tracking-widest outline-none transition-all appearance-none cursor-pointer
              ${data.status === 'PASS' ? 'bg-green-50 border-green-200 text-green-700' : 
                data.status === 'FAIL' ? 'bg-red-50 border-red-200 text-red-700' : 
                data.status === 'IN_PROGRESS' ? 'bg-blue-50 border-blue-200 text-blue-700' : 
                'bg-slate-50 border-slate-200 text-slate-600'}`}
          >
            <option value="PENDING">PENDING</option>
            <option value="IN_PROGRESS">IN PROGRESS</option>
            <option value="PASS">PASS</option>
            <option value="FAIL">FAIL</option>
          </select>
        </div>
      </div>

      {/* Grid 1x2: Scope & Template */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Scope & Description */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <InfoIcon />
            <h3 className="font-black text-slate-800 text-sm tracking-widest uppercase">SCOPE & DESCRIPTION</h3>
          </div>
          <textarea 
            value={data.scopeDescription || ''}
            onChange={e => updateField('scopeDescription', e.target.value)}
            disabled={readOnly}
            className="w-full h-32 p-3 text-sm text-slate-600 italic outline-none bg-slate-50 rounded-xl border border-slate-100 focus:bg-white transition-all resize-none"
            placeholder="Describe testing scope..."
          />
        </div>

        {/* Linked Template */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <FileIcon />
            <h3 className="font-black text-slate-800 text-sm tracking-widest uppercase">LINKED REPORT TEMPLATE</h3>
          </div>
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
            <div className="flex items-center gap-3">
              <span className="text-2xl">📄</span>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-slate-700 truncate max-w-[200px]">{templateName || 'No Template Linked'}</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Master Protocol Doc</span>
              </div>
            </div>
            {templateName && (
              <span className="px-3 py-1 bg-red-100 text-[#B71C1C] text-[10px] font-black rounded-lg uppercase tracking-widest">Linked</span>
            )}
          </div>
        </div>
      </div>

      {/* Table A: Personnel & Schedule */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white">
          <h3 className="text-center font-black uppercase tracking-widest text-xs">Personnel & Test Schedule</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-orange-50 text-orange-900 border-b border-orange-100 text-center font-black tracking-tighter uppercase">
                <th className="px-4 py-3 border-r border-orange-100">Prepared By</th>
                <th className="px-4 py-3 border-r border-orange-100">Tested By</th>
                <th className="px-4 py-3 border-r border-orange-100">Tester Email</th>
                <th className="px-4 py-3 border-r border-orange-100">Witnessed By</th>
                <th className="px-4 py-3 border-r border-orange-100">Approved By</th>
                <th className="px-4 py-3">Test Date</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="p-0 border-r border-slate-100"><input value={data.preparedBy || ''} onChange={e => updateField('preparedBy', e.target.value)} disabled={readOnly} className="w-full px-4 py-3 outline-none focus:bg-orange-50 transition-colors" placeholder="Name" /></td>
                <td className="p-0 border-r border-slate-100"><input value={data.testedBy || ''} onChange={e => updateField('testedBy', e.target.value)} disabled={readOnly} className="w-full px-4 py-3 outline-none focus:bg-orange-50 transition-colors" placeholder="Name" /></td>
                <td className="p-0 border-r border-slate-100"><input value={data.testerEmail || ''} onChange={e => updateField('testerEmail', e.target.value)} disabled={readOnly} className="w-full px-4 py-3 outline-none focus:bg-orange-50 transition-colors" placeholder="email@company.com" /></td>
                <td className="p-0 border-r border-slate-100"><input value={data.witnessedBy || ''} onChange={e => updateField('witnessedBy', e.target.value)} disabled={readOnly} className="w-full px-4 py-3 outline-none focus:bg-orange-50 transition-colors" placeholder="Name" /></td>
                <td className="p-0 border-r border-slate-100"><input value={data.approvedBy || ''} onChange={e => updateField('approvedBy', e.target.value)} disabled={readOnly} className="w-full px-4 py-3 outline-none focus:bg-orange-50 transition-colors" placeholder="Name" /></td>
                <td className="p-0"><input type="date" value={data.testDate || ''} onChange={e => updateField('testDate', e.target.value)} disabled={readOnly} className="w-full px-4 py-3 outline-none focus:bg-orange-50 transition-colors" /></td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* System Inspection (Dynamic Sections) */}
      <div className="space-y-8">
        <div className="flex justify-between items-center px-1">
          <div className="flex items-center gap-2">
            <ShieldIcon />
            <h3 className="font-black text-[#1E40AF] tracking-widest uppercase">System Inspection</h3>
          </div>
          {!readOnly && (
            <button 
              onClick={addDCSection}
              className="px-6 py-2 bg-blue-600 text-white rounded-xl font-black text-[10px] tracking-widest uppercase shadow-lg shadow-blue-100 hover:bg-blue-700 active:scale-95 transition-all"
            >
              + Add DC Section
            </button>
          )}
        </div>

        {(data.dcSections || []).map(section => (
          <div key={section.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in-down">
            {/* Section Controls */}
            <div className="bg-blue-50 px-6 py-4 border-b border-blue-100 flex justify-between items-center">
              <div className="flex items-center gap-4 flex-1">
                <input 
                  value={section.name} 
                  onChange={e => updateDCSectionName(section.id, e.target.value)}
                  className="bg-transparent font-black text-blue-900 uppercase tracking-widest text-sm outline-none border-b border-blue-200 focus:border-blue-500 transition-colors w-48"
                  placeholder="SECTION NAME (e.g. DC-1)"
                  disabled={readOnly}
                />
                {!readOnly && (
                  <button 
                    onClick={() => addInspectionRow(section.id)}
                    className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-[9px] font-black tracking-widest uppercase hover:bg-blue-700 transition-colors shadow-md shadow-blue-200"
                  >
                    + Add Equipment Detail
                  </button>
                )}
              </div>
              {!readOnly && (
                <button 
                  onClick={() => deleteDCSection(section.id)}
                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-all"
                  title="Delete Section"
                >
                  <TrashIcon />
                </button>
              )}
            </div>

            {/* Inspection Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-black uppercase tracking-tighter border-b border-slate-200">
                    <th className="px-6 py-4 border-r border-slate-200 w-1/3">CRITICAL EQUIPMENT LIST</th>
                    <th className="px-6 py-4 border-r border-slate-200 text-center">SOURCE</th>
                    <th className="px-6 py-4 border-r border-slate-200 text-center">REDUNDANT</th>
                    <th className="px-6 py-4">REMARKS</th>
                    {!readOnly && <th className="w-40 text-center">ACTIONS</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {(section.rows || []).map((row, idx) => (
                    <tr key={row.id} className="hover:bg-slate-50/50 group">
                      <td className="p-0 border-r border-slate-200">
                        <input 
                          value={row.criticalEquipment} 
                          onChange={e => updateInspectionRow(section.id, row.id, 'criticalEquipment', e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none font-medium"
                          placeholder="Equipment Name..."
                          disabled={readOnly}
                        />
                      </td>
                      <td className="p-0 border-r border-slate-200">
                        <input 
                          value={row.source} 
                          onChange={e => updateInspectionRow(section.id, row.id, 'source', e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none text-center"
                          placeholder="Input..."
                          disabled={readOnly}
                        />
                      </td>
                      <td className="p-0 border-r border-slate-200">
                        <input 
                          value={row.redundant} 
                          onChange={e => updateInspectionRow(section.id, row.id, 'redundant', e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none text-center font-bold text-blue-600"
                          placeholder="Input..."
                          disabled={readOnly}
                        />
                      </td>
                      <td className="p-0">
                        <input 
                          value={row.remarks} 
                          onChange={e => updateInspectionRow(section.id, row.id, 'remarks', e.target.value)}
                          className="w-full px-6 py-4 bg-transparent outline-none"
                          placeholder="Observations..."
                          disabled={readOnly}
                        />
                      </td>
                      {!readOnly && (
                        <td className="px-2 min-w-[145px]">
                          <div className="flex items-center justify-center gap-1.5 py-1">
                            <button 
                              type="button"
                              onClick={() => insertInspectionRow(section.id, idx, 'above')} 
                              className="w-6 h-6 flex items-center justify-center text-blue-700 bg-blue-50 hover:bg-blue-100 rounded font-bold text-[9px] transition-colors"
                              title="Insert Empty Detail Above"
                            >
                              +↑
                            </button>
                            <button 
                              type="button"
                              onClick={() => insertInspectionRow(section.id, idx, 'below')} 
                              className="w-6 h-6 flex items-center justify-center text-blue-700 bg-blue-50 hover:bg-blue-100 rounded font-bold text-[9px] transition-colors"
                              title="Insert Empty Detail Below"
                            >
                              +↓
                            </button>
                            <button 
                              type="button"
                              onClick={() => duplicateInspectionRow(section.id, idx, 'above')} 
                              className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                              title="Duplicate Detail Above"
                            >
                              ❐↑
                            </button>
                            <button 
                              type="button"
                              onClick={() => duplicateInspectionRow(section.id, idx, 'below')} 
                              className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                              title="Duplicate Detail Below"
                            >
                              ❐↓
                            </button>
                            <button 
                              type="button"
                              onClick={() => deleteInspectionRow(section.id, row.id)} 
                              className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                              title="Delete Detail"
                            >
                              ×
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                  {(section.rows || []).length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">No inspection rows yet. Click "+ Add Equipment Detail" to begin checking redundancy.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        ))}

        {(data.dcSections || []).length === 0 && (
          <div className="py-20 text-center border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50">
            <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mb-4">No Inspection Sections Registered</p>
            {!readOnly && (
              <button 
                onClick={addDCSection}
                className="px-8 py-3 bg-blue-600 text-white rounded-xl font-black text-xs tracking-widest uppercase shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all"
              >
                + Initialize DC-1 Section
              </button>
            )}
          </div>
        )}
      </div>

      {/* Observations & Recommendations */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 space-y-4">
         <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <InfoIcon />
            <h3 className="font-black text-slate-800 tracking-widest uppercase text-sm">Observations & Recommendations</h3>
         </div>
         
         <ObservationsRecommendationsTable 
           data={data.observationsAndRecommendations || []}
           onChange={(val) => updateField('observationsAndRecommendations', val)}
           readOnly={readOnly}
         />
      </section>

    </div>
  );
};

export const INITIAL_SPOF_DATA: SPOFReading = {
  status: 'PENDING',
  preparedBy: '',
  testedBy: '',
  testerEmail: '',
  witnessedBy: '',
  approvedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  scopeDescription: '',
  equipmentList: [],
  dcSections: [],
  observationsAndRecommendations: []
};
