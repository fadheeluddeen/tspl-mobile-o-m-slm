import React from 'react';
import { ObservationRecommendationRow } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

interface ObservationsRecommendationsTableProps {
  data: ObservationRecommendationRow[];
  onChange: (data: ObservationRecommendationRow[]) => void;
  readOnly?: boolean;
  isLCA?: boolean;
  rulRows?: any[];
}

const PlusIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
);

const TrashIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 hover:text-red-500 transition-colors"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

export const ObservationsRecommendationsTable: React.FC<ObservationsRecommendationsTableProps> = ({ 
  data = [], 
  onChange, 
  readOnly = false,
  isLCA = false,
  rulRows = []
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

  const getRowStatus = (r: any) => {
    const designLife = r.designLifeYrs || '';
    const age = r.ageYrs || '';
    const ageNum = Number(age) || 0;
    const hi = r.healthIndex || '';
    const hiNum = Number(hi) || 0;
    const uf = r.utilizationFactor || '';
    const ufNum = Number(uf) || 1;

    const dlNum = Number(designLife) || 0;
    const computedAL = (dlNum > 0 && hiNum > 0) 
      ? ((dlNum * hiNum) * ufNum).toFixed(1) 
      : '';
    const alNum = Number(computedAL) || 0;

    const computedRulYrs = (alNum > 0) 
      ? (alNum - ageNum).toFixed(1) 
      : '';
    const rulYrsNum = Number(computedRulYrs) || 0;

    const computedRulPct = (alNum > 0) 
      ? ((rulYrsNum / alNum) * 100).toFixed(1) 
      : '';
    const rulPctNum = Number(computedRulPct) || 0;

    let autoStatus = '';
    if (alNum > 0) {
      if (rulPctNum > 50) {
        autoStatus = 'Fit for Service';
      } else if (rulPctNum >= 25) {
        autoStatus = 'Degrading Stage';
      } else if (rulPctNum >= 10) {
        autoStatus = 'Approaching Replacement';
      } else if (rulPctNum > 0) {
        autoStatus = 'Reaching End-of-Life';
      } else {
        autoStatus = 'End-of-Life';
      }
    }
    return r.lifeCycleStatus !== '' && r.lifeCycleStatus !== undefined ? r.lifeCycleStatus : autoStatus;
  };

  const LCA_STATUSES = [
    'Fit for Service',
    'Degrading Stage',
    'Approaching Replacement',
    'Reaching End-of-Life',
    'End-of-Life'
  ];

  const lcaRowsToRender = LCA_STATUSES.map(status => {
    const existing = data.find(row => row.lifeCycleStatus === status);

    let defaultObs = '';
    let defaultRec = '';
    if (status === 'Fit for Service') {
      defaultObs = "Equipment is in good operating condition with sufficient remaining life.";
      defaultRec = "Continue normal operations. Maintain routine preventive maintenance schedule.";
    } else if (status === 'Degrading Stage') {
      defaultObs = "Early signs of ageing, performance still acceptable but degradation may begin.";
      defaultRec = "Increase preventive maintenance frequency and closely monitor performance.";
    } else if (status === 'Approaching Replacement') {
      defaultObs = "Significant life consumption, Increases risk of low performance.";
      defaultRec = "Initiate replacement planning, allocate budget, and define shutdown schedule.";
    } else if (status === 'Reaching End-of-Life') {
      defaultObs = "Equipment is near end of usable life, high risk of failure.";
      defaultRec = "Immediate replacement planning required. Prepare procurement and execution plan.";
    } else if (status === 'End-of-Life') {
      defaultObs = "1. Equipment has exceeded its estimated useful life.";
      defaultRec = "Urgent replacement required. Operate only if critical, with contingency support.";
    }

    const matchingRulRows = (rulRows || []).filter(r => getRowStatus(r) === status);
    const count = matchingRulRows.length;
    const tagsStr = count > 0 
      ? matchingRulRows.map(r => r.equipmentTag || 'Unnamed').join('\n') 
      : '-';

    return {
      id: existing?.id || `lca-status-${status}`,
      lifeCycleStatus: status,
      noOfEquipment: String(count),
      equipmentTag: tagsStr,
      observation: existing ? existing.observation : defaultObs,
      recommendation: existing ? existing.recommendation : defaultRec
    };
  });

  const handleLCAChange = (status: string, field: 'observation' | 'recommendation', val: string) => {
    const updated = lcaRowsToRender.map(row => {
      if (row.lifeCycleStatus === status) {
        return {
          ...row,
          [field]: val
        };
      }
      return row;
    });
    onChange(updated);
  };

  const addRow = () => {
    if (readOnly) return;
    const newList = [...data];
    newList.push({
      id: `obs-${Date.now()}`,
      observation: '',
      recommendation: '',
      lifeCycleStatus: isLCA ? '' : undefined,
      noOfEquipment: isLCA ? '' : undefined,
      equipmentTag: isLCA ? '' : undefined
    });
    onChange(newList);
  };

  const insertRow = (idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const newList = [...data];
    const newRow = {
      id: `obs-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      observation: '',
      recommendation: '',
      lifeCycleStatus: isLCA ? '' : undefined,
      noOfEquipment: isLCA ? '' : undefined,
      equipmentTag: isLCA ? '' : undefined
    };
    newList.splice(targetIdx, 0, newRow);
    onChange(newList);
  };

  const duplicateRow = (idx: number, position: 'above' | 'below') => {
    if (readOnly) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const newList = [...data];
    const source = newList[idx] || { observation: '', recommendation: '' };
    const newRow = {
      ...source,
      id: `obs-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };
    newList.splice(targetIdx, 0, newRow);
    onChange(newList);
  };

  const updateRow = (id: string, field: keyof ObservationRecommendationRow, value: string) => {
    if (readOnly) return;
    const newList = data.map(row => row.id === id ? { ...row, [field]: value } : row);
    onChange(newList);
  };

  const deleteRow = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this observation row?",
      onConfirm: () => {
        const newList = data.filter(row => row.id !== id);
        onChange(newList);
      }
    });
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      <div className="px-6 py-4 flex justify-between items-center border-b border-slate-100 bg-slate-50/50">
        <h3 className="font-black text-slate-800 text-xs uppercase tracking-widest flex items-center gap-2">
          <span>📋</span> Observations & Recommendations
        </h3>
        {!readOnly && !isLCA && (
          <button 
            type="button"
            onClick={addRow} 
            className="px-4 py-1.5 bg-[#135D7A] text-white rounded-lg font-black text-[10px] uppercase shadow-sm hover:bg-[#0e4b63] transition-all flex items-center gap-2"
          >
            <PlusIcon /> Add Observation
          </button>
        )}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-[11px] border-collapse">
          <thead>
            {isLCA ? (
              <tr className="bg-[#135D7A] text-white font-black uppercase tracking-wider text-xs border-b border-slate-200 divide-x divide-white/10">
                <th className="px-5 py-3.5 min-w-[170px] text-center">Life cycle Status</th>
                <th className="px-5 py-3.5 w-40 text-center">No. of Equipment</th>
                <th className="px-5 py-3.5 min-w-[200px] text-center">Equipment Tag / Name</th>
                <th className="px-5 py-3.5 min-w-[300px]">Observation</th>
                <th className="px-5 py-3.5 min-w-[300px]">Recommendation</th>
              </tr>
            ) : (
              <tr className="bg-[#135D7A] text-white font-black uppercase tracking-widest divide-x divide-white/10">
                <th className="px-4 py-3 w-16 text-center">SI. No</th>
                <th className="px-4 py-3 min-w-[300px]">Observation</th>
                <th className="px-4 py-3 min-w-[300px]">Recommendation</th>
                {!readOnly && <th className="px-4 py-3 w-40 text-center">Actions</th>}
              </tr>
            )}
          </thead>
          <tbody className="divide-y divide-slate-200">
            {isLCA ? (
              lcaRowsToRender.filter(row => Number(row.noOfEquipment) > 0).map((row) => (
                <tr key={row.id} className="hover:bg-slate-50/40 divide-x divide-slate-200">
                  {/* Life Cycle Status */}
                  <td className="px-5 py-4 text-center font-bold text-slate-800 text-xs bg-[#F0F7FF]/50 min-w-[170px] align-middle">
                    {row.lifeCycleStatus}
                  </td>

                  {/* No. of Equipment */}
                  <td className="px-5 py-4 text-center font-bold text-slate-700 font-mono text-xs bg-[#F0F7FF]/50 w-40 align-middle">
                    {row.noOfEquipment}
                  </td>

                  {/* Equipment Tag / Name */}
                  <td className="px-5 py-4 text-center text-slate-800 font-semibold text-xs bg-[#F0F7FF]/50 min-w-[200px] whitespace-pre-line align-middle">
                    {row.equipmentTag}
                  </td>

                  {/* Observation */}
                  <td className="p-0 align-top">
                    <textarea 
                      value={row.observation} 
                      onChange={e => handleLCAChange(row.lifeCycleStatus, 'observation', e.target.value)} 
                      className="w-full px-5 py-4 bg-transparent outline-none focus:bg-white transition-all text-slate-700 text-xs leading-relaxed resize-y min-h-[90px]" 
                      disabled={readOnly} 
                      placeholder="Describe specific observation..."
                    />
                  </td>

                  {/* Recommendation */}
                  <td className="p-0 align-top">
                    <textarea 
                      value={row.recommendation} 
                      onChange={e => handleLCAChange(row.lifeCycleStatus, 'recommendation', e.target.value)} 
                      className="w-full px-5 py-4 bg-transparent outline-none focus:bg-white transition-all text-slate-700 text-xs leading-relaxed resize-y min-h-[90px]" 
                      disabled={readOnly} 
                      placeholder="Technical recommendation..."
                    />
                  </td>
                </tr>
              ))
            ) : (
              data.map((row, i) => (
                <tr key={row.id} className="hover:bg-slate-50 divide-x divide-slate-100">
                  <td className="px-4 py-3 text-center text-slate-500 font-black">{i + 1}</td>
                  
                  {/* Observation */}
                  <td className="p-0">
                    <textarea 
                      value={row.observation} 
                      onChange={e => updateRow(row.id, 'observation', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none focus:bg-white transition-all resize-none min-h-[60px]" 
                      disabled={readOnly} 
                      placeholder="Describe specific observation..."
                    />
                  </td>

                  {/* Recommendation */}
                  <td className="p-0">
                    <textarea 
                      value={row.recommendation} 
                      onChange={e => updateRow(row.id, 'recommendation', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none focus:bg-white transition-all resize-none min-h-[60px]" 
                      disabled={readOnly} 
                      placeholder="Technical recommendation..."
                    />
                  </td>
                  {!readOnly && (
                    <td className="px-2 min-w-[140px]">
                      <div className="flex items-center justify-center gap-1 py-1">
                        <button 
                          type="button"
                          onClick={() => insertRow(i, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Empty Observation Above"
                        >
                          +↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => insertRow(i, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Empty Observation Below"
                        >
                          +↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(i, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Observation Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(i, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Observation Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => deleteRow(row.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                          title="Delete Observation"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))
            )}
            {!isLCA && data.length === 0 && (
              <tr>
                <td colSpan={readOnly ? 3 : 4} className="px-6 py-12 text-center text-slate-400 italic bg-white">
                  No observations recorded. {!readOnly && 'Click "+ Add Observation" to begin.'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
