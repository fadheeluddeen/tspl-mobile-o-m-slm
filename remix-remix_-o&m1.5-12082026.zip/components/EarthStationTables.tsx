
import React, { useRef } from 'react';
import * as XLSX from 'xlsx';
import { Download, Upload, Camera } from 'lucide-react';
import { EarthStationReading, EarthEquipmentRow, EarthMeasuringRow, LiveCaptureConfig } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { exportEarthStationToExcel } from '../utils/excelExport';
import { readEarthContinuityDisplay } from '../services/geminiClient';

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

interface EarthStationTablesProps {
  data: EarthStationReading;
  onChange: (data: EarthStationReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

export const EarthStationTables: React.FC<EarthStationTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = false,
  liveCaptureConfig
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast, showToast } = useConfirmDelete();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const safeEquipmentList = Array.isArray(data?.equipmentList) ? data.equipmentList : [];
  const safeReadings = Array.isArray(data?.readings) ? data.readings : [];

  const [liveCapture, setLiveCapture] = React.useState<{
    active: boolean;
    rowIndex: number;
    rows: EarthMeasuringRow[];
    phase: 'camera' | 'reading' | 'review';
    readValue: string;
    error: string;
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? { ...prev, error: 'Camera not available or permission denied. Enter value manually below.', phase: 'review' } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    // Downscale to max 1280px at JPEG quality 0.7
    let width = video.videoWidth;
    let height = video.videoHeight;
    const maxDim = 1280;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }
    
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);
    
    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');
    
    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);
    
    try {
      const result = await readEarthContinuityDisplay(base64);
      setLiveCapture(prev => prev ? { ...prev, phase: 'review', readValue: result.measuredValue || '', error: '' } : null);
    } catch (err: any) {
      console.error('Live Capture error:', err);
      setLiveCapture(prev => prev ? { 
        ...prev, 
        phase: 'review', 
        readValue: '',
        error: `Error: ${err?.message || JSON.stringify(err)}`
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const { rowIndex, rows, readValue } = liveCapture;
    const row = rows[rowIndex];
    if (!row) return;
    
    // Write Measured Value via the existing contract
    updateMeasuringRow(row.id, 'measuredValue', readValue);
    
    const nextIndex = rowIndex + 1;
    if (nextIndex < rows.length) {
      setLiveCapture(prev => prev ? {
        ...prev,
        rowIndex: nextIndex,
        phase: 'camera',
        readValue: '',
        error: ''
      } : null);
    } else {
      stopCamera();
      setLiveCapture(null);
      showToast('All earth pits captured successfully!', 'success');
    }
  };

  const handleCancelCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const openLiveCapture = () => {
    if (safeReadings.length === 0) {
      showToast('Please add at least one earth pit row first.', 'error');
      return;
    }
    // Start with the first row that doesn't have a measuredValue, or first row
    let startIndex = safeReadings.findIndex(r => !r.measuredValue);
    if (startIndex === -1) startIndex = 0;
    
    setLiveCapture({
      active: true,
      rowIndex: startIndex,
      rows: safeReadings,
      phase: 'camera',
      readValue: '',
      error: ''
    });
  };

  React.useEffect(() => {
    if (liveCapture?.phase === 'camera') {
      startCamera();
    }
    return () => {
      if (liveCapture?.phase === 'camera') {
        stopCamera();
      }
    };
  }, [liveCapture?.phase, liveCapture?.rowIndex]);

  React.useEffect(() => {
    return () => stopCamera();
  }, []);

  const updateField = (field: keyof EarthStationReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isCsv = file.name.endsWith('.csv');
    const reader = new FileReader();

    reader.onload = (evt) => {
      const dataContent = evt.target?.result;
      if (!dataContent) return;

      let rows: any[] = [];

      try {
        if (isCsv) {
          const text = dataContent as string;
          rows = text.split('\n').map(line => line.split(',').map(c => c.trim()));
        } else {
          const workbook = XLSX.read(dataContent, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        }

        if (rows.length === 0) {
          showToast("The imported file is empty.", "error");
          return;
        }

        // Map columns by HEADER NAME
        let headerRowIndex = -1;
        let colIndices = {
          pitNo: -1,
          description: -1,
          measuredValue: -1,
          limitValue: -1
        };

        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          if (!row || !Array.isArray(row)) continue;

          let hasPit = false;
          let hasDesc = false;

          row.forEach((cell) => {
            if (cell === undefined || cell === null) return;
            const val = cell.toString().toLowerCase().trim().replace(/\s+/g, '');
            if (val.includes('pit') || val.includes('pitno')) {
              hasPit = true;
            }
            if (val.includes('desc') || val.includes('earthing')) {
              hasDesc = true;
            }
          });

          if (hasPit && hasDesc) {
            headerRowIndex = i;
            row.forEach((cell, cellIdx) => {
              if (cell === undefined || cell === null) return;
              const val = cell.toString().toLowerCase().trim().replace(/\s+/g, '');
              if (val.includes('pit') || val.includes('pitno')) {
                colIndices.pitNo = cellIdx;
              } else if (val.includes('desc') || val.includes('earthing')) {
                colIndices.description = cellIdx;
              } else if (val.includes('measured') || val.includes('measuredvalue') || val.includes('measuredvalue(ω)')) {
                colIndices.measuredValue = cellIdx;
              } else if (val.includes('limit') || val.includes('limitvalue') || val.includes('limitvalue(ω)')) {
                colIndices.limitValue = cellIdx;
              }
            });
            break;
          }
        }

        let startIdx = 0;
        if (headerRowIndex !== -1) {
          startIdx = headerRowIndex + 1;
        } else {
          // Fallback to default index mapping
          colIndices = {
            pitNo: 0,
            description: 1,
            measuredValue: 2,
            limitValue: 3
          };
          const firstCell = rows[0]?.[0]?.toString().toLowerCase();
          if (firstCell && (firstCell.includes('pit') || firstCell.includes('pitno') || firstCell.includes('earth'))) {
            startIdx = 1;
          } else {
            startIdx = 0;
          }
        }

        const newReadings: EarthMeasuringRow[] = [];

        for (let i = startIdx; i < rows.length; i++) {
          const cols = rows[i];
          if (!cols || !Array.isArray(cols)) continue;

          const rawPitNo = colIndices.pitNo !== -1 ? cols[colIndices.pitNo] : undefined;
          const rawDesc = colIndices.description !== -1 ? cols[colIndices.description] : undefined;
          const rawMeasured = colIndices.measuredValue !== -1 ? cols[colIndices.measuredValue] : '';
          const rawLimit = colIndices.limitValue !== -1 ? cols[colIndices.limitValue] : '2';

          if ((rawPitNo === undefined || rawPitNo === null || rawPitNo === '') &&
              (rawDesc === undefined || rawDesc === null || rawDesc === '') &&
              (rawMeasured === undefined || rawMeasured === null || rawMeasured === '')) {
            continue; // Skip blank rows
          }

          const pitNo = rawPitNo !== undefined && rawPitNo !== null ? rawPitNo.toString().trim() : `EP-${newReadings.length + 1}`;
          const description = rawDesc !== undefined && rawDesc !== null ? rawDesc.toString().trim() : '';
          const measuredValue = rawMeasured !== undefined && rawMeasured !== null ? rawMeasured.toString().trim() : '';
          const limitValue = rawLimit !== undefined && rawLimit !== null ? rawLimit.toString().trim() : '2';

          // Recompute Remarks from Measured vs Limit
          let remarks = 'ok';
          const mv = parseFloat(measuredValue);
          const lv = parseFloat(limitValue);
          if (!isNaN(mv) && !isNaN(lv) && mv > lv) {
            remarks = 'High Resistance - Review Required';
          } else if (!isNaN(mv)) {
            remarks = 'ok';
          }

          newReadings.push({
            id: `rd-imported-${Date.now()}-${i}`,
            pitNo,
            description,
            measuredValue,
            limitValue,
            remarks
          });
        }

        if (newReadings.length === 0) {
          showToast("No valid data rows found to import.", "error");
          return;
        }

        updateField('readings', newReadings);
        showToast(`Successfully imported ${newReadings.length} earth pit readings!`, "success");
      } catch (err: any) {
        console.error('Error importing Excel:', err);
        showToast(`Failed to import Excel: ${err?.message || 'Check console log'}`, "error");
      } finally {
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    };

    if (isCsv) {
      reader.readAsText(file);
    } else {
      reader.readAsBinaryString(file);
    }
  };

  const addEquipmentRow = () => {
    const newList = [...safeEquipmentList];
    newList.push({
      id: `eq-${Date.now()}`,
      name: '',
      make: '',
      serial: '',
      model: '',
      calDate: '',
      expDate: ''
    });
    updateField('equipmentList', newList);
  };

  const addMeasuringRow = () => {
    const newList = [...safeReadings];
    newList.push({
      id: `rd-${Date.now()}`,
      pitNo: `EP-${newList.length + 1}`,
      description: '',
      measuredValue: '',
      limitValue: '2',
      remarks: 'ok'
    });
    updateField('readings', newList);
  };

  const updateEquipmentRow = (id: string, field: keyof EarthEquipmentRow, value: string) => {
    const newList = safeEquipmentList.map(item => item.id === id ? { ...item, [field]: value } : item);
    updateField('equipmentList', newList);
  };

  const updateMeasuringRow = (id: string, field: keyof EarthMeasuringRow, value: string) => {
    const newList = safeReadings.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value };
        // Auto-flag non-conformance
        if (field === 'measuredValue' || field === 'limitValue') {
          const mv = parseFloat(updated.measuredValue);
          const lv = parseFloat(updated.limitValue);
          if (!isNaN(mv) && !isNaN(lv) && mv > lv) {
            updated.remarks = 'High Resistance - Review Required';
          } else if (!isNaN(mv)) {
            updated.remarks = 'ok';
          }
        }
        return updated;
      }
      return item;
    });
    updateField('readings', newList);
  };

  const deleteRow = (field: 'equipmentList' | 'readings', id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: `Are you sure you want to delete this ${field === 'equipmentList' ? 'equipment' : 'earth pit reading'} record?`,
      onConfirm: () => {
        const newList = (data[field] as any[]).filter(item => item.id !== id);
        updateField(field, newList);
      }
    });
  };

  return (
    <div className="space-y-10 animate-fade-in">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* 1. TEST PERSONNEL & SCHEDULE */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#FB923C] px-6 py-3 text-white">
          <h3 className="text-center font-bold uppercase tracking-wider text-sm">Personnel & Test Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Prepared By</label>
            <input 
              value={data?.preparedBy || ''} 
              onChange={e => updateField('preparedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tested By</label>
            <input 
              value={data?.testedBy || ''} 
              onChange={e => updateField('testedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tester Email</label>
            <input 
              value={data?.testerEmail || ''} 
              onChange={e => updateField('testerEmail', e.target.value)}
              placeholder="Email"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Witnessed By</label>
            <input 
              value={data?.witnessedBy || ''} 
              onChange={e => updateField('witnessedBy', e.target.value)}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Test Date</label>
            <input 
              type="date"
              value={data?.testDate || ''} 
              onChange={e => updateField('testDate', e.target.value)}
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
        </div>
      </section>

      {/* Table 1: Test Equipment Used */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-4 text-white flex justify-between items-center">
          <h3 className="font-black uppercase tracking-tight text-sm">Table: Test Equipment Used</h3>
          {!readOnly && (
            <button onClick={addEquipmentRow} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-[10px] font-black uppercase transition-all">
              + Add Equipment
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="bg-orange-50 text-orange-800 border-b border-orange-100">
                <th className="px-4 py-3 font-black w-12 text-center border-r border-orange-100">Sr.No.</th>
                <th className="px-4 py-3 font-black border-r border-orange-100">Equipment name</th>
                <th className="px-4 py-3 font-black border-r border-orange-100">Make</th>
                <th className="px-4 py-3 font-black border-r border-orange-100">Serial number</th>
                <th className="px-4 py-3 font-black border-r border-orange-100">Model</th>
                <th className="px-4 py-3 font-black border-r border-orange-100 text-center">Calibration date</th>
                <th className="px-4 py-3 font-black text-center">Expiry date</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {safeEquipmentList.map((row, idx) => (
                <tr key={row.id} className="hover:bg-slate-50 group">
                  <td className="px-4 py-3 text-center text-slate-400 font-mono border-r border-slate-50">{idx + 1}</td>
                  <td className="p-0 border-r border-slate-50"><input value={row.name || ''} onChange={e => updateEquipmentRow(row.id, 'name', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 font-medium" placeholder="Earth Tester" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.make || ''} onChange={e => updateEquipmentRow(row.id, 'make', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Make" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.serial || ''} onChange={e => updateEquipmentRow(row.id, 'serial', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Serial" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.model || ''} onChange={e => updateEquipmentRow(row.id, 'model', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="Model" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input type="date" value={row.calDate || ''} onChange={e => updateEquipmentRow(row.id, 'calDate', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 text-center" disabled={readOnly} /></td>
                  <td className="p-0"><input type="date" value={row.expDate || ''} onChange={e => updateEquipmentRow(row.id, 'expDate', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 text-center" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="text-center px-2">
                      <button onClick={() => deleteRow('equipmentList', row.id)} className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><TrashIcon /></button>
                    </td>
                  )}
                </tr>
              ))}
              {safeEquipmentList.length === 0 && (
                <tr><td colSpan={8} className="py-8 text-center text-slate-400 italic font-medium">No equipment recorded.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Table 2: Measuring Details */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#FB923C] px-6 py-4 text-white flex justify-between items-center flex-wrap gap-4">
          <h3 className="font-black uppercase tracking-tight text-sm">Table: Measuring Details (Readings)</h3>
          <div className="flex items-center gap-3 flex-wrap">
            <button
              onClick={() => exportEarthStationToExcel(data, `Earth_Continuity_Report_${data.testDate || 'Report'}.xlsx`)}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-black uppercase shadow-sm transition-all border border-indigo-500 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export Excel
            </button>
            {!readOnly && (
              <>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black uppercase shadow-sm transition-all border border-emerald-500 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  Import Data
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".xlsx, .xls, .csv"
                  onChange={handleImportExcel}
                  className="hidden"
                />
              </>
            )}
            {aiEnabled && !readOnly && (
              <button
                onClick={openLiveCapture}
                className="flex items-center gap-2 px-3 py-1.5 bg-violet-600 hover:bg-violet-700 text-white rounded-lg text-[10px] font-black uppercase shadow-sm transition-all border border-violet-500 cursor-pointer"
                title="Live Capture - photograph meter readings"
              >
                <Camera className="w-3.5 h-3.5" />
                Live Capture
              </button>
            )}
            {!readOnly && (
              <button onClick={addMeasuringRow} className="px-3 py-1.5 bg-white text-orange-600 hover:bg-orange-50 rounded-lg text-[10px] font-black uppercase transition-all shadow-sm">
                + Add Earth Pit
              </button>
            )}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="bg-orange-50 text-orange-800 border-b border-orange-100">
                <th className="px-4 py-3 font-black border-r border-orange-100 w-32">Earth pit no</th>
                <th className="px-4 py-3 font-black border-r border-orange-100">Earthing description</th>
                <th className="px-4 py-3 font-black border-r border-orange-100 text-center w-36">Measured value (Ω)</th>
                <th className="px-4 py-3 font-black border-r border-orange-100 text-center w-36">Limit value (Ω)</th>
                <th className="px-4 py-3 font-black">Remarks</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {safeReadings.map(row => (
                <tr key={row.id} className="hover:bg-slate-50 group">
                  <td className="p-0 border-r border-slate-50"><input value={row.pitNo || ''} onChange={e => updateMeasuringRow(row.id, 'pitNo', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 font-bold text-slate-700" placeholder="EP-1" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input value={row.description || ''} onChange={e => updateMeasuringRow(row.id, 'description', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50" placeholder="e.g. UPS Input Grounding" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input type="number" step="0.01" value={row.measuredValue || ''} onChange={e => updateMeasuringRow(row.id, 'measuredValue', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 text-center font-black text-slate-900" placeholder="0.00" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-50"><input type="number" step="0.01" value={row.limitValue || ''} onChange={e => updateMeasuringRow(row.id, 'limitValue', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 text-center text-slate-500" placeholder="2.0" disabled={readOnly} /></td>
                  <td className="p-0">
                    <input 
                      value={row.remarks || ''} 
                      onChange={e => updateMeasuringRow(row.id, 'remarks', e.target.value)} 
                      className={`w-full px-4 py-3 bg-transparent outline-none focus:bg-orange-50 font-bold 
                        ${row.remarks === 'ok' ? 'text-green-600' : 'text-red-600'}`} 
                      placeholder="Remarks" 
                      disabled={readOnly} 
                    />
                  </td>
                  {!readOnly && (
                    <td className="text-center px-2">
                      <button onClick={() => deleteRow('readings', row.id)} className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><TrashIcon /></button>
                    </td>
                  )}
                </tr>
              ))}
              {safeReadings.length === 0 && (
                <tr><td colSpan={6} className="py-8 text-center text-slate-400 italic font-medium">No readings recorded.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Summary Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-2">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1 flex items-center gap-2">
            <span>📝</span> Test Observations
          </label>
          <textarea 
            value={data?.observations || ''} 
            onChange={e => updateField('observations', e.target.value)} 
            disabled={readOnly}
            placeholder="Capture environmental conditions (soil moisture, weather) and overall grid health..."
            className="w-full h-40 p-5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none text-sm leading-relaxed shadow-sm transition-all"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1 flex items-center gap-2">
            <span>🛠️</span> Professional Recommendations
          </label>
          <textarea 
            value={data?.recommendations || ''} 
            onChange={e => updateField('recommendations', e.target.value)} 
            disabled={readOnly}
            placeholder="Corrective actions (chemical treatment, deep boring, or conductor replacement)..."
            className="w-full h-40 p-5 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-orange-500 outline-none text-sm leading-relaxed shadow-sm transition-all"
          />
        </div>
      </div>

      {/* Live Capture Modal/Wizard */}
      {liveCapture && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-violet-600 px-6 py-4 rounded-t-2xl flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Live Capture (Earth Continuity)</h3>
                <p className="text-violet-200 text-sm">
                  Reading {liveCapture.rowIndex + 1} of {liveCapture.rows.length} — {liveCapture.rows[liveCapture.rowIndex]?.pitNo || 'Unknown'} — Measured Value (Ω)
                </p>
              </div>
              <button onClick={handleCancelCapture} className="text-white/80 hover:text-white text-2xl font-bold">×</button>
            </div>
            <div className="p-6 space-y-4">
              {liveCapture.phase === 'camera' && (
                <>
                  <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
                  <button onClick={capturePhoto} className="w-full py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer">
                    <Camera className="w-5 h-5" /> Capture Reading
                  </button>
                </>
              )}
              {liveCapture.phase === 'reading' && (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-violet-200 border-t-violet-600 mx-auto mb-4" />
                  <p className="text-slate-600 font-medium">Reading display...</p>
                  <p className="text-slate-400 text-sm mt-1">Analysing display photo</p>
                </div>
              )}
              {liveCapture.phase === 'review' && (
                <>
                  {liveCapture.error && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-amber-800 text-sm">
                      {liveCapture.error}
                    </div>
                  )}
                  <div className="bg-slate-50 rounded-xl p-4">
                    <h4 className="font-bold text-slate-700 mb-3">
                      Value for {liveCapture.rows[liveCapture.rowIndex]?.pitNo} ({liveCapture.rows[liveCapture.rowIndex]?.description || 'No Description'}) — confirm or correct:
                    </h4>
                    <div className="grid grid-cols-1 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Measured Value (Ω)</label>
                        <input
                          type="text"
                          value={liveCapture.readValue}
                          onChange={(e) => setLiveCapture(prev => prev ? { ...prev, readValue: e.target.value } : null)}
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-center font-mono text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="0.00"
                          autoFocus
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={handleConfirmReading} className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors cursor-pointer">
                      ✓ Confirm & Next
                    </button>
                    <button onClick={handleCancelCapture} className="px-6 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl transition-colors cursor-pointer">
                      Cancel
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const INITIAL_EARTH_STATION_DATA: EarthStationReading = {
  preparedBy: '',
  testedBy: '',
  testerEmail: '',
  witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  equipmentList: [],
  readings: [],
  observations: '',
  recommendations: ''
};
