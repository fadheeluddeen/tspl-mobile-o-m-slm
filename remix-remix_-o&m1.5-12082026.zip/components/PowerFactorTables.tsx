
import React, { useRef, useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { Download, Upload, Camera, CheckCircle, ChevronRight, ChevronLeft, X, RefreshCw, AlertCircle, Sparkles } from 'lucide-react';
import { 
  PowerFactorReading, 
  PowerFactorPanel, 
  PowerFactorBankRow, 
  PowerFactorBalanceRow,
  SPOFEquipmentRow,
  LiveCaptureConfig
} from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { exportPowerFactorToExcel } from '../utils/excelExport';
import { readSingleInstrumentDisplay } from '../services/geminiClient';

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

const ZapIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#B71C1C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
);

interface PowerFactorTablesProps {
  data: PowerFactorReading;
  onChange: (data: PowerFactorReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

interface CaptureStep {
  panelId: string;
  panelName: string;
  rowId: string;
  feederName: string;
  table: 'bank' | 'balance';
  fieldKey: string;
  fieldLabel: string;
  unit?: string;
  readingGuidance: string;
  currentVal?: string;
}

export const PowerFactorTables: React.FC<PowerFactorTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = true,
  liveCaptureConfig
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast, showToast } = useConfirmDelete();

  // --- Live Capture Wizard State ---
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [wizardSteps, setWizardSteps] = useState<CaptureStep[]>([]);
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [stepPhase, setStepPhase] = useState<'camera' | 'analyzing' | 'review'>('camera');
  const [capturedValue, setCapturedValue] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsCameraActive(true);
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError('Unable to access camera. You can enter values manually.');
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    if (isWizardOpen && stepPhase === 'camera') {
      startCamera();
    } else if (!isWizardOpen) {
      stopCamera();
    }
  }, [isWizardOpen, stepPhase, currentStepIdx]);

  const startLiveCapture = () => {
    if (readOnly) return;

    let currentPanels = data.panels || [];
    if (currentPanels.length === 0) {
      const rowId = `row-${Date.now()}`;
      const newPanel: PowerFactorPanel = {
        id: `panel-${Date.now()}`,
        panelName: 'MLTP-1 APFC',
        bankRows: [{
          id: rowId,
          feederName: 'Feeder 1',
          bankKvar: '', breakerRating: '', contactorRating: '', obtainedCap: '',
          actualRY: '', actualYB: '', actualBR: '', measuredKvar: '', acceptableLimit: '', remarks: ''
        }],
        balanceRows: [{
          id: rowId,
          feederName: 'Feeder 1',
          caseTemp: '', currentR: '', currentY: '', currentB: '', remarks: ''
        }]
      };
      currentPanels = [newPanel];
      onChange({ ...data, panels: currentPanels });
    } else {
      let needsUpdate = false;
      currentPanels = currentPanels.map(p => {
        if ((!p.bankRows || p.bankRows.length === 0) && (!p.balanceRows || p.balanceRows.length === 0)) {
          needsUpdate = true;
          const rowId = `row-${Date.now()}`;
          return {
            ...p,
            bankRows: [{
              id: rowId,
              feederName: 'Feeder 1',
              bankKvar: '', breakerRating: '', contactorRating: '', obtainedCap: '',
              actualRY: '', actualYB: '', actualBR: '', measuredKvar: '', acceptableLimit: '', remarks: ''
            }],
            balanceRows: [{
              id: rowId,
              feederName: 'Feeder 1',
              caseTemp: '', currentR: '', currentY: '', currentB: '', remarks: ''
            }]
          };
        }
        return p;
      });
      if (needsUpdate) {
        onChange({ ...data, panels: currentPanels });
      }
    }

    const balanceFields = liveCaptureConfig?.tables?.find(t => t.tableKey === 'balanceRows')?.fields || [
      { key: 'caseTemp', label: 'Case Temperature', unit: '°C', readingGuidance: 'Read the temperature value shown on the meter or thermal scanner in °C for case temperature. Preserve decimals. Ignore secondary readouts, range text, battery icon, and limit values.' },
      { key: 'currentR', label: 'R Phase Current', unit: 'A', readingGuidance: 'Read the live AC current measurement shown in Amperes (A) on the MECO 1080 clamp meter for R phase. Preserve decimals. Ignore range/mode text, MIN/MAX/HOLD annunciators, secondary readouts, battery icon, and limit values.' },
      { key: 'currentY', label: 'Y Phase Current', unit: 'A', readingGuidance: 'Read the live AC current measurement shown in Amperes (A) on the MECO 1080 clamp meter for Y phase. Preserve decimals. Ignore range/mode text, MIN/MAX/HOLD annunciators, secondary readouts, battery icon, and limit values.' },
      { key: 'currentB', label: 'B Phase Current', unit: 'A', readingGuidance: 'Read the live AC current measurement shown in Amperes (A) on the MECO 1080 clamp meter for B phase. Preserve decimals. Ignore range/mode text, MIN/MAX/HOLD annunciators, secondary readouts, battery icon, and limit values.' }
    ];

    const bankFields = liveCaptureConfig?.tables?.find(t => t.tableKey === 'bankRows')?.fields || [
      { key: 'measuredKvar', label: 'Measured kVAR', unit: 'kVAR', readingGuidance: 'Read the live reactive power measurement in kVAR shown on the meter display. Preserve decimals. Ignore ratings, limit thresholds, secondary readouts, range text, and battery icon.' },
      { key: 'actualRY', label: 'Actual RY Capacitance', unit: 'µF', readingGuidance: 'Read the live RY phase capacitance value in microfarads (µF) shown on the meter display. Preserve decimals. Ignore nominal ratings, limits, range text, and battery icon.' },
      { key: 'actualYB', label: 'Actual YB Capacitance', unit: 'µF', readingGuidance: 'Read the live YB phase capacitance value in microfarads (µF) shown on the meter display. Preserve decimals. Ignore nominal ratings, limits, range text, and battery icon.' },
      { key: 'actualBR', label: 'Actual BR Capacitance', unit: 'µF', readingGuidance: 'Read the live BR phase capacitance value in microfarads (µF) shown on the meter display. Preserve decimals. Ignore nominal ratings, limits, range text, and battery icon.' }
    ];

    const steps: CaptureStep[] = [];
    currentPanels.forEach(panel => {
      const rowCount = Math.max(panel.balanceRows?.length || 0, panel.bankRows?.length || 0);
      for (let i = 0; i < rowCount; i++) {
        const balRow = panel.balanceRows?.[i];
        const bankRow = panel.bankRows?.[i];
        const rowId = balRow?.id || bankRow?.id || `row-${i}`;
        const feederName = balRow?.feederName || bankRow?.feederName || `Feeder ${i + 1}`;

        // Table 2 (balance) fields first
        balanceFields.forEach(f => {
          steps.push({
            panelId: panel.id,
            panelName: panel.panelName || 'APFC Panel',
            rowId,
            feederName,
            table: 'balance',
            fieldKey: f.key,
            fieldLabel: f.label,
            unit: f.unit,
            readingGuidance: f.readingGuidance,
            currentVal: (balRow as any)?.[f.key] || ''
          });
        });

        // Table 1 (bank) fields next
        bankFields.forEach(f => {
          steps.push({
            panelId: panel.id,
            panelName: panel.panelName || 'APFC Panel',
            rowId,
            feederName,
            table: 'bank',
            fieldKey: f.key,
            fieldLabel: f.label,
            unit: f.unit,
            readingGuidance: f.readingGuidance,
            currentVal: (bankRow as any)?.[f.key] || ''
          });
        });
      }
    });

    if (steps.length === 0) {
      showToast('No metric rows available for capture.', 'error');
      return;
    }

    setWizardSteps(steps);
    setCurrentStepIdx(0);
    setCapturedValue(steps[0].currentVal || '');
    setStepPhase('camera');
    setIsWizardOpen(true);
  };

  const takePhotoAndAnalyze = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;

    let width = video.videoWidth || 1280;
    let height = video.videoHeight || 720;
    const maxDim = 1280;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, width, height);
    }
    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64Jpeg = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    setStepPhase('analyzing');

    const currentStep = wizardSteps[currentStepIdx];
    try {
      const val = await readSingleInstrumentDisplay(
        base64Jpeg,
        currentStep.fieldLabel,
        currentStep.unit,
        currentStep.readingGuidance
      );
      setCapturedValue(val);
      setStepPhase('review');
    } catch (err: any) {
      console.error('Gemini OCR error:', err);
      showToast('Unable to read display. Please enter value manually.', 'error');
      setCapturedValue('');
      setStepPhase('review');
    }
  };

  const confirmAndNext = () => {
    const currentStep = wizardSteps[currentStepIdx];
    if (currentStep) {
      updateMetricValue(
        currentStep.panelId,
        currentStep.rowId,
        currentStep.table,
        currentStep.fieldKey,
        capturedValue
      );
    }

    if (currentStepIdx < wizardSteps.length - 1) {
      const nextIdx = currentStepIdx + 1;
      setCurrentStepIdx(nextIdx);
      setCapturedValue(wizardSteps[nextIdx].currentVal || '');
      setStepPhase('camera');
    } else {
      stopCamera();
      setIsWizardOpen(false);
      showToast('Live capture complete! All values recorded successfully.', 'success');
    }
  };

  const skipStep = () => {
    if (currentStepIdx < wizardSteps.length - 1) {
      const nextIdx = currentStepIdx + 1;
      setCurrentStepIdx(nextIdx);
      setCapturedValue(wizardSteps[nextIdx].currentVal || '');
      setStepPhase('camera');
    } else {
      stopCamera();
      setIsWizardOpen(false);
    }
  };

  const prevStep = () => {
    if (currentStepIdx > 0) {
      const prevIdx = currentStepIdx - 1;
      setCurrentStepIdx(prevIdx);
      setCapturedValue(wizardSteps[prevIdx].currentVal || '');
      setStepPhase('camera');
    }
  };

  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isCsv = file.name.endsWith('.csv');
    const reader = new FileReader();

    reader.onload = (evt) => {
      try {
        const dataContent = evt.target?.result;
        if (!dataContent) return;

        let rows: any[][] = [];
        if (isCsv) {
          const text = dataContent as string;
          rows = text.split('\n').map(line => line.split(',').map(c => c.trim()));
        } else {
          const workbook = XLSX.read(dataContent, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        }

        if (!rows || rows.length === 0) {
          showToast("The imported file is empty.", "error");
          return;
        }

        const cleanVal = (val: any) => (val !== undefined && val !== null ? String(val).trim() : '');

        const panelStores: Array<{ panelName: string; itemsMap: Map<string, { feederName: string; bank: any; balance: any }> }> = [];

        const getOrCreatePanelStore = (name: string) => {
          let found = panelStores.find(p => p.panelName.toUpperCase() === name.toUpperCase());
          if (!found) {
            found = { panelName: name, itemsMap: new Map() };
            panelStores.push(found);
          }
          return found;
        };

        let activePanelStore = getOrCreatePanelStore(
          data.panels?.[0]?.panelName || 'MLTP-1 APFC'
        );

        let currentMode: 'BANK' | 'BALANCE' | 'BOTH' | 'NONE' = 'NONE';
        let colMap: { [key: string]: number } = {};

        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          if (!row || !Array.isArray(row) || row.length === 0) continue;

          const fullRowStr = row.map(cleanVal).join(' ').toUpperCase();

          if (fullRowStr.includes('APFC PANEL:') || fullRowStr.includes('PANEL:')) {
            let extractedName = fullRowStr;
            if (extractedName.includes('APFC PANEL:')) {
              extractedName = extractedName.split('APFC PANEL:')[1].trim();
            } else if (extractedName.includes('PANEL:')) {
              extractedName = extractedName.split('PANEL:')[1].trim();
            }
            if (extractedName) {
              activePanelStore = getOrCreatePanelStore(extractedName);
              currentMode = 'NONE';
              colMap = {};
              continue;
            }
          }

          let isBankHeader = false;
          let isBalanceHeader = false;
          const tempColMap: { [key: string]: number } = {};

          row.forEach((cell, cellIdx) => {
            if (cell === undefined || cell === null) return;
            const norm = cleanVal(cell).toLowerCase().replace(/[^a-z0-9]/g, '');
            if (!norm) return;

            if (norm.includes('feeder')) {
              tempColMap.feederName = cellIdx;
            } else if (norm.includes('bank') && !norm.includes('measured') && !norm.includes('limit') && !norm.includes('acceptable')) {
              tempColMap.bankKvar = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('breaker')) {
              tempColMap.breakerRating = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('contactor')) {
              tempColMap.contactorRating = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('obtained')) {
              tempColMap.obtainedCap = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('actualry') || norm === 'ry' || (norm.includes('actual') && norm.includes('ry'))) {
              tempColMap.actualRY = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('actualyb') || norm === 'yb' || (norm.includes('actual') && norm.includes('yb'))) {
              tempColMap.actualYB = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('actualbr') || norm === 'br' || (norm.includes('actual') && norm.includes('br'))) {
              tempColMap.actualBR = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('measured')) {
              tempColMap.measuredKvar = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('acceptable') || norm.includes('limit')) {
              tempColMap.acceptableLimit = cellIdx;
              isBankHeader = true;
            } else if (norm.includes('casetemp') || norm.includes('temperature') || norm === 'casetemperature') {
              tempColMap.caseTemp = cellIdx;
              isBalanceHeader = true;
            } else if (norm.includes('rphase') || norm.includes('currentr') || (norm.includes('r') && norm.includes('amp'))) {
              tempColMap.currentR = cellIdx;
              isBalanceHeader = true;
            } else if (norm.includes('yphase') || norm.includes('currenty') || (norm.includes('y') && norm.includes('amp'))) {
              tempColMap.currentY = cellIdx;
              isBalanceHeader = true;
            } else if (norm.includes('bphase') || norm.includes('currentb') || (norm.includes('b') && norm.includes('amp'))) {
              tempColMap.currentB = cellIdx;
              isBalanceHeader = true;
            } else if (norm.includes('remark')) {
              tempColMap.remarks = cellIdx;
              isBalanceHeader = true;
            }
          });

          if (isBankHeader || isBalanceHeader) {
            if (isBankHeader && isBalanceHeader) {
              currentMode = 'BOTH';
            } else if (isBankHeader) {
              currentMode = 'BANK';
            } else {
              currentMode = 'BALANCE';
            }
            colMap = tempColMap;
            continue;
          }

          if (currentMode !== 'NONE' && (tempColMap.feederName !== undefined || colMap.feederName !== undefined)) {
            const feederIdx = colMap.feederName ?? -1;
            const rawFeeder = feederIdx >= 0 ? cleanVal(row[feederIdx]) : '';

            if (!rawFeeder && !row.some(c => cleanVal(c) !== '')) continue;
            if (rawFeeder.toUpperCase().includes('TABLE') || rawFeeder.toUpperCase().includes('OBSERVATIONS') || rawFeeder.toUpperCase().includes('RECOMMENDATIONS')) continue;

            const feederKey = rawFeeder || `Row_${i}`;

            let existing = activePanelStore.itemsMap.get(feederKey);
            if (!existing) {
              existing = { feederName: rawFeeder, bank: {}, balance: {} };
              activePanelStore.itemsMap.set(feederKey, existing);
            }

            if (currentMode === 'BANK' || currentMode === 'BOTH') {
              if (colMap.bankKvar !== undefined) existing.bank.bankKvar = cleanVal(row[colMap.bankKvar]);
              if (colMap.breakerRating !== undefined) existing.bank.breakerRating = cleanVal(row[colMap.breakerRating]);
              if (colMap.contactorRating !== undefined) existing.bank.contactorRating = cleanVal(row[colMap.contactorRating]);
              if (colMap.obtainedCap !== undefined) existing.bank.obtainedCap = cleanVal(row[colMap.obtainedCap]);
              if (colMap.actualRY !== undefined) existing.bank.actualRY = cleanVal(row[colMap.actualRY]);
              if (colMap.actualYB !== undefined) existing.bank.actualYB = cleanVal(row[colMap.actualYB]);
              if (colMap.actualBR !== undefined) existing.bank.actualBR = cleanVal(row[colMap.actualBR]);
              if (colMap.measuredKvar !== undefined) existing.bank.measuredKvar = cleanVal(row[colMap.measuredKvar]);
              if (colMap.acceptableLimit !== undefined) existing.bank.acceptableLimit = cleanVal(row[colMap.acceptableLimit]);
            }

            if (currentMode === 'BALANCE' || currentMode === 'BOTH') {
              if (colMap.caseTemp !== undefined) existing.balance.caseTemp = cleanVal(row[colMap.caseTemp]);
              if (colMap.currentR !== undefined) existing.balance.currentR = cleanVal(row[colMap.currentR]);
              if (colMap.currentY !== undefined) existing.balance.currentY = cleanVal(row[colMap.currentY]);
              if (colMap.currentB !== undefined) existing.balance.currentB = cleanVal(row[colMap.currentB]);
              if (colMap.remarks !== undefined) existing.balance.remarks = cleanVal(row[colMap.remarks]);
            }
          }
        }

        if (panelStores.length === 0 || panelStores.every(p => p.itemsMap.size === 0)) {
          showToast("No valid metric rows found in the imported file.", "error");
          return;
        }

        let totalRowsCount = 0;
        const newPanels: PowerFactorPanel[] = panelStores.map((ps, pIdx) => {
          const bankRows: PowerFactorBankRow[] = [];
          const balanceRows: PowerFactorBalanceRow[] = [];

          let rowCounter = 0;
          ps.itemsMap.forEach((item, feederNameKey) => {
            rowCounter++;
            totalRowsCount++;
            const rowId = `row-${Date.now()}-${pIdx}-${rowCounter}`;
            const feederNameVal = item.feederName || feederNameKey;

            bankRows.push({
              id: rowId,
              feederName: feederNameVal,
              bankKvar: item.bank.bankKvar || '',
              breakerRating: item.bank.breakerRating || '',
              contactorRating: item.bank.contactorRating || '',
              obtainedCap: item.bank.obtainedCap || '',
              actualRY: item.bank.actualRY || '',
              actualYB: item.bank.actualYB || '',
              actualBR: item.bank.actualBR || '',
              measuredKvar: item.bank.measuredKvar || '',
              acceptableLimit: item.bank.acceptableLimit || '',
              remarks: ''
            });

            balanceRows.push({
              id: rowId,
              feederName: feederNameVal,
              caseTemp: item.balance.caseTemp || '',
              currentR: item.balance.currentR || '',
              currentY: item.balance.currentY || '',
              currentB: item.balance.currentB || '',
              remarks: item.balance.remarks || ''
            });
          });

          return {
            id: `panel-${Date.now()}-${pIdx}`,
            panelName: ps.panelName || `MLTP-${pIdx + 1} APFC`,
            bankRows,
            balanceRows
          };
        });

        updateField('panels', newPanels);
        showToast(`Successfully imported ${totalRowsCount} rows across ${newPanels.length} panel(s)!`, "success");
      } catch (err: any) {
        console.error('Import error:', err);
        showToast(`Error reading Excel file: ${err?.message || 'Invalid format'}`, "error");
      }
    };

    if (isCsv) {
      reader.readAsText(file);
    } else {
      reader.readAsBinaryString(file);
    }

    if (e.target) e.target.value = '';
  };
  const updateField = (field: keyof PowerFactorReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  // --- Equipment Management ---
  const addEquipment = () => {
    const list = [...(data.equipmentList || [])];
    list.push({ id: `eq-${Date.now()}`, name: '', make: '', model: '', serialNo: '', calDate: '', expDate: '' });
    updateField('equipmentList', list);
  };

  const updateEquipment = (id: string, f: keyof SPOFEquipmentRow, v: string) => {
    const list = data.equipmentList.map(eq => eq.id === id ? { ...eq, [f]: v } : eq);
    updateField('equipmentList', list);
  };

  // --- Panel Management ---
  const addPanel = () => {
    const panels = [...(data.panels || [])];
    panels.push({
      id: `panel-${Date.now()}`,
      panelName: `MLTP-${panels.length + 1} APFC`,
      bankRows: [],
      balanceRows: []
    });
    updateField('panels', panels);
  };

  const deletePanel = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this entire panel section and all its associated bank and balance metrics?",
      onConfirm: () => {
        const panels = data.panels.filter(p => p.id !== id);
        updateField('panels', panels);
      }
    });
  };

  // --- Synchronized Row Logic ---
  const addMetricRow = (panelId: string) => {
    const rowId = `row-${Date.now()}`;
    const panels = data.panels.map(p => {
      if (p.id === panelId) {
        return {
          ...p,
          bankRows: [...p.bankRows, { 
            id: rowId, 
            feederName: '', 
            bankKvar: '', 
            breakerRating: '', 
            contactorRating: '', 
            obtainedCap: '', 
            actualRY: '', 
            actualYB: '', 
            actualBR: '', 
            measuredKvar: '', 
            acceptableLimit: '', 
            remarks: '' 
          }],
          balanceRows: [...p.balanceRows, { id: rowId, feederName: '', caseTemp: '', currentR: '', currentY: '', currentB: '', remarks: '' }]
        };
      }
      return p;
    });
    updateField('panels', panels);
  };

  const deleteMetricRow = (panelId: string, rowId: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this metric row (both bank and balance readings)?",
      onConfirm: () => {
        const panels = data.panels.map(p => {
          if (p.id === panelId) {
            return {
              ...p,
              bankRows: p.bankRows.filter(r => r.id !== rowId),
              balanceRows: p.balanceRows.filter(r => r.id !== rowId)
            };
          }
          return p;
        });
        updateField('panels', panels);
      }
    });
  };

  // --- Field Sync Logic (Critical) ---
  const updateMetricValue = (panelId: string, rowId: string, table: 'bank' | 'balance', field: string, value: string) => {
    const panels = data.panels.map(p => {
      if (p.id === panelId) {
        let newBankRows = [...p.bankRows];
        let newBalanceRows = [...p.balanceRows];

        if (table === 'bank') {
          newBankRows = newBankRows.map(r => {
            if (r.id === rowId) {
              const updated = { ...r, [field]: value };
              // Sync Feeder Name bi-directionally
              if (field === 'feederName') {
                newBalanceRows = newBalanceRows.map(balR => balR.id === rowId ? { ...balR, feederName: value } : balR);
              }
              return updated;
            }
            return r;
          });
        } else {
          newBalanceRows = newBalanceRows.map(r => {
            if (r.id === rowId) {
              const updated = { ...r, [field]: value };
              // Sync Feeder Name bi-directionally
              if (field === 'feederName') {
                newBankRows = newBankRows.map(bankR => bankR.id === rowId ? { ...bankR, feederName: value } : bankR);
              }
              return updated;
            }
            return r;
          });
        }

        return { ...p, bankRows: newBankRows, balanceRows: newBalanceRows };
      }
      return p;
    });
    updateField('panels', panels);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-24">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* LIVE CAPTURE WIZARD MODAL */}
      {isWizardOpen && wizardSteps.length > 0 && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 px-6 py-4 text-white flex justify-between items-center">
              <div>
                <div className="flex items-center gap-2">
                  <Camera className="w-5 h-5 text-indigo-400" />
                  <h3 className="font-black uppercase tracking-wider text-sm text-indigo-100">Live Instrument Capture</h3>
                </div>
                <p className="text-xs text-slate-300 font-medium mt-0.5">
                  {wizardSteps[currentStepIdx]?.panelName} &bull; {wizardSteps[currentStepIdx]?.feederName}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs bg-indigo-500/20 text-indigo-200 px-3 py-1 rounded-full border border-indigo-500/30 font-bold">
                  Step {currentStepIdx + 1} of {wizardSteps.length}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setIsWizardOpen(false);
                  }}
                  className="text-slate-400 hover:text-white transition-colors p-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-5">
              {/* Target Field Info Banner */}
              <div className="bg-gradient-to-r from-orange-50 to-indigo-50 border border-orange-200/60 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-orange-600 block">
                    Target Measurement
                  </span>
                  <h4 className="text-lg font-black text-slate-800">
                    {wizardSteps[currentStepIdx]?.fieldLabel}
                    {wizardSteps[currentStepIdx]?.unit && (
                      <span className="text-sm font-bold text-slate-500 ml-1.5">
                        ({wizardSteps[currentStepIdx]?.unit})
                      </span>
                    )}
                  </h4>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Table
                  </span>
                  <span className="text-xs font-black uppercase text-indigo-700 bg-indigo-100/80 px-2.5 py-1 rounded-lg">
                    {wizardSteps[currentStepIdx]?.table === 'balance' ? 'Temperature & Current' : 'Capacitor Metrics'}
                  </span>
                </div>
              </div>

              {/* Guidance Note */}
              <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200/60 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                <p>{wizardSteps[currentStepIdx]?.readingGuidance}</p>
              </div>

              {/* Phase 1: Camera */}
              {stepPhase === 'camera' && (
                <div className="space-y-4">
                  <div className="relative bg-slate-950 rounded-2xl overflow-hidden aspect-video flex items-center justify-center border border-slate-800 shadow-inner">
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover"
                      playsInline
                      muted
                      autoPlay
                    />
                    <canvas ref={canvasRef} className="hidden" />

                    {/* Viewport Overlay */}
                    <div className="absolute inset-0 border-2 border-dashed border-white/40 m-8 rounded-xl pointer-events-none flex items-center justify-center">
                      <div className="text-white/60 text-[10px] font-bold uppercase tracking-widest bg-black/40 px-3 py-1 rounded-full backdrop-blur-sm">
                        Align meter display here
                      </div>
                    </div>

                    {cameraError && (
                      <div className="absolute inset-0 bg-slate-900/90 p-6 flex flex-col items-center justify-center text-center">
                        <AlertCircle className="w-10 h-10 text-amber-400 mb-2" />
                        <p className="text-sm text-slate-200 font-bold mb-3">{cameraError}</p>
                        <button
                          type="button"
                          onClick={() => setStepPhase('review')}
                          className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition-colors cursor-pointer"
                        >
                          Switch to Manual Entry
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-3 pt-2">
                    <button
                      type="button"
                      onClick={prevStep}
                      disabled={currentStepIdx === 0}
                      className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-900 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 cursor-pointer"
                    >
                      <ChevronLeft className="w-4 h-4" /> Previous
                    </button>

                    <button
                      type="button"
                      onClick={takePhotoAndAnalyze}
                      disabled={!isCameraActive && !cameraError}
                      className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-indigo-600 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-lg hover:from-orange-600 hover:to-indigo-700 transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer disabled:opacity-50"
                    >
                      <Camera className="w-4 h-4" /> Capture & Read
                    </button>

                    <button
                      type="button"
                      onClick={() => setStepPhase('review')}
                      className="px-4 py-2.5 text-xs font-bold text-indigo-600 hover:bg-indigo-50 rounded-xl transition-colors cursor-pointer"
                    >
                      Manual Entry
                    </button>
                  </div>
                </div>
              )}

              {/* Phase 2: Analyzing */}
              {stepPhase === 'analyzing' && (
                <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                    <Sparkles className="w-6 h-6 text-orange-500 absolute inset-0 m-auto animate-pulse" />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-800 text-base">Reading Instrument Display...</h4>
                    <p className="text-xs text-slate-500 mt-1">Gemini AI is extracting {wizardSteps[currentStepIdx]?.fieldLabel}</p>
                  </div>
                </div>
              )}

              {/* Phase 3: Review */}
              {stepPhase === 'review' && (
                <div className="space-y-5">
                  <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
                    <label className="text-xs font-black uppercase text-slate-500 tracking-wider block">
                      Captured / Verified Value
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="text"
                        value={capturedValue}
                        onChange={(e) => setCapturedValue(e.target.value)}
                        placeholder="e.g. 12.5"
                        autoFocus
                        className="flex-1 px-4 py-3 bg-white border-2 border-indigo-500 rounded-xl font-mono text-xl font-bold text-slate-900 outline-none focus:ring-4 ring-indigo-500/20 transition-all"
                      />
                      {wizardSteps[currentStepIdx]?.unit && (
                        <span className="font-bold text-slate-600 text-sm bg-slate-200/70 px-3 py-3 rounded-xl border border-slate-300">
                          {wizardSteps[currentStepIdx]?.unit}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Verify or edit the extracted value before confirming.
                    </p>
                  </div>

                  <div className="flex items-center justify-between gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setStepPhase('camera')}
                      className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                    >
                      <RefreshCw className="w-4 h-4" /> Retake Photo
                    </button>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={skipStep}
                        className="px-4 py-2.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                      >
                        Skip
                      </button>
                      <button
                        type="button"
                        onClick={confirmAndNext}
                        className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-lg hover:bg-emerald-700 transition-all flex items-center gap-2 active:scale-95 cursor-pointer"
                      >
                        <CheckCircle className="w-4 h-4" /> Confirm & Next
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer / Progress bar */}
            <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex items-center gap-4">
              <div className="flex-1 bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-orange-500 to-indigo-600 h-full transition-all duration-300 rounded-full"
                  style={{
                    width: `${((currentStepIdx + 1) / wizardSteps.length) * 100}%`
                  }}
                />
              </div>
              <span className="text-[10px] font-bold text-slate-400 font-mono">
                {Math.round(((currentStepIdx + 1) / wizardSteps.length) * 100)}%
              </span>
            </div>
          </div>
        </div>
      )}
      
      {/* HEADER SECTION */}
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3">
             <ZapIcon />
             <h2 className="text-3xl font-bold text-slate-800 tracking-tight uppercase">Power Factor / Capacitor health assessment</h2>
          </div>
          <p className="text-sm font-black text-slate-400 mt-1 tracking-widest uppercase">ELECTRICAL PORTFOLIO - EXECUTION DATA</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            type="button"
            onClick={() => exportPowerFactorToExcel(data, `Power_Factor_Assessment_${data.testDate || 'report'}.xlsx`)}
            className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow hover:bg-emerald-700 transition-all cursor-pointer"
            title="Export to Excel"
          >
            <Download className="w-4 h-4" /> Export Excel
          </button>
          {!readOnly && (
            <>
              {aiEnabled && (
                <button 
                  type="button"
                  onClick={startLiveCapture}
                  className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow hover:from-purple-700 hover:to-indigo-700 transition-all cursor-pointer active:scale-95"
                  title="Start Live Instrument Capture"
                >
                  <Camera className="w-4 h-4" /> Live Capture
                </button>
              )}
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow hover:bg-blue-700 transition-all cursor-pointer"
                title="Import from Excel"
              >
                <Upload className="w-4 h-4" /> Import Excel
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImportExcel} 
                accept=".xlsx, .xls, .csv" 
                className="hidden" 
              />
            </>
          )}
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Global Status</label>
          <select 
            value={data.status || 'PENDING'}
            onChange={e => updateField('status', e.target.value)}
            disabled={readOnly}
            className="px-4 py-2 rounded-xl border-2 font-black text-xs uppercase tracking-widest bg-white outline-none focus:ring-4 focus:ring-blue-50 transition-all cursor-pointer"
          >
            <option value="PENDING">Pending</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="PASS">Pass</option>
            <option value="FAIL">Fail</option>
          </select>
        </div>
      </div>

      {/* PERSONNEL & SCHEDULE */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white">
          <h3 className="text-center font-black uppercase tracking-widest text-xs">Personnel & Test Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                placeholder="---"
                className="w-full text-sm font-bold text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-500 outline-none p-2.5 rounded-xl transition-all"
              />
            </div>
          ))}
        </div>
      </section>

      {/* EQUIPMENT LIST */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white flex justify-between items-center">
          <h3 className="font-black uppercase tracking-widest text-xs">List of testing equipment (Calibration Detail)</h3>
          {!readOnly && (
            <button onClick={addEquipment} className="px-4 py-1 bg-white/20 hover:bg-white/30 rounded text-[9px] font-black uppercase tracking-widest transition-all">
              + ADD TOOL
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[10px] text-center border-collapse">
            <thead className="bg-orange-50 text-orange-900 font-black uppercase tracking-tighter">
              <tr className="divide-x divide-orange-100">
                <th className="px-4 py-3">EQUIPMENT NAME</th>
                <th className="px-4 py-3">MAKE</th>
                <th className="px-4 py-3">MODEL</th>
                <th className="px-4 py-3">SERIAL NO</th>
                <th className="px-4 py-3">CALIBRATION DATE</th>
                <th className="px-4 py-3">EXPIRY DATE</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
{((data.equipmentList || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data.equipmentList || []).map(eq => (
                <tr key={eq.id} className="hover:bg-slate-50 transition-colors divide-x divide-slate-100">
                  <td className="p-0"><input value={eq.name} onChange={e => updateEquipment(eq.id, 'name', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0"><input value={eq.make} onChange={e => updateEquipment(eq.id, 'make', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0"><input value={eq.model} onChange={e => updateEquipment(eq.id, 'model', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0"><input value={eq.serialNo} onChange={e => updateEquipment(eq.id, 'serialNo', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none font-mono" disabled={readOnly} /></td>
                  <td className="p-0"><input type="date" value={eq.calDate} onChange={e => updateEquipment(eq.id, 'calDate', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="p-0"><input type="date" value={eq.expDate} onChange={e => updateEquipment(eq.id, 'expDate', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                  {!readOnly && <td className="px-2">
                    <button 
                      onClick={() => 
                        confirmDelete({
                          message: "Are you sure you want to delete this instrument detailed record?",
                          onConfirm: () => updateField('equipmentList', data.equipmentList.filter(e => e.id !== eq.id))
                        })
                      } 
                      className="text-slate-300 hover:text-red-500 transition-colors"
                    >
                      🗑️
                    </button>
                  </td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* APFC PANEL INSPECTION DETAILS */}
      <section className="space-y-6">
        <div className="flex justify-between items-center px-1">
          <h3 className="font-black text-slate-800 tracking-widest text-sm uppercase">APFC PANEL INSPECTION DETAILS</h3>
          {!readOnly && (
            <button 
              onClick={addPanel}
              className="px-6 py-2 bg-blue-600 text-white rounded-xl font-black text-[10px] tracking-widest uppercase shadow-xl hover:bg-blue-700 transition-all flex items-center gap-2 active:scale-95"
            >
              <span className="text-lg">+</span> ADD PANEL SECTION
            </button>
          )}
        </div>

        {(data.panels || []).map(panel => (
          <div key={panel.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden slide-in-from-bottom-2 animate-in duration-300">
            <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
              <input 
                value={panel.panelName} 
                onChange={e => updateField('panels', data.panels.map(p => p.id === panel.id ? { ...p, panelName: e.target.value.toUpperCase() } : p))}
                className="bg-transparent font-black text-slate-800 uppercase tracking-widest text-sm outline-none w-1/3 focus:border-b-2 border-blue-500 transition-all"
                disabled={readOnly}
              />
              {!readOnly && (
                <div className="flex gap-2">
                   <button onClick={() => addMetricRow(panel.id)} className="px-5 py-2 bg-[#F97316] text-white rounded-xl font-black text-[10px] tracking-widest uppercase shadow-lg shadow-orange-100 hover:bg-orange-600 active:scale-95 transition-all">+ ADD METRIC ROW</button>
                   <button onClick={() => deletePanel(panel.id)} className="p-2 text-slate-300 hover:text-red-600 transition-colors"><TrashIcon /></button>
                </div>
              )}
            </div>

            <div className="p-6 space-y-8">
              {/* TABLE 1: BANK METRICS */}
              <div className="overflow-x-auto">
                <table className="w-full text-[9px] text-center border-collapse">
                  <thead className="bg-[#F97316] text-white uppercase font-black tracking-tighter">
                    <tr className="divide-x divide-white/10">
                      <th className="py-3 px-4 text-left w-48">FEEDER NAME</th>
                      <th className="py-3 px-2">CAPACITOR BANK IN KVAR</th>
                      <th className="py-3 px-2">BREAKER RATING IN A</th>
                      <th className="py-3 px-2">CONTACTOR RATING IN A</th>
                      <th className="py-3 px-2">OBTAINED CAPACITANCE IN <span className="normal-case">μF</span></th>
                      <th className="py-3 px-2">ACTUAL RY CAPACITANCE IN <span className="normal-case">μF</span></th>
                      <th className="py-3 px-2">ACTUAL YB CAPACITANCE IN <span className="normal-case">μF</span></th>
                      <th className="py-3 px-2">ACTUAL BR CAPACITANCE IN <span className="normal-case">μF</span></th>
                      <th className="py-3 px-2">MEASURED KVAR</th>
                      <th className="py-3 px-4">ACCEPTABLE LIMIT OF CAPACITANCE IN KVAR</th>
                      {!readOnly && <th className="w-8"></th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {panel.bankRows.map(row => (
                      <tr key={row.id} className="hover:bg-orange-50/20 transition-colors divide-x divide-slate-100">
                        <td className="p-0 text-left"><input value={row.feederName} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'feederName', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none font-bold uppercase" placeholder="..." disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.bankKvar} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'bankKvar', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.breakerRating} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'breakerRating', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.contactorRating} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'contactorRating', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.obtainedCap} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'obtainedCap', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.actualRY} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'actualRY', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.actualYB} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'actualYB', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.actualBR} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'actualBR', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.measuredKvar} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'measuredKvar', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center font-black text-blue-600" placeholder="0.00" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.acceptableLimit} onChange={e => updateMetricValue(panel.id, row.id, 'bank', 'acceptableLimit', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none font-medium" placeholder="Limit..." disabled={readOnly} /></td>
                        {!readOnly && <td className="px-2 text-center"><button onClick={() => deleteMetricRow(panel.id, row.id)} className="text-slate-300 hover:text-red-500 transition-colors">×</button></td>}
                      </tr>
                    ))}
                    {panel.bankRows.length === 0 && (
                       <tr><td colSpan={10} className="py-12 text-slate-400 italic text-center">No bank metrics added.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* TABLE 2: BALANCE DATA */}
              <div className="overflow-x-auto">
                <table className="w-full text-[9px] text-center border-collapse">
                  <thead className="bg-[#F97316] text-white uppercase font-black tracking-tighter">
                    <tr className="divide-x divide-white/10">
                      <th className="py-3 px-4 text-left w-48">FEEDER NAME</th>
                      <th className="py-3 px-2">CASE TEMPERATURE</th>
                      <th className="py-3 px-2">R PHASE CURRENT IN AMP</th>
                      <th className="py-3 px-2">Y PHASE CURRENT IN AMP</th>
                      <th className="py-3 px-2">B PHASE CURRENT IN AMP</th>
                      <th className="py-3 px-4">REMARKS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {panel.balanceRows.map(row => (
                      <tr key={row.id} className="hover:bg-orange-50/20 transition-colors divide-x divide-slate-100">
                        <td className="p-0 text-left bg-slate-50/50"><input value={row.feederName} onChange={e => updateMetricValue(panel.id, row.id, 'balance', 'feederName', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none font-bold uppercase text-slate-400" placeholder="..." disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.caseTemp} onChange={e => updateMetricValue(panel.id, row.id, 'balance', 'caseTemp', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="°C" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.currentR} onChange={e => updateMetricValue(panel.id, row.id, 'balance', 'currentR', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.currentY} onChange={e => updateMetricValue(panel.id, row.id, 'balance', 'currentY', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.currentB} onChange={e => updateMetricValue(panel.id, row.id, 'balance', 'currentB', e.target.value)} className="w-full py-3 bg-transparent outline-none text-center" placeholder="-" disabled={readOnly} /></td>
                        <td className="p-0"><input value={row.remarks} onChange={e => updateMetricValue(panel.id, row.id, 'balance', 'remarks', e.target.value)} className="w-full px-4 py-3 bg-transparent outline-none" placeholder="Notes..." disabled={readOnly} /></td>
                      </tr>
                    ))}
                    {panel.balanceRows.length === 0 && (
                       <tr><td colSpan={6} className="py-12 text-slate-400 italic text-center">No balance readings added. <button onClick={() => addMetricRow(panel.id)} className="text-blue-600 font-bold hover:underline">Add Initial Reading</button></td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* FOOTER SECTION */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 border-t border-slate-100 pt-8">
        <div className="space-y-2">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1">TEST OBSERVATIONS</label>
          <textarea 
            value={data.observations}
            onChange={e => updateField('observations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter detailed test observations..."
            className="w-full h-40 p-5 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 outline-none text-sm shadow-sm transition-all"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-1">RECOMMENDATIONS</label>
          <textarea 
            value={data.recommendations}
            onChange={e => updateField('recommendations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter professional recommendations..."
            className="w-full h-40 p-5 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-50 outline-none text-sm shadow-sm transition-all"
          />
        </div>
      </section>

    </div>
  );
};

export const INITIAL_POWER_FACTOR_DATA: PowerFactorReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  status: 'PENDING',
  equipmentList: [],
  panels: [],
  observations: '',
  recommendations: ''
};
