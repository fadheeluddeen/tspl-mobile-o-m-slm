
import React, { useMemo, useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { 
  CFMReading, 
  CFMCacTable, 
  CFMCacRow, 
  SPOFEquipmentRow,
  CFMToolRow,
  ObservationRecommendationRow,
  LiveCaptureConfig
} from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { CheckCircle, XCircle, FileSpreadsheet, ClipboardPaste, Upload, Camera } from 'lucide-react';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import { parseCFMExcel } from '../utils/excelImport';
import { readCfmDisplay } from '../services/geminiClient';

interface ParsedRow {
  rackRef: string;
  loadW: string;
  actualCFM: string;
}

interface BulkPasteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (rows: ParsedRow[], targetSide: 'left' | 'right' | 'split', mode: 'append' | 'replace' | 'merge') => void;
}

const BulkPasteModal: React.FC<BulkPasteModalProps> = ({ isOpen, onClose, onConfirm }) => {
  const [pasteData, setPasteData] = useState('');
  const [targetSide, setTargetSide] = useState<'left' | 'right' | 'split'>('left');
  const [mode, setMode] = useState<'append' | 'replace' | 'merge'>('merge');
  const [singleColMapping, setSingleColMapping] = useState<'auto' | 'rackRef' | 'loadW' | 'actualCFM'>('auto');
  const [error, setError] = useState('');
  const [previewRows, setPreviewRows] = useState<ParsedRow[] | null>(null);

  if (!isOpen) return null;

  const handleParse = () => {
    setError('');
    if (!pasteData.trim()) {
      setError('Paste data cannot be empty.');
      return;
    }

    const lines = pasteData.trim().split('\n');
    let startIndex = 0;
    let detectedMapping: 'rackRef' | 'loadW' | 'actualCFM' | null = null;

    if (lines.length > 0) {
      const firstLineCols = lines[0].split('\t').map(c => c.trim().toLowerCase());
      if (firstLineCols.length > 0) {
        const firstCol = firstLineCols[0];
        const isHeader = firstCol.includes('rack') || 
                        firstCol.includes('ref') || 
                        firstCol.includes('load') || 
                        firstCol.includes('cfm') ||
                        firstCol.includes('actual') ||
                        firstCol.includes('measure') ||
                        firstCol.includes('require') ||
                        firstCol.includes('deficit');
                        
        if (isHeader) {
          startIndex = 1;
          if (firstLineCols.length === 1) {
            if (firstCol.includes('cfm') || firstCol.includes('actual') || firstCol.includes('measure')) {
              detectedMapping = 'actualCFM';
            } else if (firstCol.includes('load') || firstCol.includes('w')) {
              detectedMapping = 'loadW';
            } else if (firstCol.includes('rack') || firstCol.includes('ref')) {
              detectedMapping = 'rackRef';
            }
          }
        }
      }
    }
    
    if (startIndex >= lines.length && lines.length > startIndex) {
      setError('No valid data rows found after skipping header.');
      return;
    }

    const rows: ParsedRow[] = [];
    for (let i = startIndex; i < lines.length; i++) {
        const lineVal = lines[i].trim();
        if (!lineVal) continue; // skip empty lines
        
        const cols = lines[i].split('\t').map(c => c.trim());
        if (cols.length === 0 || (cols.length === 1 && !cols[0])) continue;

        let rackRef = '';
        let loadW = '';
        let actualCFMVal = '';

        if (cols.length === 1) {
            const val = cols[0];
            const cleanVal = val.replace(/,/g, '').trim();
            const isNumeric = cleanVal !== '' && !isNaN(Number(cleanVal));
            
            let mapping = singleColMapping;
            if (mapping === 'auto' && detectedMapping) {
                mapping = detectedMapping;
            }

            if (mapping === 'auto') {
                if (isNumeric) {
                    loadW = cleanVal;
                } else {
                    rackRef = val;
                }
            } else if (mapping === 'rackRef') {
                rackRef = val;
            } else if (mapping === 'loadW') {
                loadW = cleanVal;
            } else if (mapping === 'actualCFM') {
                actualCFMVal = cleanVal;
            }
        } else {
            rackRef = cols[0] || '';
            const rawLoad = cols[1] || '';
            const cleanLoad = rawLoad.replace(/,/g, '');
            if (cleanLoad !== '' && !isNaN(Number(cleanLoad))) {
                loadW = cleanLoad;
            } else {
                loadW = rawLoad;
            }

            if (cols.length >= 3) {
                const rawCFM = cols[2] || '';
                const cleanCFM = rawCFM.replace(/,/g, '');
                if (cleanCFM !== '' && !isNaN(Number(cleanCFM))) {
                    actualCFMVal = cleanCFM;
                } else {
                    actualCFMVal = rawCFM;
                }
            }
        }
        
        rows.push({ rackRef, loadW, actualCFM: actualCFMVal });
    }

    if (rows.length === 0) {
        setError("No valid rows parsed.");
        return;
    }

    setPreviewRows(rows);
  };

  const handleSubmit = () => {
    if (previewRows) {
        onConfirm(previewRows, targetSide, mode);
        handleClose();
    }
  };

  const handleClose = () => {
    setPasteData('');
    setPreviewRows(null);
    setSingleColMapping('auto');
    setError('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest flex items-center gap-2">
            <ClipboardPaste size={16} className="text-orange-500" />
            Bulk Paste from Excel
          </h3>
          <button onClick={handleClose} className="p-2 text-slate-400 hover:text-red-500 hover:bg-slate-100 rounded-full transition-colors">
            <XCircle size={20} />
          </button>
        </div>

        <div className="p-6 flex-1 overflow-y-auto space-y-6">
          {error && (
            <div className="p-4 bg-red-50 border border-red-100 rounded-xl text-xs text-red-600 font-bold flex items-center gap-2">
              <XCircle size={14} className="text-red-500" />
              {error}
            </div>
          )}

          {!previewRows ? (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-black text-slate-600 uppercase tracking-widest mb-2 block">
                  1. Paste Excel Data
                </label>
                <div className="bg-orange-50 border border-orange-100 p-3 rounded-lg text-xs text-orange-800 mb-4 font-medium flex items-start gap-2">
                  <div className="px-1.5 py-0.5 bg-orange-200 rounded text-[10px] font-black shrink-0 mt-0.5">INFO</div>
                  <div>
                    Copy one, two, or three columns from Excel (RACK REFERENCE, RACK LOAD W, ACTUAL CFM) to paste them individually or together.<br/>
                    Headers (if present) will be automatically skipped.
                  </div>
                </div>
                <textarea
                  value={pasteData}
                  onChange={(e) => setPasteData(e.target.value)}
                  placeholder="A1&#9;6900&#9;800&#10;A2&#9;5400&#9;700&#10;B1&#9;4000..."
                  className="w-full h-48 p-4 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono focus:ring-2 focus:ring-orange-200 focus:border-orange-400 outline-none transition-all placeholder:text-slate-300 whitespace-pre"
                />
              </div>

              <div className="grid grid-cols-3 gap-6 pt-2 border-t border-slate-100">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Target Columns</label>
                  <div className="flex flex-col gap-2">
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={targetSide === 'left'} onChange={() => setTargetSide('left')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">CAC (Left Side)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={targetSide === 'split'} onChange={() => setTargetSide('split')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">Split L & R</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={targetSide === 'right'} onChange={() => setTargetSide('right')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">TABLE 1 (Right)</span>
                    </label>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">If pasting 1 column</label>
                  <div className="flex flex-col gap-2">
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={singleColMapping === 'auto'} onChange={() => setSingleColMapping('auto')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">Auto-Detect</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={singleColMapping === 'rackRef'} onChange={() => setSingleColMapping('rackRef')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">Rack Reference</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={singleColMapping === 'loadW'} onChange={() => setSingleColMapping('loadW')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">Rack Load W</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={singleColMapping === 'actualCFM'} onChange={() => setSingleColMapping('actualCFM')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">Actual CFM</span>
                    </label>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Action</label>
                  <div className="flex flex-col gap-2">
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={mode === 'merge'} onChange={() => setMode('merge')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-blue-600 group-hover:text-blue-700 transition-colors">Merge / Update columns</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={mode === 'append'} onChange={() => setMode('append')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-slate-700 group-hover:text-orange-600 transition-colors">Append below</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input type="radio" checked={mode === 'replace'} onChange={() => setMode('replace')} className="text-orange-500 focus:ring-orange-500" />
                      <span className="text-xs font-bold text-red-600 group-hover:text-red-700 transition-colors">Replace all</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
               <label className="text-xs font-black text-slate-600 uppercase tracking-widest block">
                 2. Preview Data ({previewRows.length} Rows)
               </label>
               <div className="bg-orange-50 border border-orange-100 p-4 rounded-xl overflow-x-auto max-h-64 overflow-y-auto">
                 <table className="w-full text-left text-xs bg-white rounded-lg overflow-hidden border-collapse">
                   <thead>
                     <tr className="bg-orange-100 text-orange-800 font-bold uppercase tracking-wider text-[10px]">
                       <th className="px-4 py-2 border-b border-orange-200">#</th>
                       <th className="px-4 py-2 border-b border-orange-200">Rack Reference</th>
                       <th className="px-4 py-2 border-b border-orange-200 text-right">Rack Load (W)</th>
                       <th className="px-4 py-2 border-b border-orange-200 text-right">Actual CFM</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-orange-50">
                     {previewRows.map((row, idx) => (
                       <tr key={idx} className="hover:bg-orange-50/30">
                         <td className="px-4 py-2 text-slate-400 font-mono w-10">{idx + 1}</td>
                         <td className="px-4 py-2 font-bold text-slate-700">{row.rackRef}</td>
                         <td className="px-4 py-2 text-right font-mono text-slate-700">{row.loadW}</td>
                         <td className="px-4 py-2 text-right font-mono text-slate-700">{row.actualCFM || '-'}</td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </div>
          )}
        </div>

        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
          <button 
            type="button"
            onClick={() => previewRows ? setPreviewRows(null) : handleClose()} 
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 bg-slate-100 rounded-lg transition-colors"
          >
            {previewRows ? 'Back to Paste' : 'Cancel'}
          </button>
          
          {!previewRows ? (
             <button 
              type="button"
              onClick={handleParse} 
              className="px-6 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-lg transition-colors shadow-md"
            >
              Parse Data
            </button>
          ) : (
            <button 
              type="button"
              onClick={handleSubmit} 
              className="px-6 py-2 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-2 shadow-md"
            >
              <CheckCircle size={14} /> Compare & Apply
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

interface CFMTablesProps {
  data: CFMReading;
  onChange: (data: CFMReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

const PlusIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
);

const SearchIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
);

const TrashIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 hover:text-red-500 transition-colors"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

export const CFMTables: React.FC<CFMTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = true,
  liveCaptureConfig
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, showToast, hideToast } = useConfirmDelete();
  const canEdit = !readOnly;
  const isVerified = data.isVerified || false;
  const [searchTerm, setSearchTerm] = useState('');
  const [pasteModalTableId, setPasteModalTableId] = useState<string | null>(null);

  // Live Capture state & refs
  const [liveCapture, setLiveCapture] = useState<{
    active: boolean;
    tableId: string;
    side: 'left' | 'right';
    rowIndex: number;
    rowId: string;
    rackRef: string;
    phase: 'camera' | 'reading' | 'review';
    value: string;
    error: string;
  } | null>(null);

  const videoRef = React.useRef<HTMLVideoElement | null>(null);
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null);
  const streamRef = React.useRef<MediaStream | null>(null);

  const openLiveCapture = (tableId: string, side: 'left' | 'right', rowIndex: number, rowId: string, rackRef: string) => {
    setLiveCapture({
      active: true,
      tableId,
      side,
      rowIndex,
      rowId,
      rackRef,
      phase: 'camera',
      value: '',
      error: ''
    });
  };

  const closeLiveCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera access error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? {
          ...prev,
          phase: 'review',
          error: 'Camera access unavailable. Enter value manually below.'
        } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (liveCapture?.active && liveCapture.phase === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [liveCapture?.active, liveCapture?.phase, liveCapture?.tableId, liveCapture?.side, liveCapture?.rowIndex]);

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;

    let width = video.videoWidth || 1280;
    let height = video.videoHeight || 720;
    const maxDim = 1280;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);

    const guidance = liveCaptureConfig?.tables?.[0]?.fields?.[0]?.readingGuidance ||
      'Read the single airflow value shown, in its displayed unit (CFM, CMM, or m³/h — read exactly as shown, do not convert). If using the anemometer (G-tech AVM-02) or flow hood (Testo 420): ignore air-velocity (m/s, ft/min) and temperature readouts; read only the airflow/CFM figure. Ignore mode/range text, min/max/hold indicators, and battery icons on either instrument.';

    try {
      const readVal = await readCfmDisplay(base64, guidance);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        value: readVal,
        error: readVal ? '' : 'Could not read value clearly. Please verify or enter manually.'
      } : null);
    } catch (err: any) {
      console.error('Gemini extraction error:', err);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        value: '',
        error: 'Failed to extract value. Please enter manually.'
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const { tableId, side, rowId, value } = liveCapture;
    updateCacRow(tableId, side, rowId, 'actualCFM', value);
    showToast(`Captured Actual CFM (${value || '0'}) for ${liveCapture.rackRef || 'rack'}.`, 'success');
    closeLiveCapture();
  };


  const setIsVerified = (v: boolean) => {
    if (v) {
      // Validate all required fields before allowing verification
      const errors: string[] = [];
      
      if (!data.preparedBy?.trim()) errors.push("Prepared By is required");
      if (!data.testedBy?.trim()) errors.push("Tested By is required");
      if (!data.testerEmail?.trim()) errors.push("Tester Email is required");
      if (!data.witnessedBy?.trim()) errors.push("Witnessed By is required");
      if (!data.testDate?.trim()) errors.push("Test Date is required");
      
      if (!data.deltaT?.trim()) errors.push("Rack Delta is required");
      if (!data.multiplier?.trim()) errors.push("Envelop Multiplier is required");

      if (!data.toolsUsed || data.toolsUsed.length === 0) {
        errors.push("At least one Tool is required");
      } else {
        data.toolsUsed.forEach((tool, i) => {
          if (!tool.instrumentName?.trim()) errors.push(`Tool ${i+1}: Instrument Name is required`);
          if (!tool.purpose?.trim()) errors.push(`Tool ${i+1}: Purpose is required`);
          if (!tool.make?.trim()) errors.push(`Tool ${i+1}: Make is required`);
          if (!tool.model?.trim()) errors.push(`Tool ${i+1}: Model is required`);
          if (!tool.calibrationIssue?.trim()) errors.push(`Tool ${i+1}: Calibration Issue date is required`);
          if (!tool.calibrationExpiry?.trim()) errors.push(`Tool ${i+1}: Calibration Expiry date is required`);
        });
      }

      if (!data.cacTables || data.cacTables.length === 0) {
        errors.push("At least one CAC Table is required");
      } else {
        data.cacTables.forEach((cac, i) => {
          if (!cac.cacName?.trim()) errors.push(`CAC Table ${i+1}: CAC Name is required`);
          
          if (cac.leftRows.length === 0 && cac.rightRows.length === 0) {
            errors.push(`CAC Table ${cac.cacName}: At least one row pair is required`);
          }

          cac.leftRows.forEach((row, j) => {
            if (!row.rackRef?.trim()) errors.push(`CAC ${cac.cacName}: Left Row ${j+1} - Rack Reference is required`);
            if (!row.loadW?.trim()) errors.push(`CAC ${cac.cacName}: Left Row ${j+1} - Rack Load is required`);
            if (!row.actualCFM?.trim()) errors.push(`CAC ${cac.cacName}: Left Row ${j+1} - Actual CFM is required`);
          });

          cac.rightRows.forEach((row, j) => {
            if (!row.rackRef?.trim()) errors.push(`CAC ${cac.cacName}: Right Row ${j+1} - Rack Reference is required`);
            if (!row.loadW?.trim()) errors.push(`CAC ${cac.cacName}: Right Row ${j+1} - Rack Load is required`);
            if (!row.actualCFM?.trim()) errors.push(`CAC ${cac.cacName}: Right Row ${j+1} - Actual CFM is required`);
          });
        });
      }

      if (errors.length > 0) {
        showToast(errors[0], "error");
        console.error("Validation errors:", errors);
        return;
      }
      
      showToast("Verification successful.", "success");
    }
    onChange({ ...data, isVerified: v });
  };

  const n = (v: string | number) => parseFloat(v.toString()) || 0;
  const f = (val: number) => val % 1 === 0 ? val.toFixed(0) : val.toFixed(2);

  const exportTableToExcel = (cac: CFMCacTable) => {
    // Sheet 1: Input Table Matches Above UI
    const sheet1Headers = [
      ["CAC", "", "", "", "TABLE 1", "", "", ""],
      ["RACK REFERENCE", "RACK LOAD W", "ACTUAL CFM", "REQUIRED CFM", "RACK REFERENCE", "RACK LOAD W", "ACTUAL CFM", "REQUIRED CFM"]
    ];

    const leftSub = cac.leftRows.reduce((sum, r) => sum + calculateReqCFM(r.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier), 0);
    const rightSub = cac.rightRows.reduce((sum, r) => sum + calculateReqCFM(r.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier), 0);
    const totalCfm = leftSub + rightSub;

    const sheet1Rows = Array.from({ length: Math.max(cac.leftRows.length, cac.rightRows.length) }).map((_, idx) => {
      const left = cac.leftRows[idx] || { rackRef: '', loadW: '', actualCFM: '' };
      const right = cac.rightRows[idx] || { rackRef: '', loadW: '', actualCFM: '' };

      const leftReq = calculateReqCFM(left.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);
      const rightReq = calculateReqCFM(right.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);

      return [
        left.rackRef, left.loadW, left.actualCFM, leftReq > 0 ? f(leftReq) : '',
        right.rackRef, right.loadW, right.actualCFM, rightReq > 0 ? f(rightReq) : ''
      ];
    });

    const sheet1Footer = [
      ["SUB TOTAL", "", "", Math.round(leftSub).toFixed(0), "SUB TOTAL", "", "", Math.round(rightSub).toFixed(0)],
      ["TOTAL CFM REQUIRED", "", "", Math.round(leftSub).toFixed(0), "TOTAL CFM REQUIRED", "", "", Math.round(rightSub).toFixed(0)],
      ["TOTAL SUPPLY CFM", "", "", "", "", "", "", Math.round(totalCfm).toFixed(0)]
    ];

    const worksheet1 = XLSX.utils.aoa_to_sheet([...sheet1Headers, ...sheet1Rows, ...sheet1Footer]);

    // Merges for Sheet 1
    worksheet1['!merges'] = [
      { s: { r: 0, c: 0 }, e: { r: 0, c: 3 } }, // CAC
      { s: { r: 0, c: 4 }, e: { r: 0, c: 7 } }, // TABLE 1
      { s: { r: sheet1Headers.length + sheet1Rows.length, c: 0 }, e: { r: sheet1Headers.length + sheet1Rows.length, c: 2 } }, // SUB TOTAL (Left)
      { s: { r: sheet1Headers.length + sheet1Rows.length, c: 4 }, e: { r: sheet1Headers.length + sheet1Rows.length, c: 6 } }, // SUB TOTAL (Right)
      { s: { r: sheet1Headers.length + sheet1Rows.length + 1, c: 0 }, e: { r: sheet1Headers.length + sheet1Rows.length + 1, c: 2 } }, // TOTAL CFM REQUIRED (Left)
      { s: { r: sheet1Headers.length + sheet1Rows.length + 1, c: 4 }, e: { r: sheet1Headers.length + sheet1Rows.length + 1, c: 6 } }, // TOTAL CFM REQUIRED (Right)
      { s: { r: sheet1Headers.length + sheet1Rows.length + 2, c: 0 }, e: { r: sheet1Headers.length + sheet1Rows.length + 2, c: 6 } }, // TOTAL SUPPLY CFM
    ];

    // Sheet 2: Preview Table Matches Below UI
    const sheet2Headers = [
      ["GRILL", "R 0 1", "", "", "", "R 0 2", "", "", ""],
      ["", "RACK LOAD", "ACTUAL", "REQUIRED", "DEFICIT", "RACK LOAD", "ACTUAL", "REQUIRED", "DEFICIT"]
    ];

    const sheet2Rows = Array.from({ length: Math.max(cac.leftRows.length, cac.rightRows.length) }).map((_, idx) => {
      const left = cac.leftRows[idx] || { loadW: '0', actualCFM: '0' };
      const right = cac.rightRows[idx] || { loadW: '0', actualCFM: '0' };

      const leftReq = calculateReqCFM(left.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);
      const rightReq = calculateReqCFM(right.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);

      const leftDef = n(left.actualCFM) - leftReq;
      const rightDef = n(right.actualCFM) - rightReq;

      return [
        idx + 1,
        left.loadW, left.actualCFM, f(leftReq), f(leftDef),
        right.loadW, right.actualCFM, f(rightReq), f(rightDef)
      ];
    });

    const leftLoadW = cac.leftRows.reduce((s, r) => s + n(r.loadW), 0);
    const rightLoadW = cac.rightRows.reduce((s, r) => s + n(r.loadW), 0);
    const leftActual = cac.leftRows.reduce((s, r) => s + n(r.actualCFM), 0);
    const rightActual = cac.rightRows.reduce((s, r) => s + n(r.actualCFM), 0);

    const sheet2Footer = [
      [
        "SUBTOTAL", 
        Math.round(leftLoadW).toFixed(0), Math.round(leftActual).toFixed(0), Math.round(leftSub).toFixed(0), Math.round(leftActual - leftSub).toFixed(0),
        Math.round(rightLoadW).toFixed(0), Math.round(rightActual).toFixed(0), Math.round(rightSub).toFixed(0), Math.round(rightActual - rightSub).toFixed(0)
      ]
    ];

    const worksheet2 = XLSX.utils.aoa_to_sheet([...sheet2Headers, ...sheet2Rows, ...sheet2Footer]);

    // Merges for Sheet 2
    worksheet2['!merges'] = [
      { s: { r: 0, c: 0 }, e: { r: 1, c: 0 } }, // GRILL
      { s: { r: 0, c: 1 }, e: { r: 0, c: 4 } }, // R 0 1
      { s: { r: 0, c: 5 }, e: { r: 0, c: 8 } }  // R 0 2
    ];

    const workbook = XLSX.utils.book_new();
    const safeSheetName = String(cac.cacName || 'CAC').substring(0, 20);
    XLSX.utils.book_append_sheet(workbook, worksheet1, `${safeSheetName} Input`);
    XLSX.utils.book_append_sheet(workbook, worksheet2, `${safeSheetName} Preview`);
    
    XLSX.writeFile(workbook, `${cac.cacName || 'CAC'}_Data.xlsx`);
  };

  const filteredCacTables = useMemo(() => {
    if (!searchTerm.trim()) return data.cacTables || [];
    const lowerQuery = searchTerm.toLowerCase();
    return (data.cacTables || []).filter(cac => 
      cac.cacName.toLowerCase().includes(lowerQuery)
    );
  }, [data.cacTables, searchTerm]);

  // --- Engineering Logic ---
  const calculateReqCFM = (watts: string, deltaT: string, multiplier: string) => {
    const w = n(watts);
    const dt = n(deltaT);
    const m = n(multiplier) || 1;
    if (w === 0 || dt === 0) return 0;
    // Formula: CFM = (Load_W * 3.412969 * Multiplier) / (1.8 * 1.08 * Delta_T)
    return (w * 3.412969 * m) / (1.8 * 1.08 * dt);
  };

  const getUnitSummaries = useMemo(() => {
    return filteredCacTables.map(cac => {
      const leftW = cac.leftRows.reduce((sum, r) => sum + n(r.loadW), 0);
      const rightW = cac.rightRows.reduce((sum, r) => sum + n(r.loadW), 0);
      const totalW = leftW + rightW;
      
      const leftReq = cac.leftRows.reduce((sum, r) => sum + calculateReqCFM(r.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier), 0);
      const rightReq = cac.rightRows.reduce((sum, r) => sum + calculateReqCFM(r.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier), 0);
      // Requirement including 10% envelope load as per header
      const totalReq = (leftReq + rightReq); 

      const leftAct = cac.leftRows.reduce((sum, r) => sum + n(r.actualCFM), 0);
      const rightAct = cac.rightRows.reduce((sum, r) => sum + n(r.actualCFM), 0);
      const totalAct = leftAct + rightAct;

      return {
        ref: cac.cacName,
        rackKw: f(totalW / 1000),
        rackTr: f(totalW / 3517),
        reqAirflow: Math.round(totalReq).toFixed(0),
        actualCfm: Math.round(totalAct).toFixed(0),
        deficit: Math.round(totalAct - totalReq).toFixed(0)
      };
    });
  }, [filteredCacTables, data.deltaT, data.multiplier]);

  const unitTotals = useMemo(() => {
    return getUnitSummaries.reduce((acc, curr) => ({
      kw: acc.kw + n(curr.rackKw),
      tr: acc.tr + n(curr.rackTr),
      req: acc.req + n(curr.reqAirflow),
      act: acc.act + n(curr.actualCfm),
      def: acc.def + n(curr.deficit)
    }), { kw: 0, tr: 0, req: 0, act: 0, def: 0 });
  }, [getUnitSummaries]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.totalPahuCfm !== undefined && json.totalPacCfm !== undefined) {
          onChange({
            ...data,
            importedPahuCfm: json.totalPahuCfm,
            importedPacCfm: json.totalPacCfm,
            importedPahuTr: json.totalPahuTr,
            importedPacTr: json.totalPacTr
          });
        }
      } catch (err) {
        console.error("Failed to parse CFM data", err);
      }
    };
    reader.readAsText(file);
  };

  const handleImportExcel = (cacId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const result = parseCFMExcel(evt.target?.result);
        if (result) {
          const updatedCacTables = data.cacTables.map(cac => {
            if (cac.id === cacId) {
              return {
                ...cac,
                leftRows: result.left,
                rightRows: result.right
              };
            }
            return cac;
          });
          onChange({
            ...data,
            cacTables: updatedCacTables
          });
        } else {
          alert("Could not parse file. Ensure headers match the original export template.");
        }
      };
      reader.readAsBinaryString(file);
    };
    input.click();
  };

  const pahuAvailable = data.importedPahuCfm ? parseFloat(data.importedPahuCfm) : unitTotals.act;
  const pacAvailable = data.importedPacCfm ? parseFloat(data.importedPacCfm) : unitTotals.act;
  const pahuAvailableTr = data.importedPahuTr ? parseFloat(data.importedPahuTr) : (unitTotals.tr * 1.07877);
  const pacAvailableTr = data.importedPacTr ? parseFloat(data.importedPacTr) : (unitTotals.tr * 0.66579);

  // --- Handlers ---
  const updateField = (field: keyof CFMReading, value: any) => {
    if (!canEdit) return;
    onChange({ ...data, [field]: value });
  };

  const addTool = () => {
    const tools = [...(data.toolsUsed || [])];
    tools.push({ 
      id: `tool-${Date.now()}`, 
      instrumentName: '', 
      purpose: '', 
      make: '', 
      model: '', 
      calibrationIssue: '', 
      calibrationExpiry: '' 
    });
    updateField('toolsUsed', tools);
  };

  const insertTool = (idx: number, position: 'above' | 'below') => {
    if (!canEdit) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const tools = [...(data.toolsUsed || [])];
    const newTool = { 
      id: `tool-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`, 
      instrumentName: '', 
      purpose: '', 
      make: '', 
      model: '', 
      calibrationIssue: '', 
      calibrationExpiry: '' 
    };
    tools.splice(targetIdx, 0, newTool);
    updateField('toolsUsed', tools);
  };

  const duplicateTool = (idx: number, position: 'above' | 'below') => {
    if (!canEdit) return;
    const targetIdx = position === 'above' ? idx : idx + 1;
    const tools = [...(data.toolsUsed || [])];
    const source = tools[idx] || { instrumentName: '', purpose: '', make: '', model: '', calibrationIssue: '', calibrationExpiry: '' };
    const newTool = { 
      ...source,
      id: `tool-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`, 
    };
    tools.splice(targetIdx, 0, newTool);
    updateField('toolsUsed', tools);
  };

  const updateTool = (id: string, field: keyof CFMToolRow, value: string) => {
    const tools = data.toolsUsed.map(t => t.id === id ? { ...t, [field]: value } : t);
    updateField('toolsUsed', tools);
  };

  const deleteTool = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    confirmDelete({
      message: "Are you sure you want to delete this tool?",
      onConfirm: () => {
        const tools = data.toolsUsed.filter(t => t.id !== id);
        updateField('toolsUsed', tools);
      }
    });
  };

  const addCacTable = () => {
    const newList = [...(data.cacTables || [])];
    newList.push({
      id: `cac-${Date.now()}`,
      cacName: `CAC-${(newList.length + 1).toString().padStart(2, '0')}`,
      deltaT: '13',
      multiplier: '1',
      leftRows: [],
      rightRows: []
    });
    updateField('cacTables', newList);
  };

  const updateCacTable = (id: string, updates: Partial<CFMCacTable>) => {
    const newList = data.cacTables.map(t => t.id === id ? { ...t, ...updates } : t);
    updateField('cacTables', newList);
  };

  const addCacRow = (tableId: string) => {
    const newList = data.cacTables.map(t => {
      if (t.id === tableId) {
        return { 
          ...t, 
          leftRows: [...t.leftRows, { id: `l-${Date.now()}`, rackRef: '', loadW: '', actualCFM: '' }],
          rightRows: [...t.rightRows, { id: `r-${Date.now()}`, rackRef: '', loadW: '', actualCFM: '' }]
        };
      }
      return t;
    });
    updateField('cacTables', newList);
  };

  const insertCacRow = (tableId: string, idx: number, position: 'above' | 'below') => {
    const targetIdx = position === 'above' ? idx : idx + 1;
    const newList = data.cacTables.map(t => {
      if (t.id === tableId) {
        const leftNew = { id: `l-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`, rackRef: '', loadW: '', actualCFM: '' };
        const rightNew = { id: `r-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`, rackRef: '', loadW: '', actualCFM: '' };
        
        const newLeftRows = [...t.leftRows];
        newLeftRows.splice(targetIdx, 0, leftNew);
        
        const newRightRows = [...t.rightRows];
        newRightRows.splice(targetIdx, 0, rightNew);
        
        return { 
          ...t, 
          leftRows: newLeftRows,
          rightRows: newRightRows
        };
      }
      return t;
    });
    updateField('cacTables', newList);
    showToast(`Row pair inserted successfully ${position} row ${idx + 1}.`, "success");
  };

  const duplicateCacRow = (tableId: string, idx: number, position: 'above' | 'below') => {
    const targetIdx = position === 'above' ? idx : idx + 1;
    const newList = data.cacTables.map(t => {
      if (t.id === tableId) {
        const currentLeft = t.leftRows[idx] || { rackRef: '', loadW: '', actualCFM: '' };
        const currentRight = t.rightRows[idx] || { rackRef: '', loadW: '', actualCFM: '' };
        
        const leftNew = { 
          id: `l-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`, 
          rackRef: currentLeft.rackRef ? `${currentLeft.rackRef}` : '', 
          loadW: currentLeft.loadW, 
          actualCFM: currentLeft.actualCFM 
        };
        const rightNew = { 
          id: `r-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`, 
          rackRef: currentRight.rackRef ? `${currentRight.rackRef}` : '', 
          loadW: currentRight.loadW, 
          actualCFM: currentRight.actualCFM 
        };
        
        const newLeftRows = [...t.leftRows];
        newLeftRows.splice(targetIdx, 0, leftNew);
        
        const newRightRows = [...t.rightRows];
        newRightRows.splice(targetIdx, 0, rightNew);
        
        return { 
          ...t, 
          leftRows: newLeftRows,
          rightRows: newRightRows
        };
      }
      return t;
    });
    updateField('cacTables', newList);
    showToast(`Row pair duplicated successfully ${position} row ${idx + 1}.`, "success");
  };

  const updateCacRow = (tableId: string, side: 'left' | 'right', rowId: string, field: keyof CFMCacRow, value: string) => {
    const newList = data.cacTables.map(t => {
      if (t.id === tableId) {
        const sideKey = side === 'left' ? 'leftRows' : 'rightRows';
        const rows = [...t[sideKey]].map(r => 
          r.id === rowId ? { ...r, [field]: value } : r
        );
        return { ...t, [sideKey]: rows };
      }
      return t;
    });
    updateField('cacTables', newList);
  };

  const deleteCacRow = (e: React.MouseEvent, tableId: string, idx: number) => {
    e.preventDefault();
    e.stopPropagation();
    
    confirmDelete({
      message: "Are you sure you want to delete this pair?",
      onConfirm: () => {
        const newList = data.cacTables.map(t => {
          if (t.id === tableId) {
            return {
              ...t,
              leftRows: t.leftRows.filter((_, i) => i !== idx),
              rightRows: t.rightRows.filter((_, i) => i !== idx)
            };
          }
          return t;
        });
        updateField('cacTables', newList);
      }
    });
  };

  const handleBulkPaste = (tableId: string, parsedRows: ParsedRow[], targetSide: 'left' | 'right' | 'split', mode: 'append' | 'replace' | 'merge') => {
    const newList = data.cacTables.map(t => {
      if (t.id !== tableId) return t;

      let newLeftRows = mode === 'replace' && (targetSide === 'left' || targetSide === 'split') ? [] : [...t.leftRows];
      let newRightRows = mode === 'replace' && (targetSide === 'right' || targetSide === 'split') ? [] : [...t.rightRows];

      if (targetSide === 'left') {
        parsedRows.forEach((r, i) => {
          if (mode === 'merge') {
            if (i < newLeftRows.length) {
              newLeftRows[i] = {
                ...newLeftRows[i],
                rackRef: r.rackRef || newLeftRows[i].rackRef,
                loadW: r.loadW || newLeftRows[i].loadW,
                actualCFM: r.actualCFM || newLeftRows[i].actualCFM
              };
            } else {
              newLeftRows.push({ id: `l-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
            }
          } else {
            newLeftRows.push({ id: `l-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
          }
        });
      } else if (targetSide === 'right') {
        parsedRows.forEach((r, i) => {
          if (mode === 'merge') {
            if (i < newRightRows.length) {
              newRightRows[i] = {
                ...newRightRows[i],
                rackRef: r.rackRef || newRightRows[i].rackRef,
                loadW: r.loadW || newRightRows[i].loadW,
                actualCFM: r.actualCFM || newRightRows[i].actualCFM
              };
            } else {
              newRightRows.push({ id: `r-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
            }
          } else {
            newRightRows.push({ id: `r-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
          }
        });
      } else if (targetSide === 'split') {
        const mid = Math.ceil(parsedRows.length / 2);
        const leftPart = parsedRows.slice(0, mid);
        const rightPart = parsedRows.slice(mid);
        leftPart.forEach((r, i) => {
          if (mode === 'merge') {
            if (i < newLeftRows.length) {
              newLeftRows[i] = {
                ...newLeftRows[i],
                rackRef: r.rackRef || newLeftRows[i].rackRef,
                loadW: r.loadW || newLeftRows[i].loadW,
                actualCFM: r.actualCFM || newLeftRows[i].actualCFM
              };
            } else {
              newLeftRows.push({ id: `l-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
            }
          } else {
            newLeftRows.push({ id: `l-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
          }
        });
        rightPart.forEach((r, i) => {
          if (mode === 'merge') {
            if (i < newRightRows.length) {
              newRightRows[i] = {
                ...newRightRows[i],
                rackRef: r.rackRef || newRightRows[i].rackRef,
                loadW: r.loadW || newRightRows[i].loadW,
                actualCFM: r.actualCFM || newRightRows[i].actualCFM
              };
            } else {
              newRightRows.push({ id: `r-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
            }
          } else {
            newRightRows.push({ id: `r-pasted-${Date.now()}-${i}`, rackRef: r.rackRef, loadW: r.loadW, actualCFM: r.actualCFM || '' });
          }
        });
      }

      // Balance arrays so they are the same length visually using existing or new empty records
      while (newLeftRows.length < newRightRows.length) {
        newLeftRows.push({ id: `l-pad-${Date.now()}-${newLeftRows.length}`, rackRef: '', loadW: '', actualCFM: '' });
      }
      while (newRightRows.length < newLeftRows.length) {
        newRightRows.push({ id: `r-pad-${Date.now()}-${newRightRows.length}`, rackRef: '', loadW: '', actualCFM: '' });
      }

      return {
        ...t,
        leftRows: newLeftRows,
        rightRows: newRightRows
      };
    });
    updateField('cacTables', newList);
    showToast(`Pasted ${parsedRows.length} rows successfully.`, "success");
  };

  return (
    <div className="space-y-12 animate-fade-in pb-24 font-sans text-slate-800">
      <BulkPasteModal 
        isOpen={!!pasteModalTableId}
        onClose={() => setPasteModalTableId(null)}
        onConfirm={(rows, side, mode) => {
          if (pasteModalTableId) {
            handleBulkPaste(pasteModalTableId, rows, side, mode);
          }
        }}
      />
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* PERSONNEL HEADER (ORANGE) */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                className="w-full text-xs font-bold p-2 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-orange-50 outline-none"
              />
            </div>
          ))}
      </section>

      {/* TOOLS USED FOR AUDIT */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 flex justify-between items-center border-b border-slate-100 bg-slate-50/50">
          <h3 className="font-black text-slate-800 text-xs uppercase tracking-widest flex items-center gap-2">
            <span>🛠️</span> TOOLS USED FOR AUDIT
          </h3>
          {canEdit && (
            <button 
              type="button"
              onClick={addTool} 
              className="px-4 py-1.5 bg-orange-50 text-orange-600 rounded-lg font-black text-[10px] uppercase shadow-sm hover:bg-orange-100 transition-all flex items-center gap-2"
            >
              <PlusIcon /> Add Equipment
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px]">
            <thead>
              <tr className="bg-[#F97316] text-white font-black uppercase divide-x divide-white/10">
                <th className="px-4 py-3 w-12 text-center">S. NO</th>
                <th className="px-4 py-3">INSTRUMENT NAME</th>
                <th className="px-4 py-3">PURPOSE</th>
                <th className="px-4 py-3">MAKE</th>
                <th className="px-4 py-3">MODEL</th>
                <th colSpan={2} className="px-4 py-3 text-center">CALIBRATION DATE</th>
                {canEdit && <th className="px-4 py-3 w-40 text-center">ACTIONS</th>}
              </tr>
              <tr className="bg-[#FFBD88] text-white font-black text-[9px] uppercase divide-x divide-white/10 border-t border-white/10">
                <th colSpan={5}></th>
                <th className="py-2 text-center">ISSUE</th>
                <th className="py-2 text-center">EXPIRY</th>
                {canEdit && <th className="w-40"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.toolsUsed || []).map((tool, i) => (
                <tr key={tool.id} className="hover:bg-slate-50 divide-x divide-slate-50">
                  <td className="px-4 py-3 text-center text-slate-400 font-mono">{i + 1}</td>
                  <td className="p-0">
                    <input 
                      value={tool.instrumentName} 
                      onChange={e => updateTool(tool.id, 'instrumentName', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="Instrument Name"
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      value={tool.purpose} 
                      onChange={e => updateTool(tool.id, 'purpose', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="Purpose"
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      value={tool.make} 
                      onChange={e => updateTool(tool.id, 'make', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="Make"
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      value={tool.model} 
                      onChange={e => updateTool(tool.id, 'model', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none" 
                      disabled={readOnly} 
                      placeholder="Model"
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      type="date" 
                      value={tool.calibrationIssue} 
                      onChange={e => updateTool(tool.id, 'calibrationIssue', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none text-center" 
                      disabled={readOnly} 
                    />
                  </td>
                  <td className="p-0">
                    <input 
                      type="date" 
                      value={tool.calibrationExpiry} 
                      onChange={e => updateTool(tool.id, 'calibrationExpiry', e.target.value)} 
                      className="w-full px-4 py-3 bg-transparent outline-none text-center" 
                      disabled={readOnly} 
                    />
                  </td>
                  {canEdit && (
                    <td className="px-2 min-w-[145px]">
                      <div className="flex items-center justify-center gap-1.5 py-1">
                        <button 
                          type="button"
                          onClick={() => insertTool(i, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-[#E65100] bg-orange-50 hover:bg-orange-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Empty Equipment Above"
                        >
                          +↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => insertTool(i, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-[#E65100] bg-orange-50 hover:bg-orange-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Empty Equipment Below"
                        >
                          +↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateTool(i, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Equipment Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateTool(i, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Equipment Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          type="button"
                          onClick={(e) => deleteTool(e, tool.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                          title="Delete Equipment"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
              {(data.toolsUsed || []).length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-8 text-center text-slate-400 italic">No tools added. Click "+ Add Equipment" to begin.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* DETAILED CAC TABLES (ORANGE THEME) */}
      <div className="space-y-16">
        <div className="flex flex-col md:flex-row justify-between items-center bg-white rounded-xl border border-slate-200 shadow-sm p-6 gap-6">
          <div className="flex items-center gap-4 flex-1">
            {!readOnly && (
              <button 
                type="button"
                onClick={addCacTable} 
                className="px-6 py-2.5 bg-[#F97316] text-white rounded-lg font-bold text-sm flex items-center gap-2 shadow-md hover:bg-orange-600 transition-all whitespace-nowrap"
              >
                <PlusIcon /> Add New CAC Table
              </button>
            )}
            <div className="relative flex-1 max-w-xs">
              <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                <SearchIcon />
              </div>
              <input 
                type="text"
                placeholder="Search CAC Reference..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:ring-2 focus:ring-orange-200 outline-none transition-all shadow-inner"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-8 bg-orange-50/50 p-4 rounded-2xl border border-orange-100/50">
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Rack Delta</span>
              <input 
                type="number" 
                value={data.deltaT || '13'} 
                onChange={e => updateField('deltaT', e.target.value)}
                className="bg-white border border-orange-200 text-[#E65100] font-black text-sm w-20 text-center rounded-lg py-2 outline-none focus:ring-2 focus:ring-orange-200 transition-all"
                disabled={!canEdit}
              />
            </div>
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Envelop Multiplier</span>
              <input 
                type="number" 
                value={data.multiplier || '1'} 
                onChange={e => updateField('multiplier', e.target.value)}
                className="bg-white border border-orange-200 text-[#E65100] font-black text-sm w-20 text-center rounded-lg py-2 outline-none focus:ring-2 focus:ring-orange-200 transition-all"
                disabled={!canEdit}
              />
            </div>
          </div>
        </div>

        {filteredCacTables.map((cac) => {
          const leftSub = cac.leftRows.reduce((sum, r) => sum + calculateReqCFM(r.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier), 0);
          const rightSub = cac.rightRows.reduce((sum, r) => sum + calculateReqCFM(r.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier), 0);
          const totalCfm = leftSub + rightSub;

          return (
            <div key={cac.id} className="bg-white rounded-xl shadow-2xl overflow-hidden border-4 border-[#E65100] animate-in fade-in slide-in-from-bottom-8 duration-700">
               {/* CAC UNIT HEADER */}
               <div className="bg-[#E65100] p-4 text-white flex flex-col md:flex-row justify-between items-center gap-4">
                  <div className="flex items-center gap-4">
                     <div className="text-2xl">📈</div>
                     <div className="flex items-center gap-2 border-b-2 border-white/30">
                        <input 
                          value={cac.cacName} 
                          onChange={e => updateCacTable(cac.id, { cacName: e.target.value.toUpperCase() })}
                          className="bg-transparent border-none outline-none font-black text-2xl tracking-tighter w-48 focus:ring-0"
                          disabled={!canEdit}
                        />
                     </div>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-6">
                     <div className="flex items-center gap-2">
                       <button 
                        type="button"
                        onClick={() => setPasteModalTableId(cac.id)} 
                        className="px-4 py-2 bg-white text-[#E65100] rounded font-black text-[11px] uppercase tracking-widest shadow-md hover:bg-orange-50 transition-all flex items-center gap-2"
                        title="Bulk Paste from Excel"
                       >
                          <ClipboardPaste size={14} /> PASTE
                       </button>
                       {!readOnly && (
                         <button 
                          type="button"
                          onClick={() => addCacRow(cac.id)} 
                          className="px-6 py-2 bg-white text-[#E65100] rounded font-black text-[11px] uppercase tracking-widest shadow-md hover:bg-orange-50 transition-all"
                         >
                            + ADD PAIR
                         </button>
                       )}
                     </div>
                     
                     <div className="flex gap-2">
                       <button
                         type="button"
                         onClick={(e) => {
                           e.preventDefault();
                           e.stopPropagation();
                           exportTableToExcel(cac);
                         }}
                         className="flex items-center gap-2 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-md"
                       >
                         <FileSpreadsheet size={14} />
                         Export Excel
                       </button>
                       
                       {!readOnly && (
                         <button
                           type="button"
                           onClick={(e) => {
                             e.preventDefault();
                             e.stopPropagation();
                             handleImportExcel(cac.id);
                           }}
                           className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-md"
                         >
                           <Upload size={14} />
                           Import Excel
                         </button>
                       )}
                     </div>

                     {!readOnly && (
                        <button 
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            
                            confirmDelete({
                              message: "Are you sure you want to delete this Entire Table?",
                              onConfirm: () => {
                                updateField('cacTables', data.cacTables.filter(t => t.id !== cac.id));
                              }
                            });
                          }} 
                          className="p-2 bg-white/20 hover:bg-red-500 hover:text-white rounded-lg transition-all shadow-sm"
                          title="Delete Table"
                        >
                          <TrashIcon />
                        </button>
                     )}
                  </div>
               </div>

               {/* SIDE-BY-SIDE TABLE DATA */}
               <div className="overflow-x-auto">
                  <table className="w-full text-center border-collapse text-[11px]">
                    <thead>
                      <tr className="bg-[#FFF3E0] text-[#E65100] font-black uppercase tracking-widest border-b border-orange-100">
                         <th colSpan={4} className="py-3 border-r border-orange-200">CAC</th>
                         <th colSpan={4} className="py-3">TABLE 1</th>
                         {canEdit && <th className="w-40"></th>}
                      </tr>
                      <tr className="bg-[#FFE0B2] text-[#E65100] font-black uppercase tracking-tighter text-[10px] border-b border-orange-200 divide-x divide-orange-200">
                         <th className="py-3">RACK REFERENCE</th>
                         <th className="py-3">RACK LOAD W</th>
                         <th className="py-3">ACTUAL CFM</th>
                         <th className="py-3">REQUIRED CFM</th>
                         <th className="py-3">RACK REFERENCE</th>
                         <th className="py-3">RACK LOAD W</th>
                         <th className="py-3">ACTUAL CFM</th>
                         <th className="py-3">REQUIRED CFM</th>
                         {canEdit && <th className="py-3 text-[9px] text-[#E65100]">ACTIONS</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-orange-100">
                       {Array.from({ length: Math.max(cac.leftRows.length, cac.rightRows.length) }).map((_, idx) => {
                         const left = cac.leftRows[idx] || { id: '', rackRef: '', loadW: '', actualCFM: '' };
                         const right = cac.rightRows[idx] || { id: '', rackRef: '', loadW: '', actualCFM: '' };
                         
                         const leftReq = calculateReqCFM(left.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);
                         const rightReq = calculateReqCFM(right.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);

                         return (
                           <tr key={idx} className="hover:bg-orange-50/50 transition-colors divide-x divide-orange-100">
                              <td className="p-0 font-bold"><input value={left.rackRef} onChange={e => updateCacRow(cac.id, 'left', left.id, 'rackRef', e.target.value)} disabled={!canEdit} className="w-full py-3 bg-transparent outline-none text-center" placeholder="A1" /></td>
                              <td className="p-0"><input value={left.loadW} onChange={e => updateCacRow(cac.id, 'left', left.id, 'loadW', e.target.value)} disabled={!canEdit} className="w-full py-3 bg-transparent outline-none text-center" placeholder="0" /></td>
                              <td className="p-0">
                                <div className="flex items-center">
                                  <input value={left.actualCFM} onChange={e => updateCacRow(cac.id, 'left', left.id, 'actualCFM', e.target.value)} disabled={!canEdit} className="w-full py-3 bg-transparent outline-none text-center" placeholder="0" />
                                  {canEdit && aiEnabled && left.id && (
                                    <button
                                      type="button"
                                      onClick={() => openLiveCapture(cac.id, 'left', idx, left.id, left.rackRef)}
                                      className="p-1 text-orange-600 hover:text-orange-800 hover:bg-orange-100 rounded transition-colors mr-1 shrink-0"
                                      title="Live Capture Actual CFM"
                                    >
                                      <Camera size={13} />
                                    </button>
                                  )}
                                </div>
                              </td>
                              <td className="py-3 font-black text-[#10B981] bg-emerald-50/30">{leftReq > 0 ? f(leftReq) : ''}</td>

                              <td className="p-0 font-bold"><input value={right.rackRef} onChange={e => updateCacRow(cac.id, 'right', right.id, 'rackRef', e.target.value)} disabled={!canEdit} className="w-full py-3 bg-transparent outline-none text-center" placeholder="A2" /></td>
                              <td className="p-0"><input value={right.loadW} onChange={e => updateCacRow(cac.id, 'right', right.id, 'loadW', e.target.value)} disabled={!canEdit} className="w-full py-3 bg-transparent outline-none text-center" placeholder="0" /></td>
                              <td className="p-0">
                                <div className="flex items-center">
                                  <input value={right.actualCFM} onChange={e => updateCacRow(cac.id, 'right', right.id, 'actualCFM', e.target.value)} disabled={!canEdit} className="w-full py-3 bg-transparent outline-none text-center" placeholder="0" />
                                  {canEdit && aiEnabled && right.id && (
                                    <button
                                      type="button"
                                      onClick={() => openLiveCapture(cac.id, 'right', idx, right.id, right.rackRef)}
                                      className="p-1 text-orange-600 hover:text-orange-800 hover:bg-orange-100 rounded transition-colors mr-1 shrink-0"
                                      title="Live Capture Actual CFM"
                                    >
                                      <Camera size={13} />
                                    </button>
                                  )}
                                </div>
                              </td>
                              <td className="py-3 font-black text-[#10B981] bg-emerald-50/30">{rightReq > 0 ? f(rightReq) : ''}</td>
                              
                              {canEdit && (

                                <td className="px-2 min-w-[140px]">
                                   <div className="flex items-center justify-center gap-1.5 py-1">
                                     <button 
                                       type="button"
                                       onClick={() => insertCacRow(cac.id, idx, 'above')} 
                                       className="w-6 h-6 flex items-center justify-center text-[#E65100] bg-orange-50 hover:bg-orange-100 rounded font-bold text-[9px] transition-colors animate-fade-in"
                                       title="Insert Empty Pair Above"
                                     >
                                       +↑
                                     </button>
                                     <button 
                                       type="button"
                                       onClick={() => insertCacRow(cac.id, idx, 'below')} 
                                       className="w-6 h-6 flex items-center justify-center text-[#E65100] bg-orange-50 hover:bg-orange-100 rounded font-bold text-[9px] transition-colors animate-fade-in"
                                       title="Insert Empty Pair Below"
                                     >
                                       +↓
                                     </button>
                                     <button 
                                       type="button"
                                       onClick={() => duplicateCacRow(cac.id, idx, 'above')} 
                                       className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors animate-fade-in"
                                       title="Duplicate Pair Above"
                                     >
                                       ❐↑
                                     </button>
                                     <button 
                                       type="button"
                                       onClick={() => duplicateCacRow(cac.id, idx, 'below')} 
                                       className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors animate-fade-in"
                                       title="Duplicate Pair Below"
                                     >
                                       ❐↓
                                     </button>
                                     <button 
                                       type="button"
                                       onClick={(e) => deleteCacRow(e, cac.id, idx)} 
                                       className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors animate-fade-in"
                                       title="Delete Row Pair"
                                     >
                                       ×
                                     </button>
                                   </div>
                                </td>
                              )}
                           </tr>
                         );
                       })}
                    </tbody>
                    <tfoot className="text-white font-black uppercase text-[11px] divide-x divide-white/10">
                       <tr className="bg-[#4a2412]">
                          <td colSpan={3} className="py-3 text-right pr-8">SUB TOTAL</td>
                          <td className="py-3 bg-sky-500">{Math.round(leftSub).toFixed(0)}</td>
                          <td colSpan={3} className="py-3 text-right pr-8">SUB TOTAL</td>
                          <td className="py-3 bg-sky-500">{Math.round(rightSub).toFixed(0)}</td>
                          {canEdit && <td className="bg-sky-500"></td>}
                       </tr>
                       <tr className="bg-[#31190d]">
                          <td colSpan={3} className="py-3 text-right pr-8">TOTAL CFM REQUIRED</td>
                          <td className="py-3 bg-sky-600">{Math.round(leftSub).toFixed(0)}</td>
                          <td colSpan={3} className="py-3 text-right pr-8">TOTAL CFM REQUIRED</td>
                          <td className="py-3 bg-sky-600">{Math.round(rightSub).toFixed(0)}</td>
                          {canEdit && <td className="bg-sky-600"></td>}
                       </tr>
                       <tr className="bg-[#1B0F09]">
                          <td colSpan={7} className="py-4 text-right pr-8 text-sm tracking-widest">TOTAL SUPPLY CFM</td>
                          <td className="py-4 bg-[#053d2f] text-2xl font-black">{Math.round(totalCfm).toFixed(0)}</td>
                          {canEdit && <td className="bg-[#053d2f]"></td>}
                       </tr>
                    </tfoot>
                  </table>
               </div>

      {/* PREVIEW TABLE (MATCHING IMAGE) */}
               <div className="bg-[#F8FAFC] p-8 border-t border-slate-200">
                  <div className="max-w-5xl mx-auto space-y-6">
                    <div className="flex rounded-lg overflow-hidden shadow-lg border border-slate-200 bg-white">
                      <div className="w-24 bg-[#1E293B]"></div>
                      <div className="flex-1 bg-[#B91C1C] py-4 text-center">
                        <span className="text-white font-black text-xl tracking-[0.3em] uppercase">{cac.cacName}</span>
                      </div>
                    </div>

                    <div className="rounded-xl overflow-hidden shadow-xl border border-slate-200 bg-white">
                      <table className="w-full text-center border-collapse text-[11px]">
                        <thead>
                          <tr className="text-[#1E293B] font-black uppercase tracking-widest border-b border-slate-100">
                            <th className="py-4 border-r border-slate-100"></th>
                            <th colSpan={4} className="py-4 border-r border-slate-100">R 0 1</th>
                            <th colSpan={4} className="py-4">R 0 2</th>
                          </tr>
                          <tr className="bg-slate-50 text-slate-400 font-black uppercase tracking-tighter text-[9px] border-b border-slate-100 divide-x divide-slate-100">
                            <th className="py-3 w-20">GRILL</th>
                            <th className="py-3">RACK LOAD</th>
                            <th className="py-3">ACTUAL</th>
                            <th className="py-3">REQUIRED</th>
                            <th className="py-3 text-red-500">DEFICIT</th>
                            <th className="py-3">RACK LOAD</th>
                            <th className="py-3">ACTUAL</th>
                            <th className="py-3">REQUIRED</th>
                            <th className="py-3 text-red-500">DEFICIT</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {Array.from({ length: Math.max(cac.leftRows.length, cac.rightRows.length) }).map((_, idx) => {
                            const left = cac.leftRows[idx] || { loadW: '0', actualCFM: '0' };
                            const right = cac.rightRows[idx] || { loadW: '0', actualCFM: '0' };
                            
                            const leftReq = calculateReqCFM(left.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);
                            const rightReq = calculateReqCFM(right.loadW, data.deltaT || cac.deltaT, data.multiplier || cac.multiplier);
                            
                            const leftDef = n(left.actualCFM) - leftReq;
                            const rightDef = n(right.actualCFM) - rightReq;

                            return (
                              <tr key={idx} className="divide-x divide-slate-50 text-slate-600 font-bold">
                                <td className="py-4 text-slate-400">{idx + 1}</td>
                                <td className="py-4">{f(n(left.loadW))}</td>
                                <td className="py-4">{f(n(left.actualCFM))}</td>
                                <td className="py-4 text-slate-300">{leftReq > 0 ? f(leftReq) : '0'}</td>
                                <td className={`py-4 font-black ${leftDef < 0 ? 'bg-red-50/50 text-red-600' : 'bg-emerald-50/50 text-emerald-600'}`}>{f(leftDef)}</td>
                                
                                <td className="py-4">{f(n(right.loadW))}</td>
                                <td className="py-4">{f(n(right.actualCFM))}</td>
                                <td className="py-4 text-slate-300">{rightReq > 0 ? f(rightReq) : '0'}</td>
                                <td className={`py-4 font-black ${rightDef < 0 ? 'bg-red-50/50 text-red-600' : 'bg-emerald-50/50 text-emerald-600'}`}>{f(rightDef)}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                        <tfoot className="text-[#1E293B] font-black uppercase text-[11px] divide-x divide-slate-100">
                          <tr className="bg-sky-50 border-t-2 border-sky-100">
                            <td className="py-4 text-left pl-4">SUBTOTAL</td>
                            <td className="py-4 font-black text-slate-800 bg-sky-200/50">{Math.round(cac.leftRows.reduce((s, r) => s + n(r.loadW), 0)).toFixed(0)}</td>
                            <td className="py-4 font-black text-slate-800 bg-sky-200/50">{Math.round(cac.leftRows.reduce((s, r) => s + n(r.actualCFM), 0)).toFixed(0)}</td>
                            <td className="py-4 text-slate-500 bg-sky-200/50">{Math.round(leftSub).toFixed(0)}</td>
                            <td className={`py-4 font-black bg-sky-200/50 ${(cac.leftRows.reduce((s, r) => s + n(r.actualCFM), 0) - leftSub) < 0 ? 'text-red-700' : 'text-emerald-700'}`}>{Math.round(cac.leftRows.reduce((s, r) => s + n(r.actualCFM), 0) - leftSub).toFixed(0)}</td>
                            
                            <td className="py-4 font-black text-slate-800 bg-sky-200/30">{Math.round(cac.rightRows.reduce((s, r) => s + n(r.loadW), 0)).toFixed(0)}</td>
                            <td className="py-4 font-black text-slate-800 bg-sky-200/30">{Math.round(cac.rightRows.reduce((s, r) => s + n(r.actualCFM), 0)).toFixed(0)}</td>
                            <td className="py-4 text-slate-500 bg-sky-200/30">{Math.round(rightSub).toFixed(0)}</td>
                            <td className={`py-4 font-black bg-sky-200/30 ${(cac.rightRows.reduce((s, r) => s + n(r.actualCFM), 0) - rightSub) < 0 ? 'text-red-700' : 'text-emerald-700'}`}>{Math.round(cac.rightRows.reduce((s, r) => s + n(r.actualCFM), 0) - rightSub).toFixed(0)}</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>

                    <div className="flex justify-end">
                      <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 p-6 flex items-center gap-12">
                        <div className="space-y-1 text-center">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">RACK LOAD</p>
                          <p className="text-xl font-black text-slate-800">{Math.round(cac.leftRows.reduce((s, r) => s + n(r.loadW), 0) + cac.rightRows.reduce((s, r) => s + n(r.loadW), 0)).toFixed(0)}</p>
                        </div>
                        <div className="space-y-1 text-center">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">ACTUAL CFM</p>
                          <p className="text-xl font-black text-slate-800">{Math.round(cac.leftRows.reduce((s, r) => s + n(r.actualCFM), 0) + cac.rightRows.reduce((s, r) => s + n(r.actualCFM), 0)).toFixed(0)}</p>
                        </div>
                        <div className="space-y-1 text-center">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">REQUIRED CFM</p>
                          <p className="text-xl font-black text-slate-800">{Math.round(totalCfm).toFixed(0)}</p>
                        </div>
                        <div className="bg-red-50 border border-red-100 rounded-xl px-8 py-4 text-center">
                           <p className="text-[9px] font-black text-red-700 uppercase tracking-tighter">UNIT DEFICIT</p>
                           <p className={`text-3xl font-black ${((cac.leftRows.reduce((s, r) => s + n(r.actualCFM), 0) + cac.rightRows.reduce((s, r) => s + n(r.actualCFM), 0)) - totalCfm) < 0 ? 'text-red-600' : 'text-emerald-600'}`}>{Math.round((cac.leftRows.reduce((s, r) => s + n(r.actualCFM), 0) + cac.rightRows.reduce((s, r) => s + n(r.actualCFM), 0)) - totalCfm).toFixed(0)}</p>
                        </div>
                      </div>
                    </div>
                  </div>
               </div>
            </div>
          );
        })}
      </div>

      {/* CFM SUMMARY ANALYSIS TABLE */}
      <section className="space-y-6">
        <div className="flex items-center gap-3 px-4">
          <div className="text-orange-500">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
            </svg>
          </div>
          <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest">CFM SUMMARY ANALYSIS</h3>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          <table className="w-full text-center border-collapse text-[10px]">
            <thead>
              <tr className="bg-[#1E293B] text-white font-black uppercase tracking-widest divide-x divide-white/10">
                <th className="py-6 px-4">REF</th>
                <th className="py-6 px-4">RACK (KW)</th>
                <th className="py-6 px-4">RACK (TR)</th>
                <th className="py-6 px-4 leading-tight">
                  REQUIRED MINIMUM AIRFLOW @ {data.deltaT || '13'} DEG C<br/>
                  RACK DELTA & {Math.round(((Number(data.multiplier) || 1) - 1) * 100)}% ENVELOPE MULTIPLIER
                </th>
                <th className="py-6 px-4">ACTUAL CFM</th>
                <th className="py-6 px-4">DEFICIT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
{(getUnitSummaries).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {getUnitSummaries.map((summary, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                  <td className="py-5 px-4 font-black text-slate-900">{summary.ref}</td>
                  <td className="py-5 px-4">{summary.rackKw}</td>
                  <td className="py-5 px-4">{summary.rackTr}</td>
                  <td className="py-5 px-4">{summary.reqAirflow}</td>
                  <td className="py-5 px-4">{summary.actualCfm}</td>
                  <td className={`py-5 px-4 font-black ${n(summary.deficit) < 0 ? 'bg-red-50 text-red-600' : 'text-emerald-600'}`}>
                    {summary.deficit}
                  </td>
                </tr>
              ))}
              {getUnitSummaries.length > 1 && (
                <tr className="bg-sky-600 text-white font-black uppercase divide-x divide-white/10">
                  <td className="py-5 px-4">TOTAL</td>
                  <td className="py-5 px-4">{unitTotals.kw.toFixed(2)}</td>
                  <td className="py-5 px-4">{unitTotals.tr.toFixed(2)}</td>
                  <td className="py-5 px-4">{Math.round(unitTotals.req).toFixed(0)}</td>
                  <td className="py-5 px-4">{Math.round(unitTotals.act).toFixed(0)}</td>
                  <td className={`py-5 px-4 ${unitTotals.def < 0 ? 'text-red-200' : 'text-emerald-200'}`}>
                    {Math.round(unitTotals.def).toFixed(0)}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* HIGH-LEVEL SUMMARY ANALYSIS TABLE */}
      <section className="space-y-6">
        <div className="flex justify-between items-center px-4">
          <div className="space-y-1">
            <h3 className="font-black text-slate-800 text-lg tracking-tight uppercase">CFM Summary Analysis</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Aggregate Performance Metrics</p>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsVerified(!isVerified)}
              className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase transition-all shadow-lg flex items-center gap-2 ${
                isVerified 
                  ? 'bg-emerald-600 text-white shadow-emerald-900/20' 
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 shadow-slate-900/5'
              }`}
            >
              {isVerified ? '✅ Verified' : '🔍 Verify'}
            </button>
            <div className="flex flex-col items-end">
              <span className="text-[9px] text-slate-400 font-black uppercase tracking-widest mb-1">External Data Sync</span>
              <label className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg text-[10px] font-black uppercase transition-all flex items-center gap-2 shadow-lg shadow-slate-900/20">
                <span>📥</span> Upload Capacity Data
                <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="bg-[#F97316] text-white font-black uppercase tracking-widest divide-x divide-white/10 text-center">
                <th className="py-4 px-6">CATEGORY</th>
                <th className="py-4 px-4">VALUE</th>
                <th className="py-4 px-4">UNIT</th>
                <th className="py-4 px-4">TOTAL AIRFLOW REQUIRED (CFM)</th>
                <th className="py-4 px-4">TOTAL AIRFLOW AVAILABLE (CFM)</th>
                <th className="py-4 px-4">DEFICIT (CFM)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {/* Total Rack Load */}
              <tr className="bg-sky-50/50 hover:bg-sky-100/50 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                <td className="py-4 px-6 font-black text-slate-900">Total Rack Load</td>
                <td className="py-4 px-4 text-center text-sky-700">{unitTotals.kw.toFixed(2)}</td>
                <td className="py-4 px-4 text-center text-slate-400">kW</td>
                <td className="py-4 px-4 text-center text-sky-700">{Math.round(unitTotals.req).toFixed(0)}</td>
                <td className="py-4 px-4 text-center text-sky-700">{Math.round(unitTotals.act).toFixed(0)}</td>
                <td className={`py-4 px-4 text-center font-black ${(unitTotals.act - unitTotals.req) < 0 ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'}`}>{Math.round(unitTotals.act - unitTotals.req).toFixed(0)}</td>
              </tr>
              {/* Total Rack TR */}
              <tr className="bg-sky-50/30 hover:bg-sky-100/30 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                <td className="py-4 px-6 font-black text-slate-900">Total Rack TR</td>
                <td className="py-4 px-4 text-center text-sky-700">{unitTotals.tr.toFixed(2)}</td>
                <td className="py-4 px-4 text-center text-slate-400">TR</td>
                <td className="py-4 px-4 text-center"></td>
                <td className="py-4 px-4 text-center"></td>
                <td className="py-4 px-4 text-center"></td>
              </tr>
              {/* Adding Room Load dynamic percentage */}
              <tr className="bg-sky-50/30 hover:bg-sky-100/30 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                <td className="py-4 px-6 font-black text-slate-900">Adding Room Load of {data.multiplier || '1'}%</td>
                <td className="py-4 px-4 text-center text-sky-700">{(unitTotals.tr * (Number(data.multiplier) || 1)).toFixed(2)}</td>
                <td className="py-4 px-4 text-center text-slate-400">TR</td>
                <td className="py-4 px-4 text-center"></td>
                <td className="py-4 px-4 text-center"></td>
                <td className="py-4 px-4 text-center"></td>
              </tr>
              
              {/* Spacer Row */}
              <tr className="bg-slate-50/50 h-4">
                <td colSpan={6}></td>
              </tr>

              {/* Return Airflow for All PAHU */}
              {(!isVerified || pahuAvailable !== 0) && (
                <tr className="hover:bg-slate-50 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                  <td className="py-4 px-6 font-black text-slate-900 flex items-center gap-2">
                    Return Airflow for All PAHU
                    {data.importedPahuCfm && <span className="text-[8px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded uppercase tracking-tighter">Imported</span>}
                  </td>
                  <td className="py-4 px-4 text-center font-black text-blue-600">{Math.round(pahuAvailable).toFixed(0)}</td>
                  <td className="py-4 px-4 text-center text-slate-400">CFM</td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                </tr>
              )}
              {/* Return Airflow for All PAC */}
              {(!isVerified || pacAvailable !== 0) && (
                <tr className="hover:bg-slate-50 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                  <td className="py-4 px-6 font-black text-slate-900 flex items-center gap-2">
                    Return Airflow for All PAC
                    {data.importedPacCfm && <span className="text-[8px] bg-orange-100 text-orange-600 px-1.5 py-0.5 rounded uppercase tracking-tighter">Imported</span>}
                  </td>
                  <td className="py-4 px-4 text-center font-black text-orange-600">{Math.round(pacAvailable).toFixed(0)}</td>
                  <td className="py-4 px-4 text-center text-slate-400">CFM</td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                </tr>
              )}

              {/* Spacer Row */}
              <tr className="bg-slate-50/50 h-4">
                <td colSpan={6}></td>
              </tr>

              {/* Total TR for PAHU */}
              {(!isVerified || pahuAvailable !== 0) && pahuAvailableTr !== 0 && pahuAvailableTr.toFixed(2) !== '0.00' && (
                <tr className="hover:bg-slate-50 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                  <td className="py-4 px-6 font-black text-slate-900 flex items-center gap-2">
                    Total TR for PAHU
                    {data.importedPahuTr && <span className="text-[8px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded uppercase tracking-tighter">Imported</span>}
                  </td>
                  <td className="py-4 px-4 text-center">{pahuAvailableTr.toFixed(2)}</td>
                  <td className="py-4 px-4 text-center text-slate-400">TR</td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                </tr>
              )}
              {/* Total TR for PAC */}
              {(!isVerified || pacAvailable !== 0) && pacAvailableTr !== 0 && pacAvailableTr.toFixed(2) !== '0.00' && (
                <tr className="hover:bg-slate-50 transition-colors font-bold text-slate-700 divide-x divide-slate-50">
                  <td className="py-4 px-6 font-black text-slate-900 flex items-center gap-2">
                    Total TR for PAC
                    {data.importedPacTr && <span className="text-[8px] bg-orange-100 text-orange-600 px-1.5 py-0.5 rounded uppercase tracking-tighter">Imported</span>}
                  </td>
                  <td className="py-4 px-4 text-center">{pacAvailableTr.toFixed(2)}</td>
                  <td className="py-4 px-4 text-center text-slate-400">TR</td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                  <td className="py-4 px-4 text-center"></td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* DATA CENTER AIRFLOW & LOAD SUMMARY - IMAGE MATCH */}
      <section className="space-y-12 py-10">
        <div className="max-w-4xl mx-auto overflow-hidden rounded-lg shadow-sm border border-slate-300">
           <table className="w-full border-collapse">
              <thead>
                 <tr className="bg-[#135D7A] text-white divide-x divide-white/20 text-sm">
                    <th className="py-2.5 px-6"></th>
                    <th className="py-2.5 px-6 font-bold">Measured (CFM)</th>
                    <th className="py-2.5 px-6 font-bold">Required (CFM)</th>
                    <th className="py-2.5 px-6 font-bold">Deficit (CFM)</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-300">
                 <tr className="bg-[#F0F7FA] divide-x divide-slate-300 text-xs font-bold text-slate-700 hover:bg-white transition-colors">
                    <td className="py-2.5 px-6 text-center">Supply Airflow for DC Hall (Grills)</td>
                    <td className={`py-2.5 px-6 text-center font-black ${unitTotals.act >= unitTotals.req ? 'text-blue-600' : 'text-red-600'}`}>{Math.round(unitTotals.act).toFixed(0)}</td>
                    <td className="py-2.5 px-6 text-center">{Math.round(unitTotals.req).toFixed(0)}</td>
                    <td className={`py-2.5 px-6 text-center font-black ${(unitTotals.act - unitTotals.req) < 0 ? 'text-red-600' : 'text-emerald-600'}`}>{Math.round(unitTotals.act - unitTotals.req).toFixed(0)}</td>
                 </tr>
                 <tr className="bg-[#F0F7FA] divide-x divide-slate-300 text-xs font-bold text-slate-700 hover:bg-white transition-colors">
                    <td className="py-2.5 px-6 text-center">Return Airflow for DC Hall</td>
                    <td className={`py-2.5 px-6 text-center font-black ${(pahuAvailable + pacAvailable) >= unitTotals.req ? 'text-blue-600' : 'text-red-600'}`}>{Math.round(pahuAvailable + pacAvailable).toFixed(0)}</td>
                    <td className="py-2.5 px-6 text-center">{Math.round(unitTotals.req).toFixed(0)}</td>
                    <td className={`py-2.5 px-6 text-center font-black ${(pahuAvailable + pacAvailable - unitTotals.req) < 0 ? 'text-red-600' : 'text-emerald-600'}`}>{Math.round(pahuAvailable + pacAvailable - unitTotals.req).toFixed(0)}</td>
                 </tr>
              </tbody>
           </table>
        </div>

        <div className="max-w-2xl mx-auto overflow-hidden rounded-lg shadow-sm border border-slate-400">
           <table className="w-full border-collapse bg-[#DAEAF7]">
              <tbody className="divide-y divide-slate-400 text-xs font-bold text-slate-800">
                 <tr className="divide-x divide-slate-400 hover:bg-white/20 transition-colors">
                    <td className="py-2.5 px-6 text-center w-2/3">Total Rack Load</td>
                    <td className="py-2.5 px-6 text-center bg-white/40">{unitTotals.kw.toFixed(2)}</td>
                    <td className="py-2.5 px-6 text-left pl-6">kW</td>
                 </tr>
                 <tr className="divide-x divide-slate-400 hover:bg-white/20 transition-colors">
                    <td className="py-2.5 px-6 text-center">Total Rack TR</td>
                    <td className="py-2.5 px-6 text-center bg-white/40">{unitTotals.tr.toFixed(2)}</td>
                    <td className="py-2.5 px-6 text-left pl-6">TR</td>
                 </tr>
                 <tr className="divide-x divide-slate-400 hover:bg-white/20 transition-colors">
                    <td className="py-2.5 px-6 text-center">Adding Room Load of {Math.round(((Number(data.multiplier) || 1) - 1) * 100)}%</td>
                    <td className="py-2.5 px-6 text-center bg-white/40">{(unitTotals.tr * (Number(data.multiplier) || 1)).toFixed(2)}</td>
                    <td className="py-2.5 px-6 text-left pl-6">TR</td>
                 </tr>
                 {pahuAvailableTr !== 0 && pahuAvailableTr.toFixed(2) !== '0.00' && (
                  <tr className="divide-x divide-slate-400 hover:bg-white/20 transition-colors">
                     <td className="py-2.5 px-6 text-center">Total TR for PAHU</td>
                      <td className="py-2.5 px-6 text-center bg-white/40">{pahuAvailableTr.toFixed(2)}</td>
                     <td className="py-2.5 px-6 text-left pl-6">TR</td>
                  </tr>
                 )}
                 {pacAvailableTr !== 0 && pacAvailableTr.toFixed(2) !== '0.00' && (
                  <tr className="divide-x divide-slate-400 hover:bg-white/20 transition-colors">
                     <td className="py-2.5 px-6 text-center">Total TR for PAC</td>
                      <td className="py-2.5 px-6 text-center bg-white/40">{pacAvailableTr.toFixed(2)}</td>
                     <td className="py-2.5 px-6 text-left pl-6">TR</td>
                  </tr>
                 )}
              </tbody>
           </table>
        </div>
      </section>

      {/* SUMMARY SECTIONS */}
      <section className="bg-white rounded-[3.5rem] border border-slate-200 shadow-2xl p-16 space-y-12">
         <div className="flex items-center gap-5 border-b border-slate-100 pb-8">
            <div className="w-16 h-16 bg-orange-50 text-[#F97316] rounded-2xl flex items-center justify-center text-4xl shadow-inner">📋</div>
            <div className="space-y-1">
               <h3 className="font-black text-slate-800 text-2xl tracking-tighter uppercase">Audit Assessment Summary</h3>
               <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Formal Reporting Context</p>
            </div>
         </div>
         
         <ObservationsRecommendationsTable 
           data={data.observationsAndRecommendations || []}
           onChange={(val) => updateField('observationsAndRecommendations', val)}
           readOnly={readOnly}
         />
      </section>

      {/* Live Capture Modal */}
      {liveCapture?.active && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden flex flex-col">
            <div className="bg-gradient-to-r from-orange-600 to-amber-600 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2 font-black text-sm uppercase tracking-wider">
                <Camera size={18} />
                <span>Live Instrument Capture — {liveCapture.rackRef ? `Rack ${liveCapture.rackRef}` : `Row ${liveCapture.rowIndex + 1}`} ({liveCapture.side === 'left' ? 'CAC Side' : 'Table 1 Side'})</span>
              </div>
              <button onClick={closeLiveCapture} className="text-white/80 hover:text-white text-lg font-bold">×</button>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-orange-50 border border-orange-100 p-3 rounded-xl text-xs text-orange-900 space-y-1">
                <p className="font-bold">Target: Actual Airflow (CFM)</p>
                <p className="text-[11px] text-orange-700">Point camera at Digital Anemometer (G-tech AVM-02) or Volume Flow Hood (Testo 420) display.</p>
              </div>

              <div className="relative aspect-video bg-slate-900 rounded-xl overflow-hidden border-2 border-slate-200 flex items-center justify-center">
                <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
                <canvas ref={canvasRef} className="hidden" />

                {liveCapture.phase === 'camera' && (
                  <div className="absolute inset-0 border-2 border-dashed border-orange-400/60 pointer-events-none flex items-center justify-center">
                    <span className="text-white/70 text-[10px] font-bold bg-slate-900/60 px-3 py-1 rounded-full uppercase tracking-widest">
                      Align Display
                    </span>
                  </div>
                )}

                {liveCapture.phase === 'reading' && (
                  <div className="absolute inset-0 bg-slate-900/90 flex flex-col items-center justify-center text-white gap-3 p-4">
                    <div className="w-10 h-10 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
                    <p className="font-bold text-sm">Extracting Airflow Reading...</p>
                    <p className="text-xs text-slate-400 text-center">Gemini AI is reading the instrument display.</p>
                  </div>
                )}
              </div>

              {liveCapture.phase === 'review' && (
                <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Extracted Actual CFM:</label>
                    <span className="text-[10px] bg-orange-100 text-orange-800 font-bold px-2 py-0.5 rounded">
                      Value-Only (Photo Discarded)
                    </span>
                  </div>
                  <input
                    type="text"
                    value={liveCapture.value}
                    onChange={e => setLiveCapture(prev => prev ? { ...prev, value: e.target.value } : null)}
                    placeholder="Enter or verify value"
                    className="w-full p-2.5 text-base font-black bg-white border border-slate-300 rounded-lg text-slate-800 text-center focus:ring-2 focus:ring-orange-500 outline-none"
                  />
                  {liveCapture.error && (
                    <p className="text-xs text-red-600 font-medium">{liveCapture.error}</p>
                  )}
                </div>
              )}
            </div>

            <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={closeLiveCapture}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Cancel
              </button>

              {liveCapture.phase === 'camera' && (
                <button
                  type="button"
                  onClick={capturePhoto}
                  className="px-5 py-2 text-xs font-bold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-md transition-all flex items-center gap-2"
                >
                  <Camera size={14} /> Capture Reading
                </button>
              )}

              {liveCapture.phase === 'review' && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'camera', value: '', error: '' } : null)}
                    className="px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100"
                  >
                    Retake
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmReading}
                    className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-md transition-all"
                  >
                    Confirm Value
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>

  );
};

export const INITIAL_CFM_DATA: CFMReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  deltaT: '13',
  multiplier: '1',
  status: 'PENDING',
  equipmentList: [],
  toolsUsed: [],
  cacTables: [
    {
      id: 'cac-initial',
      cacName: 'CAC-01',
      deltaT: '13',
      multiplier: '1',
      leftRows: [],
      rightRows: []
    }
  ],
  observationsAndRecommendations: []
};
