
import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Info, X } from 'lucide-react';

interface IncompleteFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  missingFields?: string[];
  onSubmitAnyway?: () => void;
}

const IncompleteFormModal: React.FC<IncompleteFormModalProps> = ({ isOpen, onClose, missingFields = [], onSubmitAnyway }) => {
  const modalRef = useRef<HTMLDivElement>(null);

  // Close on ESC
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm transition-opacity duration-300"
          onClick={handleBackdropClick}
        >
          <motion.div
            ref={modalRef}
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 350 }}
            className="w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100"
            role="alertdialog"
            aria-modal="true"
          >
            <div className="relative p-8 flex flex-col items-center text-center">
              {/* Close Button */}
              <button 
                onClick={onClose}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all"
                aria-label="Close"
              >
                <X size={18} />
              </button>

              {/* Info Icon */}
              <div className="mb-6">
                <div className="w-16 h-16 bg-orange-50 text-orange-500 rounded-full flex items-center justify-center animate-pulse">
                  <Info size={32} />
                </div>
              </div>

              {/* Text Content */}
              <h2 className="text-xl font-black text-slate-900 mb-2 tracking-tight">
                Incomplete Form
              </h2>
              <p className="text-slate-500 text-sm leading-relaxed px-2 mt-2">
                Please fill in all required fields before submitting the form.
              </p>

              {missingFields && missingFields.length > 0 && (
                <div className="w-full mt-4 text-left bg-slate-50 border border-slate-200/60 rounded-2xl p-4 max-h-48 overflow-y-auto font-sans">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Unfilled / Blank Fields:</p>
                  <ul className="space-y-1.5">
                    {missingFields.map((field, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs font-bold text-slate-600 leading-tight">
                        <span className="text-amber-500 shrink-0 mt-0.5">⚠️</span>
                        <span>{field}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Action */}
              <div className="flex flex-col w-full mt-8 gap-3">
                <button
                  onClick={onClose}
                  autoFocus
                  className="w-full py-3 bg-slate-900 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-800 active:scale-[0.98] transition-all"
                >
                  Go Back & Fill
                </button>
                {onSubmitAnyway && (
                  <button
                    onClick={() => {
                      onClose();
                      onSubmitAnyway();
                    }}
                    className="w-full py-3 bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 rounded-2xl text-xs font-black uppercase tracking-widest active:scale-[0.98] transition-all shadow-sm"
                  >
                    Submit anyway
                  </button>
                )}
              </div>
            </div>
            
            <div className="h-2 bg-gradient-to-r from-orange-500 to-amber-500"></div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default IncompleteFormModal;
