
import React, { useState } from 'react';
import { TestTemplateMetadata, UserRole } from '../types';
import { useAuth } from '../context/AuthContext';
import { TestLibraryService } from '../services/mockDatabase';

interface TemplateCardProps {
  template?: TestTemplateMetadata;
  testName: string;
  testId?: string; // Passed from parent to handle direct service call
  onUploadSuccess?: (metadata: TestTemplateMetadata) => void;
}

const TemplateCard: React.FC<TemplateCardProps> = ({ template, testName, testId, onUploadSuccess }) => {
  const { user } = useAuth();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const canModify = user?.role === UserRole.ADMIN || user?.role === UserRole.DEVELOPER;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && testId && user) {
      const file = e.target.files[0];
      setError(null);
      
      // Client-side guard
      if (file.size > 20 * 1024 * 1024) { 
        alert("File too large. Please keep report templates under 20MB.");
        return;
      }

      setIsUploading(true);
      setUploadProgress(0);

      try {
        const metadata = await TestLibraryService.uploadTemplateChunked(
          file, 
          testId,
          user, 
          (percent) => setUploadProgress(percent)
        );
        if (onUploadSuccess) onUploadSuccess(metadata);
      } catch (err: any) {
        console.error("Upload UI error:", err);
        setError(err.message || "Failed to upload file.");
      } finally {
        setIsUploading(false);
        setUploadProgress(0);
        e.target.value = '';
      }
    }
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
        <h3 className="font-semibold text-slate-700 text-sm">Report Template Linked</h3>
        {template ? (
           <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
             Linked
           </span>
        ) : (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
             Not Linked
           </span>
        )}
      </div>
      
      <div className="p-4 space-y-3">
        {error && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 leading-relaxed shadow-sm">
            <div className="flex gap-2 mb-2">
              <span className="text-base">⚠️</span>
              <p className="font-bold">Critical Error:</p>
            </div>
            <p className="mb-3">{error}</p>
            {error.includes("TIMEOUT") && (
               <div className="mt-2 p-2 bg-white border border-red-100 rounded text-[10px] text-slate-600">
                 <p className="font-bold text-red-600 mb-1">PRO TIP:</p>
                 A 0% hang is 99% a CORS issue. Open Google Cloud Shell and run:<br/>
                 <code className="bg-slate-100 p-1 block mt-1 font-mono">gsutil cors set cors.json gs://YOUR_BUCKET</code>
               </div>
            )}
            <button 
              onClick={() => setError(null)}
              className="mt-3 text-red-600 font-bold hover:underline"
            >
              Dismiss & Retry
            </button>
          </div>
        )}

        {template ? (
          <>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <span className="text-slate-500">File Name:</span>
              <span className="font-medium text-slate-900 truncate" title={template.name}>{template.name}</span>
              
              <span className="text-slate-500">Version:</span>
              <span className="font-medium text-slate-900">v{template.version}</span>
              
              <span className="text-slate-500">Size:</span>
              <span className="font-medium text-slate-900">{(template.sizeBytes / 1024).toFixed(1)} KB</span>
              
              <span className="text-slate-500">Last Updated:</span>
              <span className="font-medium text-slate-900">{new Date(template.updatedAt).toLocaleDateString()}</span>
            </div>
            
            {canModify && (
              <div className="mt-4 pt-3 border-t border-slate-100">
                 {isUploading ? (
                   <div className="space-y-2">
                     <div className="flex justify-between text-xs font-bold text-indigo-600">
                       <span>{uploadProgress === 0 ? 'Starting Session...' : 'Processing Chunks...'}</span>
                       <span>{uploadProgress}%</span>
                     </div>
                     <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden shadow-inner">
                       <div className="bg-indigo-600 h-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                     </div>
                   </div>
                 ) : (
                   <>
                    <p className="text-xs text-slate-400 mb-2">Update Template (Will increment version)</p>
                    <label className="block w-full text-center px-4 py-2 border border-slate-300 border-dashed rounded-md text-sm font-medium text-slate-600 transition-colors hover:bg-slate-50 cursor-pointer">
                        Upload New Version
                        <input type="file" className="hidden" accept=".docx,.xlsx,.pdf" onChange={handleFileChange} />
                    </label>
                   </>
                 )}
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-6">
            <div className="mx-auto flex items-center justify-center h-10 w-10 rounded-full bg-slate-100 mb-2">
              <span className="text-xl">📄</span>
            </div>
            <p className="text-sm text-slate-500">No template assigned to {testName}.</p>
            {canModify && (
              <div className="mt-4">
                 {isUploading ? (
                   <div className="max-w-[200px] mx-auto space-y-2">
                     <div className="flex justify-between text-xs font-bold text-indigo-600">
                       <span>{uploadProgress === 0 ? 'Handshaking...' : 'Chunking...'}</span>
                       <span>{uploadProgress}%</span>
                     </div>
                     <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden shadow-inner">
                       <div className="bg-indigo-600 h-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                     </div>
                   </div>
                 ) : (
                   <>
                    <label className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white shadow-sm transition-all bg-indigo-600 hover:bg-indigo-700 cursor-pointer">
                        Upload Template
                        <input type="file" className="hidden" accept=".docx,.xlsx,.pdf" onChange={handleFileChange} />
                    </label>
                    <p className="mt-2 text-[10px] text-slate-400">Large files will be chunked automatically.</p>
                   </>
                 )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TemplateCard;
