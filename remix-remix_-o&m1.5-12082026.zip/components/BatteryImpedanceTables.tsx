
import React, { useRef } from 'react';
import * as XLSX from 'xlsx';
import { Camera } from 'lucide-react';
import { 
  BatteryImpedanceReading, 
  BatteryUPS, 
  BatteryString, 
  BatteryReading,
  SPOFEquipmentRow,
  LiveCaptureConfig
} from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { exportBatteryImpedanceToExcel } from '../utils/excelExport';
import { readBatteryImpedanceDisplay } from '../services/geminiClient';

interface BatteryImpedanceTablesProps {
  data: BatteryImpedanceReading;
  onChange: (data: BatteryImpedanceReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

const UploadIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
);

export const BatteryImpedanceTables: React.FC<BatteryImpedanceTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = false,
  liveCaptureConfig
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, showToast, hideToast } = useConfirmDelete();
  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  const [liveCapture, setLiveCapture] = React.useState<{
    active: boolean;
    upsId: string;
    strId: string;
    rowIndex: number;
    readings: BatteryReading[];
    phase: 'camera' | 'reading' | 'review';
    readValues: { measuredIr: string; voltage: string };
    error: string;
  } | null>(null);

  const videoRef = React.useRef<HTMLVideoElement>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? { ...prev, error: 'Camera not available. Enter values manually below.', phase: 'review' } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    // Downscale to max 1280px
    const maxDim = 1280;
    let width = video.videoWidth;
    let height = video.videoHeight;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }
    
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, width, height);
    
    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');
    
    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);
    
    try {
      const parsed = await readBatteryImpedanceDisplay(base64);
      setLiveCapture(prev => prev ? { 
        ...prev, 
        phase: 'review', 
        readValues: { 
          measuredIr: parsed.measuredIr || '', 
          voltage: parsed.voltage || '' 
        }, 
        error: '' 
      } : null);
    } catch (err: any) {
      console.error('Live Capture error:', err);
      setLiveCapture(prev => prev ? { 
        ...prev, 
        phase: 'review', 
        readValues: { measuredIr: '', voltage: '' },
        error: `Error: ${err?.message || JSON.stringify(err)}`
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const { upsId, strId, rowIndex, readings, readValues } = liveCapture;
    const row = readings[rowIndex];
    if (!row) return;

    const updatedRow = {
      ...row,
      measuredIr: readValues.measuredIr,
      measuredVolt: readValues.voltage
    };
    updatedRow.remarks = calculateStatus(updatedRow);

    const upsList = data.upsSystems.map(u => {
      if (u.id === upsId) {
        return {
          ...u,
          strings: u.strings.map(s => {
            if (s.id === strId) {
              return {
                ...s,
                readings: s.readings.map(r => r.id === row.id ? updatedRow : r)
              };
            }
            return s;
          })
        };
      }
      return u;
    });
    updateField('upsSystems', upsList);

    const nextIndex = rowIndex + 1;
    if (nextIndex < readings.length) {
      setLiveCapture(prev => prev ? {
        ...prev,
        rowIndex: nextIndex,
        readings: readings.map(r => r.id === row.id ? updatedRow : r),
        phase: 'camera',
        readValues: { measuredIr: '', voltage: '' },
        error: ''
      } : null);
    } else {
      stopCamera();
      setLiveCapture(null);
      showToast('All cell rows captured successfully!', 'success');
    }
  };

  const handleCancelCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const openLiveCapture = (upsId: string, strId: string, readings: BatteryReading[]) => {
    if (readings.length === 0) {
      showToast('No cell rows to capture. Please add at least one cell.', 'error');
      return;
    }
    let startIndex = readings.findIndex(r => !r.measuredIr && !r.measuredVolt);
    if (startIndex === -1) startIndex = 0;

    setLiveCapture({
      active: true,
      upsId,
      strId,
      rowIndex: startIndex,
      readings,
      phase: 'camera',
      readValues: { measuredIr: '', voltage: '' },
      error: ''
    });
  };

  React.useEffect(() => {
    if (liveCapture?.phase === 'camera') {
      startCamera();
    }
    return () => {
      if (liveCapture?.phase === 'camera') {
        stopCamera();
      }
    };
  }, [liveCapture?.phase, liveCapture?.rowIndex]);

  React.useEffect(() => {
    return () => stopCamera();
  }, []);

  const updateField = (field: keyof BatteryImpedanceReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const calculateStatus = (row: BatteryReading): string => {
    const mir = parseFloat(row.measuredIr);
    const fth = parseFloat(row.irFailThresh);
    const wth = parseFloat(row.irWarnThresh);
    const mv = parseFloat(row.measuredVolt);
    const vth = parseFloat(row.voltThresh);

    if (isNaN(mir) && isNaN(mv)) return '...';

    // FAIL Priority
    if ((!isNaN(mir) && !isNaN(fth) && mir >= fth) || (!isNaN(mv) && !isNaN(vth) && mv < vth)) {
      return 'FAIL';
    }

    // WARN Priority
    if (!isNaN(mir) && !isNaN(wth) && mir >= wth) {
      return 'WARN';
    }

    // Default PASS
    if (!isNaN(mir) || !isNaN(mv)) return 'PASS';
    return '...';
  };

  const getStatusColor = (status: string) => {
    const s = (status || "").toUpperCase();
    switch (s) {
      case 'FAIL': return 'bg-[#DC2626] text-white';
      case 'WARN':
      case 'WARNING': return 'bg-[#F59E0B] text-white';
      case 'PASS': return 'bg-[#198754] text-white';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const addTool = () => {
    const list = [...(data.equipmentList || [])];
    list.push({ id: `eq-${Date.now()}`, name: '', make: '', model: '', serialNo: '', calDate: '', expDate: '' });
    updateField('equipmentList', list);
  };

  const updateEquipment = (id: string, f: keyof SPOFEquipmentRow, v: string) => {
    const list = (data.equipmentList || []).map(eq => eq.id === id ? { ...eq, [f]: v } : eq);
    updateField('equipmentList', list);
  };

  const deleteEquipment = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this equipment instrumentation?",
      onConfirm: () => {
        const list = (data.equipmentList || []).filter(eq => eq.id !== id);
        updateField('equipmentList', list);
      }
    });
  };

  const addUPS = () => {
    const upsList = [...(data.upsSystems || [])];
    upsList.push({
      id: `ups-${Date.now()}`,
      name: `UPS-${upsList.length + 1}`,
      location: '', make: '', batteryType: '',
      strings: []
    });
    updateField('upsSystems', upsList);
  };

  const addString = (upsId: string) => {
    const upsList = data.upsSystems.map(u => {
      if (u.id === upsId) {
        return {
          ...u,
          strings: [...u.strings, {
            id: `str-${Date.now()}`,
            name: `STRING ${u.strings.length + 1}`,
            isCollapsed: false,
            readings: []
          }]
        };
      }
      return u;
    });
    updateField('upsSystems', upsList);
  };

  const addReading = (upsId: string, strId: string) => {
    const upsList = data.upsSystems.map(u => {
      if (u.id === upsId) {
        const newStrings = u.strings.map(s => {
          if (s.id === strId) {
            const nextNo = s.readings.length + 1;
            return {
              ...s,
              readings: [...s.readings, {
                id: `r-${Date.now()}`,
                batteryNo: nextNo,
                measuredIr: '', irFailThresh: '13', irWarnThresh: '8',
                measuredVolt: '', voltThresh: '12.1', remarks: '...'
              }]
            };
          }
          return s;
        });
        return { ...u, strings: newStrings };
      }
      return u;
    });
    updateField('upsSystems', upsList);
  };

  const updateReadingField = (upsId: string, strId: string, readId: string, field: keyof BatteryReading, value: string) => {
    const upsList = data.upsSystems.map(u => {
      if (u.id === upsId) {
        const newStrings = u.strings.map(s => {
          if (s.id === strId) {
            const newReadings = s.readings.map(r => {
              if (r.id === readId) {
                const updated = { ...r, [field]: value };
                if (field !== 'remarks') {
                  updated.remarks = calculateStatus(updated);
                }
                return updated;
              }
              return r;
            });
            return { ...s, readings: newReadings };
          }
          return s;
        });
        return { ...u, strings: newStrings };
      }
      return u;
    });
    updateField('upsSystems', upsList);
  };

  const handleFileUpload = (upsId: string, strId: string, file: File) => {
    const isCsv = file.name.endsWith('.csv');
    const reader = new FileReader();

    reader.onload = (e) => {
      const dataContent = e.target?.result;
      if (!dataContent) return;

      let rows: any[] = [];

      if (isCsv) {
        const text = dataContent as string;
        rows = text.split('\n').map(line => line.split(',').map(c => c.trim()));
      } else {
        const workbook = XLSX.read(dataContent, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      }

      if (rows.length === 0) {
        showToast("The imported file is empty.", "error");
        return;
      }

      // Map columns by HEADER NAME, not fixed position, so reordering does not corrupt the import.
      let headerRowIndex = -1;
      let colIndices = {
        no: -1,
        ir: -1,
        failThresh: -1,
        warnThresh: -1,
        voltage: -1,
        voltThresh: -1,
        status: -1
      };

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        if (!row || !Array.isArray(row)) continue;
        
        let hasNo = false;
        let hasIr = false;
        let hasVolt = false;

        row.forEach((cell) => {
          if (!cell) return;
          const val = cell.toString().toLowerCase().trim();
          if (val === 'no' || val === 's.no' || val === 's.no.' || val === 'battery no') {
            hasNo = true;
          }
          if (val.includes('ir') || val.includes('impedance') || val.includes('impedence')) {
            hasIr = true;
          }
          if (val.includes('volt') || val.includes('voltage')) {
            hasVolt = true;
          }
        });

        if (hasNo && (hasIr || hasVolt)) {
          headerRowIndex = i;
          row.forEach((cell, cellIdx) => {
            if (!cell) return;
            const val = cell.toString().toLowerCase().trim();
            if (val === 'no' || val === 's.no' || val === 's.no.' || val === 'battery no' || val === 'number') {
              colIndices.no = cellIdx;
            } else if (val.includes('measured ir') || val.includes('measured_ir') || (val.includes('ir') && !val.includes('thresh'))) {
              colIndices.ir = cellIdx;
            } else if (val.includes('fail thresh') || val.includes('fail_thresh') || val.includes('failthresh')) {
              colIndices.failThresh = cellIdx;
            } else if (val.includes('warn thresh') || val.includes('warn_thresh') || val.includes('warnthresh')) {
              colIndices.warnThresh = cellIdx;
            } else if (val.includes('voltage') || val.includes('volt') && !val.includes('thresh')) {
              colIndices.voltage = cellIdx;
            } else if (val.includes('volt thresh') || val.includes('volt_thresh') || val.includes('voltthresh') || val.includes('voltage thresh')) {
              colIndices.voltThresh = cellIdx;
            } else if (val.includes('status') || val.includes('remarks') || val.includes('condition')) {
              colIndices.status = cellIdx;
            }
          });
          break;
        }
      }

      let startIdx = 0;
      if (headerRowIndex !== -1) {
        startIdx = headerRowIndex + 1;
      } else {
        // Fallback to default index mapping
        colIndices = {
          no: 0,
          ir: 1,
          failThresh: 2,
          warnThresh: 3,
          voltage: 4,
          voltThresh: 5,
          status: 6
        };
        const firstCell = rows[0]?.[0]?.toString().toLowerCase();
        if (firstCell && (firstCell.includes('no') || firstCell.includes('s.no') || firstCell.includes('s.no.'))) {
          startIdx = 1;
        } else {
          startIdx = 0;
        }
      }

      const newReadings: BatteryReading[] = [];

      for (let i = startIdx; i < rows.length; i++) {
        const cols = rows[i];
        if (!cols || !Array.isArray(cols)) continue;

        // Skip comments or completely empty rows
        const rawNo = colIndices.no !== -1 ? cols[colIndices.no] : undefined;
        if (rawNo === undefined || rawNo === null || rawNo === '') {
          continue;
        }

        const batteryNo = parseInt(rawNo.toString()) || (newReadings.length + 1);
        if (isNaN(batteryNo)) {
          continue; // skip rows with non-numeric indices if they are headers or comments
        }
        
        const rawIr = colIndices.ir !== -1 ? cols[colIndices.ir] : '';
        const rawFailThresh = colIndices.failThresh !== -1 ? cols[colIndices.failThresh] : '13';
        const rawWarnThresh = colIndices.warnThresh !== -1 ? cols[colIndices.warnThresh] : '8';
        const rawVoltage = colIndices.voltage !== -1 ? cols[colIndices.voltage] : '';
        const rawVoltThresh = colIndices.voltThresh !== -1 ? cols[colIndices.voltThresh] : '12.1';

        const irStr = rawIr !== undefined && rawIr !== null ? rawIr.toString().trim() : '';
        const voltStr = rawVoltage !== undefined && rawVoltage !== null ? rawVoltage.toString().trim() : '';
        
        // Skip row if both IR and Voltage are blank and it doesn't look like a valid battery row
        if (irStr === '' && voltStr === '') {
          continue;
        }

        const reading: BatteryReading = {
          id: `r-up-${Date.now()}-${i}`,
          batteryNo: batteryNo,
          measuredIr: irStr,
          irFailThresh: (rawFailThresh !== undefined && rawFailThresh !== null ? rawFailThresh.toString().trim() : '13'),
          irWarnThresh: (rawWarnThresh !== undefined && rawWarnThresh !== null ? rawWarnThresh.toString().trim() : '8'),
          measuredVolt: voltStr,
          voltThresh: (rawVoltThresh !== undefined && rawVoltThresh !== null ? rawVoltThresh.toString().trim() : '12.1'),
          remarks: ''
        };

        // Do not import status column, calculate automatically
        reading.remarks = calculateStatus(reading);
        newReadings.push(reading);
      }

      if (newReadings.length > 0) {
        const upsList = data.upsSystems.map(u => {
          if (u.id === upsId) {
            const newStrings = u.strings.map(s => {
              if (s.id === strId) {
                // Populate the cells of the current String
                return { ...s, readings: newReadings };
              }
              return s;
            });
            return { ...u, strings: newStrings };
          }
          return u;
        });
        updateField('upsSystems', upsList);
        showToast(`Imported ${newReadings.length} cell rows successfully!`, "success");
      } else {
        showToast("No valid cell rows could be parsed from the file.", "error");
      }
    };

    if (isCsv) {
      reader.readAsText(file);
    } else {
      reader.readAsBinaryString(file);
    }
  };

  const syncThresholds = (upsId: string, strId: string, sourceReadId: string) => {
    const upsList = data.upsSystems.map(u => {
      if (u.id === upsId) {
        const newStrings = u.strings.map(s => {
          if (s.id === strId) {
            const source = s.readings.find(r => r.id === sourceReadId);
            if (!source) return s;
            const newReadings = s.readings.map(r => {
              const updated = {
                ...r,
                irFailThresh: source.irFailThresh,
                irWarnThresh: source.irWarnThresh,
                voltThresh: source.voltThresh
              };
              updated.remarks = calculateStatus(updated);
              return updated;
            });
            return { ...s, readings: newReadings };
          }
          return s;
        });
        return { ...u, strings: newStrings };
      }
      return u;
    });
    updateField('upsSystems', upsList);
  };

  const problematicReadings = (data.upsSystems || []).flatMap(u => 
    u.strings.flatMap(s => 
      s.readings.filter(r => r.remarks !== 'PASS' && r.remarks !== '...' && r.remarks !== '').map(r => ({ ...r, upsName: u.name, strName: s.name }))
    )
  );

  return (
    <div className="space-y-12 animate-fade-in pb-24 font-sans">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      <style>{`
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
        input[type=number] {
          -moz-appearance: textfield;
        }
      `}</style>
      
      {/* PERSONNEL DATA */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-8 grid grid-cols-1 md:grid-cols-5 gap-8">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f]} onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                className="w-full text-sm font-bold text-slate-800 border-b-2 border-slate-100 focus:border-orange-500 outline-none p-2 transition-all bg-slate-50 rounded-lg"
              />
            </div>
          ))}
      </section>

      {/* SECTION 1: TOOLS USED FOR AUDIT */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-4 flex justify-between items-center text-white">
          <h3 className="font-black uppercase tracking-widest text-sm">SECTION 1: TOOLS USED FOR AUDIT</h3>
          {!readOnly && (
            <button 
              onClick={addTool}
              className="px-4 py-1.5 bg-white text-orange-600 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-orange-50 transition-all active:scale-95"
            >
              + Add Tool
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px] border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-black uppercase tracking-tighter border-b border-slate-200">
                <th className="px-6 py-3 border-r border-slate-200">EQUIPMENT NAME</th>
                <th className="px-6 py-3 border-r border-slate-200">MAKE</th>
                <th className="px-6 py-3 border-r border-slate-200">MODEL</th>
                <th className="px-6 py-3 border-r border-slate-200">SERIAL NO</th>
                <th className="px-6 py-3 border-r border-slate-200 text-center">CALIB. DATE</th>
                <th className="px-6 py-3 text-center">EXPIRY DATE</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.equipmentList || []).map(eq => (
                <tr key={eq.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-0 border-r border-slate-100"><input value={eq.name} onChange={e => updateEquipment(eq.id, 'name', e.target.value)} className="w-full px-6 py-3 bg-transparent outline-none font-medium" placeholder="Instrument name..." disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={eq.make} onChange={e => updateEquipment(eq.id, 'make', e.target.value)} className="w-full px-6 py-3 bg-transparent outline-none" placeholder="Make" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={eq.model} onChange={e => updateEquipment(eq.id, 'model', e.target.value)} className="w-full px-6 py-3 bg-transparent outline-none" placeholder="Model" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={eq.serialNo} onChange={e => updateEquipment(eq.id, 'serialNo', e.target.value)} className="w-full px-6 py-3 bg-transparent outline-none font-mono" placeholder="SN-XXXX" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input type="text" value={eq.calDate} onChange={e => updateEquipment(eq.id, 'calDate', e.target.value)} className="w-full px-6 py-3 bg-transparent outline-none text-center" placeholder="dd-mm-yyyy" disabled={readOnly} /></td>
                  <td className="p-0"><input type="text" value={eq.expDate} onChange={e => updateEquipment(eq.id, 'expDate', e.target.value)} className="w-full px-6 py-3 bg-transparent outline-none text-center" placeholder="dd-mm-yyyy" disabled={readOnly} /></td>
                  {!readOnly && <td className="px-4 py-3 text-center"><button onClick={() => deleteEquipment(eq.id)} className="text-slate-300 hover:text-red-500 transition-colors"><TrashIcon /></button></td>}
                </tr>
              ))}
              {(data.equipmentList || []).length === 0 && (
                <tr><td colSpan={7} className="px-6 py-8 text-center text-slate-400 italic font-medium">No tools registered for this test.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* UPS HIERARCHY */}
      <div className="space-y-8">
        {(data.upsSystems || []).map((ups) => (
          <div key={ups.id} className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden animate-fade-in-up">
            <div className="bg-[#F97316] p-8 text-white flex justify-between items-start">
               <div className="space-y-4 flex-1">
                  <div className="flex items-center gap-4">
                     <span className="text-3xl">🔋</span>
                     <input 
                      value={ups.name} 
                      onChange={e => updateField('upsSystems', data.upsSystems.map(u => u.id === ups.id ? {...u, name: e.target.value.toUpperCase()} : u))}
                      className="bg-transparent border-none outline-none font-black text-3xl tracking-tighter w-full focus:ring-0" 
                      disabled={readOnly}
                     />
                  </div>
                  <div className="grid grid-cols-3 gap-6 max-w-2xl">
                     <div>
                        <label className="text-[10px] font-black uppercase opacity-60 block mb-1">LOCATION</label>
                        <input value={ups.location} onChange={e => updateField('upsSystems', data.upsSystems.map(u => u.id === ups.id ? {...u, location: e.target.value} : u))} className="w-full bg-white/10 border-b border-white/30 p-1.5 outline-none font-bold text-xs" />
                     </div>
                     <div>
                        <label className="text-[10px] font-black uppercase opacity-60 block mb-1">MAKE/MODEL</label>
                        <input value={ups.make} onChange={e => updateField('upsSystems', data.upsSystems.map(u => u.id === ups.id ? {...u, make: e.target.value} : u))} className="w-full bg-white/10 border-b border-white/30 p-1.5 outline-none font-bold text-xs" />
                     </div>
                     <div>
                        <label className="text-[10px] font-black uppercase opacity-60 block mb-1">BATTERY TYPE</label>
                        <input value={ups.batteryType} onChange={e => updateField('upsSystems', data.upsSystems.map(u => u.id === ups.id ? {...u, batteryType: e.target.value} : u))} className="w-full bg-white/10 border-b border-white/30 p-1.5 outline-none font-bold text-xs" />
                     </div>
                  </div>
               </div>
               <div className="flex flex-col gap-2">
                 {!readOnly && <button onClick={() => addString(ups.id)} className="px-6 py-2.5 bg-white text-orange-600 rounded-xl font-black text-[10px] uppercase shadow-xl hover:scale-105 transition-all">Add String</button>}
                  {!readOnly && (
                    <button 
                      onClick={() => {
                        confirmDelete({
                          message: "Are you sure you want to delete this Entire UPS and all its recorded battery strings?",
                          onConfirm: () => {
                            updateField('upsSystems', data.upsSystems.filter(u => u.id !== ups.id));
                          }
                        });
                      }} 
                      className="text-[10px] font-black uppercase text-white/50 hover:text-white mt-2"
                    >
                      Delete UPS
                    </button>
                  )}
               </div>
            </div>

            <div className="p-8 space-y-6">
              {ups.strings.map((str) => (
                <div key={str.id} className="border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
                   <div 
                    onClick={() => updateField('upsSystems', data.upsSystems.map(u => u.id === ups.id ? { ...u, strings: u.strings.map(s => s.id === str.id ? { ...s, isCollapsed: !s.isCollapsed } : s) } : u))}
                    className="w-full bg-slate-50 px-6 py-4 flex justify-between items-center hover:bg-slate-100 transition-colors cursor-pointer"
                   >
                     <div className="flex items-center gap-3">
                        <span className="text-xl">{str.isCollapsed ? '📁' : '📂'}</span>
                        <input 
                          value={str.name} 
                          onClick={e => e.stopPropagation()}
                          onChange={e => updateField('upsSystems', data.upsSystems.map(u => u.id === ups.id ? { ...u, strings: u.strings.map(s => s.id === str.id ? { ...s, name: e.target.value.toUpperCase() } : s) } : u))}
                          className="bg-transparent font-black text-slate-800 text-sm outline-none w-48 border-b border-transparent focus:border-slate-400" 
                        />
                        <span className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded font-black uppercase">{str.readings.length} CELLS</span>
                     </div>
                     <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={(e) => { 
                              e.stopPropagation(); 
                              exportBatteryImpedanceToExcel(data, `Battery_Impedance_${ups.name || 'UPS'}_${str.name || 'String'}.xlsx`); 
                            }} 
                            className="flex items-center gap-2 px-4 py-1.5 bg-indigo-600 text-white rounded-lg text-[9px] font-black uppercase shadow-sm hover:bg-indigo-700 transition-all"
                          >
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                              <polyline points="7 10 12 15 17 10"></polyline>
                              <line x1="12" y1="15" x2="12" y2="3"></line>
                            </svg>
                            Export Excel
                          </button>

                          {!readOnly && aiEnabled && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                openLiveCapture(ups.id, str.id, str.readings);
                              }}
                              className="flex items-center gap-2 px-4 py-1.5 bg-violet-600 text-white rounded-lg text-[9px] font-black uppercase shadow-sm hover:bg-violet-700 transition-all"
                            >
                              <Camera className="w-3 h-3" />
                              Live Capture
                            </button>
                          )}

                          {!readOnly && (
                            <>
                              <button 
                                onClick={(e) => { e.stopPropagation(); fileInputRefs.current[str.id]?.click(); }} 
                                className="flex items-center gap-2 px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-[9px] font-black uppercase shadow-sm hover:bg-emerald-700 transition-all"
                              >
                                <UploadIcon />
                                Import Data
                              </button>
                              <input 
                                type="file" 
                                accept=".csv, .xlsx, .xls" 
                                ref={el => fileInputRefs.current[str.id] = el}
                                className="hidden"
                                onClick={e => e.stopPropagation()}
                                onChange={e => {
                                  const file = e.target.files?.[0];
                                  if (file) handleFileUpload(ups.id, str.id, file);
                                  e.target.value = ''; // Reset for next upload
                                }}
                              />
                            </>
                          )}
                        </div>
                        {!readOnly && <button onClick={(e) => { e.stopPropagation(); addReading(ups.id, str.id); }} className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg text-[9px] font-black uppercase">+ Cell</button>}
                        <span className="text-slate-400">{str.isCollapsed ? '▼' : '▲'}</span>
                     </div>
                   </div>

                   {!str.isCollapsed && (
                     <div className="overflow-x-auto p-4 animate-fade-in">
                        <table className="w-full text-[10px] text-center border-collapse">
                           <thead className="bg-slate-800 text-white font-black uppercase tracking-tighter">
                              <tr>
                                 <th className="py-3 px-2 w-12">No</th>
                                 <th className="py-3 px-2">Measured IR (mΩ)</th>
                                 <th className="py-3 px-2">Fail Thresh</th>
                                 <th className="py-3 px-2">Warn Thresh</th>
                                 <th className="py-3 px-2">Voltage (V)</th>
                                 <th className="py-3 px-2">Volt Thresh</th>
                                 <th className="py-3 px-2 w-24">STATUS</th>
                                 <th className="py-3 px-2 w-8"></th>
                              </tr>
                           </thead>
                           <tbody className="divide-y divide-slate-100">
{(str.readings).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

                              {str.readings.map((r, rIdx) => (
                                <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                                   <td className="py-3 font-black text-slate-400">{r.batteryNo}</td>
                                   <td className="p-0 border-x border-slate-100"><input type="number" step="0.01" value={r.measuredIr} onChange={e => updateReadingField(ups.id, str.id, r.id, 'measuredIr', e.target.value)} className="w-full h-full p-2 text-center bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                                   <td className="p-0 group relative border-r border-slate-100">
                                      <input type="number" step="0.01" value={r.irFailThresh} onChange={e => updateReadingField(ups.id, str.id, r.id, 'irFailThresh', e.target.value)} className="w-full h-full p-2 text-center bg-transparent outline-none font-bold" disabled={readOnly} />
                                      
                                        

                                   </td>
                                   <td className="p-0 border-r border-slate-100"><input type="number" step="0.01" value={r.irWarnThresh} onChange={e => updateReadingField(ups.id, str.id, r.id, 'irWarnThresh', e.target.value)} className="w-full h-full p-2 text-center bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                                   <td className="p-0 border-r border-slate-100"><input type="number" step="0.01" value={r.measuredVolt} onChange={e => updateReadingField(ups.id, str.id, r.id, 'measuredVolt', e.target.value)} className="w-full h-full p-2 text-center bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                                   <td className="p-0 border-r border-slate-100"><input type="number" step="0.01" value={r.voltThresh} onChange={e => updateReadingField(ups.id, str.id, r.id, 'voltThresh', e.target.value)} className="w-full h-full p-2 text-center bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                                   <td className={`p-0 align-middle ${getStatusColor(r.remarks)}`}>
                                      <input 
                                        value={r.remarks} 
                                        onChange={e => updateReadingField(ups.id, str.id, r.id, 'remarks', e.target.value)}
                                        className="w-full h-full p-2 text-center bg-transparent outline-none font-black tracking-widest uppercase"
                                        disabled={readOnly}
                                      />
                                   </td>
                                   <td className="p-0">
                                       <button 
                                        onClick={() => {
                                          confirmDelete({
                                            message: "Are you sure you want to delete this battery cell reading?",
                                            onConfirm: () => {
                                              updateField('upsSystems', data.upsSystems.map(u => u.id === ups.id ? { ...u, strings: u.strings.map(s => s.id === str.id ? { ...s, readings: s.readings.filter(rd => rd.id !== r.id) } : s) } : u));
                                            }
                                          });
                                        }} 
                                        className="text-slate-200 hover:text-red-500 transition-colors px-2 font-bold text-lg"
                                      >
                                        ×
                                      </button>
                                   </td>
                                </tr>
                              ))}
                           </tbody>
                        </table>
                        {!readOnly && str.readings.length === 0 && (
                          <div className="py-8 text-center bg-slate-50 rounded-xl border-2 border-dashed border-slate-100">
                             <button onClick={() => addReading(ups.id, str.id)} className="text-indigo-600 font-black uppercase text-[10px]">+ Add Initial Cells</button>
                          </div>
                        )}
                     </div>
                   )}
                </div>
              ))}
              {(ups.strings || []).length === 0 && (
                <div className="py-12 text-center border-2 border-dashed border-slate-100 rounded-3xl">
                   <p className="text-slate-300 font-black uppercase tracking-widest text-[10px] mb-4">No battery strings defined for this UPS</p>
                   {!readOnly && <button onClick={() => addString(ups.id)} className="px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl">+ Initialize String 01</button>}
                </div>
              )}
            </div>
          </div>
        ))}
        {!readOnly && (
          <div className="flex justify-center pt-6">
             <button onClick={addUPS} className="px-12 py-5 bg-slate-900 text-white rounded-3xl font-black text-sm uppercase tracking-[0.3em] shadow-2xl hover:scale-105 active:scale-95 transition-all">+ Initialize Next UPS System</button>
          </div>
        )}
      </div>

      {/* SUMMARY TABLES */}
      <section className="space-y-8 pt-12 border-t-4 border-slate-100">
          <div className="flex items-center gap-3">
             <span className="text-2xl">🚨</span>
             <h3 className="text-2xl font-black text-slate-800 tracking-tighter uppercase">OBSERVATIONS</h3>
          </div>
          <div className="bg-white rounded-3xl border-4 border-red-100 shadow-2xl overflow-hidden">
             <div className="overflow-x-auto">
                <table className="w-full text-center text-xs">
                   <thead>
                      <tr className="bg-red-600 text-white font-black uppercase tracking-widest text-[9px]">
                         <th className="py-4 px-6 text-left">UPS System</th>
                         <th className="py-4 px-6">String</th>
                         <th className="py-4 px-6">Battery No</th>
                         <th className="py-4 px-6">Measured IR</th>
                         <th className="py-4 px-6">Measured Voltage</th>
                         <th className="py-4 px-6">Condition</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-red-50">
                      {problematicReadings.map((pr, idx) => (
                        <tr key={idx} className="hover:bg-red-50 transition-colors">
                           <td className="py-4 px-6 text-left font-black text-slate-800">{pr.upsName}</td>
                           <td className="py-4 px-6 font-bold text-slate-500">{pr.strName}</td>
                           <td className="py-4 px-6 font-black bg-slate-50">{pr.batteryNo}</td>
                           <td className="py-4 px-6 font-medium text-red-600">{pr.measuredIr} mΩ</td>
                           <td className="py-4 px-6 font-medium text-blue-600">{pr.measuredVolt} V</td>
                           <td className="py-4 px-6">
                              <span className={`px-4 py-1 rounded-full font-black text-[9px] uppercase ${getStatusColor(pr.remarks)}`}>{pr.remarks}</span>
                           </td>
                        </tr>
                      ))}
                      {problematicReadings.length === 0 && (
                        <tr><td colSpan={6} className="py-16 text-slate-300 font-bold uppercase tracking-widest text-center italic">No batteries requiring urgent intervention detected.</td></tr>
                      )}
                   </tbody>
                </table>
             </div>
          </div>
      </section>

      {/* FINAL SUMMARY */}
      <section className="pt-10 space-y-10">
        <div className="space-y-4">
           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-2">TECHNICAL RECOMMENDATIONS</label>
           <textarea 
            value={data.recommendations} onChange={e => updateField('recommendations', e.target.value)}
            disabled={readOnly}
            placeholder="Suggest specific cell replacements, load testing, or environment cooling adjustments..."
            className="w-full h-48 p-8 bg-white border border-slate-200 rounded-[2.5rem] outline-none focus:ring-8 focus:ring-blue-50 transition-all text-sm italic leading-relaxed resize-none shadow-xl"
           />
        </div>
      </section>

      {/* Live Capture Modal */}
      {liveCapture && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-violet-600 px-6 py-4 rounded-t-2xl flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Live Capture (Battery Impedance)</h3>
                <p className="text-violet-200 text-xs mt-1">
                  Cell {liveCapture.rowIndex + 1} of {liveCapture.readings.length} — ID: {liveCapture.readings[liveCapture.rowIndex]?.batteryId || 'Unknown'}
                </p>
              </div>
              <button onClick={handleCancelCapture} className="text-white/80 hover:text-white text-2xl font-bold leading-none">×</button>
            </div>
            <div className="p-6 space-y-4">
              {liveCapture.phase === 'camera' && (
                <>
                  <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
                  <button onClick={capturePhoto} className="w-full py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2">
                    <Camera className="w-5 h-5" /> Capture Reading
                  </button>
                </>
              )}
              {liveCapture.phase === 'reading' && (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-violet-200 border-t-violet-600 mx-auto mb-4" />
                  <p className="text-slate-600 font-medium">Reading display...</p>
                  <p className="text-slate-400 text-sm mt-1">Analyzing HIOKI BT3554 display</p>
                </div>
              )}
              {liveCapture.phase === 'review' && (
                <>
                  {liveCapture.error && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-amber-800 text-sm">
                      {liveCapture.error}
                    </div>
                  )}
                  <div className="bg-slate-50 rounded-xl p-4 space-y-4">
                    <h4 className="font-bold text-slate-700 text-sm">
                      Verify values for Cell {liveCapture.readings[liveCapture.rowIndex]?.batteryId}:
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Measured IR (mΩ)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues.measuredIr}
                          onChange={(e) => setLiveCapture(prev => prev ? { ...prev, readValues: { ...prev.readValues, measuredIr: e.target.value } } : null)}
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-center font-mono text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="0.00"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Voltage (V)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues.voltage}
                          onChange={(e) => setLiveCapture(prev => prev ? { ...prev, readValues: { ...prev.readValues, voltage: e.target.value } } : null)}
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-center font-mono text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="0.00"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={handleConfirmReading} className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors">
                      ✓ Confirm & Next
                    </button>
                    <button onClick={handleCancelCapture} className="px-6 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl transition-colors">
                      Cancel
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export const INITIAL_BATTERY_IMPEDANCE_DATA: BatteryImpedanceReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  equipmentList: [],
  upsSystems: [],
  recommendations: ''
};
