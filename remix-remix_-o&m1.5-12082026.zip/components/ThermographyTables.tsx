
import React, { useRef, useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../services/firebase';
import { exportThermographyToExcel } from '../utils/excelExport';
import { 
  ThermographyReading, 
  ThermographyToolRow, 
  ThermographyInspectionRow, 
  ThermographyImageRow,
  LiveCaptureConfig
} from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { Camera, RefreshCw } from 'lucide-react';
import { readThermographyDisplay } from '../services/geminiClient';

// Icons
const PlusIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
);

const TrashIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 hover:text-red-500 transition-colors"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

const ShieldCheckIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
);

const InfoIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
);

interface ThermographyTablesProps {
  data: ThermographyReading;
  onChange: (data: ThermographyReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

export const ThermographyTables: React.FC<ThermographyTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = false,
  liveCaptureConfig
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingImageId, setUploadingImageId] = useState<string | null>(null);

  const [liveCapture, setLiveCapture] = useState<{
    active: boolean;
    rowIndex: number;
    phase: 'camera' | 'reading' | 'review';
    readValues: { maxTemp: string; minTemp: string };
    capturedImageBase64: string;
    capturedImageUrl: string;
    isUploading: boolean;
    error: string;
    saveToImagesTable: boolean;
  } | null>(null);

  const [singleRowCapture, setSingleRowCapture] = useState<{
    active: boolean;
    rowId: string;
    phase: 'camera' | 'uploading';
    error: string;
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, showToast, hideToast } = useConfirmDelete();

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera error:', err);
      const errMsg = 'Camera not available. Please verify or enter values manually below.';
      if (liveCapture) {
        setLiveCapture(prev => prev ? { ...prev, error: errMsg, phase: 'review' } : null);
      } else if (singleRowCapture) {
        setSingleRowCapture(prev => prev ? { ...prev, error: errMsg } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if ((liveCapture?.active && liveCapture?.phase === 'camera') || (singleRowCapture?.active && singleRowCapture?.phase === 'camera')) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [liveCapture?.active, liveCapture?.phase, liveCapture?.rowIndex, singleRowCapture?.active, singleRowCapture?.phase]);

  const uploadCanvasPhoto = async (canvas: HTMLCanvasElement, rowId: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      canvas.toBlob(async (blob) => {
        if (!blob) {
          reject(new Error("Failed to create blob from canvas"));
          return;
        }
        try {
          const file = new File([blob], `capture_${rowId}.jpg`, { type: 'image/jpeg' });
          const storageRef = ref(storage, `thermography/${rowId}_${Date.now()}_capture.jpg`);
          const snapshot = await uploadBytes(storageRef, file);
          const downloadUrl = await getDownloadURL(snapshot.ref);
          resolve(downloadUrl);
        } catch (err) {
          reject(err);
        }
      }, 'image/jpeg', 0.8);
    });
  };

  const openLiveCaptureWizard = () => {
    if (!data.inspections || data.inspections.length === 0) {
      showToast("Please add at least one inspection row first.", "error");
      return;
    }
    let startIndex = data.inspections.findIndex(r => !r.maxTemp && !r.minTemp);
    if (startIndex === -1) startIndex = 0;

    setLiveCapture({
      active: true,
      rowIndex: startIndex,
      phase: 'camera',
      readValues: { maxTemp: '', minTemp: '' },
      capturedImageBase64: '',
      capturedImageUrl: '',
      isUploading: false,
      error: '',
      saveToImagesTable: true
    });
  };

  const handleCancelCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');

    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', capturedImageBase64: base64, error: '' } : null);

    try {
      const geminiReadings = await readThermographyDisplay(base64);
      let uploadedUrl = '';
      if (liveCaptureConfig?.keepPhotoAsEvidence !== false) {
        setLiveCapture(prev => prev ? { ...prev, isUploading: true } : null);
        uploadedUrl = await uploadCanvasPhoto(canvas, `tg_evidence_${data.inspections[liveCapture.rowIndex].id}`);
      }

      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        readValues: geminiReadings,
        capturedImageUrl: uploadedUrl,
        isUploading: false,
        error: ''
      } : null);
    } catch (err: any) {
      console.error('Live Capture extraction/upload error:', err);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        isUploading: false,
        error: `Error: ${err?.message || JSON.stringify(err)}. Please verify or enter values manually.`
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const currentInspection = data.inspections[liveCapture.rowIndex];
    if (!currentInspection) return;

    // Update inspection row maxTemp and minTemp
    updateRow('inspections', currentInspection.id, 'maxTemp', liveCapture.readValues.maxTemp);
    updateRow('inspections', currentInspection.id, 'minTemp', liveCapture.readValues.minTemp);

    // Save to images table if selected
    if (liveCapture.saveToImagesTable && liveCapture.capturedImageUrl) {
      const existingIdx = (data.images || []).findIndex(img => 
        img.roomName === currentInspection.roomName &&
        img.panelName === currentInspection.panelName &&
        img.feederName === currentInspection.feederName
      );

      if (existingIdx !== -1) {
        const updatedImages = [...(data.images || [])];
        updatedImages[existingIdx] = {
          ...updatedImages[existingIdx],
          imageUrl: liveCapture.capturedImageUrl,
          remarks: updatedImages[existingIdx].remarks || 'Captured during thermography inspection'
        };
        updateField('images', updatedImages);
      } else {
        const newImageRow: ThermographyImageRow = {
          id: `tg-img-${Date.now()}`,
          roomName: currentInspection.roomName,
          panelName: currentInspection.panelName,
          feederName: currentInspection.feederName,
          imageUrl: liveCapture.capturedImageUrl,
          remarks: 'Captured during thermography inspection'
        };
        const updatedImages = [...(data.images || []), newImageRow];
        updateField('images', updatedImages);
      }
    }

    const nextIndex = liveCapture.rowIndex + 1;
    if (nextIndex < data.inspections.length) {
      setLiveCapture(prev => prev ? {
        ...prev,
        rowIndex: nextIndex,
        phase: 'camera',
        readValues: { maxTemp: '', minTemp: '' },
        capturedImageBase64: '',
        capturedImageUrl: '',
        isUploading: false,
        error: ''
      } : null);
    } else {
      stopCamera();
      setLiveCapture(null);
      showToast("All inspection rows captured successfully!", "success");
    }
  };

  const startSingleRowCapture = (rowId: string) => {
    setSingleRowCapture({
      active: true,
      rowId,
      phase: 'camera',
      error: ''
    });
  };

  const cancelSingleRowCapture = () => {
    stopCamera();
    setSingleRowCapture(null);
  };

  const captureSingleRowPhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !singleRowCapture) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);

    setSingleRowCapture(prev => prev ? { ...prev, phase: 'uploading', error: '' } : null);

    try {
      const url = await uploadCanvasPhoto(canvas, singleRowCapture.rowId);
      updateRow('images', singleRowCapture.rowId, 'imageUrl', url);
      showToast("Image captured and uploaded successfully!", "success");
      stopCamera();
      setSingleRowCapture(null);
    } catch (err: any) {
      console.error('Single row capture error:', err);
      setSingleRowCapture(prev => prev ? { ...prev, phase: 'camera', error: `Upload failed: ${err.message || err}` } : null);
    }
  };
  
  const updateField = (field: keyof ThermographyReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addRow = (field: 'equipmentList' | 'inspections' | 'images', template: any) => {
    const list = [...((data[field] as any[]) || [])];
    list.push({ ...template, id: `tg-${Date.now()}` });
    updateField(field, list);
  };

  const deleteRow = (field: 'equipmentList' | 'inspections' | 'images', id: string) => {
    confirmDelete({
      message: `Are you sure you want to delete this ${field === 'equipmentList' ? 'tool' : field === 'inspections' ? 'inspection' : 'image'} record?`,
      onConfirm: () => {
        const list = (data[field] as any[]).filter(item => item.id !== id);
        updateField(field, list);
      }
    });
  };

  const updateRow = (field: 'equipmentList' | 'inspections' | 'images', id: string, key: string, value: any) => {
    const list = (data[field] as any[]).map(item => item.id === id ? { ...item, [key]: value } : item);
    updateField(field, list);
  };

  const handleImageUpload = async (rowId: string, file: File) => {
    try {
      setUploadingImageId(rowId);
      const storageRef = ref(storage, `thermography/${rowId}_${Date.now()}_${file.name}`);
      const snapshot = await uploadBytes(storageRef, file);
      const downloadUrl = await getDownloadURL(snapshot.ref);
      
      updateRow('images', rowId, 'imageUrl', downloadUrl);
      showToast("Image uploaded successfully.", "success");
    } catch (err) {
      console.error("Failed to upload image:", err);
      showToast("Failed to upload image. Please try again.", "error");
    } finally {
      setUploadingImageId(null);
    }
  };

  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        if (!bstr) return;

        const workbook = XLSX.read(bstr, { type: 'binary' });
        let worksheet = workbook.Sheets['Thermography Inspection'];
        if (!worksheet) {
          worksheet = workbook.Sheets[workbook.SheetNames[0]];
        }

        if (!worksheet) {
          showToast("Worksheet not found", "error");
          return;
        }

        const rows: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        if (rows.length === 0) {
          showToast("Empty excel sheet", "error");
          return;
        }

        const headerMap: { [key: string]: keyof ThermographyInspectionRow } = {
          'room name': 'roomName',
          'roomname': 'roomName',
          'room': 'roomName',
          'panel name': 'panelName',
          'panelname': 'panelName',
          'panel': 'panelName',
          'feeder name': 'feederName',
          'feedername': 'feederName',
          'feeder': 'feederName',
          'max temp': 'maxTemp',
          'maxtemp': 'maxTemp',
          'max temp °c': 'maxTemp',
          'max temp°c': 'maxTemp',
          'min temp': 'minTemp',
          'mintemp': 'minTemp',
          'min temp °c': 'minTemp',
          'min temp°c': 'minTemp',
          'remarks': 'remarks',
          'remark': 'remarks'
        };

        let headerRowIndex = -1;
        let headerRow: any[] = [];
        for (let i = 0; i < Math.min(10, rows.length); i++) {
          const row = rows[i];
          if (row && row.some(cell => {
            const val = String(cell || '').toLowerCase();
            return val.includes('room') || val.includes('panel') || val.includes('feeder');
          })) {
            headerRowIndex = i;
            headerRow = row;
            break;
          }
        }

        if (headerRowIndex === -1) {
          showToast("No valid header row found in excel. Make sure columns like 'Room Name', 'Panel Name', and 'Feeder Name' exist.", "error");
          return;
        }

        const colMap: { [key: number]: keyof ThermographyInspectionRow } = {};
        headerRow.forEach((cell, idx) => {
          const cellStr = String(cell || '').toLowerCase().trim();
          const mappedKey = headerMap[cellStr];
          if (mappedKey) {
            colMap[idx] = mappedKey;
          }
        });

        const hasRequired = Object.values(colMap).some(k => k === 'roomName' || k === 'panelName');
        if (!hasRequired) {
          showToast("Could not map 'Room Name' or 'Panel Name' column headers.", "error");
          return;
        }

        const importedInspections: ThermographyInspectionRow[] = [];
        for (let i = headerRowIndex + 1; i < rows.length; i++) {
          const row = rows[i];
          if (!row || row.length === 0) continue;

          const inspectionRow: Partial<ThermographyInspectionRow> = {
            id: `tg-${Date.now()}-${i}-${Math.random().toString(36).substr(2, 4)}`,
            roomName: '',
            panelName: '',
            feederName: '',
            maxTemp: '',
            minTemp: '',
            remarks: ''
          };

          let hasData = false;
          row.forEach((cell, idx) => {
            const key = colMap[idx];
            if (key) {
              const cellVal = cell !== undefined && cell !== null ? String(cell).trim() : '';
              inspectionRow[key] = cellVal;
              if (cellVal) hasData = true;
            }
          });

          if (hasData && (inspectionRow.roomName || inspectionRow.panelName || inspectionRow.feederName)) {
            importedInspections.push(inspectionRow as ThermographyInspectionRow);
          }
        }

        if (importedInspections.length === 0) {
          showToast("No valid inspection rows found to import.", "error");
          return;
        }

        const updatedInspections = [...(data.inspections || []), ...importedInspections];
        onChange({
          ...data,
          inspections: updatedInspections
        });
        showToast(`Imported ${importedInspections.length} inspection rows successfully!`, "success");
      } catch (err) {
        console.error(err);
        showToast("Error parsing excel file.", "error");
      }
    };

    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  const checkExpiry = (dateStr: string) => {
    if (!dateStr) return false;
    const expiry = new Date(dateStr);
    return expiry < new Date();
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* PERSONNEL GRID */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                placeholder="Enter details..."
                className="w-full text-sm font-bold text-slate-700 bg-slate-50 border-b-2 border-transparent focus:border-orange-500 outline-none p-2.5 rounded-xl transition-all"
              />
            </div>
          ))}
        </div>
      </section>

      {/* TOOLS & CALIBRATION DETAIL */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-4 flex justify-between items-center">
          <h3 className="text-white font-black text-xs uppercase tracking-widest flex items-center gap-2">
            <span>🛠️</span> TOOLS USED & CALIBRATION DETAILS
          </h3>
          {!readOnly && (
            <button onClick={() => addRow('equipmentList', { instrumentName: '', make: '', model: '', serialNumber: '', calibrationIssue: '', calibrationExpiry: '' })} className="px-4 py-1.5 bg-white text-orange-600 rounded-lg text-[10px] font-black uppercase shadow-lg hover:bg-orange-50 transition-all">+ Add Tool</button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px] border-collapse table-auto">
            <thead>
              <tr className="bg-orange-50 text-orange-900 font-black uppercase border-b border-orange-100">
                <th className="px-4 py-3 border-r border-orange-100 w-12 text-center whitespace-nowrap">SR. NO</th>
                <th className="px-4 py-3 border-r border-orange-100 whitespace-nowrap">INSTRUMENT NAME</th>
                <th className="px-4 py-3 border-r border-orange-100 whitespace-nowrap">MAKE</th>
                <th className="px-4 py-3 border-r border-orange-100 whitespace-nowrap">MODEL</th>
                <th className="px-4 py-3 border-r border-orange-100 whitespace-nowrap">SERIAL NUMBER</th>
                <th colSpan={2} className="px-4 py-3 text-center whitespace-nowrap">CALIBRATION DATE (ISSUE / EXPIRY)</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
{((data.equipmentList || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data.equipmentList || []).map((row, idx) => {
                const expired = checkExpiry(row.calibrationExpiry);
                return (
                  <tr key={row.id} className={`hover:bg-slate-50 group transition-colors ${expired ? 'bg-red-50/50' : ''}`}>
                    <td className="px-4 py-2 text-center text-slate-400 font-mono">{idx + 1}</td>
                    <td className="p-0 border-r border-slate-100"><input value={row.instrumentName} onChange={e => updateRow('equipmentList', row.id, 'instrumentName', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input value={row.make} onChange={e => updateRow('equipmentList', row.id, 'make', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input value={row.model} onChange={e => updateRow('equipmentList', row.id, 'model', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input value={row.serialNumber} onChange={e => updateRow('equipmentList', row.id, 'serialNumber', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none font-mono" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input type="date" value={row.calibrationIssue} onChange={e => updateRow('equipmentList', row.id, 'calibrationIssue', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        type="date" 
                        value={row.calibrationExpiry} 
                        onChange={e => updateRow('equipmentList', row.id, 'calibrationExpiry', e.target.value)} 
                        className={`w-full px-4 py-2 bg-transparent outline-none ${expired ? 'text-red-600 font-black' : ''}`}
                        disabled={readOnly} 
                      />
                    </td>
                    {!readOnly && (
                      <td className="px-2 text-center">
                        <button onClick={() => deleteRow('equipmentList', row.id)}><TrashIcon /></button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* THERMOGRAPHY INSPECTION PORTFOLIO */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-blue-50 px-6 py-4 flex justify-between items-center border-b border-blue-100">
          <h3 className="text-blue-600 font-black text-xs uppercase tracking-widest flex items-center gap-2">
             <span>📷</span> THERMOGRAPHY INSPECTION
          </h3>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => exportThermographyToExcel(data, `Thermography_Report_${Date.now()}.xlsx`)}
              className="px-4 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-lg text-[10px] font-black uppercase shadow-lg transition-all flex items-center gap-1"
            >
              📥 Export Excel
            </button>
            {!readOnly && (
              <>
                {aiEnabled && (
                  <button 
                    onClick={openLiveCaptureWizard} 
                    className="px-4 py-1.5 bg-violet-600 hover:bg-violet-700 text-white rounded-lg text-[10px] font-black uppercase shadow-lg transition-all flex items-center gap-1"
                  >
                    <Camera className="w-3.5 h-3.5" /> Live Capture
                  </button>
                )}
                <button 
                  onClick={() => fileInputRef.current?.click()} 
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black uppercase shadow-lg transition-all flex items-center gap-1"
                >
                  📤 Import Excel
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  accept=".xlsx, .xls" 
                  className="hidden" 
                  onChange={handleExcelImport} 
                />
                <button onClick={() => addRow('inspections', { roomName: '', panelName: '', feederName: '', maxTemp: '', minTemp: '', remarks: '' })} className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase shadow-lg hover:bg-blue-700 transition-all">+ Add Inspection Row</button>
              </>
            )}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px] border-collapse table-auto">
            <thead>
              <tr className="bg-[#F97316] text-white font-black uppercase tracking-tighter">
                <th className="px-4 py-3 border-r border-white/10 w-12 text-center whitespace-nowrap">S.NO</th>
                <th className="px-4 py-3 border-r border-white/10 whitespace-nowrap">ROOM NAME</th>
                <th className="px-4 py-3 border-r border-white/10 whitespace-nowrap">PANEL NAME</th>
                <th className="px-4 py-3 border-r border-white/10 whitespace-nowrap">FEEDER NAME</th>
                <th className="px-4 py-3 border-r border-white/10 text-center w-24 whitespace-nowrap">MAX TEMP °C</th>
                <th className="px-4 py-3 border-r border-white/10 text-center w-24 whitespace-nowrap">MIN TEMP °C</th>
                <th className="px-4 py-3 whitespace-nowrap">REMARKS</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
{((data.inspections || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data.inspections || []).map((row, idx) => {
                return (
                  <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-2 text-center text-slate-400">{idx + 1}</td>
                    <td className="p-0 border-r border-slate-100"><input value={row.roomName} onChange={e => updateRow('inspections', row.id, 'roomName', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input value={row.panelName} onChange={e => updateRow('inspections', row.id, 'panelName', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input value={row.feederName} onChange={e => updateRow('inspections', row.id, 'feederName', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input type="number" value={row.maxTemp} onChange={e => updateRow('inspections', row.id, 'maxTemp', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none text-center font-black text-[#DC2626]" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input type="number" value={row.minTemp} onChange={e => updateRow('inspections', row.id, 'minTemp', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none text-center font-black text-[#2563EB]" disabled={readOnly} /></td>
                    <td className="p-0 border-r border-slate-100"><input value={row.remarks} onChange={e => updateRow('inspections', row.id, 'remarks', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none italic" placeholder="Observation notes..." disabled={readOnly} /></td>
                    {!readOnly && (
                      <td className="px-2 text-center">
                        <button onClick={() => deleteRow('inspections', row.id)}><TrashIcon /></button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* CRITICAL IMAGES MATRIX */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-slate-50 px-6 py-4 flex justify-between items-center border-b border-slate-100">
          <h3 className="text-slate-700 font-black text-xs uppercase tracking-widest flex items-center gap-2">
             <span>📸</span> CRITICAL IMAGES
          </h3>
          {!readOnly && (
            <button onClick={() => addRow('images', { roomName: '', panelName: '', feederName: '', imageUrl: '', remarks: '' })} className="px-4 py-1.5 bg-white text-slate-600 border border-slate-200 rounded-lg text-[10px] font-black uppercase shadow-sm hover:bg-slate-50 transition-all">+ Add Image Row</button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px] border-collapse table-auto">
            <thead>
              <tr className="bg-[#F97316] text-white font-black uppercase tracking-tighter">
                <th className="px-4 py-3 border-r border-white/10 w-12 text-center whitespace-nowrap">S.NO</th>
                <th className="px-4 py-3 border-r border-white/10 whitespace-nowrap">ROOM NAME</th>
                <th className="px-4 py-3 border-r border-white/10 whitespace-nowrap">PANEL NAME</th>
                <th className="px-4 py-3 border-r border-white/10 whitespace-nowrap">FEEDER NAME</th>
                <th className="px-4 py-3 border-r border-white/10 text-center w-32 whitespace-nowrap">CRITICAL IMAGES</th>
                <th className="px-4 py-3 whitespace-nowrap">REMARKS</th>
                {!readOnly && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
{((data.images || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data.images || []).map((row, idx) => (
                <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-2 text-center text-slate-400">{idx + 1}</td>
                  <td className="p-0 border-r border-slate-100"><input value={row.roomName} onChange={e => updateRow('images', row.id, 'roomName', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={row.panelName} onChange={e => updateRow('images', row.id, 'panelName', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none font-bold" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={row.feederName} onChange={e => updateRow('images', row.id, 'feederName', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" disabled={readOnly} /></td>
                  <td className="px-4 py-2 border-r border-slate-100 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <div className="relative group w-10 h-10 bg-slate-100 rounded-md border border-slate-200 overflow-hidden flex items-center justify-center">
                        {uploadingImageId === row.id ? (
                          <div className="flex flex-col items-center justify-center">
                            <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                            <span className="text-[6px] font-bold text-slate-500 mt-1 uppercase">Uploading</span>
                          </div>
                        ) : row.imageUrl ? (
                          <>
                            <img src={row.imageUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            {!readOnly && (
                              <button 
                                onClick={() => updateRow('images', row.id, 'imageUrl', '')}
                                className="absolute inset-0 bg-black/60 text-white text-[8px] font-black opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                              >
                                REMOVE
                              </button>
                            )}
                          </>
                        ) : (
                          <div className="flex flex-col items-center gap-0.5">
                             <span className="text-[14px]">📁</span>
                             {!readOnly && <span className="text-[6px] font-black uppercase text-slate-400">Upload</span>}
                             {!readOnly && (
                               <input 
                                 type="file" 
                                 accept="image/*"
                                 className="absolute inset-0 opacity-0 cursor-pointer" 
                                 onChange={(e) => {
                                   const file = e.target.files?.[0];
                                   if (file) {
                                     handleImageUpload(row.id, file);
                                   }
                                 }} 
                               />
                             )}
                          </div>
                        )}
                      </div>
                      {aiEnabled && !readOnly && !row.imageUrl && (
                        <button 
                          onClick={() => startSingleRowCapture(row.id)}
                          className="p-1.5 bg-violet-100 hover:bg-violet-200 text-violet-700 rounded transition-colors"
                          title="Capture image from camera"
                        >
                          <Camera className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                  <td className="p-0 border-r border-slate-100"><input value={row.remarks} onChange={e => updateRow('images', row.id, 'remarks', e.target.value)} className="w-full px-4 py-2 bg-transparent outline-none" placeholder="Defect description..." disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="px-2 text-center">
                      <button onClick={() => deleteRow('images', row.id)}><TrashIcon /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* SUMMARY SECTIONS */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-8 space-y-8 animate-in slide-in-from-bottom-2">
         <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
           <ShieldCheckIcon />
           <h3 className="font-black text-slate-800 tracking-widest text-xs uppercase">OBSERVATIONS & RECOMMENDATIONS</h3>
         </div>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <div className="flex items-center gap-2 px-1">
                <InfoIcon />
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">TEST OBSERVATIONS</label>
              </div>
              <textarea 
                value={data.observations}
                onChange={e => updateField('observations', e.target.value)}
                disabled={readOnly}
                placeholder="Describe thermal anomalies, environmental conditions, and severity findings..."
                className="w-full h-40 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-orange-50 outline-none text-sm transition-all italic resize-none"
              />
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2 px-1">
                <ShieldCheckIcon />
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">RECOMMENDATIONS</label>
              </div>
              <textarea 
                value={data.recommendations}
                onChange={e => updateField('recommendations', e.target.value)}
                disabled={readOnly}
                placeholder="Provide professional engineering suggestions for remediation or periodic monitoring..."
                className="w-full h-40 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-orange-50 outline-none text-sm transition-all italic resize-none"
              />
            </div>
         </div>
      </section>

      {/* Live Capture Wizard Modal */}
      {liveCapture && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-violet-600 px-6 py-4 rounded-t-2xl flex justify-between items-center text-white">
              <div>
                <h3 className="font-black text-xs uppercase tracking-widest text-violet-100">Live Instrument Capture</h3>
                <p className="text-sm font-bold mt-1">
                  Row {liveCapture.rowIndex + 1} of {data.inspections.length}
                </p>
              </div>
              <button onClick={handleCancelCapture} className="text-white/80 hover:text-white text-2xl font-bold leading-none">×</button>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Row Context Header */}
              <div className="bg-violet-50 rounded-xl p-3.5 border border-violet-100 text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="font-semibold text-violet-400">ROOM:</span>
                  <span className="font-bold text-violet-900">{data.inspections[liveCapture.rowIndex]?.roomName || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-violet-400">PANEL:</span>
                  <span className="font-bold text-violet-900">{data.inspections[liveCapture.rowIndex]?.panelName || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-violet-400">FEEDER:</span>
                  <span className="font-bold text-violet-900">{data.inspections[liveCapture.rowIndex]?.feederName || 'N/A'}</span>
                </div>
              </div>

              {liveCapture.phase === 'camera' && (
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Point camera at the Fluke VT08 display</p>
                    <p className="text-[11px] text-slate-400 mt-1">Ensure MAX and MIN temperature readouts are clearly visible and in focus.</p>
                  </div>
                  <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative shadow-inner">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
                  <button 
                    onClick={capturePhoto} 
                    className="w-full py-3 bg-violet-600 hover:bg-violet-700 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md"
                  >
                    <Camera className="w-4 h-4" /> Capture Photo & Read
                  </button>
                </div>
              )}

              {liveCapture.phase === 'reading' && (
                <div className="text-center py-12 space-y-4">
                  <div className="relative w-16 h-16 mx-auto">
                    <div className="absolute inset-0 rounded-full border-4 border-violet-100 animate-pulse"></div>
                    <div className="absolute inset-0 rounded-full border-4 border-t-violet-600 animate-spin"></div>
                  </div>
                  <div>
                    <p className="text-slate-700 font-bold text-sm">Gemini AI is analyzing thermometer display...</p>
                    <p className="text-slate-400 text-xs mt-1">Extracting MAX and MIN values and prepping thermal evidence image</p>
                  </div>
                </div>
              )}

              {liveCapture.phase === 'review' && (
                <div className="space-y-5">
                  {liveCapture.error && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-amber-800 text-xs font-semibold">
                      ⚠️ {liveCapture.error}
                    </div>
                  )}

                  {liveCapture.capturedImageBase64 && (
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Captured Thermal Photo</span>
                      <div className="bg-slate-100 rounded-xl overflow-hidden aspect-video relative border border-slate-200 shadow-sm">
                        <img 
                          src={`data:image/jpeg;base64,${liveCapture.capturedImageBase64}`} 
                          className="w-full h-full object-cover" 
                          referrerPolicy="no-referrer"
                        />
                        {liveCapture.isUploading && (
                          <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white">
                            <RefreshCw className="w-6 h-6 animate-spin text-white mb-2" />
                            <span className="text-[10px] font-bold tracking-widest uppercase text-white/90">Uploading Evidence...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 space-y-4">
                    <h4 className="font-black text-[10px] text-slate-400 uppercase tracking-widest">
                      Confirm or adjust extracted readings
                    </h4>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Max Temp (°C)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues.maxTemp}
                          onChange={(e) => setLiveCapture(prev => prev ? { ...prev, readValues: { ...prev.readValues, maxTemp: e.target.value } } : null)}
                          className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-center font-mono font-bold text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="e.g. 38.5"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Min Temp (°C)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues.minTemp}
                          onChange={(e) => setLiveCapture(prev => prev ? { ...prev, readValues: { ...prev.readValues, minTemp: e.target.value } } : null)}
                          className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-center font-mono font-bold text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="e.g. 24.1"
                        />
                      </div>
                    </div>

                    {liveCapture.capturedImageUrl && (
                      <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                        <input
                          type="checkbox"
                          id="saveToImagesCheck"
                          checked={liveCapture.saveToImagesTable}
                          onChange={(e) => setLiveCapture(prev => prev ? { ...prev, saveToImagesTable: e.target.checked } : null)}
                          className="w-4 h-4 rounded text-violet-600 focus:ring-violet-400"
                        />
                        <label htmlFor="saveToImagesCheck" className="text-xs font-semibold text-slate-600 cursor-pointer">
                          Add captured image to the Critical Images table for this panel
                        </label>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-3 pt-2">
                    <button 
                      onClick={handleConfirmReading} 
                      disabled={liveCapture.isUploading}
                      className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors shadow-md"
                    >
                      ✓ Confirm & Next
                    </button>
                    <button 
                      onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'camera', capturedImageBase64: '', capturedImageUrl: '', error: '' } : null)}
                      className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs uppercase tracking-wider rounded-xl transition-colors"
                    >
                      Retake
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Single-Row Critical Image Capture Modal */}
      {singleRowCapture && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
            <div className="bg-violet-600 px-6 py-4 flex justify-between items-center text-white">
              <div>
                <h3 className="font-black text-xs uppercase tracking-widest text-violet-100">Capture Critical Image</h3>
                <p className="text-sm font-bold mt-1">Take photo for images table record</p>
              </div>
              <button onClick={cancelSingleRowCapture} className="text-white/80 hover:text-white text-2xl font-bold leading-none">×</button>
            </div>

            <div className="p-6 space-y-4">
              {singleRowCapture.phase === 'camera' ? (
                <>
                  {singleRowCapture.error && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-amber-800 text-xs font-semibold">
                      ⚠️ {singleRowCapture.error}
                    </div>
                  )}
                  <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative">
                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
                  <div className="flex gap-3">
                    <button 
                      onClick={captureSingleRowPhoto} 
                      className="flex-1 py-3 bg-violet-600 hover:bg-violet-700 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md"
                    >
                      <Camera className="w-4 h-4" /> Snap & Upload
                    </button>
                    <button 
                      onClick={cancelSingleRowCapture} 
                      className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs uppercase tracking-wider rounded-xl transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center py-12 space-y-4">
                  <div className="relative w-12 h-12 mx-auto">
                    <div className="absolute inset-0 rounded-full border-4 border-violet-100 animate-pulse"></div>
                    <div className="absolute inset-0 rounded-full border-4 border-t-violet-600 animate-spin"></div>
                  </div>
                  <div>
                    <p className="text-slate-700 font-bold text-sm">Uploading captured image...</p>
                    <p className="text-slate-400 text-xs mt-1">Storing downscaled evidence photo on Firebase Storage</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export const INITIAL_THERMOGRAPHY_DATA: ThermographyReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  status: 'PENDING',
  equipmentList: [],
  inspections: [],
  images: [],
  observations: '',
  recommendations: ''
};
