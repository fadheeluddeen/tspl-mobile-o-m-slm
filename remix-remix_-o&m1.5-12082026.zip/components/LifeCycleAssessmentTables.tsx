import React, { useRef, useState, useEffect } from 'react';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../services/firebase';
import { readLcaDisplay } from '../services/geminiClient';
import { LifeCycleReading, SPOFEquipmentRow, LifeCycleAssessmentRow, ObservationRecommendationRow, LiveCaptureConfig } from '../types';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { FileSpreadsheet, Upload, Camera } from 'lucide-react';
import { exportLCATable1ToExcel, exportLCATable2ToExcel } from '../utils/excelExport';
import { parseLCATable1Excel, parseLCATable2Excel } from '../utils/excelImport';

// SVGs for Lucide-style consistency
const ActivityIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-600"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
);
const ClipboardListIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-600"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/></svg>
);
const PlusIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
);
const Trash2Icon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

interface LifeCycleAssessmentTablesProps {
  data: LifeCycleReading;
  onChange: (data: LifeCycleReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
  liveCaptureConfig?: LiveCaptureConfig;
}

export const LifeCycleAssessmentTables: React.FC<LifeCycleAssessmentTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = false,
  liveCaptureConfig
}) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();
  const canEdit = !readOnly;

  // Live capture wizard state
  const [liveCapture, setLiveCapture] = useState<{
    active: boolean;
    rowIndex: number;
    stepIndex: number;
    phase: 'camera' | 'reading' | 'uploading' | 'review';
    value: string;
    capturedImageBase64: string;
    capturedImageUrl: string;
    error: string;
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const getCaptureSteps = () => [
    {
      key: 'surfaceTemp' as const,
      label: 'Surface Temp',
      instrument: 'Thermal Imager / Visual IR (FLUKE VT08)',
      unit: '°C',
      keepPhotoAsEvidence: true,
      guidance: 'Read ONLY the spot temperature value shown on the display in °C, preserving decimals. Ignore emissivity settings, colour-scale bar numbers, battery icon, and mode text. Keep the photo as evidence.'
    },
    {
      key: 'vibrationVelocity' as const,
      label: 'Vibration Velocity',
      instrument: 'Vibration Meter (WINTACT WT63B)',
      unit: 'mm/s',
      keepPhotoAsEvidence: false,
      guidance: 'Read ONLY the overall vibration velocity value shown on the display in mm/s, preserving decimals. Ignore acceleration or displacement readouts if display cycles, and any mode/hold indicators.'
    }
  ];

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? { ...prev, error: 'Camera access denied or unavailable. Please enter values manually below.', phase: 'review' } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const openLiveCapture = (rowIndex: number = 0, stepIndex: number = 0) => {
    const targetRow = (data.lifeCycleRows || [])[rowIndex];
    if (!targetRow) return;

    setLiveCapture({
      active: true,
      rowIndex,
      stepIndex,
      phase: 'camera',
      value: '',
      capturedImageBase64: '',
      capturedImageUrl: '',
      error: ''
    });
  };

  useEffect(() => {
    if (liveCapture?.active && liveCapture.phase === 'camera') {
      startCamera();
    } else if (!liveCapture?.active || liveCapture.phase !== 'camera') {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [liveCapture?.active, liveCapture?.phase]);

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const base64Jpeg = canvas.toDataURL('image/jpeg', 0.85).split(',')[1];
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

    stopCamera();

    const steps = getCaptureSteps();
    const currentStep = steps[liveCapture.stepIndex];

    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', capturedImageBase64: dataUrl, error: '' } : null);

    try {
      const readVal = await readLcaDisplay(base64Jpeg, currentStep.label, currentStep.guidance);
      
      let imageUrl = '';
      if (currentStep.keepPhotoAsEvidence) {
        setLiveCapture(prev => prev ? { ...prev, phase: 'uploading' } : null);
        try {
          const res = await fetch(dataUrl);
          const blob = await res.blob();
          const storageRef = ref(storage, `lca_thermal_evidence/${Date.now()}_${Math.random().toString(36).substring(2, 7)}.jpg`);
          await uploadBytes(storageRef, blob);
          imageUrl = await getDownloadURL(storageRef);
        } catch (storageErr) {
          console.error("Storage upload error:", storageErr);
        }
      }

      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        value: readVal,
        capturedImageUrl: imageUrl,
        error: readVal ? '' : 'Could not confidently read instrument value. Please inspect and enter value manually.'
      } : null);
    } catch (err) {
      console.error("AI Reading error:", err);
      setLiveCapture(prev => prev ? {
        ...prev,
        phase: 'review',
        value: '',
        error: 'AI extraction error. Please enter value manually.'
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;

    const steps = getCaptureSteps();
    const currentStep = steps[liveCapture.stepIndex];
    const targetRow = (data.lifeCycleRows || [])[liveCapture.rowIndex];
    if (!targetRow) return;

    const valToSave = liveCapture.value.trim();

    let updatedRow: LifeCycleAssessmentRow = { ...targetRow };
    if (currentStep.key === 'surfaceTemp') {
      updatedRow.surfaceTemp = valToSave;
      if (liveCapture.capturedImageUrl) {
        updatedRow.thermalImageUrl = liveCapture.capturedImageUrl;
      }
    } else if (currentStep.key === 'vibrationVelocity') {
      updatedRow.vibrationVelocity = valToSave;
    }

    const nextRows = (data.lifeCycleRows || []).map((r, i) => i === liveCapture.rowIndex ? updatedRow : r);
    handleDataChange({
      ...data,
      lifeCycleRows: nextRows
    });

    if (liveCapture.stepIndex < steps.length - 1) {
      setLiveCapture({
        active: true,
        rowIndex: liveCapture.rowIndex,
        stepIndex: liveCapture.stepIndex + 1,
        phase: 'camera',
        value: '',
        capturedImageBase64: '',
        capturedImageUrl: '',
        error: ''
      });
    } else if (liveCapture.rowIndex < (data.lifeCycleRows || []).length - 1) {
      setLiveCapture({
        active: true,
        rowIndex: liveCapture.rowIndex + 1,
        stepIndex: 0,
        phase: 'camera',
        value: '',
        capturedImageBase64: '',
        capturedImageUrl: '',
        error: ''
      });
    } else {
      stopCamera();
      setLiveCapture(null);
    }
  };

  const handleDataChange = (updatedData: LifeCycleReading) => {
    if (!canEdit) return;

    const lcaRows = updatedData.lifeCycleRows || [];
    
    // Auto-calculate Age (yrs) = Current Year – Install Year, Health Index (HI) = (0.4×Vibration Score) + (0.3×Corrosion Score) + (0.3×Maint. Score), Utilization Ratio (UR) = Running Life (yrs) / Age (yrs), and Utilization Factor (UF) based on UR range
    const syncedLcaRows = lcaRows.map((lcaRow) => {
      const autoAge = (lcaRow.installYear && lcaRow.currentYear && !isNaN(Number(lcaRow.currentYear)) && !isNaN(Number(lcaRow.installYear))) 
        ? String(Number(lcaRow.currentYear) - Number(lcaRow.installYear)) 
        : '';
      
      let autoHI = '';
      if (lcaRow.vibrationScore !== '' || lcaRow.corrosionScore !== '' || lcaRow.maintScore !== '') {
        const vs = Number(lcaRow.vibrationScore) || 0;
        const cs = Number(lcaRow.corrosionScore) || 0;
        const ms = Number(lcaRow.maintScore) || 0;
        autoHI = ((0.4 * vs) + (0.3 * cs) + (0.3 * ms)).toFixed(1);
      }

      let autoUR = '';
      const ageVal = Number(autoAge);
      if (lcaRow.runningLifeYrs && ageVal > 0 && !isNaN(Number(lcaRow.runningLifeYrs))) {
        autoUR = (Number(lcaRow.runningLifeYrs) / ageVal).toFixed(2);
      }

      let autoUF = '1.0';
      if (autoUR !== '') {
        const urVal = Number(autoUR);
        if (!isNaN(urVal)) {
          if (urVal > 0.8) {
            autoUF = '0.9';
          } else if (urVal >= 0.6) {
            autoUF = '0.95';
          } else if (urVal >= 0.4) {
            autoUF = '1.0';
          } else {
            autoUF = '1.05';
          }
        }
      }

      return {
        ...lcaRow,
        ageYrs: autoAge,
        healthIndex: autoHI,
        utilizationRatio: autoUR,
        utilizationFactor: autoUF
      };
    });

    let rulRows = [...(updatedData.rulRows || [])];

    if (rulRows.length !== syncedLcaRows.length) {
      if (rulRows.length < syncedLcaRows.length) {
        for (let i = rulRows.length; i < syncedLcaRows.length; i++) {
          const lcaRow = syncedLcaRows[i];
          rulRows.push({
            id: `rul-row-${lcaRow.id.replace('lca-row-', '')}`,
            equipmentTag: lcaRow.equipmentTag || '',
            makeModel: lcaRow.makeModel || '',
            serialNo: lcaRow.serialNo || '',
            location: lcaRow.location || '',
            installYear: lcaRow.installYear || '',
            currentYear: lcaRow.currentYear || String(new Date().getFullYear()),
            ageYrs: lcaRow.ageYrs || '',
            vibrationScore: lcaRow.vibrationScore || '',
            corrosionScore: lcaRow.corrosionScore || '',
            maintScore: lcaRow.maintScore || '',
            healthIndex: lcaRow.healthIndex || '',
            runningLifeYrs: lcaRow.runningLifeYrs || '',
            utilizationRatio: lcaRow.utilizationRatio || '',
            utilizationFactor: lcaRow.utilizationFactor || '1.0',
            designLifeYrs: '',
            adjustedLifeAL: '',
            rulYrs: '',
            rulPct: '',
            lifeCycleStatus: '',
            remarksRul: ''
          });
        }
      } else {
        rulRows = rulRows.slice(0, syncedLcaRows.length);
      }
    }

    const syncedRulRows = rulRows.map((rulRow, idx) => {
      const lcaRow = syncedLcaRows[idx];
      if (!lcaRow) return rulRow;

      const autoAge = lcaRow.ageYrs || '';
      const autoHI = lcaRow.healthIndex || '';
      const autoUF = lcaRow.utilizationFactor || '1.0';

      const designLife = rulRow.designLifeYrs || '';
      const dlNum = Number(designLife) || 0;
      const hiNum = Number(autoHI) || 0;
      const ufNum = Number(autoUF) || 1;

      // Calculate Adjusted Life: Design Life (yrs) * Health Index (HI) * Utilization Factor (UF)
      const computedAL = (dlNum > 0 && hiNum > 0) 
        ? ((dlNum * hiNum) * ufNum).toFixed(1) 
        : '';

      const ageNum = Number(autoAge) || 0;
      const alNum = Number(computedAL) || 0;

      // Calculate RUL (yrs): AL - Age (yrs)
      const computedRulYrs = (alNum > 0) 
        ? (alNum - ageNum).toFixed(1) 
        : '';

      // Calculate RUL (%): (RUL (yrs) / Adjusted Life (AL)) * 100
      const rulYrsNum = Number(computedRulYrs) || 0;
      const computedRulPct = (alNum > 0 && rulYrsNum >= 0) 
        ? ((rulYrsNum / alNum) * 100).toFixed(1) 
        : '';

      // Determine Life Cycle Status automatically
      let autoStatus = '';
      if (alNum > 0) {
        const rulPctNum = Number(computedRulPct) || 0;
        if (rulPctNum > 50) {
          autoStatus = 'Fit for Service';
        } else if (rulPctNum >= 25) {
          autoStatus = 'Degrading Stage';
        } else if (rulPctNum >= 10) {
          autoStatus = 'Approaching Replacement';
        } else if (rulPctNum > 0) {
          autoStatus = 'Reaching End-of-Life';
        } else {
          autoStatus = 'End-of-Life';
        }
      }

      return {
        ...rulRow,
        equipmentTag: lcaRow.equipmentTag || '',
        ageYrs: autoAge,
        healthIndex: autoHI,
        utilizationFactor: autoUF,
        adjustedLifeAL: computedAL,
        rulYrs: computedRulYrs,
        rulPct: computedRulPct,
        lifeCycleStatus: autoStatus
      };
    });

    onChange({
      ...updatedData,
      lifeCycleRows: syncedLcaRows,
      rulRows: syncedRulRows
    });
  };

  const updateField = (field: keyof LifeCycleReading, value: any) => {
    if (!canEdit) return;
    handleDataChange({ ...data, [field]: value });
  };

  const addTool = () => {
    const list = [...(data.equipmentList || [])];
    list.push({ id: `tool-${Date.now()}`, name: '', make: '', model: '', serialNo: '', calDate: '', expDate: '' });
    updateField('equipmentList', list);
  };

  const updateTool = (id: string, f: keyof SPOFEquipmentRow, v: string) => {
    const list = data.equipmentList.map(eq => eq.id === id ? { ...eq, [f]: v } : eq);
    updateField('equipmentList', list);
  };

  const addUnifiedRow = () => {
    const list = [...(data.lifeCycleRows || [])];
    list.push({
      id: `lca-row-${Date.now()}`,
      equipmentTag: '',
      makeModel: '',
      serialNo: '',
      location: '',
      installYear: '',
      currentYear: String(new Date().getFullYear()),
      ageYrs: '',
      vibrationScore: '',
      corrosionScore: '',
      maintScore: '',
      healthIndex: '',
      runningLifeYrs: '',
      utilizationRatio: '',
      utilizationFactor: ''
    });
    updateField('lifeCycleRows', list);
  };

  const updateLifeCycleRow = (id: string, f: keyof LifeCycleAssessmentRow, v: string) => {
    const list = (data.lifeCycleRows || []).map(r => r.id === id ? { ...r, [f]: v } : r);
    updateField('lifeCycleRows', list);
  };

  const updateRULRow = (id: string, f: keyof LifeCycleAssessmentRow, v: string) => {
    const list = (data.rulRows || []).map(r => r.id === id ? { ...r, [f]: v } : r);
    updateField('rulRows', list);
  };

  const removeUnifiedRow = (idx: number) => {
    confirmDelete({
      message: "Are you sure you want to delete this asset evaluation record? This will remove the row from both tables.",
      onConfirm: () => {
        const lcaRows = (data.lifeCycleRows || []).filter((_, i) => i !== idx);
        const rulRows = (data.rulRows || []).filter((_, i) => i !== idx);
        handleDataChange({
          ...data,
          lifeCycleRows: lcaRows,
          rulRows: rulRows
        });
      }
    });
  };

  const handleImportTable1Excel = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const result = parseLCATable1Excel(evt.target?.result);
        if (result && result.length > 0) {
          handleDataChange({
            ...data,
            lifeCycleRows: result
          });
        } else {
          alert("Could not parse file. Ensure headers match the original export template for Table-1.");
        }
      };
      reader.readAsBinaryString(file);
    };
    input.click();
  };

  const handleImportTable2Excel = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const result = parseLCATable2Excel(evt.target?.result);
        if (result && result.length > 0) {
          handleDataChange({
            ...data,
            rulRows: result
          });
        } else {
          alert("Could not parse file. Ensure headers match the original export template for Table-2.");
        }
      };
      reader.readAsBinaryString(file);
    };
    input.click();
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500 pb-20 font-sans">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* A. Main Header Card */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex justify-between items-center">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center border border-emerald-100 shadow-inner">
            <ActivityIcon />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Life Cycle Assessment Test</h1>
            <p className="text-xs font-black text-slate-400 mt-1 tracking-widest uppercase">MECHANICAL TESTING + ASSET PERFORMANCE</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">Global Health Status</label>
          <select 
            value={data.status || 'PENDING'}
            onChange={e => updateField('status', e.target.value)}
            disabled={!canEdit}
            className={`px-4 py-2 rounded-xl border-2 font-black text-xs uppercase tracking-widest outline-none transition-all appearance-none cursor-pointer
              ${data.status === 'PASS' ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 
                data.status === 'FAIL' ? 'bg-red-50 border-red-200 text-[#B71C1C]' : 
                data.status === 'IN_PROGRESS' ? 'bg-blue-50 border-blue-200 text-blue-700' : 
                'bg-slate-50 border-slate-200 text-slate-600'}`}
          >
            <option value="PENDING">PENDING</option>
            <option value="IN_PROGRESS">IN PROGRESS</option>
            <option value="PASS">PASS</option>
            <option value="FAIL">FAIL</option>
          </select>
        </div>
      </section>

      {/* B. Personnel & Schedule */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white">
          <h3 className="text-center font-black uppercase tracking-widest text-[10px]">Personnel & Execution Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1.5">
              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest block px-1">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={!canEdit}
                placeholder="---"
                className="w-full text-xs font-bold text-slate-700 bg-transparent border-b border-slate-100 focus:border-[#F97316] outline-none p-1.5 transition-all"
              />
            </div>
          ))}
        </div>
      </section>

      {/* C. List of Testing Equipment */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 flex justify-between items-center border-b border-slate-100">
           <h3 className="font-black text-slate-800 text-xs uppercase tracking-widest">LIST OF TESTING EQUIPMENT (CALIBRATION DETAILS)</h3>
           {canEdit && (
             <button 
              onClick={addTool}
              className="px-4 py-1.5 bg-[#F97316] text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-orange-600 transition-all flex items-center gap-2"
             >
               <PlusIcon /> Add Tool
             </button>
           )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px] border-collapse">
            <thead>
              <tr className="bg-orange-50 text-orange-900 font-black uppercase tracking-tighter border-b border-orange-100">
                <th className="px-6 py-3 border-r border-orange-100 text-center w-12">S. No</th>
                <th className="px-6 py-3 border-r border-orange-100">EQUIPMENT NAME</th>
                <th className="px-6 py-3 border-r border-orange-100">MAKE</th>
                <th className="px-6 py-3 border-r border-orange-100">MODEL</th>
                <th className="px-6 py-3 border-r border-orange-100 text-center">SERIAL NO</th>
                <th className="px-6 py-3 border-r border-orange-100 text-center">CALIBRATION DATE</th>
                <th className="px-6 py-3 border-r border-orange-100 text-center">EXPIRY DATE</th>
                {canEdit && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.equipmentList || []).map((eq, idx) => (
                <tr key={eq.id} className="hover:bg-slate-50/50">
                  <td className="px-6 py-3 border-r border-slate-100 text-center font-bold">{idx + 1}</td>
                  <td className="p-0 border-r border-slate-100"><input value={eq.name} onChange={e => updateTool(eq.id, 'name', e.target.value)} disabled={!canEdit} className="w-full px-6 py-3 bg-transparent outline-none font-medium" placeholder="..." /></td>
                  <td className="p-0 border-r border-slate-100"><input value={eq.make} onChange={e => updateTool(eq.id, 'make', e.target.value)} disabled={!canEdit} className="w-full px-6 py-3 bg-transparent outline-none" placeholder="..." /></td>
                  <td className="p-0 border-r border-slate-100"><input value={eq.model} onChange={e => updateTool(eq.id, 'model', e.target.value)} disabled={!canEdit} className="w-full px-6 py-3 bg-transparent outline-none" placeholder="..." /></td>
                  <td className="p-0 border-r border-slate-100"><input value={eq.serialNo} onChange={e => updateTool(eq.id, 'serialNo', e.target.value)} disabled={!canEdit} className="w-full px-6 py-3 bg-transparent outline-none text-center font-mono" placeholder="SN-..." /></td>
                  <td className="p-0 border-r border-slate-100"><input type="text" value={eq.calDate} onChange={e => updateTool(eq.id, 'calDate', e.target.value)} disabled={!canEdit} className="w-full px-6 py-3 bg-transparent outline-none text-center" placeholder="DD-MM-YYYY" /></td>
                  <td className="p-0 border-r border-slate-100"><input type="text" value={eq.expDate} onChange={e => updateTool(eq.id, 'expDate', e.target.value)} disabled={!canEdit} className="w-full px-6 py-3 bg-transparent outline-none text-center" placeholder="DD-MM-YYYY" /></td>
                  {canEdit && (
                    <td className="px-4 py-3 text-center">
                      <button 
                        onClick={() => {
                          confirmDelete({
                            message: "Are you sure you want to delete this instrument detailed record?",
                            onConfirm: () => {
                              updateField('equipmentList', data.equipmentList.filter(t => t.id !== eq.id));
                            }
                          });
                        }} 
                        className="text-slate-300 hover:text-red-500"
                      >
                        <Trash2Icon />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {(data.equipmentList || []).length === 0 && (
                <tr><td colSpan={8} className="px-6 py-8 text-center text-slate-400 italic">No tools registered. Click "+ Add Tool" to begin.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* C2. Unified Asset Life Cycle Assessment Evaluation Matrix */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 bg-sky-50">
           <h3 className="font-extrabold text-sky-950 text-sm tracking-tight mb-1">4. Equipment Remaining Useful Life (RUL) Estimation</h3>
           <div className="flex justify-between items-center">
             <h4 className="font-bold text-sky-700 text-xs uppercase tracking-widest">4.1 Table-1 (Equipment Summary & Factor Calculation)</h4>
             <div className="flex items-center gap-2">
               {aiEnabled && canEdit && (data.lifeCycleRows || []).length > 0 && (
                 <button
                   type="button"
                   onClick={() => openLiveCapture(0, 0)}
                   className="px-4 py-1.5 bg-purple-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-purple-700 transition-all flex items-center gap-2"
                 >
                   <Camera className="w-3.5 h-3.5" /> Live Capture
                 </button>
               )}
               <button
                 onClick={() => exportLCATable1ToExcel(data, `LCA_Table1_Evaluation_${new Date().toISOString().split('T')[0]}.xlsx`)}
                 className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-emerald-700 transition-all flex items-center gap-2"
               >
                 <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
               </button>
               {canEdit && (
                 <>
                   <button
                     onClick={handleImportTable1Excel}
                     className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-indigo-700 transition-all flex items-center gap-2"
                   >
                     <Upload className="w-3.5 h-3.5" /> Import Excel
                   </button>
                   <button 
                    onClick={addUnifiedRow}
                    className="px-4 py-1.5 bg-sky-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-sky-700 transition-all flex items-center gap-2"
                   >
                     <PlusIcon /> Add Evaluation Row
                   </button>
                 </>
               )}
             </div>
           </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px] border-collapse min-w-[1700px]">
            <thead>
              <tr className="bg-sky-100/50 text-sky-900 font-black uppercase tracking-tighter border-b border-sky-200">
                <th className="px-3 py-3 border-r border-sky-200 text-center w-12 shrink-0">Sl No</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[140px]">Equipment Tag / Name</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[140px]">Make & Model No</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[110px]">Serial No</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[120px]">Location</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[85px] text-center">Install Year</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[85px] text-center">Current Year</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[85px] text-center">Age (yrs)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[110px] text-center bg-amber-100/60 text-amber-900">Surface Temp (°C)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[110px] text-center bg-amber-100/60 text-amber-900">Thermal Evidence</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[110px] text-center bg-purple-100/60 text-purple-900">Vibration (mm/s)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[95px] text-center">Vibration Score (VS)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[95px] text-center">Corrosion Score (CS)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[95px] text-center">Maint. Score (MS)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[100px] text-center">Health Index (HI)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[100px] text-center">Running Life (yrs)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[110px] text-center font-bold">Utilization Ratio (UR)</th>
                <th className="px-3 py-3 border-r border-sky-200 min-w-[110px] text-center font-bold">Utilization Factor (UF)</th>
                {canEdit && <th className="w-16 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.lifeCycleRows || []).map((row, idx) => {
                // Determine precalculated/auto value for Age
                const autoAge = (row.installYear && row.currentYear && !isNaN(Number(row.currentYear)) && !isNaN(Number(row.installYear))) 
                  ? String(Number(row.currentYear) - Number(row.installYear)) 
                  : '';
                
                // Determine precalculated/auto value for Health Index (HI) = (0.4×Vibration Score) + (0.3×Corrosion Score) + (0.3×Maint. Score)
                let autoHI = '';
                if (row.vibrationScore !== '' || row.corrosionScore !== '' || row.maintScore !== '') {
                  const vs = Number(row.vibrationScore) || 0;
                  const cs = Number(row.corrosionScore) || 0;
                  const ms = Number(row.maintScore) || 0;
                  autoHI = ((0.4 * vs) + (0.3 * cs) + (0.3 * ms)).toFixed(1);
                }

                // Determine precalculated/auto value for Utilization Ratio (UR) = Running Life (yrs) / Age (yrs)
                let autoUR = '';
                const ageNum = Number(autoAge);
                if (row.runningLifeYrs && ageNum > 0 && !isNaN(Number(row.runningLifeYrs))) {
                  autoUR = (Number(row.runningLifeYrs) / ageNum).toFixed(2);
                }

                // Determine precalculated/auto value for Utilization Factor (UF)
                let autoUF = '1.0';
                if (autoUR !== '') {
                  const urVal = Number(autoUR);
                  if (!isNaN(urVal)) {
                    if (urVal > 0.8) {
                      autoUF = '0.9';
                    } else if (urVal >= 0.6) {
                      autoUF = '0.95';
                    } else if (urVal >= 0.4) {
                      autoUF = '1.0';
                    } else {
                      autoUF = '1.05';
                    }
                  }
                }

                return (
                  <tr key={row.id} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2 border-r border-slate-100 text-center font-bold text-slate-500">{idx + 1}</td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.equipmentTag} 
                        onChange={e => updateLifeCycleRow(row.id, 'equipmentTag', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none font-bold text-slate-800" 
                        placeholder="e.g. PAHU-01" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.makeModel} 
                        onChange={e => updateLifeCycleRow(row.id, 'makeModel', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none" 
                        placeholder="Make & Model No" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.serialNo} 
                        onChange={e => updateLifeCycleRow(row.id, 'serialNo', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-slate-600" 
                        placeholder="Serial No" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.location} 
                        onChange={e => updateLifeCycleRow(row.id, 'location', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-slate-600" 
                        placeholder="Location/Floor" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.installYear} 
                        onChange={e => {
                          const val = e.target.value;
                          const curYear = row.currentYear || String(new Date().getFullYear());
                          const nextAge = (val && curYear && !isNaN(Number(curYear)) && !isNaN(Number(val))) 
                            ? String(Number(curYear) - Number(val)) 
                            : row.ageYrs;
                          
                          const list = (data.lifeCycleRows || []).map(r => r.id === row.id ? { ...r, installYear: val, ageYrs: nextAge } : r);
                          updateField('lifeCycleRows', list);
                        }} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center" 
                        placeholder="YYYY" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.currentYear} 
                        onChange={e => {
                          const val = e.target.value;
                          const instYear = row.installYear;
                          const nextAge = (val && instYear && !isNaN(Number(val)) && !isNaN(Number(instYear))) 
                            ? String(Number(val) - Number(instYear)) 
                            : row.ageYrs;
                          
                          const list = (data.lifeCycleRows || []).map(r => r.id === row.id ? { ...r, currentYear: val, ageYrs: nextAge } : r);
                          updateField('lifeCycleRows', list);
                        }} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center" 
                        placeholder="YYYY" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        value={autoAge} 
                        disabled={true} 
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none font-bold text-center text-slate-500 cursor-not-allowed" 
                        placeholder="Age" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100 bg-amber-50/30">
                      <input 
                        value={row.surfaceTemp || ''} 
                        onChange={e => updateLifeCycleRow(row.id, 'surfaceTemp', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center font-bold text-amber-800" 
                        placeholder="°C" 
                      />
                    </td>
                    <td className="p-1 border-r border-slate-100 bg-amber-50/30 text-center">
                      {row.thermalImageUrl ? (
                        <a
                          href={row.thermalImageUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-800 bg-amber-100 hover:bg-amber-200 px-2 py-1 rounded border border-amber-300 transition-colors"
                        >
                          📷 Evidence
                        </a>
                      ) : (
                        <span className="text-[9px] text-slate-300 italic">No image</span>
                      )}
                    </td>
                    <td className="p-0 border-r border-slate-100 bg-purple-50/30">
                      <input 
                        value={row.vibrationVelocity || ''} 
                        onChange={e => updateLifeCycleRow(row.id, 'vibrationVelocity', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center font-bold text-purple-800" 
                        placeholder="mm/s" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.vibrationScore} 
                        onChange={e => updateLifeCycleRow(row.id, 'vibrationScore', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center text-rose-600 font-bold" 
                        placeholder="1-10" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.corrosionScore} 
                        onChange={e => updateLifeCycleRow(row.id, 'corrosionScore', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center text-amber-600 font-bold" 
                        placeholder="1-10" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.maintScore} 
                        onChange={e => updateLifeCycleRow(row.id, 'maintScore', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center text-indigo-600 font-bold" 
                        placeholder="1-10" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        value={autoHI} 
                        disabled={true} 
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-black text-xs text-slate-500 cursor-not-allowed" 
                        placeholder="HI" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        value={row.runningLifeYrs} 
                        onChange={e => updateLifeCycleRow(row.id, 'runningLifeYrs', e.target.value)} 
                        disabled={!canEdit} 
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center" 
                        placeholder="Running Life" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        value={autoUR} 
                        disabled={true} 
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-bold text-slate-500 cursor-not-allowed" 
                        placeholder="UR" 
                      />
                    </td>
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        value={autoUF} 
                        disabled={true} 
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-bold text-slate-500 cursor-not-allowed" 
                        placeholder="UF" 
                      />
                    </td>
                    {canEdit && (
                      <td className="px-2 py-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {aiEnabled && (
                            <button
                              type="button"
                              onClick={() => openLiveCapture(idx, 0)}
                              className="w-6 h-6 flex items-center justify-center text-purple-700 bg-purple-50 hover:bg-purple-100 rounded font-bold text-[9px] transition-colors"
                              title="Live Capture raw condition-monitoring readings"
                            >
                              <Camera className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button 
                            onClick={() => removeUnifiedRow(idx)} 
                            className="text-slate-300 hover:text-red-500 transition-colors"
                          >
                            <Trash2Icon />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
              {(data.lifeCycleRows || []).length === 0 && (
                <tr>
                  <td colSpan={canEdit ? 16 : 15} className="px-6 py-12 text-center text-slate-400 italic font-medium">
                    No asset life cycle evaluation records registered. Click "+ Add Evaluation Row" to begin.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* C3. Table-2 (RUL Calculation) */}
      <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 bg-[#EEF2F6] flex justify-between items-center">
           <div>
             <h3 className="font-extrabold text-[#1E293B] text-sm tracking-tight mb-1">4.2 Table-2 (RUL Calculation)</h3>
             <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">
               Equipment Remaining Useful Life (RUL) estimation & current life cycle state
             </p>
           </div>
           <div className="flex items-center gap-2">
             <button
               onClick={() => exportLCATable2ToExcel(data, `LCA_Table2_Evaluation_${new Date().toISOString().split('T')[0]}.xlsx`)}
               className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-emerald-700 transition-all flex items-center gap-2"
             >
               <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
             </button>
             {canEdit && (
               <>
                 <button
                   onClick={handleImportTable2Excel}
                   className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-indigo-700 transition-all flex items-center gap-2"
                 >
                   <Upload className="w-3.5 h-3.5" /> Import Excel
                 </button>
                 <button 
                  onClick={addUnifiedRow}
                  className="px-4 py-1.5 bg-sky-600 text-white rounded-lg font-black text-[10px] uppercase tracking-widest shadow-md hover:bg-sky-700 transition-all flex items-center gap-2"
                 >
                   <PlusIcon /> Add Evaluation Row
                 </button>
               </>
             )}
           </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[10px] border-collapse min-w-[1240px]">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-extrabold uppercase tracking-tighter border-b border-slate-200">
                <th className="px-3 py-3 border-r border-slate-200 text-center w-12 shrink-0">Sl. No</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[160px]">Equipment Tag / Name</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[120px] text-center">Design Life (yrs)</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[90px] text-center">Age (yrs)</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[110px] text-center">Health Index (HI)</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[130px] text-center">Utilization Factor (UF)</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[120px] text-center font-bold text-slate-900">Adjusted Life (AL)</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[110px] text-center font-bold text-slate-900">RUL (yrs)</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[110px] text-center font-bold text-slate-900">RUL (%)</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[145px] text-center">Life cycle Status</th>
                <th className="px-3 py-3 border-r border-slate-200 min-w-[180px]">Remarks</th>
                {canEdit && <th className="w-10"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.rulRows || []).map((row, idx) => {
                const designLife = row.designLifeYrs || '';
                const age = row.ageYrs || '';
                const ageNum = Number(age) || 0;

                const hi = row.healthIndex || '';
                const hiNum = Number(hi) || 0;

                // Utilization factor
                const uf = row.utilizationFactor || '';
                const ufNum = Number(uf) || 1;

                // Calculate Adjusted Life: Design Life (yrs) * Health Index (HI) * Utilization Factor (UF)
                const dlNum = Number(designLife) || 0;
                const computedAL = (dlNum > 0 && hiNum > 0) 
                  ? ((dlNum * hiNum) * ufNum).toFixed(1) 
                  : '';
                const al = computedAL;
                const alNum = Number(al) || 0;

                // Calculate RUL (yrs): AL - Age
                const computedRulYrs = (alNum > 0) 
                  ? (alNum - ageNum).toFixed(1) 
                  : '';
                const rulYrs = computedRulYrs;
                const rulYrsNum = Number(rulYrs) || 0;

                // Calculate RUL (%): (RUL (yrs) / Adjusted Life (AL)) * 100
                const computedRulPct = (alNum > 0) 
                  ? ((rulYrsNum / alNum) * 100).toFixed(1) 
                  : '';
                const rulPct = computedRulPct;
                const rulPctNum = Number(rulPct) || 0;

                // Determine Life Cycle Status automatically
                let autoStatus = '';
                if (alNum > 0) {
                  if (rulPctNum > 50) {
                    autoStatus = 'Fit for Service';
                  } else if (rulPctNum >= 25) {
                    autoStatus = 'Degrading Stage';
                  } else if (rulPctNum >= 10) {
                    autoStatus = 'Approaching Replacement';
                  } else if (rulPctNum > 0) {
                    autoStatus = 'Reaching End-of-Life';
                  } else {
                    autoStatus = 'End-of-Life';
                  }
                }
                const statusStr = row.lifeCycleStatus !== '' && row.lifeCycleStatus !== undefined ? row.lifeCycleStatus : autoStatus;

                return (
                  <tr key={`rul-${row.id}`} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2 border-r border-slate-100 text-center font-bold text-slate-500">{idx + 1}</td>
                    
                    {/* Equipment Tag */}
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        type="text"
                        value={row.equipmentTag || ''}
                        disabled={true}
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none font-bold text-slate-500 cursor-not-allowed"
                        placeholder="Auto-synced"
                      />
                    </td>

                    {/* Design Life (yrs) */}
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        type="text"
                        value={designLife}
                        onChange={e => updateRULRow(row.id, 'designLifeYrs', e.target.value)}
                        disabled={!canEdit}
                        className="w-full px-3 py-2.5 bg-transparent outline-none text-center font-medium font-mono"
                        placeholder="e.g. 15"
                      />
                    </td>

                    {/* Age (yrs) */}
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        type="text"
                        value={age}
                        disabled={true}
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-medium font-mono text-slate-500 cursor-not-allowed"
                        placeholder="Auto-synced"
                      />
                    </td>

                    {/* Health Index (HI) */}
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        type="text"
                        value={hi}
                        disabled={true}
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-bold text-slate-500 font-mono cursor-not-allowed"
                        placeholder="Auto-synced"
                      />
                    </td>

                    {/* Utilization Factor (UF) */}
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        type="text"
                        value={uf}
                        disabled={true}
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-bold text-slate-500 font-mono cursor-not-allowed"
                        placeholder="Auto-synced"
                      />
                    </td>

                    {/* Adjusted Life (AL) */}
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        type="text"
                        value={al || ''}
                        disabled={true}
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-bold text-indigo-700 font-mono cursor-not-allowed"
                        placeholder="AL"
                      />
                    </td>

                    {/* RUL (yrs) */}
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        type="text"
                        value={rulYrs || ''}
                        disabled={true}
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-bold text-slate-750 font-mono cursor-not-allowed"
                        placeholder="RUL (yrs)"
                      />
                    </td>

                    {/* RUL (%) */}
                    <td className="p-0 border-r border-slate-100 bg-slate-50/50">
                      <input 
                        type="text"
                        value={rulPct ? (rulPct.includes('%') ? rulPct : `${rulPct}%`) : ''}
                        disabled={true}
                        className="w-full px-3 py-2.5 bg-transparent border-0 outline-none text-center font-bold text-slate-700 font-mono cursor-not-allowed"
                        placeholder="RUL (%)"
                      />
                    </td>

                    {/* Life Cycle Status */}
                    <td className="p-1 border-r border-[#E2E8F0] text-center">
                      <div
                        className={`w-full py-2 px-2 rounded-xl border font-bold text-[10px] uppercase tracking-wider text-center select-none cursor-not-allowed transition-all
                          ${statusStr === 'Fit for Service' ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 
                            statusStr === 'Degrading Stage' ? 'bg-teal-50 border-teal-200 text-teal-700' : 
                            statusStr === 'Approaching Replacement' ? 'bg-orange-50 border-orange-200 text-orange-700' : 
                            statusStr === 'Reaching End-of-Life' ? 'bg-amber-50 border-amber-200 text-amber-700' : 
                            statusStr === 'End-of-Life' ? 'bg-rose-50 border-rose-200 text-[#B71C1C]' : 
                            'bg-slate-50 border-slate-200 text-slate-600'}`}
                      >
                        {statusStr || 'Pending'}
                      </div>
                    </td>

                    {/* Remarks (RUL) */}
                    <td className="p-0 border-r border-slate-100">
                      <input 
                        type="text"
                        value={row.remarksRul || ''}
                        onChange={e => updateRULRow(row.id, 'remarksRul', e.target.value)}
                        disabled={!canEdit}
                        className="w-full px-3 py-2.5 bg-transparent outline-none"
                        placeholder="Add remarks..."
                      />
                    </td>

                    {/* Delete RUL Row */}
                    {canEdit && (
                      <td className="px-2 py-2 text-center">
                        <button 
                          onClick={() => removeUnifiedRow(idx)} 
                          className="text-slate-300 hover:text-red-500 transition-colors"
                        >
                          <Trash2Icon />
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
              {(data.rulRows || []).length === 0 && (
                <tr>
                  <td colSpan={canEdit ? 12 : 11} className="px-6 py-12 text-center text-slate-400 italic font-medium">
                    No records found. Click "+ Add Evaluation Row" to add independent RUL rows.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* E. Observations & Recommendations */}
      <section className="bg-white rounded-[2rem] border border-slate-200 shadow-sm p-8 space-y-4">
         <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <ClipboardListIcon />
            <h3 className="font-black text-slate-800 text-xs uppercase tracking-widest">OBSERVATIONS & RECOMMENDATIONS</h3>
         </div>
         
         <ObservationsRecommendationsTable rulRows={data.rulRows || []} 
           data={data.observationsAndRecommendations || []}
           onChange={(val) => updateField('observationsAndRecommendations', val)}
           readOnly={readOnly}
           isLCA={true}
        />
      </section>

      {/* 4.1 LCA LIVE CAPTURE WIZARD MODAL */}
      {liveCapture?.active && (() => {
        const targetRow = (data.lifeCycleRows || [])[liveCapture.rowIndex];
        const steps = getCaptureSteps();
        const currentStep = steps[liveCapture.stepIndex];

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-100">
              {/* Header */}
              <div className="bg-gradient-to-r from-purple-700 to-indigo-800 text-white p-4 flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-2">
                    <Camera className="w-5 h-5 text-purple-200" />
                    <h3 className="font-bold text-base uppercase tracking-wider">LCA Raw Reading Live Capture</h3>
                  </div>
                  <p className="text-xs text-purple-200 mt-0.5">
                    Equipment {liveCapture.rowIndex + 1} of {(data.lifeCycleRows || []).length}: <span className="font-semibold text-white">{targetRow?.equipmentTag || `Asset #${liveCapture.rowIndex + 1}`}</span>
                  </p>
                </div>
                <button
                  onClick={() => { stopCamera(); setLiveCapture(null); }}
                  className="text-purple-200 hover:text-white text-xl font-bold p-1 rounded-lg hover:bg-white/10 transition-colors"
                >
                  ✕
                </button>
              </div>

              {/* Step Bar */}
              <div className="bg-purple-50/80 px-4 py-2.5 border-b border-purple-100 flex items-center justify-between gap-1 text-[11px] font-semibold">
                {steps.map((st, idx) => {
                  const isActive = idx === liveCapture.stepIndex;
                  const isDone = idx < liveCapture.stepIndex;
                  return (
                    <div
                      key={st.key}
                      className={`flex-1 text-center py-1 px-1.5 rounded-md transition-all ${
                        isActive
                          ? 'bg-purple-600 text-white font-bold shadow-sm'
                          : isDone
                          ? 'bg-purple-200/60 text-purple-900'
                          : 'text-slate-400 bg-slate-100'
                      }`}
                    >
                      {st.label}
                    </div>
                  );
                })}
              </div>

              {/* Modal Body */}
              <div className="p-5 space-y-4">
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-xs text-slate-700">
                  <div className="font-bold text-slate-900 uppercase text-[11px] text-purple-900 flex items-center gap-1.5">
                    <span>Instrument:</span>
                    <span className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-[10px]">{currentStep.instrument}</span>
                  </div>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-600">{currentStep.guidance}</p>
                </div>

                <canvas ref={canvasRef} className="hidden" />

                {/* Camera Phase */}
                {liveCapture.phase === 'camera' && (
                  <div className="space-y-4">
                    <div className="relative aspect-video bg-black rounded-xl overflow-hidden shadow-inner flex items-center justify-center border border-slate-800">
                      <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
                      <div className="absolute inset-0 border-2 border-dashed border-purple-400/60 rounded-xl pointer-events-none m-6 flex items-center justify-center">
                        <span className="bg-black/50 text-white text-[10px] px-2 py-1 rounded backdrop-blur">Center display in frame</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={capturePhoto}
                        className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold text-sm tracking-wide shadow-lg flex items-center justify-center gap-2 transition-all"
                      >
                        <Camera className="w-4 h-4" /> Capture Photo
                      </button>
                      <button
                        type="button"
                        onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'review', value: '', error: '' } : null)}
                        className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs transition-colors"
                      >
                        Enter Manually
                      </button>
                    </div>
                  </div>
                )}

                {/* Reading Phase */}
                {liveCapture.phase === 'reading' && (
                  <div className="py-12 text-center space-y-3">
                    <div className="w-10 h-10 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="font-bold text-slate-800 text-sm">Analyzing instrument display with Gemini AI...</p>
                    <p className="text-xs text-slate-500">Extracting {currentStep.label} reading</p>
                  </div>
                )}

                {/* Uploading Phase */}
                {liveCapture.phase === 'uploading' && (
                  <div className="py-12 text-center space-y-3">
                    <div className="w-10 h-10 border-4 border-amber-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="font-bold text-slate-800 text-sm">Uploading evidence photo to Firebase Storage...</p>
                    <p className="text-xs text-slate-500">Securing thermal record URL</p>
                  </div>
                )}

                {/* Review Phase */}
                {liveCapture.phase === 'review' && (
                  <div className="space-y-4">
                    {liveCapture.error && (
                      <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs font-medium">
                        ⚠️ {liveCapture.error}
                      </div>
                    )}

                    {currentStep.keepPhotoAsEvidence && liveCapture.capturedImageBase64 && (
                      <div className="relative aspect-video bg-slate-100 rounded-xl overflow-hidden border border-slate-200">
                        <img src={liveCapture.capturedImageBase64} alt="Thermal Evidence" className="w-full h-full object-cover" />
                        <span className="absolute bottom-2 right-2 bg-black/60 text-white text-[9px] px-2 py-0.5 rounded backdrop-blur font-semibold">Evidence Captured</span>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Captured Value for {currentStep.label} {currentStep.unit ? `(${currentStep.unit})` : ''}
                      </label>
                      <input
                        type="text"
                        value={liveCapture.value}
                        onChange={e => setLiveCapture(prev => prev ? { ...prev, value: e.target.value } : null)}
                        placeholder={`Enter ${currentStep.label}`}
                        className="w-full text-lg font-bold p-3 bg-slate-50 border-2 border-purple-300 focus:border-purple-600 rounded-xl outline-none text-slate-900"
                        autoFocus
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setLiveCapture(prev => prev ? { ...prev, phase: 'camera', value: '', error: '' } : null)}
                        className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs transition-colors"
                      >
                        Retake Photo
                      </button>
                      <button
                        type="button"
                        onClick={handleConfirmReading}
                        className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs tracking-wider uppercase shadow-md transition-all"
                      >
                        Confirm &amp; Next →
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })()}

    </div>
  );
};

export const INITIAL_LIFE_CYCLE_DATA: LifeCycleReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  status: 'PENDING',
  equipmentList: [],
  lifeCycleRows: [],
  rulRows: [],
  observationsAndRecommendations: []
};
