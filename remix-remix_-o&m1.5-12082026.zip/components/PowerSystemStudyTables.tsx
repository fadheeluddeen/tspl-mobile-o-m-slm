
import React, { useCallback, memo } from 'react';
import { 
  PowerSystemReading, 
  PowerTfColumn, 
  PowerBranchLoadRow, 
  PowerTfLoadRow, 
  PowerShortCircuitRow, 
  RelayCoordRow,
  ReleaseSettingsRow,
  PowerArcFlashRow,
  SPOFEquipmentRow
} from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
);

const GridIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
);

const FlameIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>
);

const DuplicateIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
);

const TF_PARAMS = [
  "SPECIFICATION REFERENCE", "MAKE", "RATED IN KVA", "HV VOLTAGE IN VOLTS",
  "LV VOLTAGE IN VOLTS", "HV CURRENT IN AMPS", "LV CURRENT IN AMPS",
  "NO. OF PHASES", "FREQUENCY IN HZ", "TYPES OF COOLING",
  "IMPEDANCE VOLTAGE %", "CONNECTION SYMBOLS"
];

interface PowerSystemStudyTablesProps {
  data: PowerSystemReading;
  onChange: (data: PowerSystemReading) => void;
  readOnly?: boolean;
}

interface RelayTableProps {
  title: string;
  field: 'relayPhase' | 'relayEarth';
  theme: string;
  data: PowerSystemReading;
  readOnly: boolean;
  addRow: (field: keyof PowerSystemReading, template: any) => void;
  insertRow: (field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => void;
  updateRow: (field: keyof PowerSystemReading, id: string, row: any) => void;
  deleteListItem: (field: keyof PowerSystemReading, id: string) => void;
  duplicateRow: (field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => void;
}

interface ReleaseSettingsTableProps {
  title: string;
  field: 'releaseSettings';
  theme: string;
  data: PowerSystemReading;
  readOnly: boolean;
  addRow: (field: keyof PowerSystemReading, template: any) => void;
  insertRow: (field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => void;
  updateRow: (field: keyof PowerSystemReading, id: string, row: any) => void;
  deleteListItem: (field: keyof PowerSystemReading, id: string) => void;
  duplicateRow: (field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => void;
}

interface ArcFlashTableProps {
  title: string;
  field: 'arcFlashAnalysis';
  theme: string;
  data: PowerSystemReading;
  readOnly: boolean;
  addRow: (field: keyof PowerSystemReading, template: any) => void;
  insertRow: (field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => void;
  updateRow: (field: keyof PowerSystemReading, id: string, row: any) => void;
  deleteListItem: (field: keyof PowerSystemReading, id: string) => void;
  duplicateRow: (field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => void;
}

const RelayTable = memo(({ title, field, theme, data, readOnly, addRow, insertRow, updateRow, deleteListItem, duplicateRow }: RelayTableProps) => {
  const list = (data[field] as RelayCoordRow[]) || [];
  
  const addHeader = () => addRow(field, { feeder: 'NEW SECTION', isHeader: true, existing: {}, suggested: {}, remarks: '' });
  const addFeeder = () => addRow(field, { 
    relayNo: '',
    feeder: '', 
    ratedCurrent: '',
    relayType: '',
    ctRatio: '',
    isHeader: false, 
    existing: { curve: 'SI', plug: '', tms: '', opTimeCloseInFault: '', hiI: '', hiT: '' }, 
    suggested: { curve: 'NI', plug: '', tms: '', hiI: '', hiT: '' }, 
    remarks: '' 
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-12">
      <div className={`${theme} px-6 py-4 text-white flex justify-between items-center`}>
        <h3 className="font-black uppercase tracking-tight text-sm">{title}</h3>
        <div className="flex gap-2">
          {!readOnly && (
            <>
              <button onClick={addHeader} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[9px] font-black uppercase tracking-widest">+ Section Header</button>
              <button onClick={addFeeder} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[9px] font-black uppercase tracking-widest">+ Add Feeder</button>
            </>
          )}
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[9px] text-center border-collapse">
          <thead>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500">
              <th rowSpan={3} className="px-2 py-2 w-12">Relay No</th>
              <th rowSpan={3} className="px-2 py-2 w-48">Feeder Name</th>
              <th rowSpan={3} className="px-2 py-2 w-24">Rated Current (A)</th>
              <th rowSpan={3} className="px-2 py-2 w-32">Relay Type/ Make</th>
              <th rowSpan={3} className="px-2 py-2 w-20">CT Ratio</th>
              <th colSpan={6} className="px-2 py-1 border-b border-teal-500">Existing Settings</th>
              <th colSpan={5} className="px-2 py-1 border-b border-teal-500">Suggested Settings</th>
              <th rowSpan={3} className="px-2 py-2 w-24">Remarks</th>
              {!readOnly && <th rowSpan={3} className="w-16"></th>}
            </tr>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500">
              <th colSpan={4} className="py-1 border-b border-teal-500">IDMT</th>
              <th colSpan={2} className="py-1 border-b border-teal-500">DT</th>
              <th colSpan={3} className="py-1 border-b border-teal-500">IDMT</th>
              <th colSpan={2} className="py-1 border-b border-teal-500">DT</th>
            </tr>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500 font-bold">
              <th className="py-1">Curve</th>
              <th className="py-1">Plug Setting {field === 'relayEarth' ? 'Ie>' : '(I>)'}</th>
              <th className="py-1">TMS {field === 'relayEarth' ? 'Te>' : 'T>'}</th>
              <th className="py-1">Operating time (s) for closein fault</th>
              <th className="py-1">Hi Set {field === 'relayEarth' ? '(Ie>>)' : '(I>>)'}</th>
              <th className="py-1">Hi Set {field === 'relayEarth' ? '(te>>)' : '(t>>)'}</th>
              <th className="py-1">Curve</th>
              <th className="py-1">Plug Setting {field === 'relayEarth' ? '(Ie>)' : '(I>)'}</th>
              <th className="py-1">TMS {field === 'relayEarth' ? 'Te>' : 'T>'}</th>
              <th className="py-1">Hi Set {field === 'relayEarth' ? '(Ie>>)' : '(I>>)'}</th>
              <th className="py-1">Hi Set {field === 'relayEarth' ? '(te>>) sec' : '(t>>)'}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
{(list).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

            {list.map((row, idx) => (
              row.isHeader ? (
                <tr key={row.id} className="bg-teal-400">
                  <td colSpan={17} className="px-4 py-1 text-center font-black text-slate-900 uppercase tracking-widest border-y border-teal-500">
                    <input 
                      value={row.feeder} 
                      onChange={e => updateRow(field, row.id, { ...row, feeder: e.target.value.toUpperCase() })}
                      className="bg-transparent border-none outline-none w-full text-center"
                      disabled={readOnly}
                    />
                  </td>
                  {!readOnly && (
                    <td className="px-2 bg-teal-400 min-w-[145px]">
                      <div className="flex items-center justify-center gap-1.5 py-1">
                        <button 
                          onClick={() => insertRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Insert Section Above"
                        >
                          +↑
                        </button>
                        <button 
                          onClick={() => insertRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Insert Section Below"
                        >
                          +↓
                        </button>
                        <button 
                          onClick={() => duplicateRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Section Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          onClick={() => duplicateRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Section Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          onClick={() => deleteListItem(field, row.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-900 bg-white/20 hover:bg-white/40 rounded font-bold text-sm transition-colors"
                          title="Delete Section"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ) : (
                <tr key={row.id} className="hover:bg-slate-50 transition-colors divide-x divide-slate-100">
                  <td className="p-0"><input value={row.relayNo} onChange={e => updateRow(field, row.id, { ...row, relayNo: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="R1" disabled={readOnly} /></td>
                  <td className="p-0 text-left">
                     <input value={row.feeder} onChange={e => updateRow(field, row.id, { ...row, feeder: e.target.value })} className="w-full px-4 py-2 bg-transparent outline-none font-medium" placeholder="Feeder name..." disabled={readOnly} />
                  </td>
                  <td className="p-0"><input value={row.ratedCurrent || ''} onChange={e => updateRow(field, row.id, { ...row, ratedCurrent: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="100" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.relayType} onChange={e => updateRow(field, row.id, { ...row, relayType: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="e.g. Micom P122" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.ctRatio} onChange={e => updateRow(field, row.id, { ...row, ctRatio: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="400/1" disabled={readOnly} /></td>
                  
                  {/* Existing */}
                  <td className="p-0"><input value={row.existing.curve} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, curve: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="SI" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.plug} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, plug: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.5" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.tms} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, tms: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.1" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.opTimeCloseInFault || ''} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, opTimeCloseInFault: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.2" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.hiI} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, hiI: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="5.0" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.hiT} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, hiT: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.05" disabled={readOnly} /></td>
                  
                  {/* Suggested */}
                  <td className="p-0"><input value={row.suggested.curve} onChange={e => updateRow(field, row.id, { ...row, suggested: { ...row.suggested, curve: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="NI" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.suggested.plug} onChange={e => updateRow(field, row.id, { ...row, suggested: { ...row.suggested, plug: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="0.6" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.suggested.tms} onChange={e => updateRow(field, row.id, { ...row, suggested: { ...row.suggested, tms: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="0.15" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.suggested.hiI} onChange={e => updateRow(field, row.id, { ...row, suggested: { ...row.suggested, hiI: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="6.0" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.suggested.hiT} onChange={e => updateRow(field, row.id, { ...row, suggested: { ...row.suggested, hiT: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="0.1" disabled={readOnly} /></td>
                  
                  <td className="p-0"><input value={row.remarks} onChange={e => updateRow(field, row.id, { ...row, remarks: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="OK" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="px-2 min-w-[145px]">
                      <div className="flex items-center justify-center gap-1.5 py-1">
                        <button 
                          type="button"
                          onClick={() => insertRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Feeder Above"
                        >
                          +↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => insertRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Feeder Below"
                        >
                          +↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Feeder Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Feeder Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => deleteListItem(field, row.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                          title="Delete Feeder"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              )
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
});

const ReleaseSettingsTable = memo(({ title, field, theme, data, readOnly, addRow, insertRow, updateRow, deleteListItem, duplicateRow }: ReleaseSettingsTableProps) => {
  const list = (data[field] as ReleaseSettingsRow[]) || [];
  
  const addHeader = () => addRow(field, { feederName: 'NEW SECTION', isHeader: true, existing: {}, proposed: {}, remarks: '' });
  const addFeeder = () => addRow(field, { 
    slNo: '',
    feederName: '', 
    ratedCurrent: '',
    breakerType: '',
    relayMakeType: '',
    isHeader: false, 
    existing: { longTimePickup: '', longTimeTime: '', shortTimePickup: '', shortTimeTime: '', instantaneous: '', earthPickup: '', earthTime: '' }, 
    proposed: { longTimePickup: '', longTimeTime: '', shortTimePickup: '', shortTimeTime: '', instantaneous: '', earthPickup: '', earthTime: '' }, 
    remarks: '' 
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-12">
      <div className={`${theme} px-6 py-4 text-white flex justify-between items-center`}>
        <h3 className="font-black uppercase tracking-tight text-sm">{title}</h3>
        <div className="flex gap-2">
          {!readOnly && (
            <>
              <button onClick={addHeader} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[9px] font-black uppercase tracking-widest">+ Section Header</button>
              <button onClick={addFeeder} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[9px] font-black uppercase tracking-widest">+ Add Feeder</button>
            </>
          )}
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[9px] text-center border-collapse">
          <thead>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500">
              <th rowSpan={3} className="px-2 py-2 w-12">Sl. No.</th>
              <th rowSpan={3} className="px-2 py-2 w-48">Feeder Name</th>
              <th rowSpan={3} className="px-2 py-2 w-20">Rated current (A)</th>
              <th rowSpan={3} className="px-2 py-2 w-32">Relay Make/ type</th>
              <th colSpan={7} className="px-2 py-1 border-b border-teal-500">Existing Settings</th>
              <th colSpan={7} className="px-2 py-1 border-b border-teal-500">Proposed Settings</th>
              <th rowSpan={3} className="px-2 py-2 w-24">Remarks</th>
              {!readOnly && <th rowSpan={3} className="w-16"></th>}
            </tr>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500">
              <th colSpan={2} className="py-1 border-b border-teal-500">Long Time</th>
              <th colSpan={2} className="py-1 border-b border-teal-500">Short Time</th>
              <th rowSpan={2} className="py-1 border-b border-teal-500">Instantaneous (xIn)</th>
              <th colSpan={2} className="py-1 border-b border-teal-500">Earth</th>
              <th colSpan={2} className="py-1 border-b border-teal-500">Long Time</th>
              <th colSpan={2} className="py-1 border-b border-teal-500">Short Time</th>
              <th rowSpan={2} className="py-1 border-b border-teal-500">Instantaneous (xIn)</th>
              <th colSpan={2} className="py-1 border-b border-teal-500">Earth</th>
            </tr>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500 font-bold">
              <th className="py-1">Pickup (xIn)</th>
              <th className="py-1">Time (s) at 3xIr</th>
              <th className="py-1">Pickup (xIn)</th>
              <th className="py-1">Time (s)</th>
              <th className="py-1">Pickup (xIn)</th>
              <th className="py-1">Time (s)</th>
              <th className="py-1">Pickup (xIn)</th>
              <th className="py-1">Time (s) at 6xIr</th>
              <th className="py-1">Pickup (xIn)</th>
              <th className="py-1">Time (s)</th>
              <th className="py-1">Pickup (xIn)</th>
              <th className="py-1">Time (s)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
{(list).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

            {list.map((row, idx) => (
              row.isHeader ? (
                <tr key={row.id} className="bg-teal-400">
                  <td colSpan={19} className="px-4 py-1 text-center font-black text-slate-900 uppercase tracking-widest border-y border-teal-500">
                    <input 
                      value={row.feederName} 
                      onChange={e => updateRow(field, row.id, { ...row, feederName: e.target.value.toUpperCase() })}
                      className="bg-transparent border-none outline-none w-full text-center"
                      disabled={readOnly}
                    />
                  </td>
                  {!readOnly && (
                    <td className="px-2 bg-teal-400 min-w-[145px]">
                      <div className="flex items-center justify-center gap-1.5 py-1">
                        <button 
                          onClick={() => insertRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Insert Section Above"
                        >
                          +↑
                        </button>
                        <button 
                          onClick={() => insertRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Insert Section Below"
                        >
                          +↓
                        </button>
                        <button 
                          onClick={() => duplicateRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Section Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          onClick={() => duplicateRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Section Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          onClick={() => deleteListItem(field, row.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-900 bg-white/20 hover:bg-white/40 rounded font-bold text-sm transition-colors"
                          title="Delete Section"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ) : (
                <tr key={row.id} className="hover:bg-slate-50 transition-colors divide-x divide-slate-100">
                  <td className="p-0"><input value={row.slNo} onChange={e => updateRow(field, row.id, { ...row, slNo: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="1" disabled={readOnly} /></td>
                  <td className="p-0 text-left">
                     <input value={row.feederName} onChange={e => updateRow(field, row.id, { ...row, feederName: e.target.value })} className="w-full px-4 py-2 bg-transparent outline-none font-medium" placeholder="Feeder name..." disabled={readOnly} />
                  </td>
                  <td className="p-0"><input value={row.ratedCurrent} onChange={e => updateRow(field, row.id, { ...row, ratedCurrent: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="1600" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.relayMakeType} onChange={e => updateRow(field, row.id, { ...row, relayMakeType: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="e.g. ABB PR121" disabled={readOnly} /></td>
                  
                  {/* Existing */}
                  <td className="p-0"><input value={row.existing.longTimePickup} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, longTimePickup: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.8" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.longTimeTime} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, longTimeTime: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="12" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.shortTimePickup} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, shortTimePickup: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="3" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.shortTimeTime} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, shortTimeTime: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.2" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.instantaneous} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, instantaneous: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="10" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.earthPickup} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, earthPickup: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.2" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.existing.earthTime} onChange={e => updateRow(field, row.id, { ...row, existing: { ...row.existing, earthTime: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.1" disabled={readOnly} /></td>
                  
                  {/* Proposed */}
                  <td className="p-0"><input value={row.proposed.longTimePickup} onChange={e => updateRow(field, row.id, { ...row, proposed: { ...row.proposed, longTimePickup: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="0.9" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.proposed.longTimeTime} onChange={e => updateRow(field, row.id, { ...row, proposed: { ...row.proposed, longTimeTime: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="15" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.proposed.shortTimePickup} onChange={e => updateRow(field, row.id, { ...row, proposed: { ...row.proposed, shortTimePickup: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="4" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.proposed.shortTimeTime} onChange={e => updateRow(field, row.id, { ...row, proposed: { ...row.proposed, shortTimeTime: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="0.3" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.proposed.instantaneous} onChange={e => updateRow(field, row.id, { ...row, proposed: { ...row.proposed, instantaneous: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="12" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.proposed.earthPickup} onChange={e => updateRow(field, row.id, { ...row, proposed: { ...row.proposed, earthPickup: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="0.3" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.proposed.earthTime} onChange={e => updateRow(field, row.id, { ...row, proposed: { ...row.proposed, earthTime: e.target.value } })} className="w-full text-center py-2 bg-transparent outline-none font-bold text-blue-700" placeholder="0.2" disabled={readOnly} /></td>
                  
                  <td className="p-0"><input value={row.remarks} onChange={e => updateRow(field, row.id, { ...row, remarks: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="Adjusted" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="px-2 min-w-[145px]">
                      <div className="flex items-center justify-center gap-1.5 py-1">
                        <button 
                          type="button"
                          onClick={() => insertRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Feeder Above"
                        >
                          +↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => insertRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Feeder Below"
                        >
                          +↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Feeder Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Feeder Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => deleteListItem(field, row.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                          title="Delete Feeder"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              )
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
});

const ArcFlashTable = memo(({ title, field, theme, data, readOnly, addRow, insertRow, updateRow, deleteListItem, duplicateRow }: ArcFlashTableProps) => {
  const list = (data[field] as PowerArcFlashRow[]) || [];
  
  const addHeader = () => addRow(field, { locationName: 'NEW SECTION', isHeader: true });
  const addRowItem = () => addRow(field, { 
    locationName: '', 
    nominalKv: '', 
    boltedKa: '', 
    arcingKa: '', 
    fctSecs: '', 
    incidentEnergy: '', 
    afbM: '', 
    workingDistanceCm: '', 
    energyLevel: '', 
    remarks: '',
    isHeader: false 
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-12">
      <div className={`${theme} px-6 py-4 text-white flex justify-between items-center`}>
        <h3 className="font-black uppercase tracking-tight text-sm">{title}</h3>
        <div className="flex gap-2">
          {!readOnly && (
            <>
              <button onClick={addHeader} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[9px] font-black uppercase tracking-widest">+ Section Header</button>
              <button onClick={addRowItem} className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-[9px] font-black uppercase tracking-widest">+ Add Row</button>
            </>
          )}
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[9px] text-center border-collapse">
          <thead>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500">
              <th colSpan={2} className="px-2 py-1 border-b border-teal-500">Location</th>
              <th colSpan={3} className="px-2 py-1 border-b border-teal-500">Total Fault current</th>
              <th colSpan={4} className="px-2 py-1 border-b border-teal-500">Arc Flash Analysis Results</th>
              <th rowSpan={2} className="px-2 py-2 w-24">Remarks</th>
              {!readOnly && <th rowSpan={2} className="w-16"></th>}
            </tr>
            <tr className="bg-teal-400 text-slate-900 divide-x divide-teal-500 font-bold">
              <th className="py-1 w-48">Name</th>
              <th className="py-1 w-20">Nominal kV</th>
              <th className="py-1 w-20">Bolted kA</th>
              <th className="py-1 w-20">Arcing kA</th>
              <th className="py-1 w-20">FCT (Secs)</th>
              <th className="py-1 w-24">Incident Energy (Cal/cm²)</th>
              <th className="py-1 w-20">AFB (m)</th>
              <th className="py-1 w-24">Working Distance (cm)</th>
              <th className="py-1 w-24">Energy Level</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
{(list).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

            {list.map((row) => (
              row.isHeader ? (
                <tr key={row.id} className="bg-teal-400">
                  <td colSpan={10} className="px-4 py-1 text-center font-black text-slate-900 uppercase tracking-widest border-y border-teal-500">
                    <input 
                      value={row.locationName} 
                      onChange={e => updateRow(field, row.id, { ...row, locationName: e.target.value.toUpperCase() })}
                      className="bg-transparent border-none outline-none w-full text-center"
                      disabled={readOnly}
                    />
                  </td>
                  {!readOnly && (
                    <td className="px-2 bg-teal-400 min-w-[145px]">
                      <div className="flex items-center justify-center gap-1.5 py-1">
                        <button 
                          onClick={() => insertRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Insert Section Above"
                        >
                          +↑
                        </button>
                        <button 
                          onClick={() => insertRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Insert Section Below"
                        >
                          +↓
                        </button>
                        <button 
                          onClick={() => duplicateRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Section Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          onClick={() => duplicateRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-slate-900 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Section Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          onClick={() => deleteListItem(field, row.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-900 bg-white/20 hover:bg-white/40 rounded font-bold text-sm transition-colors"
                          title="Delete Section"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ) : (
                <tr key={row.id} className="hover:bg-slate-50 transition-colors divide-x divide-slate-100">
                  <td className="p-0 text-left">
                     <input value={row.locationName} onChange={e => updateRow(field, row.id, { ...row, locationName: e.target.value })} className="w-full px-4 py-2 bg-transparent outline-none font-medium" placeholder="Location name..." disabled={readOnly} />
                  </td>
                  <td className="p-0"><input value={row.nominalKv} onChange={e => updateRow(field, row.id, { ...row, nominalKv: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.415" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.boltedKa} onChange={e => updateRow(field, row.id, { ...row, boltedKa: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="50" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.arcingKa} onChange={e => updateRow(field, row.id, { ...row, arcingKa: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="45" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.fctSecs} onChange={e => updateRow(field, row.id, { ...row, fctSecs: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="0.1" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.incidentEnergy} onChange={e => updateRow(field, row.id, { ...row, incidentEnergy: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="8.5" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.afbM} onChange={e => updateRow(field, row.id, { ...row, afbM: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="1.2" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.workingDistanceCm} onChange={e => updateRow(field, row.id, { ...row, workingDistanceCm: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="45" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.energyLevel} onChange={e => updateRow(field, row.id, { ...row, energyLevel: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none font-bold" placeholder="Cat 2" disabled={readOnly} /></td>
                  <td className="p-0"><input value={row.remarks} onChange={e => updateRow(field, row.id, { ...row, remarks: e.target.value })} className="w-full text-center py-2 bg-transparent outline-none" placeholder="PPE Required" disabled={readOnly} /></td>
                  {!readOnly && (
                    <td className="px-2 min-w-[145px]">
                      <div className="flex items-center justify-center gap-1.5 py-1">
                        <button 
                          type="button"
                          onClick={() => insertRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Row Above"
                        >
                          +↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => insertRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                          title="Insert Row Below"
                        >
                          +↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(field, row.id, 'above')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Row Above"
                        >
                          ❐↑
                        </button>
                        <button 
                          type="button"
                          onClick={() => duplicateRow(field, row.id, 'below')} 
                          className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                          title="Duplicate Row Below"
                        >
                          ❐↓
                        </button>
                        <button 
                          type="button"
                          onClick={() => deleteListItem(field, row.id)} 
                          className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                          title="Delete Row"
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              )
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
});

export const PowerSystemStudyTables: React.FC<PowerSystemStudyTablesProps> = ({ data, onChange, readOnly = false }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();
  const updateField = useCallback((field: keyof PowerSystemReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  }, [data, onChange, readOnly]);

  // --- Transformers ---
  const addTransformer = useCallback(() => {
    const cols = [...(data.transformers || [])];
    cols.push({ id: `tf-${Date.now()}`, header: `Transformer ${cols.length + 1}`, values: new Array(12).fill('') });
    updateField('transformers', cols);
  }, [data.transformers, updateField]);

  const updateTfHeader = useCallback((id: string, v: string) => {
    const cols = data.transformers.map(c => c.id === id ? { ...c, header: v } : c);
    updateField('transformers', cols);
  }, [data.transformers, updateField]);

  const updateTfValue = useCallback((colId: string, rowIdx: number, v: string) => {
    const cols = data.transformers.map(c => {
      if (c.id === colId) {
        const vals = [...c.values];
        vals[rowIdx] = v;
        return { ...c, values: vals };
      }
      return c;
    });
    updateField('transformers', cols);
  }, [data.transformers, updateField]);

  // --- Generic Row Management ---
  const addRow = useCallback((field: keyof PowerSystemReading, template: any) => {
    const list = [...((data[field] as any[]) || [])];
    list.push({ ...template, id: `row-${Date.now()}` });
    updateField(field, list);
  }, [data, updateField]);

  const insertRow = useCallback((field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => {
    if (readOnly) return;
    const list = [...((data[field] as any[]) || [])];
    const index = list.findIndex(item => item.id === id);
    if (index !== -1) {
      const source = list[index];
      // Create empty copy
      const newRow = { ...source, id: `row-${Date.now()}-${Math.random().toString(36).substring(2, 6)}` };
      const clearValues = (obj: any): any => {
        if (obj && typeof obj === 'object') {
          if (Array.isArray(obj)) {
            return obj.map(item => clearValues(item));
          }
          const newObj: any = {};
          for (const key of Object.keys(obj)) {
            if (key === 'id') {
              newObj[key] = `val-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
            } else if (key === 'isHeader') {
              newObj[key] = obj[key];
            } else if (obj[key] === null || obj[key] === undefined) {
              newObj[key] = obj[key];
            } else if (typeof obj[key] === 'object') {
              newObj[key] = clearValues(obj[key]);
            } else if (typeof obj[key] === 'boolean') {
              newObj[key] = false;
            } else if (typeof obj[key] === 'number') {
              newObj[key] = 0;
            } else {
              newObj[key] = '';
            }
          }
          return newObj;
        }
        return '';
      };
      for (const key of Object.keys(newRow)) {
        if (key === 'id') continue;
        if (key === 'isHeader') continue;
        if (typeof newRow[key] === 'object') {
          newRow[key] = clearValues(newRow[key]);
        } else if (typeof newRow[key] === 'boolean') {
          newRow[key] = false;
        } else if (typeof newRow[key] === 'number') {
          newRow[key] = 0;
        } else {
          newRow[key] = '';
        }
      }
      const targetIdx = position === 'above' ? index : index + 1;
      list.splice(targetIdx, 0, newRow);
      updateField(field, list);
    }
  }, [data, updateField, readOnly]);

  const updateRow = useCallback((field: keyof PowerSystemReading, id: string, row: any) => {
    const list = (data[field] as any[]).map(item => item.id === id ? row : item);
    updateField(field, list);
  }, [data, updateField]);

  const deleteListItem = useCallback((field: keyof PowerSystemReading, id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this study record?",
      onConfirm: () => {
        const list = (data[field] as any[]).filter(item => item.id !== id);
        updateField(field, list);
      }
    });
  }, [data, updateField, confirmDelete, readOnly]);

  const duplicateRow = useCallback((field: keyof PowerSystemReading, id: string, position: 'above' | 'below') => {
    if (readOnly) return;
    const list = [...((data[field] as any[]) || [])];
    const index = list.findIndex(item => item.id === id);
    if (index !== -1) {
      const source = list[index];
      const deepCopy = JSON.parse(JSON.stringify(source));
      const assignNewIds = (obj: any): any => {
        if (obj && typeof obj === 'object') {
          if (Array.isArray(obj)) {
            return obj.map(item => assignNewIds(item));
          }
          if (obj.id) {
            obj.id = `subrow-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
          }
          for (const key of Object.keys(obj)) {
            if (typeof obj[key] === 'object') {
              obj[key] = assignNewIds(obj[key]);
            }
          }
        }
        return obj;
      };
      const newRow = assignNewIds(deepCopy);
      newRow.id = `row-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const targetIdx = position === 'above' ? index : index + 1;
      list.splice(targetIdx, 0, newRow);
      updateField(field, list);
    }
  }, [data, updateField, readOnly]);

  return (
    <div className="space-y-12 animate-fade-in pb-20">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* PERSONNEL & SCHEDULE */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white">
          <h3 className="text-center font-black uppercase tracking-widest text-xs">TEST PERSONNEL & SCHEDULE</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { f: 'revisionNo', p: 'Rev 0', l: 'REVISION NO.' },
            { f: 'preparedBy', p: 'John Doe', l: 'PREPARED BY' },
            { f: 'testedBy', p: 'Jane Smith', l: 'TESTED BY' },
            { f: 'approvedBy', p: 'Manager Name', l: 'APPROVED BY' },
            { f: 'testDate', p: 'YYYY-MM-DD', l: 'TEST DATE' }
          ].map(({ f, p, l }) => (
            <div key={f} className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">{l}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                placeholder={p}
                className="w-full text-sm font-bold text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-500 outline-none p-2.5 rounded-xl transition-all"
              />
            </div>
          ))}
        </div>
      </section>

      {/* TRANSFORMER NAME PLATE (Dynamic Columns) */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-4 text-white flex justify-between items-center">
          <h3 className="font-black uppercase tracking-widest text-sm">7.1 TRANSFORMER NAME PLATE DETAILS.</h3>
          {!readOnly && <button onClick={addTransformer} className="px-5 py-2 bg-white text-orange-600 rounded-xl font-black text-[10px] tracking-widest uppercase shadow-xl">+ ADD COLUMN</button>}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[10px] border-collapse">
            <thead>
              <tr className="bg-orange-50 border-b border-orange-200">
                <th className="px-4 py-3 border-r border-orange-200 w-12 text-center font-black">S.NO.</th>
                <th className="px-4 py-3 border-r border-orange-200 w-64 text-left font-black">PARAMETERS</th>
                {(data.transformers || []).map(col => (
                  <th key={col.id} className="px-4 py-3 border-r border-orange-200 relative group min-w-[200px]">
                    <div className="flex items-center justify-center gap-2">
                      <input 
                        value={col.header} 
                        onChange={e => updateTfHeader(col.id, e.target.value)} 
                        className="bg-transparent border-none outline-none font-black uppercase text-center w-full"
                        disabled={readOnly}
                      />
                      {!readOnly && (
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => {
                              const cols = [...data.transformers];
                              const idx = cols.findIndex(c => c.id === col.id);
                              if (idx !== -1) {
                                const newCol = { ...cols[idx], id: `tf-${Date.now()}`, header: `${cols[idx].header} (Copy)` };
                                cols.splice(idx + 1, 0, newCol);
                                updateField('transformers', cols);
                              }
                            }}
                            title="Duplicate"
                            className="p-1 text-orange-300 hover:text-blue-500"
                          >
                            <DuplicateIcon />
                          </button>
                          <button 
                            onClick={() => deleteListItem('transformers', col.id)}
                            title="Delete"
                            className="p-1 text-orange-300 hover:text-red-500"
                          >
                            ×
                          </button>
                        </div>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
{(TF_PARAMS).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {TF_PARAMS.map((param, rowIdx) => (
                <tr key={param} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 border-r border-slate-100 text-center font-bold text-slate-400">{rowIdx + 1}</td>
                  <td className="px-4 py-3 border-r border-slate-100 font-bold text-slate-600 uppercase tracking-tighter">{param}</td>
                  {(data.transformers || []).map(col => (
                    <td key={col.id} className="p-0 border-r border-slate-100">
                      <input 
                        value={col.values[rowIdx] || ''} 
                        onChange={e => updateTfValue(col.id, rowIdx, e.target.value)} 
                        className="w-full px-4 py-3 bg-transparent outline-none text-center font-medium"
                        placeholder={
                          rowIdx === 0 ? "IEC 60076" :
                          rowIdx === 1 ? "ABB / Siemens" :
                          rowIdx === 2 ? "2000" :
                          rowIdx === 3 ? "11000" :
                          rowIdx === 4 ? "415" :
                          rowIdx === 5 ? "105" :
                          rowIdx === 6 ? "2782" :
                          rowIdx === 7 ? "3" :
                          rowIdx === 8 ? "50" :
                          rowIdx === 9 ? "ONAN" :
                          rowIdx === 10 ? "6.0" :
                          rowIdx === 11 ? "Dyn11" : "..."
                        }
                        disabled={readOnly}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* LOAD FLOW CASE (Teal Theme) */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#2DD4BF] px-6 py-4 text-white flex justify-between items-center">
           <h3 className="font-black uppercase tracking-widest text-sm">LOAD FLOW CASE</h3>
           {!readOnly && (
             <div className="flex gap-2">
               <button onClick={() => addRow('loadFlow', { location: 'NEW SECTION', isHeader: true })} className="px-4 py-1.5 bg-white text-teal-600 rounded-lg font-black text-[10px] tracking-widest uppercase shadow-md">+ SECTION HEADER</button>
               <button onClick={() => addRow('loadFlow', { location: '', isHeader: false, busVoltKv: '', powerMva: '', realPowerMw: '', reactivePowerMvar: '', pf: '' })} className="px-4 py-1.5 bg-white text-teal-600 rounded-lg font-black text-[10px] tracking-widest uppercase shadow-md">+ ADD ROW</button>
             </div>
           )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[10px] text-center">
            <thead>
              <tr className="bg-teal-50 text-teal-900 uppercase font-black tracking-tighter divide-x divide-teal-200">
                <th className="px-4 py-3 text-left">LOCATION</th>
                <th className="px-4 py-3">BUS VOLTAGE IN KV</th>
                <th className="px-4 py-3">POWER CONSUMPTION MVA</th>
                <th className="px-4 py-3">REAL POWER CONSUMPTION MW</th>
                <th className="px-4 py-3">REACTIVE POWER CONSUMPTION MVAR</th>
                <th className="px-4 py-3">POWER FACTOR</th>
                {!readOnly && <th className="w-16"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
               {(data.loadFlow || []).map(row => (
                 row.isHeader ? (
                   <tr key={row.id} className="bg-teal-100/50">
                     <td colSpan={6} className="px-4 py-2 text-left font-black text-teal-700 uppercase tracking-widest border-y border-teal-200">
                       <input 
                         value={row.location} 
                         onChange={e => updateRow('loadFlow', row.id, { ...row, location: e.target.value.toUpperCase() })}
                         className="bg-transparent border-none outline-none w-full"
                         disabled={readOnly}
                       />
                     </td>
                     {!readOnly && (
                       <td className="px-2 border-y border-teal-200 min-w-[145px]">
                         <div className="flex items-center justify-center gap-2">
                           <button 
                             onClick={() => insertRow('loadFlow', row.id, 'above')} 
                             className="w-6 h-6 flex items-center justify-center text-teal-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Insert Section Above"
                           >
                             +↑
                           </button>
                           <button 
                             onClick={() => insertRow('loadFlow', row.id, 'below')} 
                             className="w-6 h-6 flex items-center justify-center text-teal-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Insert Section Below"
                           >
                             +↓
                           </button>
                           <button 
                             onClick={() => duplicateRow('loadFlow', row.id, 'above')} 
                             className="w-6 h-6 flex items-center justify-center text-teal-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Duplicate Section Above"
                           >
                             ❐↑
                           </button>
                           <button 
                             onClick={() => duplicateRow('loadFlow', row.id, 'below')} 
                             className="w-6 h-6 flex items-center justify-center text-teal-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Duplicate Section Below"
                           >
                             ❐↓
                           </button>
                           <button 
                             onClick={() => deleteListItem('loadFlow', row.id)} 
                             className="w-6 h-6 flex items-center justify-center text-red-700 bg-white/20 hover:bg-white/40 rounded font-bold text-sm transition-colors"
                             title="Delete Section"
                           >
                             ×
                           </button>
                         </div>
                       </td>
                     )}
                   </tr>
                 ) : (
                   <tr key={row.id} className="divide-x divide-slate-100 hover:bg-teal-50/20 transition-colors">
                      <td className="p-0 text-left"><input value={row.location} onChange={e => updateRow('loadFlow', row.id, { ...row, location: e.target.value })} className="w-full px-4 py-3 bg-transparent outline-none font-bold" placeholder="Location..." disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.busVoltKv} onChange={e => updateRow('loadFlow', row.id, { ...row, busVoltKv: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none" placeholder="11" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.powerMva} onChange={e => updateRow('loadFlow', row.id, { ...row, powerMva: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none" placeholder="1.5" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.realPowerMw} onChange={e => updateRow('loadFlow', row.id, { ...row, realPowerMw: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none" placeholder="1.2" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.reactivePowerMvar} onChange={e => updateRow('loadFlow', row.id, { ...row, reactivePowerMvar: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none" placeholder="0.9" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.pf} onChange={e => updateRow('loadFlow', row.id, { ...row, pf: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none" placeholder="0.8" disabled={readOnly} /></td>
                      {!readOnly && (
                        <td className="px-2 min-w-[145px]">
                          <div className="flex items-center justify-center gap-1.5 py-1">
                            <button 
                              type="button"
                              onClick={() => insertRow('loadFlow', row.id, 'above')} 
                              className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                              title="Insert Row Above"
                            >
                              +↑
                            </button>
                            <button 
                              type="button"
                              onClick={() => insertRow('loadFlow', row.id, 'below')} 
                              className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                              title="Insert Row Below"
                            >
                              +↓
                            </button>
                            <button 
                              type="button"
                              onClick={() => duplicateRow('loadFlow', row.id, 'above')} 
                              className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                              title="Duplicate Row Above"
                            >
                              ❐↑
                            </button>
                            <button 
                              type="button"
                              onClick={() => duplicateRow('loadFlow', row.id, 'below')} 
                              className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                              title="Duplicate Row Below"
                            >
                              ❐↓
                            </button>
                            <button 
                              type="button"
                              onClick={() => deleteListItem('loadFlow', row.id)} 
                              className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                              title="Delete Row"
                            >
                              ×
                            </button>
                          </div>
                        </td>
                      )}
                   </tr>
                 )
               ))}
               {(data.loadFlow || []).length === 0 && (
                 <tr><td colSpan={7} className="py-12 text-slate-400 italic">No load flow data. Click "+ Add Row" to begin.</td></tr>
               )}
            </tbody>
          </table>
        </div>
      </section>
      {/* SHORT CIRCUIT ANALYSIS (Blue Theme) */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#60A5FA] px-6 py-4 text-white flex justify-between items-center">
           <h3 className="font-black uppercase tracking-widest text-sm">SHORT CIRCUIT ANALYSIS</h3>
           {!readOnly && (
             <div className="flex gap-2">
               <button onClick={() => addRow('shortCircuit', { location: 'NEW SECTION', isHeader: true })} className="px-4 py-1.5 bg-white text-blue-500 rounded-lg font-black text-[10px] tracking-widest uppercase shadow-md">+ SECTION HEADER</button>
               <button onClick={() => addRow('shortCircuit', { location: '', isHeader: false, busVoltKv: '', threePhaseKa: '', lineToGroundKa: '', busRatingKa: '' })} className="px-4 py-1.5 bg-white text-blue-500 rounded-lg font-black text-[10px] tracking-widest uppercase shadow-md">+ ADD LOCATION</button>
             </div>
           )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[10px] text-center">
            <thead>
              <tr className="bg-blue-50 text-blue-900 uppercase font-black tracking-tighter divide-x divide-blue-200">
                <th className="px-4 py-3 text-left">LOCATION</th>
                <th className="px-4 py-3">BUS VOLTAGE IN KV</th>
                <th className="px-4 py-3">3 PHASE FAULT CURRENT IN KA</th>
                <th className="px-4 py-3">LINE TO GROUND FAULT CURRENT IN KA</th>
                <th className="px-4 py-3">BUS RATINGS IN KA</th>
                {!readOnly && <th className="w-16"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
               {(data.shortCircuit || []).map(row => (
                 row.isHeader ? (
                   <tr key={row.id} className="bg-blue-100/50">
                     <td colSpan={5} className="px-4 py-2 text-left font-black text-blue-700 uppercase tracking-widest border-y border-blue-200">
                       <input 
                         value={row.location} 
                         onChange={e => updateRow('shortCircuit', row.id, { ...row, location: e.target.value.toUpperCase() })}
                         className="bg-transparent border-none outline-none w-full"
                         disabled={readOnly}
                       />
                     </td>
                     {!readOnly && (
                       <td className="px-2 border-y border-blue-200 min-w-[145px]">
                         <div className="flex items-center justify-center gap-1.5 py-1">
                           <button 
                             onClick={() => insertRow('shortCircuit', row.id, 'above')} 
                             className="w-6 h-6 flex items-center justify-center text-blue-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Insert Section Above"
                           >
                             +↑
                           </button>
                           <button 
                             onClick={() => insertRow('shortCircuit', row.id, 'below')} 
                             className="w-6 h-6 flex items-center justify-center text-blue-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Insert Section Below"
                           >
                             +↓
                           </button>
                           <button 
                             onClick={() => duplicateRow('shortCircuit', row.id, 'above')} 
                             className="w-6 h-6 flex items-center justify-center text-blue-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Duplicate Section Above"
                           >
                             ❐↑
                           </button>
                           <button 
                             onClick={() => duplicateRow('shortCircuit', row.id, 'below')} 
                             className="w-6 h-6 flex items-center justify-center text-blue-700 bg-white/20 hover:bg-white/40 rounded font-bold text-[9px] transition-colors"
                             title="Duplicate Section Below"
                           >
                             ❐↓
                           </button>
                           <button 
                             onClick={() => deleteListItem('shortCircuit', row.id)} 
                             className="w-6 h-6 flex items-center justify-center text-red-700 bg-white/20 hover:bg-white/40 rounded font-bold text-sm transition-colors"
                             title="Delete Section"
                           >
                             ×
                           </button>
                         </div>
                       </td>
                     )}
                   </tr>
                 ) : (
                   <tr key={row.id} className="divide-x divide-slate-100 hover:bg-blue-50/20 transition-colors">
                      <td className="p-0 text-left"><input value={row.location} onChange={e => updateRow('shortCircuit', row.id, { ...row, location: e.target.value })} className="w-full px-4 py-3 bg-transparent outline-none font-bold" placeholder="e.g. 11kV Switchboard" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.busVoltKv} onChange={e => updateRow('shortCircuit', row.id, { ...row, busVoltKv: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none" placeholder="0.415" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.threePhaseKa} onChange={e => updateRow('shortCircuit', row.id, { ...row, threePhaseKa: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none font-black text-red-600" placeholder="50" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.lineToGroundKa} onChange={e => updateRow('shortCircuit', row.id, { ...row, lineToGroundKa: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none font-black text-red-600" placeholder="45" disabled={readOnly} /></td>
                      <td className="p-0"><input value={row.busRatingKa} onChange={e => updateRow('shortCircuit', row.id, { ...row, busRatingKa: e.target.value })} className="w-full py-3 text-center bg-transparent outline-none" placeholder="65" disabled={readOnly} /></td>
                      {!readOnly && (
                        <td className="px-2 min-w-[145px]">
                          <div className="flex items-center justify-center gap-1.5 py-1">
                            <button 
                              type="button"
                              onClick={() => insertRow('shortCircuit', row.id, 'above')} 
                              className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                              title="Insert Row Above"
                            >
                              +↑
                            </button>
                            <button 
                              type="button"
                              onClick={() => insertRow('shortCircuit', row.id, 'below')} 
                              className="w-6 h-6 flex items-center justify-center text-teal-700 bg-teal-50 hover:bg-teal-100 rounded font-bold text-[9px] transition-colors"
                              title="Insert Row Below"
                            >
                              +↓
                            </button>
                            <button 
                              type="button"
                              onClick={() => duplicateRow('shortCircuit', row.id, 'above')} 
                              className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                              title="Duplicate Row Above"
                            >
                              ❐↑
                            </button>
                            <button 
                              type="button"
                              onClick={() => duplicateRow('shortCircuit', row.id, 'below')} 
                              className="w-6 h-6 flex items-center justify-center text-amber-700 bg-amber-50 hover:bg-amber-100 rounded font-bold text-[9px] transition-colors"
                              title="Duplicate Row Below"
                            >
                              ❐↓
                            </button>
                            <button 
                              type="button"
                              onClick={() => deleteListItem('shortCircuit', row.id)} 
                              className="w-6 h-6 flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 rounded font-bold text-sm transition-colors"
                              title="Delete Row"
                            >
                              ×
                            </button>
                          </div>
                        </td>
                      )}
                   </tr>
                 )
               ))}
               {(data.shortCircuit || []).length === 0 && (
                 <tr><td colSpan={6} className="py-12 text-slate-400 italic">No analysis data. Click "+ Add Location" to begin.</td></tr>
               )}
            </tbody>
          </table>
        </div>
      </section>

      {/* RELAY COORDINATION */}
      <RelayTable 
        title="RELAY COORDINATION - PHASE SETTINGS" 
        field="relayPhase" 
        theme="bg-[#2DD4BF]" 
        data={data}
        readOnly={readOnly}
        addRow={addRow}
        insertRow={insertRow}
        updateRow={updateRow}
        deleteListItem={deleteListItem}
        duplicateRow={duplicateRow}
      />
      <RelayTable 
        title="RELAY COORDINATION - EARTH FAULT SETTINGS" 
        field="relayEarth" 
        theme="bg-[#14B8A6]" 
        data={data}
        readOnly={readOnly}
        addRow={addRow}
        insertRow={insertRow}
        updateRow={updateRow}
        deleteListItem={deleteListItem}
        duplicateRow={duplicateRow}
      />
      <ReleaseSettingsTable 
        title="415V_RELEASE SETTINGS" 
        field="releaseSettings" 
        theme="bg-[#0D9488]" 
        data={data}
        readOnly={readOnly}
        addRow={addRow}
        insertRow={insertRow}
        updateRow={updateRow}
        deleteListItem={deleteListItem}
        duplicateRow={duplicateRow}
      />
      <ArcFlashTable 
        title="ARC FLASH ANALYSIS RESULTS" 
        field="arcFlashAnalysis" 
        theme="bg-[#0891B2]" 
        data={data}
        readOnly={readOnly}
        addRow={addRow}
        insertRow={insertRow}
        updateRow={updateRow}
        deleteListItem={deleteListItem}
        duplicateRow={duplicateRow}
      />

      {/* FOOTER */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-slate-100">
        <div className="space-y-3">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest block px-1">TEST OBSERVATIONS</label>
          <textarea 
            value={data.observations || ''}
            onChange={e => updateField('observations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter detailed test observations..."
            className="w-full h-40 p-4 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-orange-50 outline-none text-sm leading-relaxed shadow-sm bg-white"
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest block px-1">RECOMMENDATIONS</label>
          <textarea 
            value={data.recommendations || ''}
            onChange={e => updateField('recommendations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter professional recommendations..."
            className="w-full h-40 p-4 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-orange-50 outline-none text-sm leading-relaxed shadow-sm bg-white"
          />
        </div>
      </section>

    </div>
  );
};

export const INITIAL_POWER_SYSTEM_DATA: PowerSystemReading = {
  revisionNo: '', preparedBy: '', testedBy: '', approvedBy: '',
  testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  transformers: [],
  loadFlow: [],
  busVoltages: [],
  shortCircuit: [],
  relayPhase: [],
  relayEarth: [],
  releaseSettings: [],
  arcFlashAnalysis: [],
  observations: '',
  recommendations: ''
};
