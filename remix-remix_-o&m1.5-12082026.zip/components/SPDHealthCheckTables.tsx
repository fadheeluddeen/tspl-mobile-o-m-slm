import React from 'react';
import { SPDReading, SPDInspectionRow } from '../types';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

// Icons
const FileTextIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>
);

const ZapIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
);

const PlusIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
);

const Trash2Icon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-300 hover:text-red-500 transition-colors"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

interface SPDHealthCheckTablesProps {
  data: SPDReading;
  onChange: (data: SPDReading) => void;
  readOnly?: boolean;
}

export const SPDHealthCheckTables: React.FC<SPDHealthCheckTablesProps> = ({ data, onChange, readOnly = false }) => {
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();

  const updateField = (field: keyof SPDReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addInspectionRow = () => {
    const list = [...(data.inspections || [])];
    list.push({ id: `spd-${Date.now()}`, location: '', panelName: '', make: '', model: '', rating: '', remark: '' });
    updateField('inspections', list);
  };

  const deleteInspectionRow = (id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this SPD inspection record?",
      onConfirm: () => {
        const list = (data.inspections || []).filter(r => r.id !== id);
        updateField('inspections', list);
      }
    });
  };

  const updateInspection = (id: string, f: keyof SPDInspectionRow, v: string) => {
    const list = data.inspections.map(r => r.id === id ? { ...r, [f]: v } : r);
    updateField('inspections', list);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-[#B71C1C] rounded-2xl flex items-center justify-center shadow-lg shadow-red-100 flex-shrink-0">
            <FileTextIcon />
          </div>
          <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tight leading-tight">Health checks for SPDs</h2>
            <p className="text-sm font-black text-slate-400 mt-1 tracking-widest uppercase">ELECTRICAL TESTING + EXECUTION DATA</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs font-black text-slate-500 uppercase tracking-widest">Protocol Status</label>
          <select 
            value={data.status || 'PENDING'}
            onChange={e => updateField('status', e.target.value)}
            disabled={readOnly}
            className="px-4 py-2 bg-slate-100 border-none rounded-xl text-xs font-black uppercase tracking-widest text-slate-700 outline-none focus:ring-4 focus:ring-slate-200 transition-all cursor-pointer"
          >
            <option value="PENDING">Pending</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="PASS">Pass</option>
            <option value="FAIL">Fail</option>
          </select>
        </div>
      </div>

      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#F97316] px-6 py-3 text-white">
          <h3 className="text-center font-black uppercase tracking-[0.2em] text-xs">Test Personnel & Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          {['preparedBy', 'testedBy', 'testerEmail', 'witnessedBy', 'testDate'].map(f => (
            <div key={f} className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">{f.replace(/([A-Z])/g, ' $1')}</label>
              <input 
                type={f === 'testDate' ? 'date' : 'text'}
                value={(data as any)[f] || ''} 
                onChange={e => updateField(f as any, e.target.value)}
                disabled={readOnly}
                placeholder="---"
                className="w-full text-sm font-bold text-slate-700 bg-transparent border-b border-transparent focus:border-orange-500 outline-none p-1 transition-all"
              />
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-center">
          <div className="flex items-center gap-3">
             <ZapIcon />
             <h3 className="font-black text-slate-800 tracking-widest text-xs uppercase">4. SURGE PROTECTIVE DEVICE INSPECTION</h3>
          </div>
          {!readOnly && (
            <button 
              onClick={addInspectionRow}
              className="px-5 py-2 text-[#F97316] bg-orange-50 rounded-xl font-black text-[10px] tracking-widest uppercase hover:bg-orange-100 transition-all border border-orange-100 flex items-center gap-2"
            >
              <PlusIcon /> Add SPD Row
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[10px] text-left">
            <thead>
              <tr className="bg-[#F97316] text-white font-black uppercase tracking-tighter">
                <th className="px-6 py-4 border-r border-white/10">SPD Location</th>
                <th className="px-6 py-4 border-r border-white/10">Panel Name</th>
                <th className="px-6 py-4 border-r border-white/10">Make</th>
                <th className="px-6 py-4 border-r border-white/10">Model</th>
                <th className="px-6 py-4 border-r border-white/10 text-center w-24">Rating</th>
                <th className="px-6 py-4 border-r border-white/10">Remark</th>
                {!readOnly && <th className="w-10 px-4"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(data.inspections || []).map(row => (
                <tr key={row.id} className="hover:bg-slate-50/50 transition-all animate-in slide-in-from-bottom-2">
                  <td className="p-0 border-r border-slate-100"><input value={row.location} onChange={e => updateInspection(row.id, 'location', e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none font-bold text-slate-700" placeholder="e.g. UPS Room" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={row.panelName} onChange={e => updateInspection(row.id, 'panelName', e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none font-bold text-slate-700" placeholder="Panel ID" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={row.make} onChange={e => updateInspection(row.id, 'make', e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none" placeholder="Make" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={row.model} onChange={e => updateInspection(row.id, 'model', e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none" placeholder="Model" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={row.rating} onChange={e => updateInspection(row.id, 'rating', e.target.value)} className="w-full py-4 bg-transparent outline-none text-center" placeholder="kA" disabled={readOnly} /></td>
                  <td className="p-0 border-r border-slate-100"><input value={row.remark} onChange={e => updateInspection(row.id, 'remark', e.target.value)} className="w-full px-6 py-4 bg-transparent outline-none" placeholder="OK/Faulty" disabled={readOnly} /></td>
                  {!readOnly && <td className="px-4 py-4 text-center"><button onClick={() => deleteInspectionRow(row.id)}><Trash2Icon /></button></td>}
                </tr>
              ))}
              {(data.inspections || []).length === 0 && (
                <tr><td colSpan={7} className="px-6 py-20 text-center text-slate-400 font-medium italic">No SPD inspections logged yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">OBSERVATIONS</label>
          <textarea 
            value={data.observations || ''}
            onChange={e => updateField('observations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter detailed test observations..."
            className="w-full h-40 bg-slate-50 border border-slate-100 rounded-xl p-4 text-sm text-slate-600 outline-none focus:bg-white focus:ring-4 focus:ring-slate-50 transition-all italic resize-none"
          />
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">RECOMMENDATIONS</label>
          <textarea 
            value={data.recommendations || ''}
            onChange={e => updateField('recommendations', e.target.value)}
            disabled={readOnly}
            placeholder="Enter professional recommendations..."
            className="w-full h-40 bg-slate-50 border border-slate-100 rounded-xl p-4 text-sm text-slate-600 outline-none focus:bg-white focus:ring-4 focus:ring-slate-50 transition-all italic resize-none"
          />
        </div>
      </div>
    </div>
  );
};

export const INITIAL_SPD_HEALTH_DATA: SPDReading = {
  preparedBy: '', testedBy: '', testerEmail: '', witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  status: 'PENDING',
  inspections: [],
  equipmentList: [],
  observations: '',
  recommendations: ''
};