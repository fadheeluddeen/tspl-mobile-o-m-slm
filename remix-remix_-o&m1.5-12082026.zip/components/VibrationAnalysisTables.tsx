
import React from 'react';
import { 
  VibrationAnalysisReading, 
  VibrationToolRow, 
  AbbreviationRow, 
  VibrationSummaryGroup, 
  VibrationSummaryRow,
  ObservationRecommendationRow 
} from '../types';
import { ObservationsRecommendationsTable } from './ObservationsRecommendationsTable';
import ConfirmModal from './ConfirmModal';
import { ToastContainer } from './Toast';
import { useConfirmDelete } from '../hooks/useConfirmDelete';
import { FileSpreadsheet, Upload } from 'lucide-react';
import { exportVibrationGroupToExcel } from '../utils/excelExport';
import { parseVibrationGroupExcel } from '../utils/excelImport';
import { Camera } from 'lucide-react';
import { readVibrationDisplay } from '../services/geminiClient';

const LIVE_CAPTURE_ENABLED = process.env.ENABLE_LIVE_CAPTURE === 'true';

const Trash2Icon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
);

const ToolIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
);

const ActivityIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-500"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
);

const InfoIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
);

const CodeIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
);

const ChartBarIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-600"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
);

interface VibrationAnalysisTablesProps {
  data: VibrationAnalysisReading;
  onChange: (data: VibrationAnalysisReading) => void;
  readOnly?: boolean;
  aiEnabled?: boolean;
}

export const VibrationAnalysisTables: React.FC<VibrationAnalysisTablesProps> = ({ 
  data, 
  onChange, 
  readOnly = false,
  aiEnabled = true
}) => {
  const isLiveCaptureAllowed = aiEnabled !== false;
  const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast } = useConfirmDelete();
  
  const [selectedCell, setSelectedCell] = React.useState<{
    rowId: string;
    field: string;
    tableType: 'tools' | 'summary';
    groupId?: string;
  } | null>(null);

  const [liveCapture, setLiveCapture] = React.useState<{
    active: boolean;
    groupId: string;
    rowIndex: number;
    rows: VibrationSummaryRow[];
    phase: 'camera' | 'reading' | 'review';
    readValues: { vertical: string; horizontal: string; axial: string };
    error: string;
  } | null>(null);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera error:', err);
      if (liveCapture) {
        setLiveCapture(prev => prev ? { ...prev, error: 'Camera not available. Enter values manually below.', phase: 'review' } : null);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !liveCapture) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, '');
    
    setLiveCapture(prev => prev ? { ...prev, phase: 'reading', error: '' } : null);
    
    try {
      const values = await readVibrationDisplay(base64);
      setLiveCapture(prev => prev ? { ...prev, phase: 'review', readValues: values, error: '' } : null);
    } catch (err: any) {
      setLiveCapture(prev => prev ? { 
        ...prev, 
        phase: 'review', 
        readValues: { vertical: '', horizontal: '', axial: '' },
        error: 'Could not read the display. Please enter values manually.'
      } : null);
    }
  };

  const handleConfirmReading = () => {
    if (!liveCapture) return;
    const { groupId, rowIndex, rows, readValues } = liveCapture;
    const row = rows[rowIndex];
    if (!row) return;
    
    // Write values using the EXISTING updateSummaryRow function.
    // This automatically triggers calculateCondition — do NOT compute maxValue or condition here.
    if (readValues.vertical !== undefined) updateSummaryRow(groupId, row.id, 'vertical', readValues.vertical);
    if (readValues.horizontal !== undefined) updateSummaryRow(groupId, row.id, 'horizontal', readValues.horizontal);
    if (readValues.axial !== undefined) updateSummaryRow(groupId, row.id, 'axial', readValues.axial);
    
    // Get latest rows for group
    const currentGroup = (data.summaryGroups || []).find(g => g.id === groupId);
    const latestRows = currentGroup ? currentGroup.rows : rows;

    const nextIndex = rowIndex + 1;
    if (nextIndex < latestRows.length) {
      // Advance to next row, reset to camera phase
      setLiveCapture(prev => prev ? {
        ...prev,
        rowIndex: nextIndex,
        rows: latestRows,
        phase: 'camera',
        readValues: { vertical: '', horizontal: '', axial: '' },
        error: ''
      } : null);
    } else {
      // All rows done — close modal
      stopCamera();
      setLiveCapture(null);
    }
  };

  const handleCancelCapture = () => {
    stopCamera();
    setLiveCapture(null);
  };

  const openLiveCapture = (groupId: string, rows: VibrationSummaryRow[], startRowIndex?: number) => {
    let currentRows = rows;
    if (currentRows.length === 0) {
      const newRow: VibrationSummaryRow = {
        id: `row-${Date.now()}`,
        equipmentId: 'PAC 01',
        classDetails: '',
        vertical: '',
        horizontal: '',
        axial: '',
        maxValue: '',
        condition: 'GOOD'
      };
      const updatedGroups = (data.summaryGroups || []).map(g => {
        if (g.id === groupId) {
          return { ...g, rows: [newRow] };
        }
        return g;
      });
      updateField('summaryGroups', updatedGroups);
      currentRows = [newRow];
    }

    let startIndex = startRowIndex;
    if (startIndex === undefined) {
      startIndex = currentRows.findIndex(r => !r.vertical && !r.horizontal && !r.axial);
      if (startIndex === -1) startIndex = 0;
    }

    setLiveCapture({
      active: true,
      groupId,
      rowIndex: startIndex,
      rows: currentRows,
      phase: 'camera',
      readValues: { vertical: '', horizontal: '', axial: '' },
      error: ''
    });
  };

  React.useEffect(() => {
    if (liveCapture?.phase === 'camera') {
      startCamera();
    }
    return () => {
      if (liveCapture?.phase === 'camera') {
        stopCamera();
      }
    };
  }, [liveCapture?.phase, liveCapture?.rowIndex]);

  // Cleanup on unmount
  React.useEffect(() => {
    return () => stopCamera();
  }, []);

  const isCellCovered = (
    rows: any[],
    rowIndex: number,
    colIndex: number,
    columns: string[]
  ): boolean => {
    // Check horizontal coverage in the same row
    for (let c = 0; c < colIndex; c++) {
      const key = columns[c];
      const cellStyle = rows[rowIndex]?.cellStyles?.[key];
      const cs = cellStyle?.colSpan || 1;
      if (c + cs > colIndex) {
        return true;
      }
    }

    // Check vertical coverage from prior rows
    for (let r = 0; r < rowIndex; r++) {
      const prevRow = rows[r];
      for (let c = 0; c < columns.length; c++) {
        const key = columns[c];
        const cellStyle = prevRow?.cellStyles?.[key];
        const rs = cellStyle?.rowSpan || 1;
        const cs = cellStyle?.colSpan || 1;
        
        const coversRow = r + rs > rowIndex;
        const coversCol = c <= colIndex && c + cs > colIndex;
        if (coversRow && coversCol) {
          return true;
        }
      }
    }

    return false;
  };

  const updateToolsCellFormat = (rowId: string, field: string, formatKey: 'align' | 'valign' | 'colSpan' | 'rowSpan', value: any) => {
    const updatedList = (data.toolsUsed || []).map(row => {
      if (row.id === rowId) {
        const currentStyles = row.cellStyles || {};
        const fieldStyles = currentStyles[field] || {};
        const newFieldStyles = { ...fieldStyles, [formatKey]: value };
        return {
          ...row,
          cellStyles: {
            ...currentStyles,
            [field]: newFieldStyles
          }
        };
      }
      return row;
    });
    updateField('toolsUsed', updatedList);
  };

  const updateSummaryCellFormat = (groupId: string, rowId: string, field: string, formatKey: 'align' | 'valign' | 'colSpan' | 'rowSpan', value: any) => {
    const updatedGroups = (data.summaryGroups || []).map(g => {
      if (g.id === groupId) {
        return {
          ...g,
          rows: g.rows.map(row => {
            if (row.id === rowId) {
              const currentStyles = row.cellStyles || {};
              const fieldStyles = currentStyles[field] || {};
              const newFieldStyles = { ...fieldStyles, [formatKey]: value };
              return {
                ...row,
                cellStyles: {
                  ...currentStyles,
                  [field]: newFieldStyles
                }
              };
            }
            return row;
          })
        };
      }
      return g;
    });
    updateField('summaryGroups', updatedGroups);
  };

  const updateField = (field: keyof VibrationAnalysisReading, value: any) => {
    if (readOnly) return;
    onChange({ ...data, [field]: value });
  };

  const addRow = (field: keyof VibrationAnalysisReading, template: any) => {
    const list = [...((data[field] as any[]) || [])];
    list.push({ ...template, id: `va-${Date.now()}` });
    updateField(field, list);
  };

  const deleteRow = (field: keyof VibrationAnalysisReading, id: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this row?",
      onConfirm: () => {
        const list = ((data[field] as any[]) || []).filter(item => item.id !== id);
        updateField(field, list);
      }
    });
  };

  const updateRow = (field: keyof VibrationAnalysisReading, id: string, rowKey: string, value: any) => {
    const list = ((data[field] as any[]) || []).map(item => item.id === id ? { ...item, [rowKey]: value } : item);
    updateField(field, list);
  };

  const addSummaryGroup = () => {
    const groups = [...(data.summaryGroups || [])];
    groups.push({
      id: `group-${Date.now()}`,
      groupName: 'NEW SECTION',
      rows: []
    });
    updateField('summaryGroups', groups);
  };

  const deleteSummaryGroup = (groupId: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this Entire Summary Table and all its measurement records?",
      onConfirm: () => {
        const groups = (data.summaryGroups || []).filter(g => g.id !== groupId);
        updateField('summaryGroups', groups);
      }
    });
  };

  const updateSummaryGroup = (groupId: string, groupName: string) => {
    const groups = (data.summaryGroups || []).map(g => g.id === groupId ? { ...g, groupName } : g);
    updateField('summaryGroups', groups);
  };

  const addSummaryRow = (groupId: string) => {
    const groups = (data.summaryGroups || []).map(g => {
      if (g.id === groupId) {
        return {
          ...g,
          rows: [...g.rows, {
            id: `row-${Date.now()}`,
            equipmentId: '',
            classDetails: '',
            vertical: '',
            horizontal: '',
            axial: '',
            maxValue: '',
            condition: 'GOOD'
          }]
        };
      }
      return g;
    });
    updateField('summaryGroups', groups);
  };

  const deleteSummaryRow = (groupId: string, rowId: string) => {
    if (readOnly) return;
    
    confirmDelete({
      message: "Are you sure you want to delete this equipment measurement row?",
      onConfirm: () => {
        const groups = (data.summaryGroups || []).map(g => {
          if (g.id === groupId) {
            return { ...g, rows: g.rows.filter(r => r.id !== rowId) };
          }
          return g;
        });
        updateField('summaryGroups', groups);
      }
    });
  };

  const calculateCondition = (isoClass: string, maxValueStr: string): string => {
    const maxValue = parseFloat(maxValueStr);
    if (isNaN(maxValue)) return '';

    if (isoClass === 'Class I') {
      if (maxValue <= 0.71) return 'GOOD';
      if (maxValue <= 1.8) return 'Satisfactory';
      if (maxValue <= 4.5) return 'Unsatisfactory';
      return 'Unacceptable';
    } else if (isoClass === 'Class II') {
      if (maxValue <= 1.12) return 'GOOD';
      if (maxValue <= 2.8) return 'Satisfactory';
      if (maxValue <= 7.1) return 'Unsatisfactory';
      return 'Unacceptable';
    } else if (isoClass === 'Class III') {
      if (maxValue <= 1.8) return 'GOOD';
      if (maxValue <= 4.5) return 'Satisfactory';
      if (maxValue <= 11.2) return 'Unsatisfactory';
      return 'Unacceptable';
    } else if (isoClass === 'Class IV') {
      if (maxValue <= 2.8) return 'GOOD';
      if (maxValue <= 7.1) return 'Satisfactory';
      if (maxValue <= 18) return 'Unsatisfactory';
      return 'Unacceptable';
    }
    return '';
  };

  const updateSummaryRow = (groupId: string, rowId: string, key: keyof VibrationSummaryRow, value: string) => {
    const groups = (data.summaryGroups || []).map(g => {
      if (g.id === groupId) {
        return {
          ...g,
          rows: g.rows.map(r => {
            if (r.id === rowId) {
              const updatedRow = { ...r, [key]: value };
              
              // Auto-calculate Max Value if vibration components are changed
              if (['vertical', 'horizontal', 'axial'].includes(key)) {
                const v = parseFloat(updatedRow.vertical) || 0;
                const h = parseFloat(updatedRow.horizontal) || 0;
                const a = parseFloat(updatedRow.axial) || 0;
                const max = Math.max(v, h, a);
                updatedRow.maxValue = max > 0 ? max.toString() : '';
              }
              
              // Auto-calculate Condition if Class or Max Value components are changed
              if (['classDetails', 'vertical', 'horizontal', 'axial', 'maxValue'].includes(key)) {
                updatedRow.condition = calculateCondition(updatedRow.classDetails, updatedRow.maxValue) || updatedRow.condition;
              }
              
              return updatedRow;
            }
            return r;
          })
        };
      }
      return g;
    });
    updateField('summaryGroups', groups);
  };

  const SectionHeader = ({ icon: Icon, title }: { icon: any; title: string }) => (
    <div className="flex items-center gap-3 py-3 px-1 border-b border-[#D1D5DB] mb-4">
      <Icon />
      <h3 className="font-bold text-slate-800 uppercase tracking-tight">{title}</h3>
    </div>
  );

  const handleImportGroupExcel = (groupId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx, .xls';
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const result = parseVibrationGroupExcel(evt.target?.result);
        if (result && result.length > 0) {
          const updatedGroups = (data.summaryGroups || []).map(g => 
            g.id === groupId ? { ...g, rows: result } : g
          );
          updateField('summaryGroups', updatedGroups);
        } else {
          alert("Could not parse file. Ensure headers match the original export template.");
        }
      };
      reader.readAsBinaryString(file);
    };
    input.click();
  };

  const CellFormatToolbar = () => {
    if (readOnly || !selectedCell) return null;

    let currentStyles: any = {};
    let groupName = '';
    if (selectedCell.tableType === 'tools') {
      const row = (data.toolsUsed || []).find(r => r.id === selectedCell.rowId);
      if (row) currentStyles = row.cellStyles?.[selectedCell.field] || {};
    } else {
      const group = (data.summaryGroups || []).find(g => g.id === selectedCell.groupId);
      if (group) {
        groupName = group.groupName;
        const row = group.rows.find(r => r.id === selectedCell.rowId);
        if (row) currentStyles = row.cellStyles?.[selectedCell.field] || {};
      }
    }

    const { align = 'left', valign = 'middle', colSpan = 1, rowSpan = 1 } = currentStyles;

    const handleAlign = (value: 'left' | 'center' | 'right') => {
      if (selectedCell.tableType === 'tools') {
        updateToolsCellFormat(selectedCell.rowId, selectedCell.field, 'align', value);
      } else if (selectedCell.groupId) {
        updateSummaryCellFormat(selectedCell.groupId, selectedCell.rowId, selectedCell.field, 'align', value);
      }
    };

    const handleValign = (value: 'top' | 'middle' | 'bottom') => {
      if (selectedCell.tableType === 'tools') {
        updateToolsCellFormat(selectedCell.rowId, selectedCell.field, 'valign', value);
      } else if (selectedCell.groupId) {
        updateSummaryCellFormat(selectedCell.groupId, selectedCell.rowId, selectedCell.field, 'valign', value);
      }
    };

    const handleColSpan = (direction: number) => {
      const nextVal = Math.max(1, colSpan + direction);
      if (selectedCell.tableType === 'tools') {
        updateToolsCellFormat(selectedCell.rowId, selectedCell.field, 'colSpan', nextVal);
      } else if (selectedCell.groupId) {
        updateSummaryCellFormat(selectedCell.groupId, selectedCell.rowId, selectedCell.field, 'colSpan', nextVal);
      }
    };

    const handleRowSpan = (direction: number) => {
      const nextVal = Math.max(1, rowSpan + direction);
      if (selectedCell.tableType === 'tools') {
        updateToolsCellFormat(selectedCell.rowId, selectedCell.field, 'rowSpan', nextVal);
      } else if (selectedCell.groupId) {
        updateSummaryCellFormat(selectedCell.groupId, selectedCell.rowId, selectedCell.field, 'rowSpan', nextVal);
      }
    };

    const getCellLabel = () => {
      const cleanFieldName = selectedCell.field
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase());
      return `${selectedCell.tableType === 'tools' ? 'Tools Reference' : groupName || 'Summary'} ➔ ${cleanFieldName}`;
    };

    return (
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/95 backdrop-blur-md text-slate-800 px-6 py-4 rounded-2xl shadow-2xl border border-orange-200 flex flex-wrap items-center gap-6 z-50 max-w-full lg:max-w-4xl animate-fade-in">
        <div className="flex flex-col">
          <span className="text-[10px] font-bold text-orange-500 uppercase tracking-widest text-[8px] leading-3">Format Active Cell</span>
          <span className="text-xs font-black text-slate-700 truncate max-w-[150px]">{getCellLabel()}</span>
        </div>

        <div className="h-8 w-[1px] bg-slate-200" />

        {/* Horizontal Alignment */}
        <div className="flex flex-col gap-1">
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Horizontal</span>
          <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200/55">
            {(['left', 'center', 'right'] as const).map(dir => (
              <button
                key={dir}
                onClick={() => handleAlign(dir)}
                className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all uppercase tracking-wider ${
                  align === dir 
                    ? 'bg-[#FB923C] text-white shadow-sm' 
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-200/50'
                }`}
              >
                {dir}
              </button>
            ))}
          </div>
        </div>

        <div className="h-8 w-[1px] bg-slate-200" />

        {/* Vertical Alignment */}
        <div className="flex flex-col gap-1">
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest text-center">Vertical</span>
          <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200/55">
            {(['top', 'middle', 'bottom'] as const).map(vdir => (
              <button
                key={vdir}
                onClick={() => handleValign(vdir)}
                className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all uppercase tracking-wider ${
                  valign === vdir 
                    ? 'bg-[#1E293B] text-white shadow-sm' 
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-200/50'
                }`}
              >
                {vdir}
              </button>
            ))}
          </div>
        </div>

        <div className="h-8 w-[1px] bg-slate-200" />

        {/* Merge Cells / Spans */}
        <div className="flex items-center gap-4">
          {/* Column Span */}
          <div className="flex flex-col gap-1 items-center">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Col Merge</span>
            <div className="flex items-center gap-2 bg-slate-100 p-0.5 rounded-lg border border-slate-200/55">
              <button 
                onClick={() => handleColSpan(-1)}
                className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded"
                title="Decrease colSpan (Split)"
              >
                -
              </button>
              <span className="text-xs font-bold font-mono px-1 w-4 text-center">{colSpan}</span>
              <button 
                onClick={() => handleColSpan(1)}
                className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded"
                title="Increase colSpan (Merge Right)"
              >
                +
              </button>
            </div>
          </div>

          {/* Row Span */}
          <div className="flex flex-col gap-1 items-center">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Row Merge</span>
            <div className="flex items-center gap-2 bg-slate-100 p-0.5 rounded-lg border border-slate-200/55">
              <button 
                onClick={() => handleRowSpan(-1)}
                className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded"
                title="Decrease rowSpan (Split)"
              >
                -
              </button>
              <span className="text-xs font-bold font-mono px-1 w-4 text-center">{rowSpan}</span>
              <button 
                onClick={() => handleRowSpan(1)}
                className="w-6 h-6 flex items-center justify-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded"
                title="Increase rowSpan (Merge Down)"
              >
                +
              </button>
            </div>
          </div>
        </div>

        <div className="h-8 w-[1px] bg-slate-200" />

        <button 
          onClick={() => setSelectedCell(null)}
          className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 rounded-xl text-xs font-black transition-all"
        >
          Dismiss
        </button>
      </div>
    );
  };

  return (
    <div className="space-y-12 animate-fade-in pb-20 relative">
      <CellFormatToolbar />
      <ConfirmModal 
        isOpen={modalConfig.isOpen}
        onClose={closeModal}
        onConfirm={modalConfig.onConfirm}
        title={modalConfig.title}
        message={modalConfig.message}
        isDeleting={isDeleting}
      />
      <ToastContainer toast={toast} onClose={hideToast} />
      
      {/* 1. Personnel & Test Schedule Header */}
      <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="bg-[#FB923C] px-6 py-3 text-white">
          <h3 className="text-center font-bold uppercase tracking-wider text-sm">Personnel & Test Schedule</h3>
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Prepared By</label>
            <input 
              value={data?.preparedBy || ''} 
              onChange={e => updateField('preparedBy', e.target.value)}
              disabled={readOnly}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tested By</label>
            <input 
              value={data?.testedBy || ''} 
              onChange={e => updateField('testedBy', e.target.value)}
              disabled={readOnly}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tester Email</label>
            <input 
              value={data?.testerEmail || ''} 
              onChange={e => updateField('testerEmail', e.target.value)}
              disabled={readOnly}
              placeholder="Email"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Witnessed By</label>
            <input 
              value={data?.witnessedBy || ''} 
              onChange={e => updateField('witnessedBy', e.target.value)}
              disabled={readOnly}
              placeholder="Name"
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Test Date</label>
            <input 
              type="date"
              value={data?.testDate || ''} 
              onChange={e => updateField('testDate', e.target.value)}
              disabled={readOnly}
              className="w-full text-sm font-medium text-slate-700 bg-slate-50 border-b border-transparent focus:border-orange-400 outline-none p-2 rounded transition-all"
            />
          </div>
        </div>
      </section>

      {/* 2. Tools Used for Audit */}
      <section>
        <SectionHeader icon={ToolIcon} title="TOOLS USED FOR AUDIT" />
        <div className="bg-white rounded-xl border border-[#D1D5DB] shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-[#FB923C] text-white border-b border-[#D1D5DB]">
                <th className="px-4 py-3 text-center font-bold border-r border-white/20 w-12">S. No</th>
                <th className="px-4 py-3 text-left font-bold border-r border-white/20 min-w-[250px]">Instrument Name</th>
                <th className="px-4 py-3 text-left font-bold border-r border-white/20 min-w-[250px]">Purpose</th>
                <th className="px-4 py-3 text-left font-bold border-r border-white/20 min-w-[250px]">Make</th>
                <th className="px-4 py-3 text-left font-bold border-r border-white/20 min-w-[250px]">Model</th>
                <th colSpan={2} className="px-4 py-3 text-center font-bold min-w-[500px]">Calibration Date</th>
                {!readOnly && <th className="w-12"></th>}
              </tr>
              <tr className="bg-[#FFDAB9] text-slate-700 text-[10px] font-bold uppercase border-b border-[#D1D5DB]">
                <th colSpan={5} className="border-r border-[#D1D5DB]"></th>
                <th className="px-4 py-2 border-r border-[#D1D5DB] text-center">Issue</th>
                <th className="px-4 py-2 text-center">Expiry</th>
                {!readOnly && <th></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D1D5DB]">
{((data?.toolsUsed || [])).length === 0 && (<tr><td colSpan={100} className="p-8 text-center text-slate-500 italic bg-slate-50">{readOnly ? 'No data entered.' : 'No data entered. Please enter data or add a row to begin.'}</td></tr>)}

              {(data?.toolsUsed || []).map((row, idx, list) => {
                const columnsList = ['instrumentName', 'purpose', 'make', 'model', 'calibrationIssue', 'calibrationExpiry'];
                return (
                  <tr key={row.id} className="hover:bg-slate-50 group transition-colors">
                    <td className="px-4 py-3 text-center border-r border-[#D1D5DB] text-slate-400 font-mono">{idx + 1}</td>
                    
                    {columnsList.map((colKey, colIdx) => {
                      if (isCellCovered(list, idx, colIdx, columnsList)) {
                        return null;
                      }

                      const styles = row.cellStyles?.[colKey] || {};
                      const colSpan = styles.colSpan || 1;
                      const rowSpan = styles.rowSpan || 1;

                      const isSelected = selectedCell?.rowId === row.id && selectedCell?.field === colKey && selectedCell?.tableType === 'tools';
                      const alignmentClass = styles.align === 'center' ? 'text-center' : styles.align === 'right' ? 'text-right' : 'text-left';
                      const verticalClass = styles.valign === 'top' ? 'align-top' : styles.valign === 'bottom' ? 'align-bottom' : 'align-middle';

                      const isDateAttr = colKey === 'calibrationIssue' || colKey === 'calibrationExpiry';
                      const placeholderText = colKey === 'instrumentName' ? 'Instrument Name' : colKey === 'purpose' ? 'Purpose' : colKey === 'make' ? 'Make' : colKey === 'model' ? 'Model' : '';

                      return (
                        <td
                          key={colKey}
                          colSpan={colSpan}
                          rowSpan={rowSpan}
                          className={`p-0 border-r border-[#D1D5DB] ${verticalClass} ${isSelected ? 'ring-2 ring-orange-500 ring-inset' : ''}`}
                          style={{ minWidth: colSpan > 1 ? 'auto' : ['instrumentName', 'purpose', 'make', 'model'].includes(colKey) ? '250px' : 'auto' }}
                        >
                          <input
                            type={isDateAttr ? "date" : "text"}
                            value={row[colKey as keyof VibrationToolRow] as string || ''}
                            onChange={e => updateRow('toolsUsed', row.id, colKey, e.target.value)}
                            onFocus={() => !readOnly && setSelectedCell({ rowId: row.id, field: colKey, tableType: 'tools' })}
                            className={`w-full px-4 py-3 bg-transparent outline-none ${isDateAttr ? 'text-center' : 'placeholder:text-slate-400'} ${alignmentClass}`}
                            disabled={readOnly}
                            placeholder={placeholderText}
                          />
                        </td>
                      );
                    })}

                    {!readOnly && (
                      <td className="text-center">
                        <button onClick={() => deleteRow('toolsUsed', row.id)} className="text-slate-400 hover:text-red-500 transition-colors"><Trash2Icon /></button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!readOnly && (
            <button onClick={() => addRow('toolsUsed', { instrumentName: '', purpose: '', make: '', model: '', calibrationIssue: '', calibrationExpiry: '' })} className="w-full py-3 bg-slate-50 text-slate-500 text-xs font-bold hover:bg-slate-100 border-t border-[#D1D5DB] transition-colors tracking-widest uppercase">+ Add Equipment</button>
          )}
        </div>
      </section>

      {/* 4. Vibration Measurement Summary */}
      <section>
        <div className="flex justify-between items-center mb-4">
          <SectionHeader icon={ChartBarIcon} title="VIBRATION MEASUREMENT SUMMARY" />
          {!readOnly && (
            <button 
              onClick={addSummaryGroup}
              className="px-6 py-2.5 bg-[#FB923C] text-white rounded-xl text-xs font-bold hover:bg-orange-600 transition-all flex items-center gap-2 shadow-md"
            >
              <span className="text-lg">+</span> Add Summary Table
            </button>
          )}
        </div>

        <div className="space-y-8">
          {(data?.summaryGroups || []).map((group) => (
            <div key={group.id} className="bg-white rounded-2xl border-2 border-[#FB923C] shadow-lg overflow-hidden">
              <div className="bg-[#FB923C] px-6 py-3 text-white flex justify-between items-center">
                <div className="flex-1 text-center">
                  <h3 className="font-black uppercase tracking-widest text-sm">VIBRATION MEASUREMENT SUMMARY</h3>
                </div>
                <div className="flex items-center gap-2">
                  {!readOnly && isLiveCaptureAllowed && (
                    <button
                      onClick={() => openLiveCapture(group.id, group.rows)}
                      className="p-1.5 bg-violet-500 hover:bg-violet-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider shadow-sm"
                      title="Live Capture — photograph meter readings"
                    >
                      <Camera className="w-3.5 h-3.5" /> Live Capture
                    </button>
                  )}
                  <button
                    onClick={() => exportVibrationGroupToExcel(group, `${group.groupName || 'Vibration_Analysis'}_Report_${new Date().toISOString().split('T')[0]}.xlsx`)}
                    className="p-1.5 bg-emerald-500/80 hover:bg-emerald-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                    title="Export to Excel"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" /> Export
                  </button>
                  {!readOnly && (
                    <>
                      <button
                        onClick={() => handleImportGroupExcel(group.id)}
                        className="p-1.5 bg-indigo-500/80 hover:bg-indigo-600 text-white rounded transition-colors flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider"
                        title="Import from Excel"
                      >
                        <Upload className="w-3.5 h-3.5" /> Import
                      </button>
                      <button 
                        onClick={() => addSummaryRow(group.id)}
                        className="p-1.5 bg-white/20 hover:bg-white/30 rounded transition-colors flex items-center justify-center w-7 h-7"
                        title="Add Row"
                      >
                        <span className="text-sm font-bold leading-none">+</span>
                      </button>
                      <button 
                        onClick={() => deleteSummaryGroup(group.id)}
                        className="p-1.5 bg-white/20 hover:bg-red-500/50 rounded transition-colors flex items-center justify-center w-7 h-7"
                        title="Delete Table"
                      >
                        <Trash2Icon />
                      </button>
                    </>
                  )}
                </div>
              </div>

              <div className="bg-slate-50 border-b border-[#D1D5DB] px-6 py-2">
                <input 
                  value={group.groupName}
                  onChange={e => updateSummaryGroup(group.id, e.target.value)}
                  disabled={readOnly}
                  className="w-full bg-transparent text-center font-black text-[#1E293B] uppercase tracking-widest text-xs outline-none focus:text-orange-600"
                  placeholder="GROUP NAME (e.g. OLD DC)"
                />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="bg-[#1E293B] text-white text-[10px] font-black uppercase tracking-wider border-b border-[#D1D5DB]">
                      <th rowSpan={2} className="px-2 py-4 text-center border-r border-slate-700 w-[15%]">Equipment ID</th>
                      <th rowSpan={2} className="px-2 py-4 text-center border-r border-slate-700 w-[15%]">Class Details</th>
                      <th colSpan={4} className="px-2 py-2 text-center border-r border-slate-700">Measured Vibration (mm/s)</th>
                      <th rowSpan={2} className="px-2 py-4 text-center">Vibration Condition</th>
                      {!readOnly && <th rowSpan={2} className="w-10"></th>}
                    </tr>
                    <tr className="bg-[#1E293B] text-white text-[9px] font-black uppercase tracking-wider border-b border-[#D1D5DB]">
                      <th className="px-2 py-2 text-center border-r border-slate-700">Vertical</th>
                      <th className="px-2 py-2 text-center border-r border-slate-700">Horizontal</th>
                      <th className="px-2 py-2 text-center border-r border-slate-700">Axial</th>
                      <th className="px-2 py-2 text-center border-r border-slate-700">Max Value (mm/s)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D1D5DB]">
                    {group.rows.map((row, rIdx, rList) => {
                      const summaryKeys = ['equipmentId', 'classDetails', 'vertical', 'horizontal', 'axial', 'maxValue', 'condition'];
                      return (
                        <tr key={row.id} className="bg-blue-50/30 hover:bg-blue-50/60 transition-colors border-b border-blue-100">
                          {summaryKeys.map((colKey, colIdx) => {
                            if (isCellCovered(rList, rIdx, colIdx, summaryKeys)) {
                              return null;
                            }

                            const styles = row.cellStyles?.[colKey] || {};
                            const colSpan = styles.colSpan || 1;
                            const rowSpan = styles.rowSpan || 1;

                            const isSelected = selectedCell?.rowId === row.id && selectedCell?.field === colKey && selectedCell?.tableType === 'summary' && selectedCell?.groupId === group.id;
                            const alignmentClass = styles.align === 'center' ? 'text-center' : styles.align === 'right' ? 'text-right' : 'text-left';
                            const verticalClass = styles.valign === 'top' ? 'align-top' : styles.valign === 'bottom' ? 'align-bottom' : 'align-middle';

                            if (colKey === 'classDetails') {
                              return (
                                <td
                                  key={colKey}
                                  colSpan={colSpan}
                                  rowSpan={rowSpan}
                                  className={`p-0 border-r border-[#D1D5DB] ${verticalClass} ${isSelected ? 'ring-2 ring-orange-500 ring-inset' : ''}`}
                                >
                                  <select
                                    value={row.classDetails}
                                    onChange={e => updateSummaryRow(group.id, row.id, 'classDetails', e.target.value)}
                                    onFocus={() => !readOnly && setSelectedCell({ rowId: row.id, field: colKey, tableType: 'summary', groupId: group.id })}
                                    disabled={readOnly}
                                    className={`w-full px-4 py-3 bg-transparent outline-none text-slate-700 text-sm appearance-none cursor-pointer ${alignmentClass}`}
                                  >
                                    <option value="">Select Class</option>
                                    <option value="Class I">Class I</option>
                                    <option value="Class II">Class II</option>
                                    <option value="Class III">Class III</option>
                                    <option value="Class IV">Class IV</option>
                                  </select>
                                </td>
                              );
                            }

                            if (colKey === 'condition') {
                              return (
                                <td
                                  key={colKey}
                                  colSpan={colSpan}
                                  rowSpan={rowSpan}
                                  className={`p-0 ${verticalClass} ${isSelected ? 'ring-2 ring-orange-500 ring-inset' : ''}`}
                                >
                                  <select
                                    value={row.condition || 'GOOD'}
                                    onChange={e => updateSummaryRow(group.id, row.id, 'condition', e.target.value)}
                                    onFocus={() => !readOnly && setSelectedCell({ rowId: row.id, field: colKey, tableType: 'summary', groupId: group.id })}
                                    disabled={readOnly}
                                    className={`w-full px-4 py-3 bg-transparent outline-none font-bold text-sm appearance-none cursor-pointer ${alignmentClass} ${
                                      (row.condition || 'GOOD') === 'GOOD' ? 'text-green-600' :
                                      row.condition === 'Satisfactory' ? 'text-blue-600' :
                                      row.condition === 'Unsatisfactory' ? 'text-orange-600' :
                                      row.condition === 'Unacceptable' ? 'text-red-600' : 'text-slate-700'
                                    }`}
                                  >
                                    <option value="">Select Condition</option>
                                    <option value="GOOD">GOOD</option>
                                    <option value="Satisfactory">Satisfactory</option>
                                    <option value="Unsatisfactory">Unsatisfactory</option>
                                    <option value="Unacceptable">Unacceptable</option>
                                  </select>
                                </td>
                              );
                            }

                            const isNumeric = ['vertical', 'horizontal', 'axial', 'maxValue'].includes(colKey);
                            const fontClass = isNumeric ? 'font-mono text-slate-600' : 'font-medium text-slate-800';
                            const finalAlignClass = isNumeric && !styles.align ? 'text-center' : alignmentClass;

                            return (
                              <td
                                key={colKey}
                                colSpan={colSpan}
                                rowSpan={rowSpan}
                                className={`p-0 border-r border-[#D1D5DB] ${verticalClass} ${isSelected ? 'ring-2 ring-orange-500 ring-inset' : ''}`}
                              >
                                <input
                                  value={row[colKey as keyof VibrationSummaryRow] as string || ''}
                                  onChange={e => updateSummaryRow(group.id, row.id, colKey as keyof VibrationSummaryRow, e.target.value)}
                                  onFocus={() => !readOnly && setSelectedCell({ rowId: row.id, field: colKey, tableType: 'summary', groupId: group.id })}
                                  disabled={readOnly}
                                  className={`w-full px-4 py-3 bg-transparent outline-none text-sm ${fontClass} ${finalAlignClass}`}
                                  placeholder={colKey === 'equipmentId' ? 'PAC 01' : ''}
                                />
                              </td>
                            );
                          })}

                          {!readOnly && (
                            <td className="text-center px-2">
                              <div className="flex items-center justify-center gap-1.5">
                                {isLiveCaptureAllowed && (
                                  <button
                                    onClick={() => openLiveCapture(group.id, group.rows, rIdx)}
                                    className="p-1 text-slate-400 hover:text-violet-600 transition-colors rounded hover:bg-violet-50"
                                    title="Live Capture for this row"
                                  >
                                    <Camera className="w-4 h-4" />
                                  </button>
                                )}
                                <button
                                  onClick={() => deleteSummaryRow(group.id, row.id)}
                                  className="p-1 text-slate-300 hover:text-red-500 transition-colors rounded hover:bg-red-50"
                                  title="Delete row"
                                >
                                  <Trash2Icon />
                                </button>
                              </div>
                            </td>
                          )}
                        </tr>
                      );
                    })}
                    {group.rows.length === 0 && (
                      <tr>
                        <td colSpan={readOnly ? 7 : 8} className="px-6 py-8 text-center text-slate-400 italic text-xs">
                          No rows added to this summary group.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
          {(data?.summaryGroups || []).length === 0 && (
            <div className="py-20 text-center border-2 border-dashed border-slate-200 rounded-3xl">
              <p className="text-slate-400 text-sm italic">No summary tables added yet. Click "Add Summary Table" to begin.</p>
            </div>
          )}
        </div>
      </section>

      {/* 5. Observations & Recommendations Summary Table */}
      <section>
        <SectionHeader icon={InfoIcon} title="Observations & Recommendations" />
        
        <div className="bg-white rounded-xl border border-[#1e293b] shadow-lg overflow-hidden">
          <div className="bg-slate-100 p-2 text-center border-b border-slate-200">
             <span className="text-[9px] font-black uppercase text-slate-500 tracking-widest">ISO Condition Legend</span>
          </div>
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-[#1e293b] text-white text-[10px] font-black uppercase tracking-wider">
                <th className="px-4 py-3 text-center border-r border-slate-700 w-[12%]">Condition</th>
                <th className="px-4 py-3 text-center border-r border-slate-700 w-[10%]">No. of Units</th>
                <th className="px-4 py-3 text-center border-r border-slate-700 w-[15%]">Unit Tags</th>
                <th className="px-4 py-3 text-center border-r border-slate-700 w-[33%]">Observation</th>
                <th className="px-4 py-3 text-center w-[30%]">Recommendation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {[
                {
                  condition: 'Good',
                  key: 'GOOD',
                  observations: [
                    '1. All units are within ISO acceptable vibration limits.',
                    '2. No abnormal vibration trend observed in H/V/A directions.',
                    '3. Equipment operating in stable dynamic condition.'
                  ],
                  recommendations: [
                    '1. Continue routine condition monitoring as per PM schedule.',
                    '2. Record baseline trends for future comparison.'
                  ]
                },
                {
                  condition: 'Satisfactory',
                  key: 'Satisfactory',
                  observations: [
                    '1. Vibration levels are within permissible ISO limits but approaching upper band.',
                    '2. Slight increase observed in one or more measurement directions (H/V/A).',
                    '3. No immediate mechanical fault indication.'
                  ],
                  recommendations: [
                    '1. Monitor vibration trend closely.',
                    '2. Inspect during next planned shutdown.',
                    '3. Check for early signs of misalignment or looseness.'
                  ]
                },
                {
                  condition: 'Unsatisfactory',
                  key: 'Unsatisfactory',
                  observations: [
                    '1. Vibration levels exceed satisfactory range as per ISO limits.',
                    '2. Indicates early mechanical degradation (possible imbalance, misalignment, or looseness).',
                    '3. Trend shows increasing deviation from baseline.'
                  ],
                  recommendations: [
                    '1. Conduct detailed vibration analysis.',
                    '2. Inspect coupling alignment, foundation tightness, and bearing condition.',
                    '3. Plan corrective maintenance in nearest shutdown window.'
                  ]
                },
                {
                  condition: 'Unacceptable',
                  key: 'Unacceptable',
                  observations: [
                    '1. Vibration levels exceed permissible ISO limits indicating critical condition.',
                    '2. High risk of mechanical failure if operation continues.',
                    '3. Abnormal vibration detected in one or more directions (H/V/A).'
                  ],
                  recommendations: [
                    '1. Immediate corrective action required.',
                    '2. Reduce load or shut down equipment if possible.',
                    '3. Perform urgent inspection: alignment correction, bearing replacement, structural tightening before restart.'
                  ]
                }
              ].map((item) => {
                const units = (data.summaryGroups || []).flatMap(g => g.rows).filter(r => (r.condition || 'GOOD') === item.key);
                const count = units.length;
                const tags = units.map(u => u.equipmentId).filter(Boolean).join('\n');

                if (count === 0) return null;

                return (
                  <tr key={item.key} className="bg-cyan-50/30">
                    <td className="px-4 py-4 text-center border-r border-slate-200 text-slate-700 font-medium">{item.condition}</td>
                    <td className="px-4 py-4 text-center border-r border-slate-200 text-slate-600">{count}</td>
                    <td className="px-4 py-4 text-center border-r border-slate-200 text-slate-600 whitespace-pre-wrap leading-relaxed text-[11px] font-mono">{tags || '-'}</td>
                    <td className="px-6 py-4 border-r border-slate-200 align-top">
                      <div className="space-y-2 text-[11px] text-slate-700 leading-relaxed">
                        {item.observations.map((obs, i) => <p key={i}>{obs}</p>)}
                      </div>
                    </td>
                    <td className="px-6 py-4 align-top">
                      <div className="space-y-2 text-[11px] text-slate-700 leading-relaxed">
                        {item.recommendations.map((rec, i) => <p key={i}>{rec}</p>)}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-8">
          <ObservationsRecommendationsTable 
            data={data.observationsAndRecommendations || []}
            onChange={(val) => updateField('observationsAndRecommendations', val)}
            readOnly={readOnly}
          />
        </div>
      </section>

      {/* Live Capture Modal */}
      {liveCapture && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="bg-violet-600 px-6 py-4 rounded-t-2xl flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Live Capture</h3>
                <p className="text-violet-200 text-sm">
                  Reading {liveCapture.rowIndex + 1} of {liveCapture.rows.length} — {liveCapture.rows[liveCapture.rowIndex]?.equipmentId || 'Unknown'}
                </p>
              </div>
              <button
                onClick={handleCancelCapture}
                className="text-white/80 hover:text-white text-2xl font-bold"
              >
                ×
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              {/* Camera Phase */}
              {liveCapture.phase === 'camera' && (
                <>
                  <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
                  <button
                    onClick={capturePhoto}
                    className="w-full py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
                  >
                    <Camera className="w-5 h-5" /> Capture Reading
                  </button>
                </>
              )}
              
              {/* Reading Phase — loading spinner */}
              {liveCapture.phase === 'reading' && (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-violet-200 border-t-violet-600 mx-auto mb-4" />
                  <p className="text-slate-600 font-medium">Reading display...</p>
                  <p className="text-slate-400 text-sm mt-1">Analysing the photo</p>
                </div>
              )}
              
              {/* Review Phase — confirm or correct */}
              {liveCapture.phase === 'review' && (
                <>
                  {liveCapture.error && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-amber-800 text-sm">
                      {liveCapture.error}
                    </div>
                  )}
                  
                  <div className="bg-slate-50 rounded-xl p-4">
                    <h4 className="font-bold text-slate-700 mb-3">
                      Values for {liveCapture.rows[liveCapture.rowIndex]?.equipmentId} — confirm or correct:
                    </h4>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Vertical (mm/s)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues.vertical}
                          onChange={(e) => setLiveCapture(prev => prev ? {
                            ...prev,
                            readValues: { ...prev.readValues, vertical: e.target.value }
                          } : null)}
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-center font-mono text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="0.00"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Horizontal (mm/s)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues.horizontal}
                          onChange={(e) => setLiveCapture(prev => prev ? {
                            ...prev,
                            readValues: { ...prev.readValues, horizontal: e.target.value }
                          } : null)}
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-center font-mono text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="0.00"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase">Axial (mm/s)</label>
                        <input
                          type="text"
                          value={liveCapture.readValues.axial}
                          onChange={(e) => setLiveCapture(prev => prev ? {
                            ...prev,
                            readValues: { ...prev.readValues, axial: e.target.value }
                          } : null)}
                          className="w-full border border-slate-300 rounded-lg px-3 py-2 text-center font-mono text-lg focus:ring-2 focus:ring-violet-400 focus:border-violet-400"
                          placeholder="0.00"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <button
                      onClick={handleConfirmReading}
                      className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors"
                    >
                      ✓ Confirm & Next
                    </button>
                    <button
                      onClick={handleCancelCapture}
                      className="px-6 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export const INITIAL_VIBRATION_DATA: VibrationAnalysisReading = {
  preparedBy: '',
  testedBy: '',
  testerEmail: '',
  witnessedBy: '',
  testDate: new Date().toISOString().split('T')[0],
  toolsUsed: [],
  abbreviations: [
    { id: '1', abbreviation: 'PAHU', fullMeaning: 'Precision Air Handling Unit' },
    { id: '2', abbreviation: 'DF', fullMeaning: 'Dual Fluid' },
    { id: '3', abbreviation: 'FAHU', fullMeaning: 'Fresh Air handling unit' },
    { id: '4', abbreviation: 'EAHU', fullMeaning: 'Exhaust Air handling unit' },
    { id: '5', abbreviation: 'CHW', fullMeaning: 'Chilled water' },
    { id: '6', abbreviation: 'AHU', fullMeaning: 'Air handling Unit' },
    { id: '7', abbreviation: 'DX', fullMeaning: 'Direct Expansion' }
  ],
  summaryGroups: [
    {
      id: 'g1',
      groupName: 'OLD DC',
      rows: [
        { id: 'r1', equipmentId: 'PAHU 01', classDetails: '', vertical: '', horizontal: '', axial: '', maxValue: '', condition: 'GOOD' },
        { id: 'r2', equipmentId: 'PAHU 02', classDetails: '', vertical: '', horizontal: '', axial: '', maxValue: '', condition: 'GOOD' },
        { id: 'r3', equipmentId: 'PAHU 03', classDetails: '', vertical: '', horizontal: '', axial: '', maxValue: '', condition: 'GOOD' },
        { id: 'r4', equipmentId: 'PAHU 04', classDetails: '', vertical: '', horizontal: '', axial: '', maxValue: '', condition: 'GOOD' }
      ]
    }
  ],
  observationsAndRecommendations: []
};
