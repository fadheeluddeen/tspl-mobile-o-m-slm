
import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  message?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isDeleting?: boolean;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title = "Delete Confirmation",
  message = "Are you sure you want to delete this pair?",
  confirmLabel = "Yes, Delete",
  cancelLabel = "Cancel",
  isDeleting = false
}) => {
  const modalRef = useRef<HTMLDivElement>(null);

  // Close on ESC
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  // Focus trap could be added here, but for simplicity we'll handle basic accessibility
  useEffect(() => {
    if (isOpen && modalRef.current) {
      // Focus the confirm button immediately for accessibility
      const confirmBtn = modalRef.current.querySelector('button[data-confirm="true"]') as HTMLButtonElement;
      confirmBtn?.focus();
    }
  }, [isOpen]);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget && !isDeleting) onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm transition-opacity duration-300"
          onClick={handleBackdropClick}
        >
          <motion.div
            ref={modalRef}
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 350 }}
            className="w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100"
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            aria-describedby="modal-message"
          >
            <div className="relative p-8 flex flex-col items-center text-center">
              {/* Close Button */}
              <button 
                onClick={onClose}
                disabled={isDeleting}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Close"
              >
                <X size={18} />
              </button>

              {/* Warning Icon Cluster */}
              <div className="mb-6 relative">
                <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center animate-pulse">
                  <AlertTriangle size={32} />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-sm"></div>
              </div>

              {/* Text Content */}
              <h2 id="modal-title" className="text-xl font-black text-slate-900 mb-2 tracking-tight">
                {title}
              </h2>
              <p id="modal-message" className="text-slate-500 text-sm leading-relaxed px-2 mt-2">
                {message}
              </p>

              {/* Actions */}
              <div className="flex flex-col w-full gap-3 mt-8">
                <button
                  data-confirm="true"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onConfirm();
                  }}
                  disabled={isDeleting}
                  className={`w-full py-3.5 rounded-2xl text-sm font-black uppercase tracking-widest transition-all shadow-lg shadow-red-200 flex items-center justify-center gap-2
                    ${isDeleting 
                      ? 'bg-red-400 text-white cursor-not-allowed' 
                      : 'bg-red-600 text-white hover:bg-red-700 active:scale-[0.98]'
                    }`}
                >
                  {isDeleting ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    confirmLabel
                  )}
                  {isDeleting ? 'Deleting...' : ''}
                </button>
                <button
                  onClick={onClose}
                  disabled={isDeleting}
                  className="w-full py-3.5 text-slate-500 text-sm font-bold rounded-2xl hover:bg-slate-50 hover:text-slate-700 transition-all border border-transparent hover:border-slate-100"
                >
                  {cancelLabel}
                </button>
              </div>
            </div>
            
            {/* Minimal footer line */}
            <div className="h-2 bg-gradient-to-r from-red-500 to-orange-500"></div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default ConfirmModal;
