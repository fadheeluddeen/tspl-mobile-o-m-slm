import React from 'react';
import { VibrationLiveCaptureLab } from '../../components/sandbox/VibrationLiveCaptureLab';
import { INITIAL_VIBRATION_DATA } from '../../components/VibrationAnalysisTables';
import { VibrationAnalysisReading } from '../../types';

const LiveCaptureLabPage: React.FC = () => {
  const [data, setData] = React.useState<VibrationAnalysisReading>(INITIAL_VIBRATION_DATA);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-6 bg-amber-50 border border-amber-200 rounded-xl p-4">
        <h2 className="font-bold text-amber-800 text-lg">🧪 Live Capture Sandbox</h2>
        <p className="text-amber-700 text-sm mt-1">
          This is a standalone test playground. Nothing here saves to any project or Firestore —
          it's local-only, throwaway data for testing the camera capture and Gemini reading flow
          safely, without touching real assignments.
        </p>
      </div>
      <VibrationLiveCaptureLab data={data} onChange={setData} readOnly={false} />
    </div>
  );
};

export default LiveCaptureLabPage;
