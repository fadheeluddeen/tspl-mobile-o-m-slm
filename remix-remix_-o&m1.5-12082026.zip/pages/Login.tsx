
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { useNavigate } from 'react-router-dom';
import { SystemService } from '../services/mockDatabase';

const Login: React.FC = () => {
  const { login, loading, user } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  React.useEffect(() => {
    if (user) {
      if (user.role === UserRole.ADMIN) navigate('/admin');
      else if (user.role === UserRole.DEVELOPER) navigate('/developer');
      else if (user.role === UserRole.PROJECT_MANAGER) navigate('/pm');
      else navigate('/engineer');
    }
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please provide both email and password.');
      return;
    }

    try {
      await login(email, password);
      await SystemService.createAuditLog({
        userEmail: email,
        userName: 'Authenticating...',
        userRole: 'UNKNOWN',
        module: 'AUTH',
        action: 'LOGIN_SUCCESS',
        status: 'SUCCESS',
        details: 'User authenticated successfully via Firebase'
      });
    } catch (err: any) {
      console.error("Auth Error:", err);
      
      let errorMsg = '';
      if (err.code === 'auth/invalid-credential') {
        errorMsg = 'Invalid email or password. \n\nNote: If this is a new project, ensure "Email/Password" sign-in is ENABLED in the Firebase Console and that you have added this user via the Admin dashboard.';
      } else {
        errorMsg = err.message || 'Authentication failed.';
      }
      
      setError(errorMsg);

      await SystemService.createAuditLog({
        userEmail: email,
        userName: 'Visitor',
        userRole: 'NONE',
        module: 'AUTH',
        action: 'LOGIN_FAILED',
        status: 'FAILED',
        details: `Reason: ${err.code || 'Unknown'}`
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
        <div className="mb-10">
          <div className="flex justify-end mb-6">
            <div className="inline-flex items-center justify-center w-48 h-20 sm:w-64 sm:h-24 bg-transparent rounded-none overflow-hidden">
              <img 
                src="https://lh3.googleusercontent.com/d/17LiSObruHI6XOCX_5g6D20KRspHCyozg" 
                alt="Logo" 
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="text-center">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">O & M Testing Portal</h1>
            <p className="text-slate-500 mt-2 font-medium text-sm sm:text-base">Enterprise Asset Performance</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {error && (
            <div className="p-4 bg-red-50 text-red-700 text-xs rounded-xl border border-red-100 flex items-start gap-3 animate-shake">
              <span className="text-lg">⚠️</span>
              <div className="flex-1 whitespace-pre-wrap">{error}</div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Email Address</label>
            <div className="relative">
              <span className="absolute left-3 top-3.5 text-slate-400">✉️</span>
              <input 
                type="email" 
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full pl-10 p-3.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all bg-slate-50/50" 
                placeholder="name@company.com"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Security Key</label>
            <div className="relative">
              <span className="absolute left-3 top-3.5 text-slate-400">🔒</span>
              <input 
                type="password" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full pl-10 p-3.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all bg-slate-50/50" 
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full bg-indigo-600 text-white font-bold py-4 rounded-xl hover:bg-indigo-700 active:scale-[0.98] transition-all shadow-lg shadow-indigo-100 flex items-center justify-center gap-2 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Authenticating...
              </>
            ) : (
              'Secure Sign In'
            )}
          </button>
        </form>

        <div className="mt-10 pt-6 border-t border-slate-100">
           <p className="text-[10px] text-slate-400 text-center uppercase tracking-[0.2em] font-bold">
             Cloud Production Environment <br/> 
             <span className="text-slate-300 font-normal mt-1 block tracking-normal">Direct Firebase Infrastructure Integration</span>
           </p>
        </div>
      </div>
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-4px); }
          75% { transform: translateX(4px); }
        }
        .animate-shake {
          animation: shake 0.2s ease-in-out 0s 2;
        }
      `}</style>
    </div>
  );
};

export default Login;
