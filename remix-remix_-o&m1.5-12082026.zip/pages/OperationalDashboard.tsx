
import React, { useState, useEffect } from 'react';
import { ExecutionService } from '../services/mockDatabase';
import { TestAssignment, WorkflowStatus } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';
import { 
  ClipboardList, 
  CheckCircle2, 
  AlertTriangle, 
  Building2, 
  ArrowRight,
  TrendingUp,
  Clock,
  History
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#94a3b8'];

const OperationalDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        const summary = await ExecutionService.fetchDashboardSummary();
        setData(summary);
      } catch (error) {
        console.error("Failed to load dashboard summary:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  if (loading || !data) {
    return (
      <div className="flex flex-col items-center justify-center py-32 gap-6 animate-pulse">
        <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 font-black uppercase tracking-widest text-xs">Aggregating Global Operations...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Operations Dashboard</h1>
          <p className="text-slate-500 font-medium">Real-time KPI tracking and operational performance overview.</p>
        </div>
        <div className="flex gap-3">
           <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Live Sync Active</span>
           </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard 
          title="Open Tasks" 
          value={data.openTasksCount} 
          icon={<ClipboardList size={24} />} 
          color="bg-indigo-50 text-indigo-600"
          subtext="Currently in progress"
        />
        <KPICard 
          title="Completed" 
          value={data.completedTasksCount} 
          icon={<CheckCircle2 size={24} />} 
          color="bg-emerald-50 text-emerald-600"
          subtext="Total processed protocols"
        />
        <KPICard 
          title="Active Projects" 
          value={data.totalProjects} 
          icon={<Building2 size={24} />} 
          color="bg-sky-50 text-sky-600"
          subtext="Total site deployments"
        />
        <KPICard 
          title="Attention Required" 
          value={data.alerts.length} 
          icon={<AlertTriangle size={24} />} 
          color="bg-rose-50 text-rose-600"
          subtext="Rejections & Overdue"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Status Distribution */}
        <div className="lg:col-span-1 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-6 flex items-center gap-2">
            <TrendingUp size={18} className="text-indigo-500" />
            Asset Status Distribution
          </h3>
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.statusDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.statusDistribution.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend layout="vertical" align="right" verticalAlign="middle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Critical Alerts */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
              <AlertTriangle size={18} className="text-rose-500" />
              Critical Operational Alerts
            </h3>
            {data.alerts.length > 0 && (
              <span className="bg-rose-600 text-white text-[10px] font-black px-2 py-1 rounded-full">{data.alerts.length} ACTION ITEMS</span>
            )}
          </div>
          <div className="flex-1 overflow-y-auto max-h-[400px] divide-y divide-slate-50">
            {data.alerts.length > 0 ? (
              data.alerts.map((alert: TestAssignment) => (
                <div key={alert.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${alert.workflowStatus === WorkflowStatus.REJECTED ? 'bg-rose-50 text-rose-500' : 'bg-amber-50 text-amber-500'}`}>
                      {alert.workflowStatus === WorkflowStatus.REJECTED ? <History size={20} /> : <Clock size={20} />}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">{alert.testName}</h4>
                      <p className="text-xs text-slate-500">
                        {alert.workflowStatus === WorkflowStatus.REJECTED ? 'Rejected by PM' : 'Overdue (>48h)'} • {alert.projectName || 'Internal Asset'}
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => navigate(`/execute/${alert.id}`)}
                    className="flex items-center gap-2 text-xs font-black text-indigo-600 uppercase tracking-widest hover:translate-x-1 transition-transform"
                  >
                    Resolve <ArrowRight size={14} />
                  </button>
                </div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-slate-400 gap-3">
                <CheckCircle2 size={48} className="text-emerald-500 opacity-20" />
                <p className="text-sm font-bold uppercase tracking-widest">No Critical Alerts</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recently Completed */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
           <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
            <CheckCircle2 size={18} className="text-emerald-500" />
            Recently Completed Protocols
          </h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-8">
          {data.recentCompleted.map((task: TestAssignment) => (
            <div key={task.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-indigo-200 transition-all cursor-pointer group" onClick={() => navigate(`/execute/${task.id}`)}>
              <div className="flex justify-between items-start mb-4">
                <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center text-lg shadow-inner group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  📄
                </div>
                <span className="text-[9px] font-black px-2 py-1 bg-emerald-100 text-emerald-700 rounded-full uppercase tracking-widest">APPROVED</span>
              </div>
              <h4 className="font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors leading-tight mb-2 truncate">{task.testName}</h4>
              <div className="space-y-1">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter truncate">Client: {task.projectName || 'N/A'}</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Done: {new Date(task.reviewedAt || task.createdAt).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
          {data.recentCompleted.length === 0 && (
             <div className="col-span-full py-16 text-center text-slate-400 font-bold uppercase tracking-widest text-xs">
                No recently completed tasks found.
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

const KPICard: React.FC<{ title: string; value: number; icon: React.ReactNode; color: string; subtext: string }> = ({ title, value, icon, color, subtext }) => (
  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col gap-4 hover:shadow-md transition-shadow">
    <div className="flex justify-between items-start">
      <div className={`p-3 rounded-2xl ${color} shadow-inner`}>
        {icon}
      </div>
      <div className="flex flex-col items-end">
        <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.15em]">{title}</h3>
        <p className="text-3xl font-black text-slate-900 mt-1">{value}</p>
      </div>
    </div>
    <div className="mt-2 border-t border-slate-50 pt-3">
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">{subtext}</p>
    </div>
  </div>
);

export default OperationalDashboard;
