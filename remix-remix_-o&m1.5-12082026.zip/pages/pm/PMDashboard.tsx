
import React, { useState, useEffect } from 'react';
import { Project, TestAssignment, WorkflowStatus, UserRole, User, TestDefinition } from '../../types';
import { ProjectService, ExecutionService, SystemService, TestLibraryService } from '../../services/mockDatabase';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

import { saveAs } from 'file-saver';

const PMDashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [assignments, setAssignments] = useState<TestAssignment[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [testDefs, setTestDefs] = useState<TestDefinition[]>([]);
  const [loading, setLoading] = useState(true);
  const [mergingProjectId, setMergingProjectId] = useState<string | null>(null);
  const [mergeProgress, setMergeProgress] = useState<number>(0);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [projData, assignData, userData, testData] = await Promise.all([
          ProjectService.fetchProjects(),
          ExecutionService.fetchAssignmentsByEngineer(''), // Fetch all
          SystemService.fetchAllUsers(),
          TestLibraryService.fetchTests()
        ]);
        setProjects(projData || []);
        setAssignments(assignData || []);
        setEngineers(userData.filter(u => u.role === UserRole.ENGINEER) || []);
        setTestDefs(testData || []);
      } catch (error) {
        console.error("Dashboard data fetch failed:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Loading Real-Time Analytics...</p>
      </div>
    );
  }

  // Calculate Stats
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === 'ACTIVE').length;
  const totalAssignments = assignments.length;
  const completedAssignments = assignments.filter(a => a.status === 'COMPLETED').length;
  const pendingReviews = assignments.filter(a => a.workflowStatus === WorkflowStatus.SUBMITTED).length;
  const approvedAssignments = assignments.filter(a => a.workflowStatus === WorkflowStatus.APPROVED).length;
  const rejectedAssignments = assignments.filter(a => a.workflowStatus === WorkflowStatus.REJECTED).length;
  const deletionPendingCount = assignments.filter(a => a.workflowStatus === WorkflowStatus.DELETION_PENDING).length;
  const firstSubmissionApprovals = assignments.filter(a => 
    a.workflowStatus === WorkflowStatus.APPROVED && (!a.rejectionCount || a.rejectionCount === 0)
  ).length;

  // Rejection Rate Calculation
  const totalSubmissions = approvedAssignments + rejectedAssignments;
  const rejectionRate = totalSubmissions > 0 
    ? Math.round((rejectedAssignments / totalSubmissions) * 100) 
    : 0;

  // SLA Tracking (Assignments > 48 hours old and still IN_PROGRESS)
  const fortyEightHoursAgo = new Date();
  fortyEightHoursAgo.setHours(fortyEightHoursAgo.getHours() - 48);
  const agingAssignments = assignments.filter(a => 
    a.status === 'IN_PROGRESS' && new Date(a.createdAt) < fortyEightHoursAgo
  );

  // Engineer Workload
  const workloadData = engineers.map(eng => {
    const count = assignments.filter(a => a.assignedEngineerId === eng.uid && a.status === 'IN_PROGRESS').length;
    return { name: eng.displayName || eng.email.split('@')[0], count };
  }).sort((a, b) => b.count - a.count);

  // Department Progress
  const departments = ['ELECTRICAL', 'MECHANICAL', 'ELV'];
  const deptStats = departments.map(dept => {
    const deptTestIds = testDefs.filter(t => t.department === dept).map(t => t.id);
    const deptAssignments = assignments.filter(a => deptTestIds.includes(a.testDefinitionId));
    const total = deptAssignments.length;
    const completed = deptAssignments.filter(a => a.status === 'COMPLETED').length;
    const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
    return { dept, total, completed, progress };
  });

  const projectStats = projects.map(project => {
    const projectAssignments = assignments.filter(a => a.projectId === project.id);
    const total = projectAssignments.length;
    const completed = projectAssignments.filter(a => a.status === 'COMPLETED').length;
    const approved = projectAssignments.filter(a => a.workflowStatus === WorkflowStatus.APPROVED).length;
    const pending = projectAssignments.filter(a => a.workflowStatus === WorkflowStatus.SUBMITTED).length;
    const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
    const approvedProgress = total > 0 ? Math.round((approved / total) * 100) : 0;

    return {
      ...project,
      total,
      completed,
      approved,
      pending,
      progress,
      approvedProgress
    };
  });

  const handleMergeReports = async (projectId: string) => {
    if (!user) return;
    
    setMergingProjectId(projectId);
    setMergeProgress(0);
    try {
      const url = await ExecutionService.mergeProjectReports(projectId, (p) => setMergeProgress(p));
      const project = projects.find(p => p.id === projectId);
      const fileName = project ? `Merged_Report_${project.name.replace(/\s+/g, '_')}.docx` : 'Merged_Report.docx';
      saveAs(url, fileName);
    } catch (e: any) {
      alert(`Merge failed: ${e.message}`);
    } finally {
      setMergingProjectId(null);
      setMergeProgress(0);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight">Executive Dashboard</h2>
          <p className="text-slate-500 font-medium mt-2">Real-time operational overview across all active projects.</p>
        </div>
        <div className="flex gap-4 items-center">
          <div className="text-right">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">System Health</p>
            <p className="text-emerald-500 font-bold flex items-center gap-2 justify-end">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span> Operational
            </p>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-2xl shadow-inner">🏢</div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Projects</p>
              <h4 className="text-2xl font-black text-slate-900">{totalProjects}</h4>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-blue-500 h-full" style={{ width: `${totalProjects > 0 ? (activeProjects / totalProjects) * 100 : 0}%` }}></div>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 font-bold uppercase tracking-tighter">{activeProjects} Active / {totalProjects - activeProjects} Archived</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-2xl shadow-inner">📋</div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Tests</p>
              <h4 className="text-2xl font-black text-slate-900">{totalAssignments}</h4>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full" style={{ width: `${totalAssignments > 0 ? (completedAssignments / totalAssignments) * 100 : 0}%` }}></div>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 font-bold uppercase tracking-tighter">{completedAssignments} Completed / {totalAssignments - completedAssignments} In Progress</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center text-2xl shadow-inner">⏳</div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pending Review</p>
              <h4 className="text-2xl font-black text-slate-900">{pendingReviews}</h4>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-amber-500 h-full" style={{ width: `${totalAssignments > 0 ? (pendingReviews / totalAssignments) * 100 : 0}%` }}></div>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 font-bold uppercase tracking-tighter">Requires PM Audit Action</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center text-2xl shadow-inner">✅</div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Approved Reports</p>
              <h4 className="text-2xl font-black text-slate-900">{approvedAssignments}</h4>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-purple-500 h-full" style={{ width: `${totalAssignments > 0 ? (approvedAssignments / totalAssignments) * 100 : 0}%` }}></div>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 font-bold uppercase tracking-tighter">{Math.round((approvedAssignments / (totalAssignments || 1)) * 100)}% Finalized Rate</p>
        </div>

        {deletionPendingCount > 0 && user?.role === UserRole.ADMIN && (
          <div className="bg-white p-6 rounded-3xl border border-red-200 shadow-sm hover:shadow-md transition-shadow ring-2 ring-red-50">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center text-2xl shadow-inner">🗑️</div>
              <div>
                <p className="text-[10px] font-black text-red-400 uppercase tracking-widest">Deletion Requests</p>
                <h4 className="text-2xl font-black text-red-900">{deletionPendingCount}</h4>
              </div>
            </div>
            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
              <div className="bg-red-500 h-full" style={{ width: '100%' }}></div>
            </div>
            <p className="text-[10px] text-red-400 mt-2 font-bold uppercase tracking-tighter">Requires Admin Approval</p>
          </div>
        )}
      </div>

      {/* Advanced Indicators Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Engineer Workload */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">Engineer Workload (Active)</h3>
          <div className="space-y-4 flex-1">
            {workloadData.slice(0, 5).map((eng, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-700">{eng.name}</span>
                  <span className="text-slate-400">{eng.count} Tests</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-500 ${eng.count > 5 ? 'bg-red-500' : eng.count > 2 ? 'bg-amber-500' : 'bg-indigo-500'}`} 
                    style={{ width: `${Math.min((eng.count / 10) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            ))}
            {workloadData.length === 0 && <p className="text-center py-10 text-slate-400 italic text-xs">No engineer data available.</p>}
          </div>
        </div>

        {/* Department Progress */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">Departmental Efficiency</h3>
          <div className="space-y-6 flex-1">
            {deptStats.map((dept, idx) => (
              <div key={idx} className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-black
                  ${dept.dept === 'ELECTRICAL' ? 'bg-amber-50 text-amber-600' : 
                    dept.dept === 'MECHANICAL' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'}`}>
                  {dept.dept.charAt(0)}
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-black text-slate-800 uppercase tracking-tighter">{dept.dept}</span>
                    <span className="text-xs font-black text-slate-900">{dept.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-slate-800 h-full" style={{ width: `${dept.progress}%` }}></div>
                  </div>
                  <p className="text-[9px] text-slate-400 font-bold uppercase">{dept.completed} / {dept.total} Completed</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Critical Operations */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">Critical Operations</h3>
          <div className="space-y-4 flex-1">
            {/* Overdue Card */}
            <div className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-2xl shadow-inner">⏱️</div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">OVERDUE (&gt;48H)</p>
                  <h4 className="text-2xl font-black text-slate-900">{agingAssignments.length}</h4>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter">Pending Field Data</p>
                </div>
              </div>
            </div>

            {/* Rejection Rate Card */}
            <div className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-2xl shadow-inner">🔄</div>
                <div>
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">REJECTION RATE</p>
                  <h4 className="text-2xl font-black text-indigo-600">{rejectionRate}%</h4>
                  <p className="text-[9px] text-indigo-300 font-bold uppercase tracking-tighter">Quality Audit Metric</p>
                </div>
              </div>
            </div>

            {/* 1st-Time Approval Card */}
            <div className="p-4 bg-white border border-emerald-100 rounded-2xl flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-2xl shadow-inner">🎯</div>
                <div>
                  <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">1ST-TIME APPROVAL</p>
                  <h4 className="text-2xl font-black text-emerald-600">{firstSubmissionApprovals}</h4>
                  <p className="text-[9px] text-emerald-400 font-bold uppercase tracking-tighter">Zero-Rejection Success</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Project Status Grid */}
      <div className="space-y-4">
        <div className="flex justify-between items-end px-2">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Project Real-Time Status</h3>
          <button 
            onClick={() => navigate('/pm')}
            className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline"
          >
            Manage Detailed Assignments →
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {projectStats.map(project => (
            <div 
              key={project.id}
              className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden group hover:border-indigo-300 transition-all"
            >
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-start">
                  <div className="min-w-0">
                    <h4 className="text-lg font-black text-slate-800 truncate leading-tight">{project.name}</h4>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-tighter truncate">{project.clientName}</p>
                  </div>
                  <span className={`text-[9px] font-black px-2 py-1 rounded-full uppercase tracking-widest ${project.status === 'ACTIVE' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
                    {project.status}
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-end">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Execution Progress</p>
                    <p className="text-sm font-black text-slate-800">{project.progress}%</p>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full transition-all duration-500" style={{ width: `${project.progress}%` }}></div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-end">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Approval Status</p>
                    <p className="text-sm font-black text-slate-800">{project.approvedProgress}%</p>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-purple-500 h-full transition-all duration-500" style={{ width: `${project.approvedProgress}%` }}></div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2">
                  <div className="bg-slate-50 p-3 rounded-2xl text-center">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter mb-1">Total</p>
                    <p className="text-sm font-black text-slate-700">{project.total}</p>
                  </div>
                  <div className="bg-amber-50 p-3 rounded-2xl text-center">
                    <p className="text-[9px] font-black text-amber-400 uppercase tracking-tighter mb-1">Pending</p>
                    <p className="text-sm font-black text-amber-700">{project.pending}</p>
                  </div>
                  <div className="bg-emerald-50 p-3 rounded-2xl text-center">
                    <p className="text-[9px] font-black text-emerald-400 uppercase tracking-tighter mb-1">Done</p>
                    <p className="text-sm font-black text-emerald-700">{project.completed}</p>
                  </div>
                </div>

                {project.approved > 0 && (
                  <button 
                    onClick={() => handleMergeReports(project.id)}
                    disabled={mergingProjectId !== null}
                    className={`w-full py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-2
                      ${mergingProjectId === project.id ? 'bg-slate-100 text-slate-400' : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-100'}`}
                  >
                    {mergingProjectId === project.id ? (
                      <>
                        <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        Merging... {mergeProgress > 0 ? `${mergeProgress}%` : ''}
                      </>
                    ) : (
                      <>
                        <span>📄</span>
                        Merge Approved Reports ({project.approved})
                      </>
                    )}
                  </button>
                )}
              </div>
              
              <button 
                onClick={() => navigate('/pm')}
                className="w-full py-4 bg-slate-50 border-t border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all"
              >
                Enter Project Hub
              </button>
            </div>
          ))}

          {projectStats.length === 0 && (
            <div className="col-span-full py-24 bg-white border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center text-slate-400 gap-4">
              <span className="text-5xl">📁</span>
              <p className="font-bold uppercase tracking-widest text-xs">No project data available to visualize.</p>
            </div>
          )}
        </div>
      </div>

      {/* Recent High-Priority Reviews */}
      {deletionPendingCount > 0 && user?.role === UserRole.ADMIN && (
        <div className="bg-white rounded-3xl border border-red-200 shadow-sm overflow-hidden mb-8">
          <div className="bg-red-50 px-8 py-4 border-b border-red-100 flex justify-between items-center">
            <h3 className="text-xs font-black text-red-700 uppercase tracking-widest flex items-center gap-2">
              <span className="animate-pulse">⚠️</span> Critical: Deletion Requests Awaiting Approval
            </h3>
            <span className="bg-red-200 text-red-800 text-[10px] font-black px-2 py-0.5 rounded-full">
              {deletionPendingCount} PENDING DELETIONS
            </span>
          </div>
          <div className="divide-y divide-slate-100">
            {assignments
              .filter(a => a.workflowStatus === WorkflowStatus.DELETION_PENDING)
              .map(assignment => {
                const proj = projects.find(p => p.id === assignment.projectId);
                return (
                  <div key={assignment.id} className="p-6 flex items-center justify-between hover:bg-red-50/30 transition-colors group">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-red-50 text-red-600 rounded-xl flex items-center justify-center text-lg shadow-inner group-hover:bg-red-600 group-hover:text-white transition-all">
                        🗑️
                      </div>
                      <div>
                        <h5 className="font-black text-slate-800 leading-tight">{assignment.testName}</h5>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                          Project: {proj?.name || 'Unknown'} • Requested: {new Date(assignment.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => navigate('/pm')}
                      className="px-4 py-2 bg-white border border-red-200 rounded-xl text-[10px] font-black text-red-600 uppercase tracking-widest hover:bg-red-600 hover:text-white hover:border-red-600 transition-all shadow-sm"
                    >
                      Go to Project Hub
                    </button>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {pendingReviews > 0 && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="bg-amber-50 px-8 py-4 border-b border-amber-100 flex justify-between items-center">
            <h3 className="text-xs font-black text-amber-700 uppercase tracking-widest flex items-center gap-2">
              <span className="animate-pulse">🔴</span> Urgent: Reports Awaiting PM Audit
            </h3>
            <span className="bg-amber-200 text-amber-800 text-[10px] font-black px-2 py-0.5 rounded-full">
              {pendingReviews} ACTION ITEMS
            </span>
          </div>
          <div className="divide-y divide-slate-100">
            {assignments
              .filter(a => a.workflowStatus === WorkflowStatus.SUBMITTED)
              .slice(0, 5)
              .map(assignment => {
                const proj = projects.find(p => p.id === assignment.projectId);
                return (
                  <div key={assignment.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors group">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center text-lg shadow-inner group-hover:bg-indigo-600 group-hover:text-white transition-all">
                        📋
                      </div>
                      <div>
                        <h5 className="font-black text-slate-800 leading-tight">{assignment.testName}</h5>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                          Project: {proj?.name || 'Unknown'} • Submitted: {new Date(assignment.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => navigate(`/execute/${assignment.id}`)}
                      className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-[10px] font-black text-slate-600 uppercase tracking-widest hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-all shadow-sm"
                    >
                      Review Data
                    </button>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
};

export default PMDashboard;

