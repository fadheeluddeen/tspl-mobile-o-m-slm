
import React, { useState, useEffect, useRef } from 'react';
import { Project, UserRole, TestDefinition, TestAssignment, WorkflowStatus, User } from '../../types';
import { ProjectService, TestLibraryService, ExecutionService, SystemService } from '../../services/mockDatabase';
import { useAuth } from '../../context/AuthContext';
import { useNavigate, useSearchParams } from 'react-router-dom';

import { saveAs } from 'file-saver';

const ProjectManager: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [projects, setProjects] = useState<Project[]>([]);
  const [availableTests, setAvailableTests] = useState<TestDefinition[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [currentAssignments, setCurrentAssignments] = useState<TestAssignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeProject, setActiveProject] = useState<string | null>(null);
  const [activeClient, setActiveClient] = useState<string | null>(null);
  const [isAssigning, setIsAssigning] = useState(false);
  const [selectedTestsForPM, setSelectedTestsForPM] = useState<string[]>([]);
  const [targetEngineerId, setTargetEngineerId] = useState<string>('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [mergingProjectId, setMergingProjectId] = useState<string | null>(null);
  const [mergeProgress, setMergeProgress] = useState<number>(0);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New Project / Edit Modal State
  const [showModal, setShowModal] = useState<'CREATE' | 'EDIT' | null>(null);
  const [dcName, setDcName] = useState('');
  const [projId, setProjId] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [approvedBy, setApprovedBy] = useState('');
  const [clientLogo, setClientLogo] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Delete Confirmation State
  const [showAssignmentDeleteConfirm, setShowAssignmentDeleteConfirm] = useState<string | null>(null);
  
  const [activeDepartment, setActiveDepartment] = useState<'ELECTRICAL' | 'MECHANICAL' | 'ELV' | null>(null);

  const getDept = (a: TestAssignment) =>
    availableTests.find(t => t.id === a.testDefinitionId)?.department ?? null;
  
  const dropdownRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [showActionMenu, setShowActionMenu] = useState(false);

  const [showQuickGuide, setShowQuickGuide] = useState(false);

  const isAdmin = user?.role === UserRole.ADMIN;
  const canManage = isAdmin || user?.role === UserRole.PROJECT_MANAGER;

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      try {
        const [projData, testData, userData] = await Promise.all([
          ProjectService.fetchProjects(),
          TestLibraryService.fetchTests(),
          SystemService.fetchAllUsers()
        ]);
        setProjects(projData || []);
        setAvailableTests(testData || []);
        setEngineers(userData.filter(u => u.role === UserRole.ENGINEER) || []);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, []);

  useEffect(() => {
    if (projects.length > 0) {
      const qProjectId = searchParams.get('projectId');
      if (qProjectId) {
        const found = projects.find(p => p.id === qProjectId);
        if (found) {
          setActiveClient((found.clientName || '').trim());
          setActiveProject(found.id);
          setActiveDepartment(null);
        }
      } else if (!activeProject && projects.length > 0) {
        setActiveProject(projects[0].id);
        setActiveClient((projects[0].clientName || '').trim());
      }
    }
  }, [searchParams, projects]);

  useEffect(() => {
    if (activeProject) {
      loadAssignments(activeProject);
    }
  }, [activeProject]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowActionMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const loadAssignments = async (projectId: string) => {
    const allAssignments = await ExecutionService.fetchAssignmentsByEngineer(''); 
    const filtered = (allAssignments || []).filter(a => a.projectId === projectId);
    setCurrentAssignments(filtered);
    setSelectedTestsForPM(filtered.map(a => a.testDefinitionId));
  };

  const getEngineerName = (uid: string) => {
    const eng = engineers.find(e => e.uid === uid);
    if (!eng) return 'Unassigned';
    if (eng.displayName && eng.displayName !== 'User') return eng.displayName;
    return eng.email.split('@')[0];
  };

  const handleReassign = async (assignmentId: string, newEngineerId: string) => {
    if (!user) return;
    try {
        await ExecutionService.updateAssignmentEngineer(assignmentId, newEngineerId, user);
        setCurrentAssignments(prev => prev.map(a => a.id === assignmentId ? { ...a, assignedEngineerId: newEngineerId } : a));
    } catch (e) {
        alert("Re-assignment failed.");
    }
  };

  const resetForm = () => {
    setDcName('');
    setProjId('');
    setCustomerName('');
    setAddress('');
    setApprovedBy('');
    setClientLogo(null);
    setShowModal(null);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        const img = new Image();
        img.onload = () => {
          setClientLogo(`${base64}|w:${img.width}|h:${img.height}`);
        };
        img.src = base64;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dcName || !customerName || !address || !user) {
      alert("Please fill in all mandatory fields.");
      return;
    }

    setIsProcessing(true);
    try {
      const p: Project = { 
          id: '', 
          projectId: projId,
          name: dcName, 
          clientName: customerName, 
          address: address,
          approvedBy: approvedBy,
          managerId: user.uid, 
          status: 'ACTIVE', 
          createdAt: new Date().toISOString() 
      };
      if (clientLogo) p.clientLogo = clientLogo;
      const id = await ProjectService.createProject(p, user);
      const newProject = { ...p, id };
      setProjects([...(projects || []), newProject]);
      setActiveProject(id);
      resetForm();
    } catch (error) {
      console.error("Project creation failed:", error);
      alert("Failed to create project.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleEditProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeProject || !isAdmin || !user) return;
    
    setIsProcessing(true);
    try {
      const updates: Partial<Project> = {
        projectId: projId,
        name: dcName,
        clientName: customerName,
        address: address,
        approvedBy: approvedBy,
        ...(clientLogo ? { clientLogo } : {}) // Note: this won't remove an existing logo if cleared in UI, but works for now
      };
      // If user completely cleared the logo (if we allow that), we'd need to explicitly set it to null 
      if (!clientLogo) updates.clientLogo = null;

      await ProjectService.updateProject(activeProject, updates, user);
      setProjects(prev => prev.map(p => p.id === activeProject ? { ...p, ...updates } : p));
      resetForm();
    } catch (error) {
      alert("Update failed.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDeleteAssignment = async () => {
    if (!showAssignmentDeleteConfirm || !user) return;
    
    const assignment = currentAssignments.find(a => a.id === showAssignmentDeleteConfirm);
    if (!assignment) return;

    setIsProcessing(true);
    try {
      if (assignment.workflowStatus === WorkflowStatus.DELETION_APPROVED) {
        // Final deletion by PM or Admin
        await ExecutionService.deleteAssignment(showAssignmentDeleteConfirm, user);
        setCurrentAssignments(prev => prev.filter(a => a.id !== showAssignmentDeleteConfirm));
      } else if (isAdmin && assignment.workflowStatus === WorkflowStatus.DELETION_PENDING) {
        // Admin approving the request
        await ExecutionService.approveAssignmentDeletionRequest(showAssignmentDeleteConfirm, user);
        setCurrentAssignments(prev => prev.map(a => a.id === showAssignmentDeleteConfirm ? { ...a, workflowStatus: WorkflowStatus.DELETION_APPROVED } : a));
      } else if (assignment.workflowStatus !== WorkflowStatus.DELETION_PENDING && assignment.workflowStatus !== WorkflowStatus.DELETION_APPROVED) {
        // Initial request for deletion
        if (isAdmin) {
          await ExecutionService.deleteAssignment(showAssignmentDeleteConfirm, user);
          setCurrentAssignments(prev => prev.filter(a => a.id !== showAssignmentDeleteConfirm));
        } else {
          await ExecutionService.requestAssignmentDeletion(showAssignmentDeleteConfirm, user);
          setCurrentAssignments(prev => prev.map(a => a.id === showAssignmentDeleteConfirm ? { ...a, workflowStatus: WorkflowStatus.DELETION_PENDING } : a));
        }
      }
      setShowAssignmentDeleteConfirm(null);
    } catch (error) {
      alert("Action failed.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRejectDeletion = async (assignmentId: string) => {
    if (!isAdmin || !user) return;
    setIsProcessing(true);
    try {
      await ExecutionService.rejectAssignmentDeletion(assignmentId, user);
      setCurrentAssignments(prev => prev.map(a => a.id === assignmentId ? { ...a, workflowStatus: WorkflowStatus.DRAFT } : a));
    } catch (e) {
      alert("Rejection failed.");
    } finally {
      setIsProcessing(false);
    }
  };

  const startEdit = () => {
    const activeP = projects.find(p => p.id === activeProject);
    if (activeP) {
      setDcName(activeP.name);
      setProjId(activeP.projectId || '');
      setCustomerName(activeP.clientName);
      setAddress(activeP.address);
      setApprovedBy(activeP.approvedBy || '');
      setClientLogo(activeP.clientLogo || null);
      setShowModal('EDIT');
    }
  };

  const toggleTestSelection = (testId: string) => {
    setSelectedTestsForPM(prev => 
      (prev || []).includes(testId) ? (prev || []).filter(id => id !== testId) : [...(prev || []), testId]
    );
  };

  const handleSyncAssignments = async () => {
    if (!activeProject || !user) return;
    if (!targetEngineerId) {
        alert("Please select an Engineer to assign these tests to.");
        return;
    }

    setIsSyncing(true);
    try {
      const existingTestIds = (currentAssignments || []).map(a => a.testDefinitionId);
      const testsToAdd = (availableTests || []).filter(t => 
        (selectedTestsForPM || []).includes(t.id) && !existingTestIds.includes(t.id)
      );

      for (const test of testsToAdd) {
        await ProjectService.assignTestToProject(activeProject, test.id, test.name, targetEngineerId, user);
      }

      await loadAssignments(activeProject);
      setIsAssigning(false);
      setTargetEngineerId('');
    } catch (e) {
      alert("Failed to update assignments.");
    } finally {
      setIsSyncing(false);
    }
  };

  const openAssignment = (assignmentId: string) => {
    navigate(`/execute/${assignmentId}`);
  };

  const handleMergeReports = async (projectId?: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const targetId = projectId || activeProject;
    if (!targetId || !user) return;
    
    setMergingProjectId(targetId);
    setMergeProgress(0);
    try {
      const url = await ExecutionService.mergeProjectReports(targetId, (p) => setMergeProgress(p));
      const project = projects.find(p => p.id === targetId);
      const fileName = project ? `Merged_Report_${project.name.replace(/\s+/g, '_')}.docx` : 'Merged_Report.docx';
      saveAs(url, fileName);
    } catch (e: any) {
      alert(`Merge failed: ${e.message}`);
    } finally {
      setMergingProjectId(null);
      setMergeProgress(0);
    }
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-24 gap-4">
      <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
      <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Synchronizing Project Hub...</p>
    </div>
  );

  const activeP = (projects || []).find(p => p.id === activeProject);

  const departmentOrder: Record<string, number> = {
    'ELECTRICAL': 1,
    'MECHANICAL': 2,
    'ELV': 3
  };

  const filteredTests = (availableTests || [])
    .filter(t => (t.name || '').toLowerCase().includes(searchTerm.toLowerCase()))
    .filter(t => t.name !== 'Air Quality Test for White Space')
    .sort((a, b) => {
      const orderA = departmentOrder[a.department || ''] || 99;
      const orderB = departmentOrder[b.department || ''] || 99;
      if (orderA !== orderB) return orderA - orderB;
      return (a.name || '').localeCompare(b.name || '');
    });

  const existingLogos = projects.reduce((acc, p) => {
    if (p.clientLogo && !acc.some(l => l.logo === p.clientLogo)) {
      acc.push({ name: p.clientName, logo: p.clientLogo });
    }
    return acc;
  }, [] as { name: string, logo: string }[]);

  return (
    <div className="space-y-6 animate-fade-in relative">
      
      {/* Create / Edit Project Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-bounce-in max-h-[90vh] flex flex-col">
            <div className="bg-emerald-600 px-6 sm:px-8 py-5 text-white shrink-0">
              <h3 className="text-xl font-black uppercase tracking-tight">{showModal === 'CREATE' ? 'Create New Asset Project' : 'Edit Project Details'}</h3>
              <p className="text-emerald-100 text-xs font-medium mt-1 uppercase tracking-widest">Enterprise Project Interface</p>
            </div>
            
            <form onSubmit={showModal === 'CREATE' ? handleCreateProject : handleEditProject} className="flex-1 min-h-0 p-6 sm:p-8 space-y-4 sm:space-y-5 overflow-y-auto">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">DC Name</label>
                <input 
                  type="text" 
                  value={dcName}
                  onChange={e => setDcName(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-50 focus:border-emerald-500 transition-all font-medium text-slate-800"
                  placeholder="e.g. Noida Data Center Alpha"
                  required
                />
              </div>

              {showModal === 'CREATE' && (
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Project ID</label>
                  <input 
                    type="text" 
                    value={projId}
                    onChange={e => setProjId(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-50 focus:border-emerald-500 transition-all font-medium text-slate-800"
                    placeholder="e.g. PRJ-2024-001"
                  />
                </div>
              )}

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Customer Name</label>
                <input 
                  type="text" 
                  value={customerName}
                  onChange={e => setCustomerName(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-50 focus:border-emerald-500 transition-all font-medium text-slate-800"
                  placeholder="e.g. Global Tech Solutions"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Site Address</label>
                <textarea 
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-50 focus:border-emerald-500 transition-all font-medium text-slate-800 resize-none h-24"
                  placeholder="Complete postal address..."
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Approved By</label>
                <input 
                  type="text" 
                  value={approvedBy}
                  onChange={e => setApprovedBy(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-50 focus:border-emerald-500 transition-all font-medium text-slate-800"
                  placeholder="Reviewer / Manager Name"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Client Logo (Optional)</label>
                {existingLogos.length > 0 && (
                  <select
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-50 focus:border-emerald-500 transition-all text-sm font-medium text-slate-800 mb-2"
                    value={clientLogo || ''}
                    onChange={e => setClientLogo(e.target.value || null)}
                  >
                    <option value="">-- No Logo / Or Upload New Below --</option>
                    {existingLogos.map((l, idx) => (
                      <option key={idx} value={l.logo}>{l.name} Logo</option>
                    ))}
                  </select>
                )}
                <input 
                  type="file" 
                  accept="image/png, image/jpeg"
                  onChange={handleLogoUpload}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-50 focus:border-emerald-500 transition-all text-sm font-medium text-slate-800 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100"
                />
                <div className="flex items-center justify-between mt-2 px-1">
                  {clientLogo ? (
                    <>
                      <button type="button" onClick={() => setClientLogo(null)} className="text-red-500 text-xs font-bold uppercase hover:underline">Remove Logo</button>
                      <img src={clientLogo.split('|')[0]} alt="Client Logo Preview" className="h-10 object-contain inline-block bg-slate-200 rounded p-1" />
                    </>
                  ) : (
                    <span className="text-[10px] text-slate-400 font-medium">No logo selected (a blank space will be used)</span>
                  )}
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-slate-200 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  disabled={isProcessing}
                  className="flex-1 px-6 py-4 bg-emerald-600 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-emerald-100 hover:bg-emerald-700 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  {isProcessing ? 'Saving...' : showModal === 'CREATE' ? 'Initialize' : 'Update Project'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Assignment Delete Confirmation Modal */}
      {showAssignmentDeleteConfirm && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center animate-bounce-in border border-red-100">
            <div className="w-20 h-20 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl shadow-inner">🗑️</div>
            <h3 className="text-2xl font-black text-slate-900 mb-2">{isAdmin ? 'Remove Assignment' : 'Request Deletion'}</h3>
            <p className="text-slate-500 text-sm mb-8 leading-relaxed">
              {isAdmin 
                ? 'Are you sure you want to remove this test assignment? This will permanently delete all data collected.' 
                : 'Are you sure you want to request deletion for this test? An Admin must approve this request before the test is removed.'}
            </p>
            <div className="flex gap-3">
              <button onClick={() => setShowAssignmentDeleteConfirm(null)} className="flex-1 px-4 py-4 bg-slate-100 text-slate-700 font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-slate-200">Cancel</button>
              <button onClick={handleDeleteAssignment} disabled={isProcessing} className="flex-1 px-4 py-4 bg-red-600 text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-red-700 shadow-xl shadow-red-100">
                {isAdmin ? 'Remove Test' : 'Request Deletion'}
              </button>
            </div>
          </div>
        </div>
      )}

       <div className="flex justify-between items-center bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tight">Project Management Hub</h2>
          <p className="text-slate-500 font-medium text-sm mt-1">Orchestrate field operations and test protocols.</p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowQuickGuide(!showQuickGuide)}
            className={`px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-widest transition-all flex items-center gap-2 border
              ${showQuickGuide ? 'bg-indigo-600 text-white border-indigo-700' : 'bg-white text-indigo-600 border-indigo-200 hover:bg-indigo-50'}`}
          >
            <span>💡</span> {showQuickGuide ? 'Hide Guide' : 'Quick Guide'}
          </button>
          {canManage && (
            <button 
              onClick={() => setShowModal('CREATE')}
              className="px-6 py-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 shadow-lg transition-all font-bold flex items-center gap-2 active:scale-95"
            >
              + Create New Project
            </button>
          )}
        </div>
      </div>

      {/* Quick Guide Panel */}
      {showQuickGuide && (
        <div className="bg-indigo-50 border border-indigo-100 rounded-3xl p-8 animate-fade-in space-y-6 shadow-sm">
          <div className="flex justify-between items-center">
            <h3 className="text-indigo-900 font-black uppercase tracking-widest text-sm flex items-center gap-2">
              <span>🚀</span> Project Manager Quick Start Guide
            </h3>
            <button onClick={() => setShowQuickGuide(false)} className="text-indigo-400 hover:text-indigo-600">✕</button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-indigo-100 shadow-sm">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Step 1: Navigation</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                You are currently in the <strong>Project Manager</strong> hub. Here you can see all active and past projects in the left inventory.
              </p>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-indigo-100 shadow-sm">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Step 2: Create Project</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Click <strong>"+ Create New Project"</strong>. Fill in DC Name, Client, Address, and Approver, then click <strong>"INITIALIZE"</strong>.
              </p>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-indigo-100 shadow-sm">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Step 3: Assign Tests</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Select a project, click <strong>"Assign Tests"</strong>, choose an Engineer, check the required tests, and click <strong>"Apply"</strong>.
              </p>
            </div>
          </div>
          
          <div className="flex justify-center">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Refer to the sidebar menu for the full User Manual.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Project List Sidebar */}
        <div className="lg:col-span-4 space-y-4">
            <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] px-2">Project Management Hub</p>
            <div className="space-y-3">
              {Array.from(new Set((projects || []).map(p => (p.clientName || '').trim()))).filter(Boolean).map(client => {
                  const clientProjects = projects.filter(p => (p.clientName || '').trim() === client);
                  const clientProjectsCount = clientProjects.length;
                  const isActive = activeClient === client || (activeProject && (activeP?.clientName || '').trim() === client);
                  return (
                    <div 
                        key={client} 
                        onClick={() => {
                          setActiveClient(client);
                          setActiveDepartment(null);
                          if (clientProjects.length === 1) {
                            setActiveProject(clientProjects[0].id);
                          } else {
                            setActiveProject(null);
                          }
                        }}
                        className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${isActive ? 'bg-white border-emerald-500 shadow-xl scale-[1.02]' : 'bg-white border-slate-100 hover:border-emerald-200 hover:bg-slate-50/50'}`}
                    >
                        <div className="flex justify-between items-start">
                            <h3 className="font-bold text-slate-800 leading-tight truncate mr-2">{client}</h3>
                            <div className="flex flex-col items-end gap-2">
                              <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase whitespace-nowrap bg-slate-100 text-slate-500`}>
                                {clientProjectsCount} {clientProjectsCount === 1 ? 'Project' : 'Projects'}
                              </span>
                            </div>
                        </div>
                    </div>
                  );
              })}
            </div>
            {projects.length === 0 && <p className="text-center py-10 text-slate-400 italic font-medium">No projects available.</p>}
        </div>

        {/* Project Detail & Assignment Area */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-sm min-h-[600px] flex flex-col relative">
            {activeClient && !activeProject ? (
              <div className="flex flex-col h-full">
                <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex items-center gap-4">
                  <button 
                    onClick={() => setActiveClient(null)}
                    className="text-slate-400 hover:text-slate-600 font-bold px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-2 text-sm"
                  >
                    ← Back
                  </button>
                  <h3 className="text-xl font-black text-slate-900 tracking-tight">{activeClient} Projects</h3>
                </div>
                <div className="p-8 space-y-6 flex-1 overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {projects.filter(p => (p.clientName || '').trim() === activeClient).map(p => (
                        <div 
                          key={p.id}
                          onClick={() => setActiveProject(p.id)}
                          className="p-5 rounded-2xl border-2 bg-white border-slate-100 hover:border-emerald-200 hover:bg-slate-50/50 cursor-pointer transition-all"
                        >
                           <div className="flex justify-between items-start mb-2">
                             <h4 className="font-bold text-slate-800 leading-tight truncate">{p.name}</h4>
                             <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase whitespace-nowrap ${p.status === 'ACTIVE' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>{p.status}</span>
                           </div>
                           {p.address && <p className="text-xs text-slate-500 truncate mt-3 font-medium">📍 {p.address}</p>}
                        </div>
                      ))}
                    </div>
                </div>
              </div>
            ) : activeP ? (
                <div className="flex flex-col h-full">
                    <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex justify-between items-start">
                        <div className="space-y-1 flex-1">
                            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Active File</span>
                            <h3 className="text-3xl font-black text-slate-900 tracking-tight">{activeP.name}</h3>
                            <div className="flex items-center gap-2">
                                <p className="text-slate-500 text-sm font-medium">Customer: {activeP.clientName}</p>
                                {activeP.projectId && (
                                    <>
                                        <span className="text-slate-300">|</span>
                                        <p className="text-slate-500 text-sm font-medium">ID: <span className="text-slate-900 font-bold">{activeP.projectId}</span></p>
                                    </>
                                )}
                            </div>
                            {activeP.address && <p className="text-slate-400 text-xs mt-2 italic flex items-center gap-2">📍 {activeP.address}</p>}
                            {activeP.approvedBy && <p className="text-slate-400 text-xs mt-1 flex items-center gap-2">✅ Approved By: <span className="font-bold text-slate-600 uppercase tracking-tight">{activeP.approvedBy}</span></p>}
                        </div>
                        
                        <div className="flex items-center gap-3">
                          {isAdmin && (
                            <div className="relative" ref={menuRef}>
                              <button 
                                onClick={() => setShowActionMenu(!showActionMenu)}
                                className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors text-slate-600"
                                title="Project Actions"
                              >
                                ⚙️
                              </button>
                              {showActionMenu && (
                                <div className="absolute right-0 mt-3 w-48 bg-white border border-slate-200 rounded-2xl shadow-2xl z-[60] overflow-hidden animate-fade-in-down">
                                  <button 
                                    onClick={() => { setShowActionMenu(false); startEdit(); }} 
                                    className="w-full text-left px-5 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                                  >
                                    ✏️ Edit Project
                                  </button>
                                </div>
                              )}
                            </div>
                          )}

                          {canManage && (
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={(e) => handleMergeReports(undefined, e)}
                                disabled={mergingProjectId !== null || currentAssignments.filter(a => a.workflowStatus === WorkflowStatus.APPROVED).length === 0}
                                className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-sm
                                  ${mergingProjectId === activeProject ? 'bg-slate-100 text-slate-400' : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'}`}
                              >
                                {mergingProjectId === activeProject ? (
                                  <>
                                    <div className="w-3 h-3 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
                                    Merging...
                                  </>
                                ) : (
                                  <>
                                    <span>📄</span>
                                    Merge Reports ({currentAssignments.filter(a => a.workflowStatus === WorkflowStatus.APPROVED).length})
                                  </>
                                )}
                              </button>

                              <div className="relative" ref={dropdownRef}>
                                <button 
                                  onClick={() => setIsAssigning(!isAssigning)}
                                  className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-sm
                                    ${isAssigning ? 'bg-slate-800 text-white' : 'bg-indigo-50 text-indigo-700 border border-indigo-200'}`}
                                >
                                  {isAssigning ? 'Close Selector' : 'Assign Tests'}
                                </button>
                                
                                {/* Dropdown Popover */}
                                {isAssigning && (
                                <div className="absolute right-0 mt-3 w-[400px] bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 animate-fade-in-down">
                                  <div className="p-4 border-b border-slate-100 space-y-3">
                                    <div className="space-y-1">
                                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Assign to Engineer</label>
                                      <select 
                                        value={targetEngineerId}
                                        onChange={e => setTargetEngineerId(e.target.value)}
                                        className="w-full px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-700"
                                      >
                                        <option value="">Select an Engineer...</option>
                                        {engineers.map(eng => (
                                          <option key={eng.uid} value={eng.uid}>
                                            {eng.displayName && eng.displayName !== 'User' ? eng.displayName : eng.email}
                                          </option>
                                        ))}
                                      </select>
                                    </div>
                                    <input 
                                      type="text" 
                                      placeholder="Filter design library..."
                                      value={searchTerm}
                                      onChange={e => setSearchTerm(e.target.value)}
                                      className="w-full px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                                    />
                                  </div>
                                  <div className="max-h-[300px] overflow-y-auto p-4 space-y-2">
                                    {(filteredTests || []).map(test => {
                                      const isChecked = (selectedTestsForPM || []).includes(test.id);
                                      const isExisting = (currentAssignments || []).some(a => a.testDefinitionId === test.id);
                                      return (
                                        <label key={test.id} className={`flex items-center justify-between p-3 rounded-xl border transition-colors cursor-pointer 
                                          ${isChecked 
                                            ? (test.department === 'ELECTRICAL' ? 'bg-red-100 border-red-400' 
                                              : test.department === 'MECHANICAL' ? 'bg-blue-100 border-blue-400' 
                                              : test.department === 'ELV' ? 'bg-orange-100 border-orange-400' 
                                              : 'bg-indigo-50 border-indigo-200') 
                                            : (test.department === 'ELECTRICAL' ? 'bg-red-50/50 border-red-100 hover:bg-red-50' 
                                              : test.department === 'MECHANICAL' ? 'bg-blue-50/50 border-blue-100 hover:bg-blue-50' 
                                              : test.department === 'ELV' ? 'bg-orange-50/50 border-orange-100 hover:bg-orange-50' 
                                              : 'bg-white border-slate-100 hover:bg-slate-50')
                                          }`}>
                                          <div className="flex items-center gap-3">
                                            <input 
                                              type="checkbox" 
                                              checked={isChecked} 
                                              disabled={isExisting} 
                                              onChange={() => toggleTestSelection(test.id)} 
                                              className="w-4 h-4 rounded text-indigo-600" 
                                            />
                                            <div>
                                              <p className={`text-sm font-bold ${test.department === 'ELECTRICAL' ? (isChecked ? 'text-red-900' : 'text-red-800') : test.department === 'MECHANICAL' ? (isChecked ? 'text-blue-900' : 'text-blue-800') : test.department === 'ELV' ? (isChecked ? 'text-orange-900' : 'text-orange-800') : 'text-slate-800'}`}>{test.name}</p>
                                              <p className={`text-[10px] font-bold uppercase ${test.department === 'ELECTRICAL' ? (isChecked ? 'text-red-600' : 'text-red-400') : test.department === 'MECHANICAL' ? (isChecked ? 'text-blue-600' : 'text-blue-400') : test.department === 'ELV' ? (isChecked ? 'text-orange-600' : 'text-orange-400') : 'text-slate-400'}`}>{test.department}</p>
                                            </div>
                                          </div>
                                          {isExisting && <span className="text-[9px] font-black text-slate-400">ALREADY LINKED</span>}
                                        </label>
                                      );
                                    })}
                                  </div>
                                  <div className="p-4 bg-slate-50 border-t border-slate-100 rounded-b-2xl flex justify-end">
                                    <button 
                                      onClick={handleSyncAssignments} 
                                      disabled={isSyncing || !targetEngineerId} 
                                      className={`px-6 py-2 rounded-xl text-sm font-bold shadow-lg transition-all
                                        ${targetEngineerId ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}
                                    >
                                      {isSyncing ? 'Linking...' : 'Apply Assignments'}
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="p-8 space-y-6 flex-1 overflow-y-auto">
                        {!activeDepartment ? (
                          <>
                            <div className="flex items-center gap-4 mb-6 pb-4 border-b border-slate-100">
                              <button 
                                onClick={() => setActiveProject(null)}
                                className="text-slate-400 hover:text-slate-600 font-bold px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-2 text-sm"
                              >
                                ← Back
                              </button>
                              <h4 className="text-sm font-black text-slate-700 uppercase tracking-widest flex items-center gap-2">
                                <span className="text-slate-400 truncate max-w-[200px]">{activeClient}</span> <span className="text-slate-300">›</span> {activeP.name}
                              </h4>
                            </div>
                            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Select Department ({currentAssignments ? currentAssignments.length : 0} Total Tests)</h4>
                            <div className="grid grid-cols-3 gap-6">
                              <button
                                onClick={() => setActiveDepartment('ELECTRICAL')}
                                className="p-6 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-2xl flex flex-col items-center justify-center gap-3 transition-colors text-indigo-700"
                              >
                                <span className="text-4xl shadow-sm">⚡</span>
                                <span className="font-black tracking-tight text-lg">Electrical</span>
                                <span className="text-xs font-bold px-3 py-1 bg-indigo-200 rounded-full">{currentAssignments.filter(a => getDept(a) === 'ELECTRICAL').length} Tests</span>
                              </button>
                              <button
                                onClick={() => setActiveDepartment('MECHANICAL')}
                                className="p-6 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-2xl flex flex-col items-center justify-center gap-3 transition-colors text-amber-700"
                              >
                                <span className="text-4xl shadow-sm">⚙️</span>
                                <span className="font-black tracking-tight text-lg">Mechanical</span>
                                <span className="text-xs font-bold px-3 py-1 bg-amber-200 rounded-full">{currentAssignments.filter(a => getDept(a) === 'MECHANICAL').length} Tests</span>
                              </button>
                              <button
                                onClick={() => setActiveDepartment('ELV')}
                                className="p-6 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-2xl flex flex-col items-center justify-center gap-3 transition-colors text-emerald-700"
                              >
                                <span className="text-4xl shadow-sm">📡</span>
                                <span className="font-black tracking-tight text-lg">ELV</span>
                                <span className="text-xs font-bold px-3 py-1 bg-emerald-200 rounded-full">{currentAssignments.filter(a => getDept(a) === 'ELV').length} Tests</span>
                              </button>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="flex items-center gap-4 border-b border-slate-100 pb-4">
                              <button 
                                onClick={() => setActiveDepartment(null)}
                                className="text-slate-400 hover:text-slate-600 font-bold px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-2 text-sm"
                              >
                                ← Back
                              </button>
                              <h4 className="text-sm font-black text-slate-700 uppercase tracking-widest flex items-center gap-2">
                                <span className="text-slate-400 truncate max-w-[200px]">{activeP.name}</span> <span className="text-slate-300">›</span> {activeDepartment}
                              </h4>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-12">
                              {(currentAssignments || []).filter(a => getDept(a) === activeDepartment).map(assignment => (
                                <div 
                                    key={assignment.id} 
                                    onClick={() => openAssignment(assignment.id)}
                                    className={`p-6 bg-white border rounded-2xl cursor-pointer hover:shadow-2xl transition-all group relative overflow-hidden flex flex-col
                                      ${assignment.workflowStatus === WorkflowStatus.SUBMITTED ? 'border-blue-400 ring-2 ring-blue-50' : 'border-slate-200'}`}
                                >
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                            <span className="text-xl">📋</span>
                                        </div>
                                        <div className="flex items-start gap-3">
                                          {canManage && (
                                            <button 
                                              onClick={(e) => { e.stopPropagation(); setShowAssignmentDeleteConfirm(assignment.id); }}
                                              className="p-1.5 bg-white shadow-sm hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg transition-all border border-slate-100 hover:border-red-100"
                                              title={isAdmin ? "Remove Assignment" : "Request Deletion"}
                                            >
                                              🗑️
                                            </button>
                                          )}
                                          <div className="flex flex-col items-end gap-1">
                                            <span className={`text-[9px] font-black px-2 py-1 rounded-full uppercase tracking-widest ${assignment.status === 'COMPLETED' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                                {assignment.status}
                                            </span>
                                            <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter border
                                              ${assignment.workflowStatus === WorkflowStatus.APPROVED ? 'bg-green-50 text-green-600 border-green-200' :
                                                assignment.workflowStatus === WorkflowStatus.SUBMITTED ? 'bg-blue-600 text-white border-blue-700' :
                                                assignment.workflowStatus === WorkflowStatus.REJECTED ? 'bg-red-50 text-red-600 border-red-200' :
                                                'bg-slate-50 text-slate-400 border-slate-200'}`}>
                                              {assignment.workflowStatus === WorkflowStatus.SUBMITTED ? 'PENDING REVIEW' : assignment.workflowStatus}
                                            </span>
                                          </div>
                                        </div>
                                    </div>
                                    <h5 className="font-black text-slate-800 text-lg group-hover:text-indigo-600 leading-tight mb-4">{assignment.testName}</h5>
                                    
                                    {/* Engineer Badge & Re-assignment */}
                                    <div className="mt-auto border-t border-slate-50 pt-4 flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                          <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-500">
                                            {getEngineerName(assignment.assignedEngineerId).charAt(0)}
                                          </div>
                                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter truncate max-w-[100px]">
                                            {getEngineerName(assignment.assignedEngineerId)}
                                          </span>
                                        </div>
                                        
                                        {canManage && (
                                          <select 
                                            onClick={e => e.stopPropagation()}
                                            value={assignment.assignedEngineerId}
                                            onChange={e => handleReassign(assignment.id, e.target.value)}
                                            className="text-[9px] font-black uppercase text-indigo-600 bg-indigo-50 border-none rounded px-2 py-1 outline-none cursor-pointer hover:bg-indigo-100"
                                          >
                                            {engineers.map(eng => (
                                              <option key={eng.uid} value={eng.uid}>
                                                REASSIGN TO: {eng.displayName && eng.displayName !== 'User' ? eng.displayName : eng.email.split('@')[0]}
                                              </option>
                                            ))}
                                          </select>
                                        )}
                                    </div>

                                    {assignment.workflowStatus === WorkflowStatus.SUBMITTED && (
                                      <div className="mt-4 p-2 bg-blue-600 text-white text-[10px] font-black uppercase tracking-widest text-center rounded-lg animate-pulse">
                                         Action Required: PM Audit
                                      </div>
                                    )}

                                    {assignment.workflowStatus === WorkflowStatus.DELETION_PENDING && (
                                      <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-center space-y-3">
                                        <p className="text-[10px] font-black text-amber-700 uppercase tracking-widest animate-pulse">
                                          ⚠️ Deletion Requested - Pending Admin Approval
                                        </p>
                                        {isAdmin && (
                                          <div className="flex gap-2">
                                            <button 
                                              onClick={(e) => { e.stopPropagation(); setShowAssignmentDeleteConfirm(assignment.id); }}
                                              className="flex-1 py-1.5 bg-red-600 text-white text-[9px] font-black uppercase rounded-lg hover:bg-red-700 transition-all"
                                            >
                                              Approve
                                            </button>
                                            <button 
                                              onClick={(e) => { e.stopPropagation(); handleRejectDeletion(assignment.id); }}
                                              className="flex-1 py-1.5 bg-slate-200 text-slate-700 text-[9px] font-black uppercase rounded-lg hover:bg-slate-300 transition-all"
                                            >
                                              Reject
                                            </button>
                                          </div>
                                        )}
                                      </div>
                                    )}

                                    {assignment.workflowStatus === WorkflowStatus.DELETION_APPROVED && (
                                      <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-xl text-center space-y-3">
                                        <p className="text-[10px] font-black text-red-700 uppercase tracking-widest animate-pulse">
                                          🚨 Deletion Approved - Pending PM Action
                                        </p>
                                        {(user?.role === UserRole.PROJECT_MANAGER || isAdmin) && (
                                          <button 
                                            onClick={(e) => { e.stopPropagation(); setShowAssignmentDeleteConfirm(assignment.id); }}
                                            className="w-full py-1.5 bg-red-600 text-white text-[9px] font-black uppercase rounded-lg hover:bg-red-700 transition-all"
                                          >
                                            Confirm Final Deletion
                                          </button>
                                        )}
                                      </div>
                                    )}
                                    <div className="absolute bottom-0 left-0 h-1 w-0 bg-indigo-500 group-hover:w-full transition-all duration-300"></div>
                                </div>
                              ))}

                              {(!currentAssignments || currentAssignments.filter(a => getDept(a) === activeDepartment).length === 0) && (
                                  <div className="col-span-full py-20 text-center border-2 border-dashed border-slate-100 rounded-3xl bg-slate-50/20">
                                      <p className="text-slate-400 font-bold">No {activeDepartment} tests assigned.</p>
                                  </div>
                              )}
                            </div>
                          </>
                        )}
                    </div>
                </div>
            ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-4 py-20">
                    <span className="text-5xl">📁</span>
                    <p className="font-bold">Select a project to manage protocols.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ProjectManager;
