
import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../../types';
import { SystemService } from '../../services/mockDatabase';
import { useAuth } from '../../context/AuthContext';

const UserManagement: React.FC = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [confirmModal, setConfirmModal] = useState<{ 
    type: 'RESET_PASSWORD' | 'TOGGLE_STATUS', 
    targetUser: User 
  } | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);

  // New User Form State
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<UserRole>(UserRole.ENGINEER);
  const [newPassword, setNewPassword] = useState('');
  const [createError, setCreateError] = useState('');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await SystemService.fetchAllUsers();
      setUsers(data || []);
    } catch (e) {
      console.error("Failed to load users:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId: string, newRole: UserRole) => {
    if (!user) return;
    setUpdatingId(userId);
    try {
      await SystemService.updateUserRole(userId, newRole, user);
      setUsers(prev => prev.map(u => u.uid === userId ? { ...u, role: newRole } : u));
    } catch (e) {
      console.error("Failed to update role:", e);
      alert("Role update failed. Please try again.");
    } finally {
      setUpdatingId(null);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || processingAction) return;
    
    setCreateError('');
    if (!newName || !newEmail || !newPassword) {
      setCreateError('Please fill in all required fields.');
      return;
    }

    setProcessingAction(true);
    try {
      await SystemService.adminCreateUser(newEmail, newPassword, newName, newRole, user);
      
      // Cleanup & Refresh
      setNewName('');
      setNewEmail('');
      setNewPassword('');
      setNewRole(UserRole.ENGINEER);
      setIsCreateModalOpen(false);
      alert('User successfully created and logged in audit trails.');
      await loadUsers();
    } catch (e: any) {
      console.error("User creation failed:", e);
      setCreateError(e.message || 'Failed to create user account.');
    } finally {
      setProcessingAction(false);
    }
  };

  const executeAction = async () => {
    if (!confirmModal || !user || processingAction) return;
    setProcessingAction(true);
    const { type, targetUser } = confirmModal;

    try {
      if (type === 'RESET_PASSWORD') {
        await SystemService.resetUserPassword(targetUser.email, user);
        alert(`A password reset link has been sent to ${targetUser.email}`);
      } else if (type === 'TOGGLE_STATUS') {
        const newStatus = targetUser.status === 'DISABLED' ? 'ACTIVE' : 'DISABLED';
        await SystemService.updateUserStatus(targetUser.uid, newStatus, user);
        setUsers(prev => prev.map(u => u.uid === targetUser.uid ? { ...u, status: newStatus } : u));
      }
      setConfirmModal(null);
    } catch (e: any) {
      console.error("Action execution failed:", e);
      alert(e.message || "Failed to complete the administrative action.");
    } finally {
      setProcessingAction(false);
    }
  };

  const getSafeName = (u: User) => {
    if (u.displayName && u.displayName !== 'User' && u.displayName !== 'Unknown User') {
      return u.displayName;
    }
    return u.email ? u.email.split('@')[0] : 'Unnamed User';
  };

  const filteredUsers = users.filter(u => {
    const name = getSafeName(u).toLowerCase();
    const email = (u.email || '').toLowerCase();
    const search = searchTerm.toLowerCase();
    return name.includes(search) || email.includes(search);
  });

  const isAdmin = user?.role === UserRole.ADMIN;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Confirmation Modal */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl animate-bounce-in text-center border border-slate-100">
            <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center text-4xl mb-6 shadow-inner ${confirmModal.type === 'RESET_PASSWORD' ? 'bg-blue-50 text-blue-600' : 'bg-red-50 text-red-600'}`}>
              {confirmModal.type === 'RESET_PASSWORD' ? '🔑' : '🚫'}
            </div>
            <h3 className="text-xl font-black text-slate-900 mb-2 uppercase tracking-tighter">
              {confirmModal.type === 'RESET_PASSWORD' ? 'Reset Password?' : 
               confirmModal.targetUser.status === 'DISABLED' ? 'Enable Account?' : 'Disable Account?'}
            </h3>
            <p className="text-slate-500 text-sm mb-8 leading-relaxed">
              {confirmModal.type === 'RESET_PASSWORD' 
                ? `Send a password recovery email to ${confirmModal.targetUser.email}?` 
                : `Are you sure you want to ${confirmModal.targetUser.status === 'DISABLED' ? 'RE-ACTIVATE' : 'DISABLE'} the account for ${getSafeName(confirmModal.targetUser)}?`}
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setConfirmModal(null)} 
                disabled={processingAction}
                className="flex-1 py-3 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-all uppercase text-xs"
              >
                Cancel
              </button>
              <button 
                onClick={executeAction} 
                disabled={processingAction}
                className={`flex-1 py-3 text-white font-bold rounded-xl shadow-lg transition-all uppercase text-xs flex items-center justify-center gap-2
                  ${confirmModal.type === 'RESET_PASSWORD' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-red-600 hover:bg-red-700'}`}
              >
                {processingAction ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create User Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
           <div className="bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-bounce-in">
              <div className="bg-indigo-600 px-10 py-8 text-white">
                 <h3 className="text-2xl font-black uppercase tracking-tight">Provision New Account</h3>
                 <p className="text-indigo-100 text-xs font-bold mt-1 uppercase tracking-widest opacity-70">Identity Management Interface</p>
              </div>
              
              <form onSubmit={handleCreateUser} className="p-10 space-y-6">
                 {createError && (
                   <div className="p-4 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100">{createError}</div>
                 )}
                 
                 <div className="grid grid-cols-1 gap-6">
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Full Identity Name</label>
                       <input 
                        value={newName} onChange={e => setNewName(e.target.value)}
                        className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all font-bold text-slate-700"
                        placeholder="e.g. John Doe" required
                       />
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Institutional Email</label>
                       <input 
                        type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)}
                        className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all font-bold text-slate-700"
                        placeholder="name@company.com" required
                       />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Security Role</label>
                          <select 
                            value={newRole} onChange={e => setNewRole(e.target.value as UserRole)}
                            className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-50 font-black text-xs text-slate-600 uppercase tracking-wider cursor-pointer"
                          >
                             <option value={UserRole.ADMIN}>ADMIN</option>
                             <option value={UserRole.PROJECT_MANAGER}>PROJECT MANAGER</option>
                             <option value={UserRole.DEVELOPER}>DEVELOPER</option>
                             <option value={UserRole.ENGINEER}>ENGINEER</option>
                          </select>
                       </div>
                       <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Initial Password</label>
                          <input 
                            type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)}
                            className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-50 focus:border-indigo-500 transition-all font-bold text-slate-700"
                            placeholder="••••••••" required
                          />
                       </div>
                    </div>
                 </div>

                 <div className="flex gap-4 pt-6">
                    <button type="button" onClick={() => setIsCreateModalOpen(false)} className="flex-1 py-4 bg-slate-100 text-slate-600 font-black uppercase text-xs tracking-widest rounded-2xl hover:bg-slate-200 transition-all">Cancel</button>
                    <button 
                      type="submit" disabled={processingAction}
                      className="flex-1 py-4 bg-indigo-600 text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center gap-2"
                    >
                      {processingAction ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Create User'}
                    </button>
                 </div>
              </form>
           </div>
        </div>
      )}

      <div className="flex justify-between items-end border-b border-slate-200 pb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">User Management</h2>
          <p className="text-slate-500 mt-1 font-medium italic">Manage system access and Role-Based Access Control (RBAC).</p>
        </div>
        {isAdmin && (
          <button 
            onClick={() => setIsCreateModalOpen(true)}
            className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-lg hover:bg-indigo-700 transition-all active:scale-95 flex items-center gap-2"
          >
            <span>+</span> Create New User
          </button>
        )}
      </div>

      <div className="flex items-center gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <span className="text-slate-400">🔍</span>
        <input 
          type="text" 
          placeholder="Search by name or email..." 
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="flex-1 bg-transparent border-none outline-none text-sm font-medium text-slate-700"
        />
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-20 text-center flex flex-col items-center gap-4">
             <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
             <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">Retrieving User Directory...</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 uppercase tracking-tighter text-[11px]">
                <tr>
                  <th className="px-6 py-4 border-r border-slate-100">User Details</th>
                  <th className="px-6 py-4 border-r border-slate-100 text-center">Status</th>
                  <th className="px-6 py-4 border-r border-slate-100">Current Role</th>
                  <th className="px-6 py-4 border-r border-slate-100 text-center">Modify Role</th>
                  <th className="px-6 py-4 text-center">User Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredUsers.map(u => {
                  const safeName = getSafeName(u);
                  const isDisabled = u.status === 'DISABLED';
                  return (
                    <tr key={u.uid} className={`hover:bg-slate-50/50 transition-colors ${isDisabled ? 'bg-slate-50 opacity-60' : ''}`}>
                      <td className="px-6 py-4 border-r border-slate-100">
                         <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-sm border ${isDisabled ? 'bg-slate-200 text-slate-400 border-slate-300' : 'bg-indigo-50 text-indigo-600 border-indigo-100'}`}>
                               {safeName.charAt(0).toUpperCase()}
                            </div>
                            <div>
                               <p className="font-bold text-slate-800">{safeName}</p>
                               <p className="text-xs text-slate-400 font-medium">{u.email}</p>
                            </div>
                         </div>
                      </td>
                      <td className="px-6 py-4 border-r border-slate-100 text-center">
                         <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border
                          ${isDisabled ? 'bg-red-50 text-red-600 border-red-200' : 'bg-green-50 text-green-600 border-green-200'}`}>
                           {isDisabled ? 'Disabled' : 'Active'}
                         </span>
                      </td>
                      <td className="px-6 py-4 border-r border-slate-100">
                         <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-tight border
                          ${u.role === UserRole.ADMIN ? 'bg-purple-50 text-purple-700 border-purple-200' :
                            u.role === UserRole.DEVELOPER ? 'bg-amber-50 text-amber-700 border-amber-200' :
                            u.role === UserRole.PROJECT_MANAGER ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                            'bg-blue-50 text-blue-700 border-blue-200'}`}>
                          {u.role}
                         </span>
                      </td>
                      <td className="px-6 py-4 border-r border-slate-100 text-center">
                         {updatingId === u.uid ? (
                           <div className="inline-block w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                         ) : (
                           <select 
                             value={u.role} 
                             onChange={e => handleRoleChange(u.uid, e.target.value as UserRole)}
                             className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-600 outline-none focus:ring-2 focus:ring-indigo-500 transition-all cursor-pointer"
                           >
                              <option value={UserRole.ADMIN}>ADMIN</option>
                              <option value={UserRole.DEVELOPER}>DEVELOPER</option>
                              <option value={UserRole.PROJECT_MANAGER}>PROJECT MANAGER</option>
                              <option value={UserRole.ENGINEER}>ENGINEER</option>
                           </select>
                         )}
                      </td>
                      <td className="px-6 py-4 text-center">
                         <div className="flex items-center justify-center gap-2">
                           <button 
                            onClick={() => setConfirmModal({ type: 'RESET_PASSWORD', targetUser: u })}
                            title="Reset Password"
                            className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-600 hover:text-white transition-all text-sm shadow-sm"
                           >
                              🔑
                           </button>
                           <button 
                            onClick={() => setConfirmModal({ type: 'TOGGLE_STATUS', targetUser: u })}
                            title={isDisabled ? "Enable User" : "Disable User"}
                            className={`p-2 rounded-lg transition-all text-sm shadow-sm ${isDisabled ? 'bg-green-50 text-green-600 hover:bg-green-600 hover:text-white' : 'bg-red-50 text-red-600 hover:bg-red-600 hover:text-white'}`}
                           >
                              {isDisabled ? '✅' : '🚫'}
                           </button>
                         </div>
                      </td>
                    </tr>
                  );
                })}
                {filteredUsers.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-20 text-center text-slate-400 italic">No users found matching your criteria.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="bg-amber-50 border border-amber-200 p-6 rounded-2xl flex items-start gap-4">
         <span className="text-2xl">💡</span>
         <div>
            <h4 className="font-bold text-amber-800 text-sm uppercase">Security Note</h4>
            <p className="text-amber-700 text-xs mt-1 leading-relaxed">
              Disabling a user will prevent them from accessing any part of the portal. Password reset emails are sent directly from Firebase infrastructure. 
              Only users with the <strong>ADMIN</strong> role can execute these security operations.
            </p>
         </div>
      </div>
    </div>
  );
};

export default UserManagement;
