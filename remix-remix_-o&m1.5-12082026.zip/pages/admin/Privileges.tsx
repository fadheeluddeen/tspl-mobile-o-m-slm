
import React, { useState, useEffect } from 'react';
import { UserRole, RolePermission } from '../../types';
import { SystemService } from '../../services/mockDatabase';
import { useAuth } from '../../context/AuthContext';

const ACTIONS = [
  { id: 'PROJECT_CREATE', label: 'Create Projects', description: 'Initialize new data center asset projects.' },
  { id: 'PROJECT_DELETE', label: 'Delete Projects', description: 'Permanently remove projects and all history.' },
  { id: 'TEST_LIBRARY_MANAGE', label: 'Manage Library', description: 'Create and edit test protocols and templates.' },
  { id: 'TEST_ASSIGN', label: 'Assign Tests', description: 'Link protocols to projects and assign engineers.' },
  { id: 'TEST_EXECUTE', label: 'Execute Tests', description: 'Enter field readings and generate AI insights.' },
  { id: 'REPORT_APPROVE', label: 'Approve Reports', description: 'PM review and final sign-off for protocols.' },
  { id: 'USER_MANAGE', label: 'User Management', description: 'Change user roles and access levels.' },
  { id: 'AUDIT_VIEW', label: 'View Audit Logs', description: 'Access system-wide event trails.' },
  { id: 'SYSTEM_CONFIG', label: 'System Settings', description: 'Modify global AI and maintenance switches.' },
  { id: 'PRIVILEGE_EDIT', label: 'Edit Privileges', description: 'Modify this RBAC matrix.' }
];

const ROLES = [UserRole.ADMIN, UserRole.PROJECT_MANAGER, UserRole.DEVELOPER, UserRole.ENGINEER];

const Privileges: React.FC = () => {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<RolePermission[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);

  useEffect(() => {
    loadPermissions();
  }, []);

  const loadPermissions = async () => {
    setLoading(true);
    try {
      const data = await SystemService.fetchPermissions();
      // Ensure all roles have an entry
      const normalized = ROLES.map(role => {
        const found = data.find(d => d.id === role);
        return found || { id: role, actions: [] };
      });
      setPermissions(normalized);
    } catch (e) {
      console.error("Failed to load permissions:", e);
    } finally {
      setLoading(false);
    }
  };

  const togglePermission = async (roleId: UserRole, actionId: string) => {
    if (!user || user.role !== UserRole.ADMIN) return;
    
    setSavingId(`${roleId}-${actionId}`);
    try {
      const targetRole = permissions.find(p => p.id === roleId);
      if (!targetRole) return;

      const newActions = targetRole.actions.includes(actionId)
        ? targetRole.actions.filter(a => a !== actionId)
        : [...targetRole.actions, actionId];

      await SystemService.updatePermissions(roleId, newActions, user);
      
      setPermissions(prev => prev.map(p => 
        p.id === roleId ? { ...p, actions: newActions } : p
      ));
    } catch (e) {
      alert("Failed to update privilege.");
    } finally {
      setSavingId(null);
    }
  };

  const hasPermission = (roleId: UserRole, actionId: string) => {
    const role = permissions.find(p => p.id === roleId);
    return role?.actions.includes(actionId) || false;
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex justify-between items-end border-b border-slate-200 pb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Role-Based Access Control (RBAC)</h2>
          <p className="text-slate-500 mt-1 font-medium italic">Define authorized actions for system personas.</p>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-20 text-center flex flex-col items-center gap-4">
             <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
             <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">Loading Privilege Matrix...</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white">
                  <th className="px-8 py-6 w-1/3">
                     <h3 className="font-black text-xs uppercase tracking-widest text-indigo-400">System Capability</h3>
                     <p className="text-[10px] text-slate-500 font-medium mt-1">Authorized Operations</p>
                  </th>
                  {ROLES.map(role => (
                    <th key={role} className="px-4 py-6 text-center border-l border-slate-800">
                       <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tight
                        ${role === UserRole.ADMIN ? 'bg-purple-900 text-purple-200' :
                          role === UserRole.DEVELOPER ? 'bg-amber-900 text-amber-200' :
                          role === UserRole.PROJECT_MANAGER ? 'bg-emerald-900 text-emerald-200' :
                          'bg-blue-900 text-blue-200'}`}>
                        {role.replace('_', ' ')}
                       </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ACTIONS.map(action => (
                  <tr key={action.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-8 py-6">
                       <div className="space-y-1">
                          <p className="font-black text-slate-800 text-sm uppercase tracking-tight">{action.label}</p>
                          <p className="text-xs text-slate-400 font-medium leading-relaxed">{action.description}</p>
                       </div>
                    </td>
                    {ROLES.map(role => {
                      const active = hasPermission(role, action.id);
                      const processing = savingId === `${role}-${action.id}`;
                      return (
                        <td key={role} className="px-4 py-6 text-center border-l border-slate-50 group-hover:bg-slate-50/50">
                           <button
                            onClick={() => togglePermission(role, action.id)}
                            disabled={processing}
                            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-sm mx-auto
                              ${active 
                                ? 'bg-indigo-600 text-white shadow-indigo-100 scale-100' 
                                : 'bg-slate-100 text-slate-300 scale-95 hover:bg-slate-200 hover:text-slate-400'}`}
                           >
                             {processing ? (
                               <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                             ) : active ? (
                               <span className="text-xl">✓</span>
                             ) : (
                               <span className="text-xl opacity-20">×</span>
                             )}
                           </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="bg-indigo-50 border border-indigo-100 p-8 rounded-3xl flex items-start gap-6 shadow-sm">
         <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-lg text-2xl">🔐</div>
         <div className="space-y-2">
            <h4 className="font-black text-indigo-900 text-sm uppercase tracking-widest">Policy Engine Governance</h4>
            <p className="text-indigo-700 text-xs leading-relaxed max-w-3xl">
              Changes to this matrix are applied globally and logged in the system audit trail. 
              Permissions dictate the visibility of navigation items and the operational capacity of the service layer. 
              <strong> ADMIN</strong> roles should always maintain <strong>PRIVILEGE_EDIT</strong> to prevent system lockout.
            </p>
         </div>
      </div>
    </div>
  );
};

export default Privileges;
