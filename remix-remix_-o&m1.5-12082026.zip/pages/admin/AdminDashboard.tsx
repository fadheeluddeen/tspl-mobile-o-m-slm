
import React, { useState, useEffect } from 'react';
import { SystemConfig, TestAssignment, WorkflowStatus } from '../../types';
import { SystemService, ExecutionService } from '../../services/mockDatabase';
import { useAuth } from '../../context/AuthContext';

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [config, setConfig] = useState<SystemConfig | null>(null);
  const [health, setHealth] = useState<any>(null);
  const [pendingDeletions, setPendingDeletions] = useState<TestAssignment[]>([]);

  useEffect(() => {
    // Load initial data
    SystemService.fetchConfig().then(setConfig);
    SystemService.getHealthStatus().then(setHealth);
    
    // Fetch pending deletions
    ExecutionService.fetchAssignmentsByEngineer("").then(all => {
      setPendingDeletions(all.filter(a => a.workflowStatus === WorkflowStatus.DELETION_PENDING));
    });
  }, []);

  const handleApproveDeletion = async (id: string) => {
    if (!user) return;
    try {
      await ExecutionService.approveAssignmentDeletionRequest(id, user);
      setPendingDeletions(prev => prev.filter(a => a.id !== id));
    } catch (e) {
      console.error("Failed to approve deletion:", e);
    }
  };

  const handleRejectDeletion = async (id: string) => {
    if (!user) return;
    try {
      await ExecutionService.rejectAssignmentDeletion(id, user);
      setPendingDeletions(prev => prev.filter(a => a.id !== id));
    } catch (e) {
      console.error("Failed to reject deletion:", e);
    }
  };

  const toggleConfig = async (key: keyof SystemConfig) => {
    if (!config || !user) return;
    const newVal = !config[key];
    const newConfig = { ...config, [key]: newVal };
    setConfig(newConfig);
    await SystemService.updateConfig({ [key]: newVal }, user);
  };

  if (!config || !health) return <div>Loading Control Panel...</div>;

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">System Control Panel</h2>
        <p className="text-slate-500">Global configuration and health monitoring.</p>
      </div>

      {/* Health Monitor */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-400 uppercase">Firestore</div>
          <div className="mt-2 flex items-center text-green-600 font-bold">
            <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
            {health.firestore}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-400 uppercase">Storage</div>
          <div className="mt-2 flex items-center text-green-600 font-bold">
            <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
            {health.storage}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-400 uppercase">Cloud Functions</div>
          <div className="mt-2 flex items-center text-blue-600 font-bold">
            <span className="w-2 h-2 rounded-full bg-blue-500 mr-2"></span>
            {health.functions}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-400 uppercase">Errors (24h)</div>
          <div className="mt-2 flex items-center text-slate-800 font-bold">
            {health.errors === 0 ? 'None' : `${health.errors} Detected`}
          </div>
        </div>
      </div>

      {/* Deletion Requests */}
      {pendingDeletions.length > 0 && (
        <div className="bg-white rounded-lg border border-rose-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-rose-100 bg-rose-50 flex items-center justify-between">
            <h3 className="font-semibold text-rose-800 flex items-center gap-2">
              <span className="text-xl">⚠️</span> Pending Deletion Requests
            </h3>
            <span className="bg-rose-600 text-white text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-widest">
              {pendingDeletions.length} Action Required
            </span>
          </div>
          <div className="divide-y divide-slate-100">
            {pendingDeletions.map(req => (
              <div key={req.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                <div>
                  <h4 className="font-bold text-slate-900">{req.testName}</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Project: <span className="font-semibold text-slate-700">{req.projectName || 'Unknown'}</span> • 
                    Requested by Engineer
                  </p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleRejectDeletion(req.id)}
                    className="px-4 py-2 text-slate-600 text-xs font-bold hover:bg-slate-100 rounded-lg transition-all"
                  >
                    Reject
                  </button>
                  <button 
                    onClick={() => handleApproveDeletion(req.id)}
                    className="px-4 py-2 bg-rose-600 text-white text-xs font-bold rounded-lg hover:bg-rose-700 transition-all shadow-sm"
                  >
                    Approve Deletion
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Feature Governance */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50">
          <h3 className="font-semibold text-slate-800">AI Governance (Gemini API)</h3>
        </div>
        <div className="p-6 space-y-6">
          
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-slate-900">Global AI Master Switch</h4>
              <p className="text-sm text-slate-500">Disabling this stops all Gemini calls via Cloud Functions.</p>
            </div>
            <button
              onClick={() => toggleConfig('aiGlobalEnabled')}
              className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${config.aiGlobalEnabled ? 'bg-indigo-600' : 'bg-slate-200'}`}
            >
              <span className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${config.aiGlobalEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>

          <div className="border-t border-slate-100 pt-6 flex items-center justify-between">
            <div>
              <h4 className="font-medium text-slate-900">Engineer AI Access</h4>
              <p className="text-sm text-slate-500">Allow engineers to trigger insight generation in the field.</p>
            </div>
             <button
              onClick={() => toggleConfig('aiEngineerAccess')}
              disabled={!config.aiGlobalEnabled}
              className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${config.aiEngineerAccess && config.aiGlobalEnabled ? 'bg-indigo-600' : 'bg-slate-200'} ${!config.aiGlobalEnabled ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <span className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${config.aiEngineerAccess && config.aiGlobalEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>

          <div className="border-t border-slate-100 pt-6">
            <h4 className="font-medium text-slate-900 mb-2">Metrics Overview</h4>
            <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-slate-50 p-3 rounded">
                    <div className="text-2xl font-bold text-slate-700">12</div>
                    <div className="text-xs text-slate-500">Active Projects</div>
                </div>
                <div className="bg-slate-50 p-3 rounded">
                    <div className="text-2xl font-bold text-slate-700">84</div>
                    <div className="text-xs text-slate-500">Tests Executed</div>
                </div>
                <div className="bg-slate-50 p-3 rounded">
                    <div className="text-2xl font-bold text-slate-700">1,204</div>
                    <div className="text-xs text-slate-500">AI Tokens Used</div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
