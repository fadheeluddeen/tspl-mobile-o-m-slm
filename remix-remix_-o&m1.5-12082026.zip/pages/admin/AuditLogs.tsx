
import React, { useState, useEffect, useMemo } from 'react';
import { AuditLog } from '../../types';
import { SystemService } from '../../services/mockDatabase';
import { TrendingUp, User, Clock, Calendar, Activity, X } from 'lucide-react';

const AuditLogs: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPayload, setSelectedPayload] = useState<string | null>(null);

  // Filters
  const [filterUser, setFilterUser] = useState('');
  const [filterModule, setFilterModule] = useState('');
  const [filterDate, setFilterDate] = useState('');

  useEffect(() => {
    setLoading(true);
    const unsubscribe = SystemService.subscribeAuditLogs((data) => {
      setLogs(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const loginStats = useMemo(() => {
    const loginLogs = logs.filter(l => l.action === 'LOGIN_SUCCESS');
    const userStats: Record<string, { 
      email: string; 
      name: string; 
      lastLogin: Date | null; 
      todayCount: number; 
      weeklyCount: number;
    }> = {};

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    loginLogs.forEach(l => {
      const email = l.userEmail;
      if (!email) return;

      if (!userStats[email]) {
        userStats[email] = {
          email,
          name: l.userName || email.split('@')[0],
          lastLogin: null,
          todayCount: 0,
          weeklyCount: 0
        };
      }

      const timestamp = l.timestamp?.toDate ? l.timestamp.toDate() : null;
      if (timestamp) {
        // Last Login
        if (!userStats[email].lastLogin || timestamp > userStats[email].lastLogin) {
          userStats[email].lastLogin = timestamp;
        }

        // Today's Count
        if (timestamp.toISOString().split('T')[0] === todayStr) {
          userStats[email].todayCount++;
        }

        // Weekly Count
        if (timestamp >= sevenDaysAgo) {
          userStats[email].weeklyCount++;
        }
      }
    });

    return Object.values(userStats).map(stat => ({
      ...stat,
      weeklyRate: (stat.weeklyCount / 7).toFixed(1)
    })).sort((a, b) => (b.lastLogin?.getTime() || 0) - (a.lastLogin?.getTime() || 0));
  }, [logs]);

  useEffect(() => {
    let result = [...logs];

    if (filterUser) {
      result = result.filter(l => 
        (l.userEmail || '').toLowerCase().includes(filterUser.toLowerCase()) ||
        (l.userName || '').toLowerCase().includes(filterUser.toLowerCase())
      );
    }

    if (filterModule) {
      result = result.filter(l => (l.module || '').toLowerCase().includes(filterModule.toLowerCase()));
    }

    if (filterDate) {
      result = result.filter(l => {
        if (!l.timestamp) return false;
        const dateStr = l.timestamp.toDate ? l.timestamp.toDate().toISOString().split('T')[0] : '';
        return dateStr === filterDate;
      });
    }

    setFilteredLogs(result);
  }, [logs, filterUser, filterModule, filterDate]);

  const exportToCSV = () => {
    const headers = ['Timestamp', 'Full Name', 'Role', 'User Email', 'Module', 'Action', 'Project ID', 'Status', 'Details'];
    const rows = filteredLogs.map(l => [
      l.timestamp?.toDate ? l.timestamp.toDate().toLocaleString() : 'N/A',
      l.userName,
      l.userRole,
      l.userEmail,
      l.module,
      l.action,
      l.projectId || 'N/A',
      l.status,
      l.details || ''
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n"
      + rows.map(e => e.map(cell => `"${cell}"`).join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `audit_logs_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Payload Modal */}
      {selectedPayload && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[80vh] overflow-hidden flex flex-col shadow-2xl">
             <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-900 text-white">
                <h3 className="font-black uppercase tracking-widest text-xs">Technical Data Snapshot</h3>
                <button onClick={() => setSelectedPayload(null)} className="text-white/60 hover:text-white font-bold text-xl">×</button>
             </div>
             <div className="flex-1 overflow-auto p-8 bg-slate-50">
                <pre className="text-[11px] font-mono text-slate-700 bg-white p-6 rounded-xl border border-slate-200 shadow-inner">
                   {JSON.stringify(JSON.parse(selectedPayload), null, 2)}
                </pre>
             </div>
             <div className="p-4 border-t border-slate-100 bg-white flex justify-end">
                <button onClick={() => setSelectedPayload(null)} className="px-6 py-2 bg-slate-900 text-white rounded-lg font-bold text-xs uppercase">Close View</button>
             </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
          <div>
            <h3 className="text-lg font-black text-slate-900 tracking-tight uppercase">Audit Log: User Login Activity</h3>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Real-time monitoring of employee access patterns</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Live Feed</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-white border-b border-slate-100">
              <tr>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Employee</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Last Login</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Today's Logins</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Weekly Rate (Avg/Day)</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loginStats.slice(0, 5).map((stat, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center font-black text-slate-400 text-sm group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-all">
                        {stat.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-black text-slate-800 text-sm tracking-tight">{stat.name}</p>
                        <p className="text-[11px] text-slate-400 font-bold">{stat.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="space-y-0.5">
                      <p className="font-black text-slate-800 text-sm tracking-tight">
                        {stat.lastLogin ? stat.lastLogin.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }).toLowerCase() : 'N/A'}
                      </p>
                      <p className="text-[10px] text-slate-400 font-bold">
                        {stat.lastLogin ? `${stat.lastLogin.getDate()}/${stat.lastLogin.getMonth() + 1}/${stat.lastLogin.getFullYear()}` : '-'}
                      </p>
                    </div>
                  </td>
                  <td className="px-8 py-6 text-center">
                    <span className="inline-flex items-center justify-center w-8 h-8 bg-indigo-50 text-indigo-600 rounded-xl font-black text-sm">
                      {stat.todayCount}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-center">
                    <div className="inline-block text-center">
                      <p className="font-black text-slate-800 text-sm mb-1">{stat.weeklyRate}</p>
                      <div className="w-12 h-1 bg-slate-100 rounded-full overflow-hidden mx-auto">
                        <div 
                          className="h-full bg-indigo-500 rounded-full" 
                          style={{ width: `${Math.min(100, (parseFloat(stat.weeklyRate) / 5) * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6 text-center">
                    <span className="px-3 py-1 bg-slate-100 text-slate-400 text-[10px] font-black rounded-lg uppercase tracking-widest">
                      Away
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="p-6 border-t border-slate-100 bg-slate-50/30 text-center">
          <button className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] hover:text-indigo-700 transition-all">
            View All Activity Logs ({logs.filter(l => l.action === 'LOGIN_SUCCESS').length})
          </button>
        </div>
      </div>

      <div className="flex justify-between items-end border-b border-slate-200 pb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">System Audit Logs</h2>
          <p className="text-slate-500 mt-1 font-medium italic">Monitor real-time system activity and compliance events.</p>
        </div>
        <button 
          onClick={exportToCSV}
          className="px-6 py-2.5 bg-slate-900 text-white rounded-xl font-bold text-xs uppercase tracking-widest shadow-lg hover:bg-slate-800 transition-all flex items-center gap-2"
        >
          <span>📥</span> Export to CSV
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Filter User / Name</label>
          <input 
            type="text" 
            placeholder="Search identity..." 
            value={filterUser}
            onChange={e => setFilterUser(e.target.value)}
            className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Filter Module</label>
          <input 
            type="text" 
            placeholder="e.g. EXECUTION" 
            value={filterModule}
            onChange={e => setFilterModule(e.target.value)}
            className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Filter Date</label>
          <input 
            type="date" 
            value={filterDate}
            onChange={e => setFilterDate(e.target.value)}
            className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-20 text-center flex flex-col items-center gap-4">
             <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
             <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">Streaming Activity Feed...</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 uppercase tracking-tighter text-[10px]">
                  <th className="px-6 py-4 border-r border-slate-50">Timestamp</th>
                  <th className="px-6 py-4 border-r border-slate-50">Full Identity</th>
                  <th className="px-6 py-4 border-r border-slate-50 text-center">Module</th>
                  <th className="px-6 py-4 border-r border-slate-50">Action Event</th>
                  <th className="px-6 py-4 border-r border-slate-50 text-center">Status</th>
                  <th className="px-6 py-4 text-center">Data</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 border-r border-slate-50 text-slate-500 whitespace-nowrap font-mono text-[10px]">
                      {log.timestamp?.toDate ? log.timestamp.toDate().toLocaleString() : 'Pending...'}
                    </td>
                    <td className="px-6 py-4 border-r border-slate-50">
                       <div className="space-y-0.5">
                          <p className="font-black text-slate-800 uppercase tracking-tighter">{log.userName || 'Unknown'}</p>
                          <p className="text-[10px] text-slate-400 font-medium">{log.userEmail}</p>
                          <span className="text-[8px] font-black text-indigo-500 uppercase tracking-[0.1em]">{log.userRole}</span>
                       </div>
                    </td>
                    <td className="px-6 py-4 border-r border-slate-50 text-center">
                      <span className="px-2 py-0.5 bg-slate-100 rounded text-[9px] font-black uppercase tracking-widest text-slate-600">
                        {log.module}
                      </span>
                    </td>
                    <td className="px-6 py-4 border-r border-slate-50">
                       <p className="font-bold text-slate-700 text-[11px] uppercase tracking-tight">{log.action.replace(/_/g, ' ')}</p>
                       <p className="text-[10px] text-slate-400 italic mt-0.5">{log.details || '-'}</p>
                    </td>
                    <td className="px-6 py-4 text-center border-r border-slate-50">
                      <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-tight border
                        ${log.status === 'SUCCESS' ? 'bg-green-50 text-green-700 border-green-200' :
                          log.status === 'FAILED' ? 'bg-red-50 text-red-700 border-red-200' :
                          'bg-blue-50 text-blue-700 border-blue-200'}`}>
                        {log.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                       {log.payload ? (
                         <button 
                          onClick={() => setSelectedPayload(log.payload!)}
                          className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-lg text-[9px] font-black uppercase hover:bg-indigo-600 hover:text-white transition-all shadow-sm"
                         >
                            JSON
                         </button>
                       ) : (
                         <span className="text-slate-300">-</span>
                       )}
                    </td>
                  </tr>
                ))}
                {filteredLogs.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-20 text-center text-slate-400 font-bold italic">No audit logs found matching current filters.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-2xl flex items-start gap-4">
         <span className="text-2xl">📋</span>
         <div>
            <h4 className="font-bold text-indigo-800 text-sm uppercase">Audit Intelligence</h4>
            <p className="text-indigo-700 text-xs mt-1 leading-relaxed">
              This log tracks all critical transitions including protocol creation, data submission, and project modifications. 
              Logs are immutable and retained for regulatory compliance purposes.
            </p>
         </div>
      </div>
    </div>
  );
};

export default AuditLogs;
