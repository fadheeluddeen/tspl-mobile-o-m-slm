
import React, { useState, useEffect, useMemo } from 'react';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  Timestamp,
  orderBy
} from 'firebase/firestore';
import { db } from '../../services/firebase';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line,
  ComposedChart,
  Area
} from 'recharts';
import { utils, writeFile } from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { 
  Calendar, 
  RefreshCw, 
  Briefcase, 
  ClipboardCheck, 
  Send, 
  CheckCircle, 
  Users, 
  Zap,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  X,
  FileDown,
  FileSpreadsheet
} from 'lucide-react';

// --- Types ---
interface DashboardData {
  projects: any[];
  assignments: any[];
  executions: any[];
  users: any[];
  testDefinitions: any[];
}

interface KPIProps {
  title: string;
  value: number | string;
  subtext: string;
  icon: React.ReactNode;
  color: string;
  trend?: {
    value: number;
    isUp: boolean;
  };
  breakdown?: { label: string; value: number; color: string }[];
}

// --- Components ---

const KPICard: React.FC<KPIProps> = ({ title, value, subtext, icon, color, trend, breakdown }) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-2 transition-all hover:shadow-md">
    <div className="flex justify-between items-start">
      <div className={`p-2.5 rounded-xl ${color} bg-opacity-10 text-opacity-100`}>
        {icon}
      </div>
      {trend && (
        <div className={`flex items-center gap-0.5 text-xs font-bold ${trend.isUp ? 'text-emerald-600' : 'text-rose-600'}`}>
          {trend.isUp ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {trend.value}%
        </div>
      )}
    </div>
    <div className="mt-2">
      <h3 className="text-slate-500 text-xs font-bold uppercase tracking-wider">{title}</h3>
      <p className="text-3xl font-black text-slate-900 mt-1">{value}</p>
    </div>
    
    {breakdown && breakdown.length > 0 && (
      <div className="flex flex-col gap-1 mt-1.5">
        {breakdown.map((item, idx) => (
          <div key={idx} className="flex items-center gap-2">
            <div className={`w-1.5 h-1.5 rounded-full ${item.color}`}></div>
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-tighter">
              {item.label}: {item.value}
            </span>
          </div>
        ))}
      </div>
    )}

    <p className="text-slate-400 text-[10px] font-medium mt-1 uppercase tracking-tight">{subtext}</p>
  </div>
);

const ChartCard: React.FC<{ title: string; children: React.ReactNode; height?: number }> = ({ title, children, height = 350 }) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col gap-6">
    <h3 className="text-slate-800 text-sm font-bold flex items-center gap-2">
      <div className="w-1.5 h-4 bg-indigo-600 rounded-full"></div>
      {title}
    </h3>
    <div style={{ width: '100%', height }}>
      {children}
    </div>
  </div>
);

const TableCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
    <div className="p-6 border-b border-slate-50">
      <h3 className="text-slate-800 text-sm font-bold flex items-center gap-2">
        <div className="w-1.5 h-4 bg-indigo-600 rounded-full"></div>
        {title}
      </h3>
    </div>
    <div className="overflow-x-auto">
      {children}
    </div>
  </div>
);

const AdoptionDashboard: React.FC = () => {
  const [dateFilter, setDateFilter] = useState<'30d' | 'custom'>('30d');
  const [customStartDate, setCustomStartDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().split('T')[0];
  });
  const [customEndDate, setCustomEndDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<DashboardData>({ projects: [], assignments: [], executions: [], users: [], testDefinitions: [] });
  const [selectedPM, setSelectedPM] = useState<{ name: string; projects: string[] } | null>(null);
  const [selectedApprovedTests, setSelectedApprovedTests] = useState<{ name: string; tests: string[] } | null>(null);
  const [selectedEngineerTests, setSelectedEngineerTests] = useState<{ name: string; tests: string[]; title?: string; color?: string } | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const now = new Date();
      let startDate = new Date();
      let endDate = new Date();
      
      if (dateFilter === 'today') {
        startDate.setHours(0, 0, 0, 0);
      } else if (dateFilter === '7d') {
        startDate.setDate(now.getDate() - 7);
      } else if (dateFilter === '30d') {
        startDate.setDate(now.getDate() - 30);
      } else if (dateFilter === 'custom' && customStartDate) {
        startDate = new Date(customStartDate);
        startDate.setHours(0, 0, 0, 0);
        if (customEndDate) {
          endDate = new Date(customEndDate);
          endDate.setHours(23, 59, 59, 999);
        }
      }

      // Fetch Users
      const usersSnap = await getDocs(collection(db, 'users'));
      const users = usersSnap.docs.map(doc => ({ uid: doc.id, ...doc.data() }));

      // Fetch Test Definitions
      const testDefsSnap = await getDocs(collection(db, 'testDefinitions'));
      const testDefinitions = testDefsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Fetch ALL Projects for the projectMap (to avoid "Unknown Project")
      // We don't filter projects by date here because old projects can have new assignments
      const projectsSnap = await getDocs(collection(db, 'projects'));
      const projects = projectsSnap.docs.map(doc => {
        const data = doc.data();
        let createdAt = data.createdAt;
        if (createdAt && typeof createdAt.toDate === 'function') {
          createdAt = createdAt.toDate().toISOString();
        }
        return { id: doc.id, ...data, createdAt };
      });

      // Fetch Assignments - Fetch ALL to show complete project-wise status
      const assignmentsSnap = await getDocs(collection(db, 'assignments'));
      const assignments = assignmentsSnap.docs.map(doc => {
        const data = doc.data();
        // Normalize projectId
        let projectId = data.projectId || data.project_id || data.projectRef || data.project;
        if (projectId && typeof projectId === 'object') {
          // Handle Firestore DocumentReference or similar objects
          if (projectId.id) projectId = projectId.id;
          else if (projectId.path) projectId = projectId.path.split('/').pop();
          else if ('id' in projectId) projectId = (projectId as any).id;
          else if ('path' in projectId) projectId = (projectId as any).path.split('/').pop();
        }
        if (typeof projectId === 'string' && projectId.includes('/')) {
          projectId = projectId.split('/').pop();
        }
        return { id: doc.id, ...data, projectId };
      });

      // Also check 'testAssignments' - Fetch ALL
      let extraAssignments: any[] = [];
      try {
        const altSnap = await getDocs(collection(db, 'testAssignments'));
        extraAssignments = altSnap.docs.map(doc => {
          const data = doc.data();
          // Normalize projectId
          let projectId = data.projectId || data.project_id || data.projectRef || data.project;
          if (projectId && typeof projectId === 'object') {
            if (projectId.id) projectId = projectId.id;
            else if (projectId.path) projectId = projectId.path.split('/').pop();
            else if ('id' in projectId) projectId = (projectId as any).id;
            else if ('path' in projectId) projectId = (projectId as any).path.split('/').pop();
          }
          if (typeof projectId === 'string' && projectId.includes('/')) {
            projectId = projectId.split('/').pop();
          }
          return { id: doc.id, ...data, projectId };
        });
      } catch (e) {
        // Collection might not exist
      }

      const allAssignments = [...assignments, ...extraAssignments];

      // Fetch Executions
      let executions: any[] = [];
      try {
        const executionsQuery = query(
          collection(db, 'testExecutions'), 
          where('submittedAt', '>=', startDate.toISOString()),
          where('submittedAt', '<=', endDate.toISOString())
        );
        const executionsSnap = await getDocs(executionsQuery);
        executions = executionsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      } catch (e) {
        // Collection might not exist
      }

      setData({ projects, assignments: allAssignments, executions, users, testDefinitions });
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (dateFilter !== 'custom') {
      fetchData();
    }
  }, [dateFilter]);

  // Handle custom date changes
  const handleCustomDateSubmit = () => {
    if (dateFilter === 'custom' && customStartDate && customEndDate) {
      fetchData();
    }
  };

  // --- Calculations ---
  const stats = useMemo(() => {
    const now = new Date();
    let startDate = new Date();
    let endDate = new Date();
    
    if (dateFilter === 'today') {
      startDate.setHours(0, 0, 0, 0);
    } else if (dateFilter === '7d') {
      startDate.setDate(now.getDate() - 7);
    } else if (dateFilter === '30d') {
      startDate.setDate(now.getDate() - 30);
    } else if (dateFilter === 'custom' && customStartDate) {
      startDate = new Date(customStartDate);
      startDate.setHours(0, 0, 0, 0);
      if (customEndDate) {
        endDate = new Date(customEndDate);
        endDate.setHours(23, 59, 59, 999);
      }
    }

    const periodAssignments = data.assignments.filter(a => {
      if (!a.createdAt) return false;
      const created = new Date(a.createdAt);
      return created >= startDate && created <= endDate;
    });

    const projectsCreated = data.projects.length;
    const testsAssigned = periodAssignments.length;
    
    // Map of testDefinitionId to department
    const testDefMap: Record<string, string> = {};
    data.testDefinitions.forEach(td => {
      testDefMap[td.id] = td.department;
    });

    const getDeptBreakdown = (tests: any[]) => {
      const counts = { ELECTRICAL: 0, MECHANICAL: 0 };
      tests.forEach(t => {
        const dept = testDefMap[t.testDefinitionId];
        if (dept === 'ELECTRICAL') counts.ELECTRICAL++;
        else if (dept === 'MECHANICAL') counts.MECHANICAL++;
      });
      return [
        { label: 'Electrical', value: counts.ELECTRICAL, color: 'bg-amber-500' },
        { label: 'Mechanical', value: counts.MECHANICAL, color: 'bg-blue-500' }
      ];
    };

    const assignedBreakdown = getDeptBreakdown(periodAssignments || []);

    // Tests Submitted: status = SUBMITTED or APPROVED
    const submittedTests = (periodAssignments || []).filter(a => ['SUBMITTED', 'APPROVED'].includes(a.workflowStatus));
    const testsSubmitted = submittedTests.length;
    const submittedBreakdown = getDeptBreakdown(submittedTests);
    
    // Tests Approved: status = APPROVED
    const approvedTests = (periodAssignments || []).filter(a => a.workflowStatus === 'APPROVED');
    const testsApproved = approvedTests.length;
    const approvedBreakdown = getDeptBreakdown(approvedTests);
    
    // Active Engineers: Unique engineerId from submitted tests
    const activeEngineersSet = new Set(submittedTests.map(t => t.assignedEngineerId));
    const activeEngineers = activeEngineersSet.size;
    
    // Engineer Utilization: submitted tests / active engineers
    const utilization = activeEngineers > 0 ? (testsSubmitted / activeEngineers).toFixed(1) : 0;

    // Project Activity Split
    const assignedProjectIds = new Set(periodAssignments.map(a => a.projectId));
    const activeProjectsCount = assignedProjectIds.size;
    const idleProjectsCount = Math.max(0, projectsCreated - activeProjectsCount);
    
    // Project ID to Name Map
    const projectMap: Record<string, string> = {};
    const projectNameMap: Record<string, string> = {};
    data.projects.forEach(p => {
      projectMap[p.id] = p.name;
      if (p.name) projectNameMap[p.name.toLowerCase()] = p.name;
    });

    // 1. Users with Roles
    const usersList = data.users
      .filter(u => u.role === 'PROJECT_MANAGER' || u.role === 'ENGINEER')
      .map(u => ({
        name: u.displayName || u.email.split('@')[0],
        role: u.role || 'NONE',
        email: u.email
      })).sort((a, b) => a.name.localeCompare(b.name));

    // 2. PM Performance Breakdown
    const pmStats: Record<string, { name: string; approvedCount: number; projects: Set<string>; approvedTests: Set<string> }> = {};
    
    // Initialize with all PMs found in users
    data.users.filter(u => u.role === 'PROJECT_MANAGER').forEach(u => {
      pmStats[u.uid] = { 
        name: u.displayName || u.email.split('@')[0], 
        approvedCount: 0, 
        projects: new Set(),
        approvedTests: new Set()
      };
    });

    // Map projects to PMs
    data.projects.forEach(p => {
      const pmId = p.managerId || 'unknown';
      if (!pmStats[pmId]) {
        const pm = data.users.find(u => u.uid === pmId);
        const pmName = pm ? (pm.displayName || pm.email.split('@')[0]) : 'Unknown PM';
        pmStats[pmId] = { name: pmName, approvedCount: 0, projects: new Set(), approvedTests: new Set() };
      }
      pmStats[pmId].projects.add(p.name);
    });

    // Helper to resolve project name from an assignment
    const resolveProjectName = (a: any) => {
      // 1. Try ID lookup (Highest priority)
      if (a.projectId && typeof a.projectId === 'string' && projectMap[a.projectId]) {
        return projectMap[a.projectId];
      }
      
      // 2. Try direct fields, but ignore "Unknown Project" placeholders
      const candidates = [
        a.projectName,
        a.projectTitle,
        a.project_name,
        a.project_title,
        a.dcName,
        a.siteName
      ];
      
      for (const cand of candidates) {
        if (cand && cand !== 'Unknown Project') return cand;
      }
      
      // 3. Try if projectId is actually the name
      if (a.projectId && typeof a.projectId === 'string') {
        const lower = a.projectId.toLowerCase();
        if (projectNameMap[lower]) return projectNameMap[lower];
        
        // If it's a string and doesn't look like a typical Firestore ID (e.g. has spaces)
        if (a.projectId.includes(' ') && a.projectId !== 'Unknown Project') {
          return a.projectId;
        }
      }
      
      // 4. Try nested project object
      if (a.project && typeof a.project === 'object') {
        const nestedName = a.project.name || a.project.title || a.project.dcName;
        if (nestedName && nestedName !== 'Unknown Project') return nestedName;
      }
      
      return 'Unknown Project';
    };

    // Count tests approved by each PM (using reviewedBy field)
    data.assignments.forEach(a => {
      if (a.workflowStatus === 'APPROVED' && a.reviewedBy && pmStats[a.reviewedBy]) {
        pmStats[a.reviewedBy].approvedCount++;
        const projectName = resolveProjectName(a);
        pmStats[a.reviewedBy].approvedTests.add(`[${projectName}] ${a.testName}`);
      }
    });

    const pmList = Object.values(pmStats).sort((a, b) => b.approvedCount - a.approvedCount || b.projects.size - a.projects.size);

    // 3. Tests under each Engineer
    const engStats: Record<string, { 
      name: string; 
      testCount: number; 
      submittedCount: number; 
      approvedCount: number;
      testNames: Set<string>;
      submittedNames: Set<string>;
      approvedNames: Set<string>;
    }> = {};

    data.assignments.forEach(a => {
      const engId = a.assignedEngineerId;
      const eng = data.users.find(u => u.uid === engId);
      const engName = eng ? (eng.displayName || eng.email.split('@')[0]) : (a.assignedEngineerName || 'Unknown');
      
      if (!engStats[engId]) {
        engStats[engId] = { 
          name: engName, 
          testCount: 0, 
          submittedCount: 0, 
          approvedCount: 0,
          testNames: new Set(),
          submittedNames: new Set(),
          approvedNames: new Set()
        };
      }
      
      const projectName = resolveProjectName(a);
      const testEntry = `[${projectName}] ${a.testName}`;

      engStats[engId].testCount++;
      engStats[engId].testNames.add(testEntry);

      if (['SUBMITTED', 'APPROVED'].includes(a.workflowStatus)) {
        engStats[engId].submittedCount++;
        engStats[engId].submittedNames.add(testEntry);
      }

      if (a.workflowStatus === 'APPROVED') {
        engStats[engId].approvedCount++;
        engStats[engId].approvedNames.add(testEntry);
      }
    });
    const engList = Object.values(engStats).sort((a, b) => b.testCount - a.testCount);

    // Project-wise Test Status
    const projectWiseStatus = data.projects.map(project => {
      const projectAssignments = data.assignments.filter(a => {
        const aProjId = a.projectId;
        const pId = project.id;
        const pName = project.name;
        
        // Exact ID match
        if (aProjId === pId) return true;
        
        // Match by project name (case-insensitive)
        if (typeof aProjId === 'string' && pName && aProjId.toLowerCase() === pName.toLowerCase()) return true;
        
        // Match by assignment's projectName field
        if (a.projectName && pName && a.projectName.toLowerCase() === pName.toLowerCase()) return true;

        // Try normalized project ID from some systems
        if (typeof aProjId === 'string' && aProjId.includes('/') && aProjId.split('/').pop() === pId) return true;

        return false;
      });
      
      const getCounts = (dept: string) => {
        const deptTests = projectAssignments.filter(a => {
          const d = testDefMap[a.testDefinitionId];
          return d && d.toUpperCase() === dept.toUpperCase();
        });
        return {
          assigned: deptTests.length,
          inProgress: deptTests.filter(a => a.status === 'IN_PROGRESS' || a.workflowStatus === 'DRAFT').length,
          completed: deptTests.filter(a => a.status === 'COMPLETED' || a.workflowStatus === 'APPROVED' || a.workflowStatus === 'SUBMITTED').length
        };
      };

      return {
        id: project.id,
        name: project.name,
        total: projectAssignments.length,
        electrical: getCounts('ELECTRICAL'),
        mechanical: getCounts('MECHANICAL')
      };
    }).sort((a, b) => b.total - a.total);

    return {
      projectsCreated,
      testsAssigned,
      testsSubmitted,
      testsApproved,
      activeEngineers,
      utilization,
      activeProjectsCount,
      idleProjectsCount,
      usersList,
      pmList,
      engList,
      assignedBreakdown,
      submittedBreakdown,
      approvedBreakdown,
      projectWiseStatus
    };
  }, [data, dateFilter, customStartDate, customEndDate]);

  // --- Chart Data ---

  // A. Adoption Funnel
  const funnelData = [
    { name: 'Projects', value: stats.projectsCreated, fill: '#6366f1' },
    { name: 'Assigned', value: stats.testsAssigned, fill: '#818cf8' },
    { name: 'Submitted', value: stats.testsSubmitted, fill: '#a5b4fc' },
    { name: 'Approved', value: stats.testsApproved, fill: '#c7d2fe' },
  ];

  // B. Submission vs Approval (Donut)
  const approvalData = [
    { name: 'Approved', value: stats.testsApproved },
    { name: 'Pending/Rejected', value: Math.max(0, stats.testsSubmitted - stats.testsApproved) },
  ];
  const APPROVAL_COLORS = ['#10b981', '#f43f5e'];

  // C. Project Activity Split (Pie)
  const projectSplitData = [
    { name: 'Active Projects', value: stats.activeProjectsCount },
    { name: 'Idle Projects', value: stats.idleProjectsCount },
  ];
  const PROJECT_COLORS = ['#6366f1', '#cbd5e1'];

  // D. Engineer Activity (Bar)
  const engineerActivityData = useMemo(() => {
    const counts: Record<string, number> = {};
    data.assignments.filter(a => ['SUBMITTED', 'APPROVED'].includes(a.workflowStatus)).forEach(a => {
      const engId = a.assignedEngineerId;
      const eng = data.users.find(u => u.uid === engId);
      const name = eng ? (eng.displayName || eng.email.split('@')[0]) : (a.assignedEngineerName || engId || 'Unknown');
      counts[name] = (counts[name] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [data]);

  // E. Adoption Trend (Line)
  const trendData = useMemo(() => {
    const days: Record<string, { projects: number; assigned: number; submitted: number }> = {};
    
    // Initialize days
    const now = new Date();
    const range = dateFilter === '30d' ? 30 : 1; // Default to 30 if custom but not yet calculated
    
    // If custom, we need to calculate range
    let actualRange = range;
    if (dateFilter === 'custom') {
      const start = new Date(customStartDate);
      const end = new Date(customEndDate);
      actualRange = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    }

    for (let i = actualRange - 1; i >= 0; i--) {
      const d = new Date();
      if (dateFilter === 'custom') {
        d.setTime(new Date(customEndDate).getTime());
      }
      d.setDate(d.getDate() - i);
      const key = d.toISOString().split('T')[0];
      days[key] = { projects: 0, assigned: 0, submitted: 0 };
    }

    data.projects.forEach(p => {
      const key = p.createdAt?.split('T')[0];
      if (days[key]) days[key].projects++;
    });

    data.assignments.forEach(a => {
      const key = a.createdAt?.split('T')[0];
      if (days[key]) days[key].assigned++;
      if (['SUBMITTED', 'APPROVED'].includes(a.workflowStatus)) {
        if (days[key]) days[key].submitted++;
      }
    });

    return Object.entries(days).map(([date, counts]) => ({
      date: date.split('-').slice(1).join('/'),
      ...counts
    }));
  }, [data, dateFilter]);

  if (loading) {
    return (
      <div className="flex flex-col gap-8 animate-pulse">
        <div className="flex justify-between items-center">
          <div className="h-8 w-48 bg-slate-200 rounded-lg"></div>
          <div className="h-10 w-64 bg-slate-200 rounded-lg"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-32 bg-slate-200 rounded-2xl"></div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-[400px] bg-slate-200 rounded-2xl"></div>
          ))}
        </div>
      </div>
    );
  }

  const dateLabel = dateFilter === '30d' ? 'Last 30 Days' : 'Custom Range';

  const exportToExcel = () => {
    const workbook = utils.book_new();
    
    // Summary Sheet
    const summaryData = [
      ['Metric', 'Total', 'Electrical', 'Mechanical'],
      ['Projects Created', stats.projectsCreated, '-', '-'],
      ['Tests Assigned', stats.testsAssigned, stats.assignedBreakdown?.[0]?.value || 0, stats.assignedBreakdown?.[1]?.value || 0],
      ['Tests Submitted', stats.testsSubmitted, stats.submittedBreakdown?.[0]?.value || 0, stats.submittedBreakdown?.[1]?.value || 0],
      ['Tests Approved', stats.testsApproved, stats.approvedBreakdown?.[0]?.value || 0, stats.approvedBreakdown?.[1]?.value || 0],
      ['Active Engineers', stats.activeEngineers, '-', '-'],
      ['Utilization', stats.utilization, '-', '-']
    ];
    const summarySheet = utils.aoa_to_sheet(summaryData);
    utils.book_append_sheet(workbook, summarySheet, 'Summary');

    // PM Performance
    const pmData = [
      ['PM Name', 'Approved Tests', 'Active Projects'],
      ...stats.pmList.map(pm => [pm.name, pm.approvedCount, pm.projects.size])
    ];
    const pmSheet = utils.aoa_to_sheet(pmData);
    utils.book_append_sheet(workbook, pmSheet, 'PM Performance');

    // Engineer Performance
    const engData = [
      ['Engineer Name', 'Assigned', 'Submitted', 'Approved'],
      ...stats.engList.map(eng => [eng.name, eng.testCount, eng.submittedCount, eng.approvedCount])
    ];
    const engSheet = utils.aoa_to_sheet(engData);
    utils.book_append_sheet(workbook, engSheet, 'Engineer Performance');

    writeFile(workbook, `Adoption_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text('Dashboard Report', 14, 22);
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, 30);
    doc.text(`Period: ${dateLabel}`, 14, 35);

    // Summary Table
    autoTable(doc, {
      startY: 45,
      head: [['Metric', 'Total', 'Electrical', 'Mechanical']],
      body: [
        ['Projects Created', stats.projectsCreated, '-', '-'],
        ['Tests Assigned', stats.testsAssigned, stats.assignedBreakdown?.[0]?.value || 0, stats.assignedBreakdown?.[1]?.value || 0],
        ['Tests Submitted', stats.testsSubmitted, stats.submittedBreakdown?.[0]?.value || 0, stats.submittedBreakdown?.[1]?.value || 0],
        ['Tests Approved', stats.testsApproved, stats.approvedBreakdown?.[0]?.value || 0, stats.approvedBreakdown?.[1]?.value || 0],
        ['Active Engineers', stats.activeEngineers, '-', '-'],
        ['Utilization', stats.utilization, '-', '-']
      ],
      theme: 'grid',
      headStyles: { fillColor: [99, 102, 241] }
    });

    // PM Performance
    doc.text('PM Performance', 14, (doc as any).lastAutoTable.finalY + 10);
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 15,
      head: [['PM Name', 'Approved Tests', 'Active Projects']],
      body: stats.pmList.map(pm => [pm.name, pm.approvedCount, pm.projects.size]),
      theme: 'striped'
    });

    // Engineer Performance
    doc.text('Engineer Performance', 14, (doc as any).lastAutoTable.finalY + 10);
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 15,
      head: [['Engineer Name', 'Assigned', 'Submitted', 'Approved']],
      body: stats.engList.map(eng => [eng.name, eng.testCount, eng.submittedCount, eng.approvedCount]),
      theme: 'striped'
    });

    doc.save(`Adoption_Report_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Top Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Dashboard</h1>
          <p className="text-slate-500 text-sm font-medium">Executive overview of system utilization and workflow efficiency.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3 bg-white p-1.5 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-1 px-2">
            <Calendar size={16} className="text-slate-400" />
          </div>
          {(['30d', 'custom'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setDateFilter(filter)}
              className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${
                dateFilter === filter 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
                  : 'text-slate-500 hover:bg-slate-50'
              }`}
            >
              {filter === '30d' ? '30 Days' : 'Custom'}
            </button>
          ))}

          {dateFilter === 'custom' && (
            <div className="flex items-center gap-2 px-2 border-l border-slate-100 ml-1">
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase">From</span>
                <input 
                  type="date" 
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="text-xs font-bold text-slate-700 bg-slate-50 border-none rounded-md px-2 py-1 focus:ring-1 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase">To</span>
                <input 
                  type="date" 
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="text-xs font-bold text-slate-700 bg-slate-50 border-none rounded-md px-2 py-1 focus:ring-1 focus:ring-indigo-500 outline-none"
                />
              </div>
              <button 
                onClick={handleCustomDateSubmit}
                className="px-3 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-black rounded-md hover:bg-indigo-100 transition-all uppercase tracking-wider"
              >
                Apply
              </button>
            </div>
          )}

          <div className="w-px h-6 bg-slate-100 mx-1"></div>
          
          <div className="flex items-center gap-2 px-1">
            <button 
              onClick={exportToExcel}
              className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 text-[10px] font-black rounded-lg hover:bg-emerald-100 transition-all uppercase tracking-wider"
              title="Export to Excel"
            >
              <FileSpreadsheet size={14} />
              Excel
            </button>
            <button 
              onClick={exportToPDF}
              className="flex items-center gap-2 px-3 py-1.5 bg-rose-50 text-rose-700 text-[10px] font-black rounded-lg hover:bg-rose-100 transition-all uppercase tracking-wider"
              title="Export to PDF"
            >
              <FileDown size={14} />
              PDF
            </button>
          </div>

          <div className="w-px h-6 bg-slate-100 mx-1"></div>
          <button 
            onClick={fetchData}
            className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
            title="Refresh Data"
          >
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <KPICard 
          title="Projects Created" 
          value={stats.projectsCreated} 
          subtext={dateLabel}
          icon={<Briefcase size={20} />}
          color="text-indigo-600"
        />
        <KPICard 
          title="Tests Assigned" 
          value={stats.testsAssigned} 
          subtext={dateLabel}
          icon={<ClipboardCheck size={20} />}
          color="text-blue-600"
          breakdown={stats.assignedBreakdown}
        />
        <KPICard 
          title="Tests Submitted" 
          value={stats.testsSubmitted} 
          subtext={dateLabel}
          icon={<Send size={20} />}
          color="text-amber-600"
          breakdown={stats.submittedBreakdown}
        />
        <KPICard 
          title="Tests Approved" 
          value={stats.testsApproved} 
          subtext={dateLabel}
          icon={<CheckCircle size={20} />}
          color="text-emerald-600"
          breakdown={stats.approvedBreakdown}
        />
        <KPICard 
          title="Active Engineers" 
          value={stats.activeEngineers} 
          subtext={dateLabel}
          icon={<Users size={20} />}
          color="text-purple-600"
        />
        <KPICard 
          title="Engineer Utilization" 
          value={stats.utilization} 
          subtext="Tests / Engineer"
          icon={<Zap size={20} />}
          color="text-rose-600"
        />
      </div>

      {/* Project-wise Test Status Table */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
           <h3 className="text-slate-800 text-sm font-black flex items-center gap-2 text-indigo-900">
             <div className="w-1.5 h-4 bg-indigo-600 rounded-full"></div>
             Project-wise Test Status
           </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-[#f8faff]">
              <tr className="border-b border-slate-100">
                <th rowSpan={2} className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-r border-slate-100">Project Name</th>
                <th rowSpan={2} className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center border-r border-slate-100">Total Tests</th>
                <th colSpan={3} className="px-6 py-3 text-[10px] font-bold text-amber-600 uppercase tracking-wider text-center border-r border-slate-100 bg-amber-50/30">Electrical Test</th>
                <th colSpan={3} className="px-6 py-3 text-[10px] font-bold text-blue-600 uppercase tracking-wider text-center bg-blue-50/30">Mechanical Test</th>
              </tr>
              <tr className="border-b border-slate-100">
                <th className="px-6 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-tighter text-center">Assigned</th>
                <th className="px-6 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-tighter text-center">In-Progress</th>
                <th className="px-6 py-2 text-[10px] font-bold text-emerald-600 uppercase tracking-tighter text-center border-r border-slate-100">Completed</th>
                <th className="px-6 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-tighter text-center">Assigned</th>
                <th className="px-6 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-tighter text-center">In-Progress</th>
                <th className="px-6 py-2 text-[10px] font-bold text-emerald-600 uppercase tracking-tighter text-center">Completed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {stats.projectWiseStatus.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 text-sm font-bold text-slate-600 border-r border-slate-50">
                    {p.name}
                  </td>
                  <td className="px-6 py-4 text-sm font-black text-slate-900 text-center border-r border-slate-50">
                    {p.total}
                  </td>
                  {/* Electrical */}
                  <td className="px-6 py-4 text-sm font-medium text-slate-600 text-center">
                    {p.electrical.assigned}
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-amber-500 text-center">
                    {p.electrical.inProgress}
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-emerald-600 text-center border-r border-slate-50">
                    {p.electrical.completed}
                  </td>
                  {/* Mechanical */}
                  <td className="px-6 py-4 text-sm font-medium text-slate-600 text-center">
                    {p.mechanical.assigned}
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-blue-600 text-center">
                    {p.mechanical.inProgress}
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-emerald-600 text-center">
                    {p.mechanical.completed}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* A. Adoption Funnel */}
        <ChartCard title="Adoption Funnel (Workflow Drop-off)">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              layout="vertical"
              data={funnelData}
              margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
              <XAxis type="number" hide />
              <YAxis 
                dataKey="name" 
                type="category" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 12, fontWeight: 600, fill: '#64748b' }}
              />
              <Tooltip 
                cursor={{ fill: '#f8fafc' }}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={40}>
                {funnelData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* B. Submission vs Approval */}
        <ChartCard title="Submission vs Approval Rate">
          <div className="flex flex-col md:flex-row items-center justify-center h-full gap-8">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={approvalData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={110}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {approvalData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={APPROVAL_COLORS[index % APPROVAL_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-col items-center justify-center bg-slate-50 p-6 rounded-2xl border border-slate-100 min-w-[160px]">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Approval Rate</p>
              <p className="text-4xl font-black text-emerald-600">
                {stats.testsSubmitted > 0 ? Math.round((stats.testsApproved / stats.testsSubmitted) * 100) : 0}%
              </p>
            </div>
          </div>
        </ChartCard>

        {/* C. Project Activity Split */}
        <ChartCard title="Project Activity Split">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={projectSplitData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={110}
                fill="#8884d8"
                dataKey="value"
              >
                {projectSplitData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={PROJECT_COLORS[index % PROJECT_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* D. Engineer Activity */}
        <ChartCard title="Top 5 Engineers (By Submissions)">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={engineerActivityData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fontWeight: 600, fill: '#64748b' }}
              />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
              <Tooltip 
                cursor={{ fill: '#f8fafc' }}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* E. Adoption Trend */}
        <ChartCard title="Adoption Trend Over Time" height={400}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={trendData}>
              <defs>
                <linearGradient id="colorProjects" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="date" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fontWeight: 600, fill: '#64748b' }}
              />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Legend verticalAlign="top" height={36}/>
              <Area type="monotone" dataKey="projects" stroke="#6366f1" fillOpacity={1} fill="url(#colorProjects)" />
              <Line type="monotone" dataKey="assigned" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
              <Line type="monotone" dataKey="submitted" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>

      </div>

      {/* Operational Details Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        
        {/* 1. Users with Roles */}
        <TableCard title="Users & Roles">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">User Name</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Role</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {stats.usersList.map((user, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-slate-700">{user.name}</span>
                      <span className="text-[10px] text-slate-400">{user.email}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-md text-[10px] font-bold tracking-wider uppercase ${
                      user.role === 'ADMIN' ? 'bg-rose-50 text-rose-600' :
                      user.role === 'PROJECT_MANAGER' ? 'bg-indigo-50 text-indigo-600' :
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {user.role}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </TableCard>

        {/* 2. PM Performance Breakdown */}
        <TableCard title="PM Performance Breakdown">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">PM Name</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Projects Handling</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Tests Approved</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {stats.pmList.map((pm, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-slate-700">{pm.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button 
                      onClick={() => setSelectedPM({ name: pm.name, projects: Array.from(pm.projects) })}
                      className="text-sm font-black text-slate-900 hover:text-indigo-600 hover:scale-110 transition-all px-4 py-1 rounded-lg hover:bg-indigo-50"
                    >
                      {pm.projects.size}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button 
                      onClick={() => setSelectedApprovedTests({ name: pm.name, tests: Array.from(pm.approvedTests) })}
                      className="text-sm font-black text-emerald-600 hover:text-emerald-700 hover:scale-110 transition-all px-4 py-1 rounded-lg hover:bg-emerald-50"
                    >
                      {pm.approvedCount}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </TableCard>

        {/* 3. Tests under each Engineer */}
        <TableCard title="Tests by Engineer">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Engineer</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Total Tests</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Sent for Approval</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Approved</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {stats.engList.map((eng, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 text-sm font-bold text-slate-700">{eng.name}</td>
                  <td className="px-6 py-4 text-center">
                    <button 
                      onClick={() => setSelectedEngineerTests({ name: eng.name, tests: Array.from(eng.testNames), title: 'Assigned Tests', color: 'blue' })}
                      className="text-sm font-black text-blue-600 hover:text-blue-700 hover:scale-110 transition-all px-4 py-1 rounded-lg hover:bg-blue-50"
                    >
                      {eng.testCount}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button 
                      onClick={() => setSelectedEngineerTests({ name: eng.name, tests: Array.from(eng.submittedNames), title: 'Sent for Approval', color: 'indigo' })}
                      className="text-sm font-black text-indigo-600 hover:text-indigo-700 hover:scale-110 transition-all px-4 py-1 rounded-lg hover:bg-indigo-50"
                    >
                      {eng.submittedCount}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button 
                      onClick={() => setSelectedEngineerTests({ name: eng.name, tests: Array.from(eng.approvedNames), title: 'Approved Tests', color: 'emerald' })}
                      className="text-sm font-black text-emerald-600 hover:text-emerald-700 hover:scale-110 transition-all px-4 py-1 rounded-lg hover:bg-emerald-50"
                    >
                      {eng.approvedCount}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </TableCard>

      </div>

      {/* Empty State Handling */}
      {data.projects.length === 0 && data.assignments.length === 0 && (
        <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
            <TrendingUp className="text-slate-300" size={32} />
          </div>
          <h3 className="text-lg font-bold text-slate-800">No data available for this period</h3>
          <p className="text-slate-500 text-sm max-w-xs mx-auto mt-2">
            Try selecting a wider date range or check back later once more activity is recorded in the system.
          </p>
        </div>
      )}

      {/* Projects Modal */}
      {selectedPM && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <div>
                <h3 className="text-lg font-black text-slate-900 tracking-tight">Projects Handled</h3>
                <p className="text-xs font-bold text-indigo-600 uppercase tracking-widest mt-0.5">{selectedPM.name}</p>
              </div>
              <button 
                onClick={() => setSelectedPM(null)}
                className="p-2 hover:bg-slate-200 rounded-xl text-slate-400 hover:text-slate-600 transition-all"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-6 max-h-[60vh] overflow-y-auto">
              <div className="flex flex-col gap-2">
                {selectedPM.projects.length > 0 ? (
                  selectedPM.projects.map((proj, idx) => (
                    <div key={idx} className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                      <span className="text-sm font-bold text-slate-700">{proj}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-400 text-sm italic text-center py-4">No active projects found.</p>
                )}
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button 
                onClick={() => setSelectedPM(null)}
                className="px-6 py-2.5 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Approved Tests Modal */}
      {selectedApprovedTests && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <div>
                <h3 className="text-lg font-black text-slate-900 tracking-tight">Tests Approved</h3>
                <p className="text-xs font-bold text-emerald-600 uppercase tracking-widest mt-0.5">{selectedApprovedTests.name}</p>
              </div>
              <button 
                onClick={() => setSelectedApprovedTests(null)}
                className="p-2 hover:bg-slate-200 rounded-xl text-slate-400 hover:text-slate-600 transition-all"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-6 max-h-[60vh] overflow-y-auto">
              <div className="flex flex-col gap-2">
                {selectedApprovedTests.tests.length > 0 ? (
                  selectedApprovedTests.tests.map((test, idx) => (
                    <div key={idx} className="flex items-center gap-3 p-3 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                      <span className="text-sm font-bold text-slate-700">{test}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-400 text-sm italic text-center py-4">No approved tests found.</p>
                )}
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button 
                onClick={() => setSelectedApprovedTests(null)}
                className="px-6 py-2.5 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Engineer Tests Modal */}
      {selectedEngineerTests && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <div>
                <h3 className="text-lg font-black text-slate-900 tracking-tight">{selectedEngineerTests.title || 'Assigned Tests'}</h3>
                <p className={`text-xs font-bold text-${selectedEngineerTests.color || 'blue'}-600 uppercase tracking-widest mt-0.5`}>{selectedEngineerTests.name}</p>
              </div>
              <button 
                onClick={() => setSelectedEngineerTests(null)}
                className="p-2 hover:bg-slate-200 rounded-xl text-slate-400 hover:text-slate-600 transition-all"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-6 max-h-[60vh] overflow-y-auto">
              <div className="flex flex-col gap-2">
                {selectedEngineerTests.tests.length > 0 ? (
                  selectedEngineerTests.tests.map((test, idx) => (
                    <div key={idx} className={`flex items-center gap-3 p-3 bg-${selectedEngineerTests.color || 'blue'}-50/50 rounded-2xl border border-${selectedEngineerTests.color || 'blue'}-100`}>
                      <div className={`w-2 h-2 bg-${selectedEngineerTests.color || 'blue'}-500 rounded-full`}></div>
                      <span className="text-sm font-bold text-slate-700">{test}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-400 text-sm italic text-center py-4">No tests found.</p>
                )}
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button 
                onClick={() => setSelectedEngineerTests(null)}
                className="px-6 py-2.5 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdoptionDashboard;
