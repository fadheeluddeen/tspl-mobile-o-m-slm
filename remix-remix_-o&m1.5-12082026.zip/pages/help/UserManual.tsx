import React, { useState } from 'react';

const UserManual: React.FC = () => {
  const [view, setView] = useState<'PM' | 'ENGINEER'>('PM');

  return (
    <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8 space-y-12 animate-fade-in">
      <div className="text-center space-y-6">
        <div className="space-y-4">
          <h1 className="text-5xl font-black text-slate-900 tracking-tight">O & M Portal User Manual</h1>
          <p className="text-xl text-slate-500 font-medium">A comprehensive guide for your workflow</p>
        </div>
        
        {/* Role Selector UI */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={() => setView('ENGINEER')}
            className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all duration-200 ${
              view === 'ENGINEER'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            For Engineers
          </button>
          <button
            onClick={() => setView('PM')}
            className={`px-6 py-2.5 rounded-full font-bold text-sm transition-all duration-200 ${
              view === 'PM'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            For Project Managers
          </button>
        </div>
      </div>

      <div className="space-y-12">
        {view === 'PM' ? (
          <>
            {/* Step 1 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center text-lg">01</span>
                Step-1. When you log in as a Project Manager, navigate to the Project Manager tab in the sidebar. You will see a list of all active and past projects
              </h2>
            </section>

            {/* Step 2 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center text-lg">02</span>
                Step 2 — Navigating the All Projects View
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>After logging in, the main panel displays a All Projects sidebar on the left when you navigate to All Projects. Projects are not listed individually — they are grouped under their respective client names.</p>
                <div className="space-y-2">
                  <p><strong>Select a Client:</strong> Click on a client card in the left sidebar. The card shows the client name and the number of projects under that client. The active client is highlighted with a green border.</p>
                  <p><strong>Single-project client:</strong> If a client has only one project, clicking the client card directly opens that project in the right panel.</p>
                  <p><strong>Multi-project client:</strong> If a client has more than one project, clicking the client card opens a project selection view on the right panel, titled <strong>"[Client Name]"</strong>. Each project is shown as a card displaying the DC/site name, its status badge (ACTIVE or ARCHIVED), and the site address. Click any project card to open it.</p>
                  <p><strong>Breadcrumb navigation:</strong> Once a project is open, a back arrow (←) appears at the top of the right panel, allowing you to return to the client's project list without losing context.</p>
                </div>
              </div>
            </section>

            {/* Step 3 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center text-lg">03</span>
                Step 3. Field Assignment Hub- Creating a New Project
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>Click the <strong>"Create New Project"</strong> button at the top right.</p>
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <p className="font-bold mb-2 uppercase text-[10px] tracking-widest text-slate-400">Fill in the project details:</p>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2"><span>o</span> <span><strong>DC Name:</strong> A unique identifier for the site.</span></li>
                    <li className="flex items-start gap-2"><span>o</span> <span><strong>Client Name:</strong> The name of the customer.</span></li>
                    <li className="flex items-start gap-2"><span>o</span> <span><strong>Location/Site Address:</strong> The physical address of the facility.</span></li>
                    <li className="flex items-start gap-2"><span>o</span> <span><strong>Approved By:</strong> Designated Approval person.</span></li>
                  </ul>
                </div>
                <p>Click <strong>"INITIALIZE"</strong>.</p>
                <div className="pt-4 border-t border-slate-100">
                  <h4 className="font-bold text-slate-800 mb-2">Editing or Deleting</h4>
                  <ul className="space-y-2">
                    <li>• <strong>Edit:</strong> Click the Edit icon next to a project to update its details.</li>
                    <li>• <strong>Delete:</strong> Click the Delete icon. Note: Deleting a project will remove all associated test data.</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Step 4 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-lg">04</span>
                Step 4. Assigning Tests to Engineers
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>Once a project is created, you must assign specific tests to your field engineers.</p>
                <ul className="space-y-3">
                  <li><strong>Select a Project:</strong> Click on a project from the list to open its details.</li>
                  <li><strong>Open Assignment Tool:</strong> Click the <strong>"Assign New Test"</strong> button.</li>
                  <li><strong>Select an Engineer:</strong> Choose the engineer responsible for the site from the dropdown.</li>
                  <li><strong>Select Tests:</strong>
                    <ul className="ml-6 mt-2 space-y-1">
                      <li className="flex items-start gap-2"><span>o</span> <span>A list of available tests (e.g., Thermography, Arc Flash, CFM Analysis) will appear.</span></li>
                      <li className="flex items-start gap-2"><span>o</span> <span>Check the boxes for the tests required for this project.</span></li>
                    </ul>
                  </li>
                  <li><strong>Apply Assignment:</strong> Click <strong>"Apply Assignment"</strong>. The engineer will now see these tests on their mobile/tablet dashboard.</li>
                </ul>
              </div>
            </section>

            {/* Step 5 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center text-lg">05</span>
                Step 5. Monitoring Progress & Reviewing Work
              </h2>
              <div className="space-y-6 text-slate-600">
                <p>As engineers perform tests on-site, the Status column in the project view will update automatically.</p>
                
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <h4 className="font-bold text-slate-800 mb-3 uppercase text-[10px] tracking-widest text-slate-400">Status Definitions:</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• <strong>PENDING:</strong> The test is assigned but not yet started.</li>
                    <li>• <strong>IN PROGRESS:</strong> The engineer is currently entering data.</li>
                    <li>• <strong>SUBMITTED:</strong> The engineer has finished and is waiting for your review.</li>
                    <li>• <strong>APPROVED:</strong> You have verified the data and it is ready for the final report.</li>
                    <li>• <strong>REJECTED:</strong> You found issues and sent it back for corrections.</li>
                  </ul>
                </div>

                <div className="space-y-3">
                  <h4 className="font-bold text-slate-800">Reviewing a Submitted Test:</h4>
                  <ul className="space-y-2">
                    <li>Click <strong>"Review"</strong> on any test with a SUBMITTED status.</li>
                    <li>Review the tables, readings, and photos provided by the engineer.</li>
                    <li><strong>Approve:</strong> If everything looks correct, click <strong>"Approve"</strong>.</li>
                    <li><strong>Reject:</strong> If data is missing or incorrect, click <strong>"Reject"</strong>. You will be prompted to leave a Rejection Comment explaining what needs to be fixed. The engineer will see this comment and can resubmit.</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Step 6 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-pink-100 text-pink-600 rounded-xl flex items-center justify-center text-lg">06</span>
                Step 6. AI Insights & Analysis
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>Before finalizing, you can use the built-in AI to analyze the data.</p>
                <ul className="space-y-2">
                  <li>Scroll to the <strong>"AI Insights"</strong> section within a project.</li>
                  <li>Click <strong>"Generate AI Insights"</strong>.</li>
                  <li>The system will analyze all approved test data to provide high-level summaries, identify risks, and suggest recommendations for the client.</li>
                </ul>
              </div>
            </section>

            {/* Step 7 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center text-lg">07</span>
                Step 7. Finalizing and Reporting
              </h2>
              <div className="space-y-6 text-slate-600">
                <p>Once all tests are APPROVED, you can generate the final deliverables.</p>
                
                <div className="space-y-2">
                  <h4 className="font-bold text-slate-800">Generating the Project Report (DOCX)</h4>
                  <ul className="space-y-1">
                    <li>Click the <strong>"Generate Final Report"</strong> button.</li>
                    <li>The system will compile all test data, photos, and AI insights into a professional Word document formatted for the client.</li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h4 className="font-bold text-slate-800">Exporting Specialized Data (Excel)</h4>
                  <p>• For Thermography tests, you can click <strong>"Export Thermography Excel"</strong> to get a detailed spreadsheet of all thermal images and temperature readings.</p>
                </div>
              </div>
            </section>

            {/* Pro-Tips */}
            <section className="bg-slate-900 p-10 rounded-[2.5rem] text-white shadow-xl">
              <h2 className="text-3xl font-black mb-8 tracking-tight">Pro-Tips for PMs-</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="space-y-2">
                  <p className="text-indigo-400 font-black uppercase text-xs tracking-widest">Efficiency</p>
                  <h4 className="font-bold">• Check Rejections Often</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">If a project is stalled, check if any tests are in "REJECTED" status and follow up with the engineer.</p>
                </div>
                <div className="space-y-2">
                  <p className="text-emerald-400 font-black uppercase text-xs tracking-widest">Real-Time</p>
                  <h4 className="font-bold">• Real-Time Updates</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">You don't need to refresh the page; the status updates in real-time as engineers save their work.</p>
                </div>
                <div className="space-y-2">
                  <p className="text-amber-400 font-black uppercase text-xs tracking-widest">Support</p>
                  <h4 className="font-bold">• Support Mode</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">If an engineer is stuck, you can view their "In Progress" work to provide guidance over the phone.</p>
                </div>
              </div>
            </section>
          </>
        ) : (
          <>
            {/* ENGINEER Content */}
            {/* Step 1 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center text-lg">01</span>
                Step-1. Portal Access & Project Inventory
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>When you log in as an Engineer, navigate to the <strong>Engineer Dashboard</strong> (Field Hub). This is your central workspace for all assigned field operations.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <h4 className="font-bold text-slate-800 mb-1 text-xs uppercase">Project Inventory</h4>
                    <p className="text-xs">The left sidebar lists every active site where you have been assigned technical protocols.</p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <h4 className="font-bold text-slate-800 mb-1 text-xs uppercase">Protocol Hub</h4>
                    <p className="text-xs">The main area displays individual test cards for the selected project, showing exactly what needs to be executed.</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Step 2 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center text-lg">02</span>
                Step-2. Field Status & Workflow Tracking
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>Each protocol (test) follows a structured lifecycle. Understanding the real-time status badges is critical for efficient handoffs:</p>
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-8">
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest">PENDING / DRAFT</p>
                    <p className="text-xs font-medium">New assignment or work-in-progress. You can edit and save data locally.</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest">SUBMITTED</p>
                    <p className="text-xs font-medium">Data sent to the Project Manager. Editing is locked during the review phase.</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-red-600 uppercase tracking-widest">REJECTED</p>
                    <p className="text-xs font-medium">Corrections needed. Look for the red feedback banner with PM comments.</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-green-600 uppercase tracking-widest">APPROVED</p>
                    <p className="text-xs font-medium">Data verified. Ready for inclusion in the final project report.</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">DELETION PENDING</p>
                    <p className="text-xs font-medium">You have requested removal of this test. Awaiting Admin confirmation.</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Step 3 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center text-lg">03</span>
                Step 3. Technical Execution & Specialized Modules
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>Click <strong>"Execute"</strong> on a card to open the specialized data entry tool. The portal provides tailor-made interfaces for different disciplines:</p>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-slate-100 rounded flex items-center justify-center flex-shrink-0 text-[10px]">🛠️</div>
                    <div><strong>Equipment & Tools:</strong> For tests like CFM airflow, you must list your instruments (Make, Model, Purpose) to ensure calibration traceability.</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-slate-100 rounded flex items-center justify-center flex-shrink-0 text-[10px]">📐</div>
                    <div><strong>Grid-Based Validation:</strong> Enter readings into interactive tables. Some fields have strict numeric validations to prevent typos in the field.</div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-slate-100 rounded flex items-center justify-center flex-shrink-0 text-[10px]">🏗️</div>
                    <div>
                      <strong>Dynamic Assets:</strong> Use "Add Row" to capture data for multiple UPS units, Battery blocks, or Electrical panels.
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-slate-100 rounded flex items-center justify-center flex-shrink-0 text-[10px]">👯</div>
                    <div>
                      <strong>Duplicate Rows:</strong> To speed up entry for identical equipment, use the <strong>"Duplicate Row"</strong> button. This clones the current row's static data (Make/Model/Specifications), allowing you to only update the unique measurement readings.
                    </div>
                  </li>
                </ul>
              </div>
            </section>

            {/* Step 4 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center text-lg">04</span>
                Step 4. Gemini Engineering AI & Reporting
              </h2>
              <div className="space-y-4 text-slate-600">
                <p>The portal leverages advanced AI to assist your field analysis:</p>
                <div className="bg-indigo-600 p-6 rounded-2xl text-white space-y-4">
                  <h4 className="font-black uppercase text-xs tracking-widest border-b border-indigo-400 pb-2">Gemini Pro Integration</h4>
                  <p className="text-xs leading-relaxed">Use the <strong>"Generate AI Insight"</strong> button to get immediate technical summaries, risk assessments, and recommendations based on your captured data.</p>
                  <div className="flex gap-4">
                    <div className="flex-1 text-[10px] bg-indigo-700/50 p-3 rounded-xl border border-indigo-500">
                       <strong>Draft Reports:</strong> Click "Generate Draft Report" at any time to preview how your data will look in the final DOCX file.
                    </div>
                    <div className="flex-1 text-[10px] bg-indigo-700/50 p-3 rounded-xl border border-indigo-500">
                       <strong>Excel Exports:</strong> For Thermography and specialized tests, one-click spreadsheet exports are available post-approval.
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Step 5 */}
            <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-lg">05</span>
                Step 5. Submission & The Revision Loop
              </h2>
              <div className="space-y-6 text-slate-600">
                <div className="space-y-2">
                  <h4 className="font-bold text-slate-800">Final Handoff</h4>
                  <p className="text-sm">Once data is complete, click <strong>"Submit for PM Approval"</strong>. This alerts your manager to review the work. If the manager finds errors, the test returns as <strong>REJECTED</strong>. Read the rejection banner at the top of the execution page carefully to see which readings need adjustment.</p>
                </div>
                
                <div className="bg-slate-900 p-5 rounded-2xl text-slate-400">
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Technical Note:</p>
                  <p className="text-xs leading-relaxed italic">
                    For high-compliance tests like CFM airflow, the portal enforces "Gatekeeping" logic. You cannot submit if required instrument lists or core measurement pairs are missing.
                  </p>
                </div>
              </div>
            </section>

            {/* Pro-Tips */}
            <section className="bg-slate-900 p-10 rounded-[2.5rem] text-white shadow-xl">
              <h2 className="text-3xl font-black mb-8 tracking-tight">Engineer's Field Guide (Pro-Tips)</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="space-y-2">
                  <p className="text-indigo-400 font-black uppercase text-xs tracking-widest">Efficiency</p>
                  <h4 className="font-bold">• Save Locally, Save Often</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">Always click "Save Draft" before moving between sites or switching applications to ensure zero data loss in low-connectivity areas.</p>
                </div>
                <div className="space-y-2">
                  <p className="text-emerald-400 font-black uppercase text-xs tracking-widest">Quality</p>
                  <h4 className="font-bold">• Descriptive Comments</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">If a reading falls outside typical limits (Red/Amber), use the notes section to explain the real-world cause. This prevents unnecessary rejections.</p>
                </div>
                <div className="space-y-2">
                  <p className="text-amber-400 font-black uppercase text-xs tracking-widest">Communication</p>
                  <h4 className="font-bold">• Deletion Requests</h4>
                  <p className="text-slate-400 text-sm leading-relaxed">Assigned a test by mistake? Use the "Request Deletion" button on the card. Admins will clear it from your dashboard once reviewed.</p>
                </div>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  );
};

export default UserManual;
