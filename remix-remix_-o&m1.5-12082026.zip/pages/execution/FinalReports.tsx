
import React, { useState, useEffect } from 'react';
import { ExecutionService, ProjectService } from '../../services/mockDatabase';
import { TestAssignment, WorkflowStatus } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { FileCheck, Download, ExternalLink, Search, Filter } from 'lucide-react';

const FinalReports: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [reports, setReports] = useState<TestAssignment[]>([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const loadReports = async () => {
            if (!user) return;
            try {
                // Fetch assignments specifically for this user and filter for APPROVED
                const all = await ExecutionService.fetchAssignmentsByEngineer(user.uid);
                const approved = (all || []).filter(a => a.workflowStatus === WorkflowStatus.APPROVED);
                
                // Enrich with project/client names
                const enriched = await Promise.all(approved.map(async (test) => {
                    if (test.projectName && test.projectName !== 'Internal Asset' && test.clientName) return test;
                    try {
                        const proj = await ProjectService.fetchProjectById(test.projectId);
                        return { 
                            ...test, 
                            projectName: proj?.name || 'Internal Asset',
                            clientName: proj?.clientName || ''
                        };
                    } catch (e) {
                        return test;
                    }
                }));

                setReports(enriched);
            } catch (e) {
                console.error("Failed to load approved reports", e);
            } finally {
                setLoading(false);
            }
        };
        loadReports();
    }, []);

    const handleDownload = async (e: React.MouseEvent, test: TestAssignment) => {
        e.stopPropagation();
        try {
            const url = await ExecutionService.generateReport(test.id, undefined, undefined, false);
            const link = document.createElement('a');
            link.href = url;
            const customDocNo = test.docNo || test.readings?.docNo || test.readings?.doc_no;
            link.setAttribute('download', customDocNo ? `${customDocNo}.docx` : `Final_Report_${test.id}.docx`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (e) {
            alert("Report generation failed");
        }
    };

    const filteredReports = reports.filter(r => 
        r.testName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.projectName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.clientName?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center py-32 gap-4">
                <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Retrieving Finalized Documents...</p>
            </div>
        );
    }

    return (
        <div className="space-y-8 animate-fade-in max-w-7xl mx-auto">
            {/* Header Section */}
            <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-5 opacity-emerald-500 pointer-events-none">
                    <FileCheck size={160} className="-rotate-12" />
                </div>
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                    <div>
                        <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                            <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center shadow-inner">
                                <FileCheck size={28} className="text-emerald-500" />
                            </div>
                            Approved Reports
                        </h1>
                        <p className="text-slate-500 font-medium mt-2">Centralized vault for all mission-critical finalized field test protocols.</p>
                    </div>
                    
                    <div className="w-full md:w-auto flex items-center gap-3 bg-slate-50 p-2 rounded-2xl border border-slate-100">
                        <div className="flex items-center gap-3 px-4 py-2 bg-white rounded-xl border border-slate-200 group-focus-within:border-emerald-500 transition-all shadow-sm">
                            <Search size={16} className="text-slate-400" />
                            <input 
                                type="text"
                                placeholder="Search reports..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="bg-transparent text-sm font-bold text-slate-600 outline-none w-48 placeholder:text-slate-300"
                            />
                        </div>
                        <div className="hidden sm:flex items-center gap-2 px-4 py-2 text-xs font-black text-emerald-600 uppercase tracking-widest">
                            {filteredReports.length} Verified
                        </div>
                    </div>
                </div>
            </div>

            {filteredReports.length === 0 ? (
                <div className="bg-white rounded-[40px] border border-slate-200 p-24 flex flex-col items-center justify-center text-center gap-5 shadow-sm">
                    <div className="w-24 h-24 bg-slate-50 rounded-[40px] flex items-center justify-center text-4xl shadow-inner">📄</div>
                    <div className="space-y-1">
                        <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">No Reports Found</h3>
                        <p className="text-slate-500 max-w-sm text-sm font-medium">Finalized and approved test protocols will automatically populate here for immediate retrieval.</p>
                    </div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredReports.map(test => (
                        <div 
                            key={test.id} 
                            onClick={() => navigate(`/execute/${test.id}`)}
                            className="bg-white p-7 rounded-[32px] border border-slate-200 shadow-sm hover:shadow-2xl hover:border-emerald-300 transition-all group relative cursor-pointer flex flex-col overflow-hidden"
                        >
                            <div className="flex items-center gap-4 mb-6">
                                <div className="w-14 h-14 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center text-xl shadow-inner group-hover:bg-emerald-600 group-hover:text-white transition-all transform group-hover:scale-110">
                                    <FileCheck size={28} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-1.5 mb-1 overflow-hidden">
                                            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest shrink-0">{test.clientName || 'CLIENT'}</span>
                                            <span className="text-[10px] font-black text-slate-300">|</span>
                                            <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest truncate">{test.projectName || 'PROJECT'}</span>
                                        </div>
                                        <h4 className="font-black text-slate-900 leading-tight truncate group-hover:text-emerald-600 transition-colors uppercase tracking-tight text-[15px]">
                                            {test.testName}
                                        </h4>
                                    </div>
                                    <div className="flex flex-wrap items-center gap-2 mt-2">
                                        <span className="text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-[0.1em] border bg-emerald-50 text-emerald-700 border-emerald-100">
                                            {test.workflowStatus}
                                        </span>
                                        {test.location && (
                                            <span className="text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-[0.1em] border bg-indigo-50 text-indigo-700 border-indigo-100">
                                                {test.location}
                                            </span>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="flex-1">
                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4">Finalized on {test.reviewedAt ? new Date(test.reviewedAt).toLocaleDateString() : 'N/A'}</p>
                            </div>

                            <div className="mt-auto pt-6 border-t border-slate-50 flex gap-3">
                                <button 
                                    onClick={(e) => handleDownload(e, test)}
                                    className="flex-1 py-3 bg-emerald-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.15em] hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-100 active:translate-y-0.5"
                                >
                                    <Download size={14} strokeWidth={3} /> Get Report
                                </button>
                                <button 
                                    onClick={() => navigate(`/execute/${test.id}`)}
                                    className="px-5 py-3 bg-white text-slate-600 rounded-2xl font-black text-[10px] uppercase tracking-[0.15em] hover:bg-slate-50 transition-all border border-slate-200 group-hover:border-emerald-200"
                                >
                                    <ExternalLink size={14} strokeWidth={3} />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default FinalReports;
