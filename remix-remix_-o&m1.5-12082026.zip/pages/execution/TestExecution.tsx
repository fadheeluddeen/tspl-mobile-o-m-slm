
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { TestAssignment, TestDefinition, ArcFlashReading, SPDReading, LightningArrestorReading, EarthStationReading, SPOFReading, PowerSystemReading, PowerFactorReading, ThermographyReading, PowerQualityReading, RackCoolingIndexReading, ELVGapAssessmentReading, DGEnduranceReading, CapacityAssessmentReading, CouponTestReading, BatteryImpedanceReading, LifeCycleReading, CFMReading, UserRole, WorkflowStatus, VibrationAnalysisReading } from '../../types';
import { ExecutionService, TestLibraryService, ProjectService } from '../../services/mockDatabase';
import { useAuth } from '../../context/AuthContext';
import { 
    EquipmentTable, 
    MeasurementTemplate, 
    TechnicalAuditSummary,
    EquipmentRow, 
    UpsUnit, 
    INITIAL_EQUIPMENT, 
    INITIAL_UPS_DATA,
    INITIAL_OBSERVATIONS
} from '../../components/TestTables';
import { Pin, MapPin } from 'lucide-react';
import { ArcFlashTables, INITIAL_ARC_FLASH_DATA } from '../../components/ArcFlashTables';
import { LightningArrestorTables, INITIAL_LA_DATA } from '../../components/LightningArrestorTables';
import { EarthStationTables, INITIAL_EARTH_STATION_DATA } from '../../components/EarthStationTables';
import { SPOFTables, INITIAL_SPOF_DATA } from '../../components/SPOFTables';
import { PowerSystemStudyTables, INITIAL_POWER_SYSTEM_DATA } from '../../components/PowerSystemStudyTables';
import { PowerFactorTables, INITIAL_POWER_FACTOR_DATA } from '../../components/PowerFactorTables';
import { SPDHealthCheckTables, INITIAL_SPD_HEALTH_DATA } from '../../components/SPDHealthCheckTables';
import { ThermographyTables, INITIAL_THERMOGRAPHY_DATA } from '../../components/ThermographyTables';
import { exportThermographyToExcel } from '../../utils/excelExport';
import { PowerQualityTables, INITIAL_POWER_QUALITY_DATA } from '../../components/PowerQualityTables';
import { RackCoolingIndexTables, INITIAL_RCI_DATA } from '../../components/RackCoolingIndexTables';
import { CFMTables, INITIAL_CFM_DATA } from '../../components/CFMTables';
import { ELVGapAssessmentTables, INITIAL_ELV_GAP_DATA } from '../../components/ELVGapAssessmentTables';
import { DGEnduranceTables, INITIAL_DG_ENDURANCE_DATA } from '../../components/DGEnduranceTables';
import { CapacityAssessmentTables, INITIAL_CAPACITY_DATA } from '../../components/CapacityAssessmentTables';
import { CouponTestTables, INITIAL_COUPON_DATA } from '../../components/CouponTestTables';
import { BatteryImpedanceTables, INITIAL_BATTERY_IMPEDANCE_DATA } from '../../components/BatteryImpedanceTables';
import { LifeCycleAssessmentTables, INITIAL_LIFE_CYCLE_DATA } from '../../components/LifeCycleAssessmentTables';
import { VibrationAnalysisTables, INITIAL_VIBRATION_DATA } from '../../components/VibrationAnalysisTables';
import { RCI_LIVE_CAPTURE_CONFIG, CAPACITY_LIVE_CAPTURE_CONFIG, LCA_LIVE_CAPTURE_CONFIG, CFM_LIVE_CAPTURE_CONFIG } from '../developer/TestLibrary';
import IncompleteFormModal from '../../components/IncompleteFormModal';

const TestExecution: React.FC = () => {
  const { assignmentId } = useParams<{ assignmentId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [assignment, setAssignment] = useState<TestAssignment | null>(null);
  const [project, setProject] = useState<any | null>(null);
  const [testDef, setTestDef] = useState<TestDefinition | null>(null);
  const [loading, setLoading] = useState(true);

  // Data States
  const [equipmentData, setEquipmentData] = useState<EquipmentRow[]>(INITIAL_EQUIPMENT);
  const [upsData, setUpsData] = useState<UpsUnit[]>(INITIAL_UPS_DATA);
  const [arcFlashData, setArcFlashData] = useState<ArcFlashReading>(INITIAL_ARC_FLASH_DATA);
  const [spdData, setSpdData] = useState<SPDReading>(INITIAL_SPD_HEALTH_DATA);
  const [laData, setLaData] = useState<LightningArrestorReading>(INITIAL_LA_DATA);
  const [earthData, setEarthData] = useState<EarthStationReading>(INITIAL_EARTH_STATION_DATA);
  const [spofData, setSpofData] = useState<SPOFReading>(INITIAL_SPOF_DATA);
  const [powerSystemData, setPowerSystemData] = useState<PowerSystemReading>(INITIAL_POWER_SYSTEM_DATA);
  const [powerFactorData, setPowerFactorData] = useState<PowerFactorReading>(INITIAL_POWER_FACTOR_DATA);
  const [thermographyData, setThermographyData] = useState<ThermographyReading>(INITIAL_THERMOGRAPHY_DATA);
  const [powerQualityData, setPowerQualityData] = useState<PowerQualityReading>(INITIAL_POWER_QUALITY_DATA);
  const [rciData, setRciData] = useState<RackCoolingIndexReading>(INITIAL_RCI_DATA);
  const [cfmData, setCfmData] = useState<CFMReading>(INITIAL_CFM_DATA);
  const [elvGapData, setElvGapData] = useState<ELVGapAssessmentReading>(INITIAL_ELV_GAP_DATA);
  const [dgEnduranceData, setDgEnduranceData] = useState<DGEnduranceReading>(INITIAL_DG_ENDURANCE_DATA);
  const [capacityData, setCapacityData] = useState<CapacityAssessmentReading>(INITIAL_CAPACITY_DATA);
  const [couponData, setCouponData] = useState<CouponTestReading>(INITIAL_COUPON_DATA);
  const [batteryImpedanceData, setBatteryImpedanceData] = useState<BatteryImpedanceReading>(INITIAL_BATTERY_IMPEDANCE_DATA);
  const [lifeCycleData, setLifeCycleData] = useState<LifeCycleReading>(INITIAL_LIFE_CYCLE_DATA);
  const [vibrationData, setVibrationData] = useState<VibrationAnalysisReading>(INITIAL_VIBRATION_DATA);
  const [locationValue, setLocationValue] = useState('');
  const [docNoValue, setDocNoValue] = useState('');
  const [dynamicReadings, setDynamicReadings] = useState<Record<string, any>>({});
  
  const [isSaving, setIsSaving] = useState(false);
  const [reportUrl, setReportUrl] = useState<string | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  
  // Workflow States
  const [isWorkflowProcessing, setIsWorkflowProcessing] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [showIncompleteModal, setShowIncompleteModal] = useState(false);
  const [missingFields, setMissingFields] = useState<string[]>([]);
  const [rejectComments, setRejectComments] = useState('');
  const [acknowledgedEmptyTables, setAcknowledgedEmptyTables] = useState(false);

  const isPM = user?.role === UserRole.PROJECT_MANAGER || user?.role === UserRole.ADMIN;
  const isEngineer = user?.role === UserRole.ENGINEER;
  const isSpecialUser = user?.email === 'it.support@technavious.com';
  const isDeletionPending = assignment?.workflowStatus === WorkflowStatus.DELETION_PENDING;
  const isDeletionApproved = assignment?.workflowStatus === WorkflowStatus.DELETION_APPROVED;
  const isDataLocked = (assignment?.workflowStatus === WorkflowStatus.SUBMITTED || (assignment?.workflowStatus === WorkflowStatus.APPROVED && !isEngineer) || isDeletionPending || isDeletionApproved) && !isSpecialUser;

  useEffect(() => {
    if (!assignmentId) return;
    setLoading(true);
    
    const loadData = async () => {
        try {
            const allAssignments = await ExecutionService.fetchAssignmentsByEngineer('');
            const found = allAssignments.find(a => a.id === assignmentId);
            if (!found) throw new Error("Assignment not found");
            
            setAssignment(found);
            setLocationValue(found.location || '');
            
            // Fetch project details for client and DC name
            const proj = await ProjectService.fetchProjectById(found.projectId);
            if (proj) setProject(proj);

            let currentDocNo = found.docNo || '';
            if (!currentDocNo && proj) {
                const getShortName = (name: string): string => {
                    const n = name.toLowerCase();
                    if (n.includes('cfm')) return 'CFM';
                    if (n.includes('rack cooling index') || n.includes('rci')) return 'RCI';
                    if (n.includes('capacity assessment')) return 'CAPACITY';
                    if (n.includes('life cycle')) return 'LIFE_CYCLE';
                    if (n.includes('vibration')) return 'VIBRATION';
                    return name.split(' ')[0].toUpperCase();
                };
                currentDocNo = `TSPL-${(proj.clientName || "").toUpperCase()}-${proj.projectId || "---"}-${found.testName.toLowerCase().includes('arc flash') || found.testName.toLowerCase().includes('spd') || found.testName.toLowerCase().includes('lightning') || found.testName.toLowerCase().includes('earth') ? 'EL' : 'ME'}-${getShortName(found.testName)}`;
            }
            setDocNoValue(currentDocNo);
            
            const tests = await TestLibraryService.fetchTests();
            const def = tests.find(t => t.id === found.testDefinitionId);
            if (def) setTestDef(def);

            const testName = found.testName.toLowerCase();
            const isArcFlash = testName.includes('arc flash');
            const isSPD = testName.includes('spd') || testName.includes('surge protective device');
            const isLA = testName.includes('lightning arrestor') || testName.includes('lightning protection');
            const isEarth = testName.includes('earth station') || testName.includes('earth continuity');
            const isSPOF = testName.includes('single point of failure');
            const isPower = testName.includes('power system study');
            const isPF = testName.includes('power factor');
            const isTG = testName.includes('thermography');
            const isPQ = testName.includes('power quality');
            const isRCI = testName.includes('rack cooling index');
            const isCFM = testName.includes('cfm') || testName.includes('airflow');
            const isELVGap = testName.includes('elv gap assessment');
            const isDGEndurance = testName.includes('dg endurance');
            const isCapacity = testName.includes('capacity assessment') || testName.includes('pahu') || testName.includes('pac');
            const isCoupon = testName.includes('coupon test') || testName.includes('corrosion');
            const isBattery = testName.includes('battery') && (testName.includes('impedance') || testName.includes('impedence'));
            const isLifeCycle = testName.includes('life cycle assessment');
            const isVibration = testName.includes('vibration analysis');
            
            const safeMerge = (initial: any, current: any) => {
                const base = { ...initial, ...(current || {}) };
                Object.keys(initial).forEach(key => {
                    if (Array.isArray(initial[key])) {
                        if (!base[key] || !Array.isArray(base[key])) {
                            base[key] = initial[key];
                        }
                    }
                });
                return base;
            };

            if (isArcFlash) {
                setArcFlashData(safeMerge(INITIAL_ARC_FLASH_DATA, found.readings));
            } else if (isSPD) {
                setSpdData(safeMerge(INITIAL_SPD_HEALTH_DATA, found.readings));
            } else if (isLA) {
                setLaData(safeMerge(INITIAL_LA_DATA, found.readings));
            } else if (isEarth) {
                setEarthData(safeMerge(INITIAL_EARTH_STATION_DATA, found.readings));
            } else if (isSPOF) {
                setSpofData(safeMerge(INITIAL_SPOF_DATA, found.readings));
            } else if (isPower) {
                setPowerSystemData(safeMerge(INITIAL_POWER_SYSTEM_DATA, found.readings));
            } else if (isPF) {
                setPowerFactorData(safeMerge(INITIAL_POWER_FACTOR_DATA, found.readings));
            } else if (isTG) {
                setThermographyData(safeMerge(INITIAL_THERMOGRAPHY_DATA, found.readings));
            } else if (isPQ) {
                setPowerQualityData(safeMerge(INITIAL_POWER_QUALITY_DATA, found.readings));
            } else if (isRCI) {
                setRciData(safeMerge(INITIAL_RCI_DATA, found.readings));
            } else if (isCFM) {
                setCfmData(safeMerge(INITIAL_CFM_DATA, found.readings));
            } else if (isELVGap) {
                setElvGapData(safeMerge(INITIAL_ELV_GAP_DATA, found.readings));
            } else if (isDGEndurance) {
                setDgEnduranceData(safeMerge(INITIAL_DG_ENDURANCE_DATA, found.readings));
            } else if (isCapacity) {
                setCapacityData(safeMerge(INITIAL_CAPACITY_DATA, found.readings));
            } else if (isCoupon) {
                setCouponData(safeMerge(INITIAL_COUPON_DATA, found.readings));
            } else if (isBattery) {
                setBatteryImpedanceData(safeMerge(INITIAL_BATTERY_IMPEDANCE_DATA, found.readings));
            } else if (isLifeCycle) {
                setLifeCycleData(safeMerge(INITIAL_LIFE_CYCLE_DATA, found.readings));
            } else if (isVibration) {
                setVibrationData(safeMerge(INITIAL_VIBRATION_DATA, found.readings));
            } else {
                const readings = (found.readings as Record<string, any>) || {};
                setEquipmentData(Array.isArray(readings?.equipment) ? readings.equipment : INITIAL_EQUIPMENT);
                setUpsData(Array.isArray(readings?.measurements) ? readings.measurements : INITIAL_UPS_DATA);
                setDynamicReadings(readings || {});
            }
        } catch (e: any) {
            console.error(e);
            alert("Error loading test execution page.");
            navigate('/pm');
        } finally {
            setLoading(false);
        }
    };

    loadData();
  }, [assignmentId, navigate]);

  const getFinalReadings = useCallback(() => {
    if (!assignment) return {};
    const testName = assignment.testName.toLowerCase();
    const isArcFlashVal = testName.includes('arc flash');
    const isSPDVal = testName.includes('spd') || testName.includes('surge protective device');
    const isLAVal = testName.includes('lightning arrestor') || testName.includes('lightning protection');
    const isEarthVal = testName.includes('earth station') || testName.includes('earth continuity');
    const isSPOFVal = testName.includes('single point of failure');
    const isPowerVal = testName.includes('power system study');
    const isPFVal = testName.includes('power factor');
    const isTGVal = testName.includes('thermography');
    const isPQVal = testName.includes('power quality');
    const isRCIVal = testName.includes('rack cooling index');
    const isCFMVal = testName.includes('cfm') || testName.includes('airflow');
    const isELVGapVal = testName.includes('elv gap assessment');
    const isDGEnduranceVal = testName.includes('dg endurance');
    const isCapacityVal = testName.includes('capacity assessment') || testName.includes('pahu') || testName.includes('pac');
    const isCouponVal = testName.includes('coupon test') || testName.includes('corrosion');
    const isBatteryVal = testName.includes('battery') && (testName.includes('impedance') || testName.includes('impedence'));
    const isLifeCycleVal = testName.includes('life cycle assessment');
    const isVibrationVal = testName.includes('vibration analysis');
    
    let finalReadings;
    if (isArcFlashVal) finalReadings = arcFlashData;
    else if (isSPDVal) finalReadings = spdData;
    else if (isLAVal) finalReadings = laData;
    else if (isEarthVal) finalReadings = earthData;
    else if (isSPOFVal) finalReadings = spofData;
    else if (isPowerVal) finalReadings = powerSystemData;
    else if (isPFVal) finalReadings = powerFactorData;
    else if (isTGVal) finalReadings = thermographyData;
    else if (isPQVal) finalReadings = powerQualityData;
    else if (isRCIVal) finalReadings = rciData;
    else if (isCFMVal) finalReadings = cfmData;
    else if (isELVGapVal) finalReadings = elvGapData;
    else if (isDGEnduranceVal) finalReadings = dgEnduranceData;
    else if (isCapacityVal) finalReadings = capacityData;
    else if (isCouponVal) finalReadings = couponData;
    else if (isBatteryVal) finalReadings = batteryImpedanceData;
    else if (isLifeCycleVal) finalReadings = lifeCycleData;
    else if (isVibrationVal) finalReadings = vibrationData;
    else finalReadings = { ...dynamicReadings, equipment: equipmentData, measurements: upsData };

    return finalReadings;
  }, [
    assignment,
    arcFlashData, spdData, laData, earthData, spofData, 
    powerSystemData, powerFactorData, thermographyData, 
    powerQualityData, rciData, cfmData, elvGapData, 
    dgEnduranceData, capacityData, couponData, 
    batteryImpedanceData, lifeCycleData, vibrationData,
    equipmentData, upsData, dynamicReadings
  ]);

  const handleTogglePin = async () => {
    if (!assignmentId || !user || !assignment) return;
    try {
        await ExecutionService.togglePin(assignmentId, user.uid, user);
        setAssignment(prev => {
            if (!prev) return null;
            const pinnedBy = prev.pinnedBy || [];
            const isPinned = pinnedBy.includes(user.uid);
            const nextPinnedBy = isPinned 
                ? pinnedBy.filter(id => id !== user.uid)
                : [...pinnedBy, user.uid];
            return { ...prev, pinnedBy: nextPinnedBy };
        });
    } catch (e) {
        console.error("Pin toggle failed", e);
    }
  };

  const handleLocationUpdate = async (val: string) => {
    setLocationValue(val);
    if (!assignmentId || !user) return;
    try {
        await ExecutionService.updateAssignmentLocation(assignmentId, val, user);
    } catch (e) {
        console.error("Location update failed", e);
    }
  };

  const handleDocNoUpdate = async (val: string) => {
    setDocNoValue(val);
    if (!assignmentId || !user) return;
    try {
        await ExecutionService.updateAssignmentDocNo(assignmentId, val, user);
    } catch (e) {
        console.error("DocNo update failed", e);
    }
  };

  const handleSave = useCallback(async (isManualUpdate = false) => {
    if (!assignmentId || !assignment || !user) return;
    setIsSaving(true);
    try {
        const finalReadings = getFinalReadings();
        await ExecutionService.saveReadings(assignmentId, finalReadings, user);

        // If Engineer or Special User is updating an APPROVED test, revert it to DRAFT for PM review
        if (isManualUpdate && assignment.workflowStatus === WorkflowStatus.APPROVED && (isEngineer || isSpecialUser)) {
            await ExecutionService.revertToDraft(assignmentId, user);
            setAssignment(prev => prev ? { ...prev, workflowStatus: WorkflowStatus.DRAFT, readings: finalReadings } : null);
            setReportUrl(null); // Remove download option
        } else {
            setAssignment(prev => prev ? { ...prev, readings: finalReadings } : null);
        }
    } finally {
        setIsSaving(false);
    }
  }, [
    assignmentId, assignment, user, isEngineer, isSpecialUser, getFinalReadings
  ]);

  const handleSubmitForPM = async (skipValidation = false) => {
    if (!assignmentId || !assignment || !user) return;

    const readings = getFinalReadings();

    const missingList: string[] = [];

    // Map camelCase keys or internal identifiers of readings to human-friendly titles
    const mapKeyToLabel = (key: string): string => {
      const map: Record<string, string> = {
        preparedBy: "Prepared By",
        testedBy: "Tested By",
        testerEmail: "Tester Email",
        witnessedBy: "Witnessed By",
        testDate: "Test Date",
        approvedBy: "Approved By",
        observations: "Observations",
        recommendations: "Recommendations",
        observationsAndRecommendations: "Observations & Recommendations",
        remarks: "Remarks",
        toolsUsed: "Tools Used",
        summary: "Summary / Narrative",
        ppeCategories: "PPE Categories Check",
        gloveClasses: "Glove Classes Check",
        workingDistances: "Working Distances",
        studyResults: "Study Results",
        inspectionRows: "Inspection Checklist",
        equipmentRows: "Equipment Details",
        readingRows: "Earthing Readings",
        measuringRows: "Measuring Checklist",
        dcSections: "DC Sections",
        elvChecklist: "ELV Checklist Rows",
        gapAnalysis: "Gap Analysis Matrix",
        onSiteTest: "On-Site Load Test",
        loadReadings: "DG Synchronizing & Load Run Audit",
        fuelSummary: "Fuel Summary",
        dgUnits: "DG Units Details",
        branchLoads: "Transformer & Branch Loading",
        tfLoads: "Transformer Loading Details Check",
        busVoltages: "Normal Bus Voltages",
        shortCircuits: "Short Circuit Fault Isolation",
        loadFlows: "System Load Flow Balancing",
        relayCoords: "Relay Settings",
        releaseSettings: "Standard Dynamic Settings",
        arcFlashRows: "Specific Arc Flash Boundaries",
        pfcBankRows: "PFC Capacitor Bank Check",
        pfcBalanceRows: "Load/Power Phase Balancing Table",
        capacitorPanels: "Capacitor Panels Inspection",
        toolsTable: "Thermography Tools & Calibration Check",
        inspectionRowsTherm: "Thermography Hotspot Analysis Details",
        imagesTable: "Critical Thermography Images Block",
        analysisGroups: "Power Quality Phase Analysis Metrics Block",
        temperatures: "Temperature Metrics Block",
        cacGroups: "Cold Aisle Cocooning Check Blocks",
        cacTables: "CAC Airflow Calculations Table",
        tools: "CFM Testing Tools Table",
        pahuTables: "PAHU/CAC Performance Table",
        pacTables: "PAC Load Capacity Table",
        toolsCapacity: "Capacity Assessment Tools Table",
        corrosionRows: "Main Copper Coupon Corrosion Data Table",
        locations: "Testing Location Boundaries & Details",
        toolsCoupon: "Corrosion Coupon Test Tools & Kit Details",
        strings: "Battery Strings Details Block",
        upsUnits: "UPS Units System Inspection",
        pahuPacInfo: "PAHU / PAC Equipment Information Table",
        pahuPacPerformance: "PAHU / PAC Operating Performance Table",
        obsolescenceSummary: "Obsolescence Lifecycle Status Check Table",
        vibrationGroups: "Vibration Frequency Analysis Table Check",
        equipmentVibr: "Vibration Test Equipment Records",
        abbreviations: "Technical Abbreviations Register",
        equipment: "Equipment Details Table",
        measurements: "Measurements Table"
      };
      return map[key] || key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()).trim();
    };

    const collectMissing = (val: any, path: string) => {
      if (typeof val === 'string') {
        if (val.trim() === '') {
          missingList.push(path);
        }
      } else if (Array.isArray(val)) {
        if (val.length === 0) {
          missingList.push(`${path} (requires at least one row)`);
        } else {
          val.forEach((row, idx) => {
            if (row && typeof row === 'object') {
              const rowMissingKeys: string[] = [];
              Object.entries(row).forEach(([k, subVal]) => {
                const skipKeys = [
                  'id', 'isVerified', 'workflowStatus', 'aiInsight', 
                  'pmComments', 'createdAt', 'updatedAt', 'userId', 
                  'projectId', 'testId', 'isDraft', 'imageUrl', 'graphImage'
                ];
                if (skipKeys.includes(k)) return;
                
                const checkIncompleteDeep = (item: any): boolean => {
                  if (typeof item === 'string') return item.trim() === '';
                  if (Array.isArray(item)) {
                    if (item.length === 0) return true;
                    return item.some(checkIncompleteDeep);
                  }
                  if (typeof item === 'object' && item !== null) {
                    if (item instanceof Date) return false;
                    return Object.entries(item).some(([sk, sv]) => {
                      if (skipKeys.includes(sk)) return false;
                      return checkIncompleteDeep(sv);
                    });
                  }
                  return false;
                };

                if (checkIncompleteDeep(subVal)) {
                  rowMissingKeys.push(mapKeyToLabel(k));
                }
              });
              if (rowMissingKeys.length > 0) {
                missingList.push(`${path} ➔ Row ${idx + 1} (${rowMissingKeys.slice(0, 3).join(', ')}${rowMissingKeys.length > 3 ? '...' : ''} missing)`);
              }
            } else if (typeof row === 'string' && row.trim() === '') {
              missingList.push(`${path} ➔ Row ${idx + 1} is blank`);
            }
          });
        }
      } else if (typeof val === 'object' && val !== null) {
        if (val instanceof Date) return;
        Object.entries(val).forEach(([key, v]) => {
          const skipKeys = [
            'id', 'isVerified', 'workflowStatus', 'aiInsight', 
            'pmComments', 'createdAt', 'updatedAt', 'userId', 
            'projectId', 'testId', 'isDraft', 'imageUrl', 'graphImage'
          ];
          if (skipKeys.includes(key)) return;
          const label = mapKeyToLabel(key);
          const nextPath = path ? `${path} ➔ ${label}` : label;
          collectMissing(v, nextPath);
        });
      }
    };

    // 1. Run deep validation on primary readings keys
    collectMissing(readings, "");

    // 2. Validate customizable dynamic schema fields (if custom test)
    if (testDef?.schema) {
      testDef.schema.forEach(field => {
        if (field.required) {
          const val = dynamicReadings[field.id];
          if (val === undefined || val === null || (typeof val === 'string' && val.trim() === '')) {
            missingList.push(`Required field: ${field.name || field.id}`);
          }
        }
      });
    }

    // 3. Check observations & recommendations Specifically
    const observationFields = ['observations', 'recommendations', 'observationsAndRecommendations'];
    observationFields.forEach(field => {
      const val = readings[field];
      if (val !== undefined && (typeof val === 'string' && val.trim() === '')) {
        missingList.push(`${mapKeyToLabel(field)} is blank`);
      }
    });

    const uniqueMissing = Array.from(new Set(missingList));

    if (!skipValidation && uniqueMissing.length > 0) {
      setMissingFields(uniqueMissing);
      setShowIncompleteModal(true);
      return;
    }

    setIsWorkflowProcessing(true);
    try {
      await handleSave();
      await ExecutionService.submitForReview(assignmentId, user);
      setAssignment(prev => prev ? { ...prev, workflowStatus: WorkflowStatus.SUBMITTED } : null);
    } catch (e) {
      alert("Submission failed.");
    } finally {
      setIsWorkflowProcessing(false);
    }
  };

  const handleApproveByPM = async () => {
    if (!assignmentId || !assignment || !user) return;
    setIsWorkflowProcessing(true);
    try {
      await ExecutionService.approveAssignment(assignmentId, user);
      setAssignment(prev => prev ? { ...prev, workflowStatus: WorkflowStatus.APPROVED } : null);
    } catch (e) {
      alert("Approval failed.");
    } finally {
      setIsWorkflowProcessing(false);
    }
  };

  const handleRejectByPM = async () => {
    if (!assignmentId || !assignment || !rejectComments || !user) return;
    setIsWorkflowProcessing(true);
    try {
      await ExecutionService.rejectAssignment(assignmentId, rejectComments, user);
      setAssignment(prev => prev ? { ...prev, workflowStatus: WorkflowStatus.REJECTED, pmComments: rejectComments } : null);
      setShowRejectModal(false);
      setRejectComments('');
    } catch (e) {
      alert("Rejection failed.");
    } finally {
      setIsWorkflowProcessing(false);
    }
  };

  const handleGenerateReport = async () => {
    if (!assignmentId || !assignment) return;
    setIsGeneratingReport(true);
    try {
        // Save first to ensure report has latest UI state
        await handleSave();
        
        const isDraft = assignment.workflowStatus !== WorkflowStatus.APPROVED;
        const url = await ExecutionService.generateReport(assignmentId, undefined, undefined, isDraft);
        setReportUrl(url);
    } catch (e: any) {
        alert(`Report generation failed: ${e.message}`);
    } finally {
        setIsGeneratingReport(false);
    }
  };

  if (loading || !assignment) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
            <div className="animate-spin w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full"></div>
        </div>
    );
  }

  const testName = assignment.testName.toLowerCase();
  const isArcFlashVal = testName.includes('arc flash');
  const isSPDVal = testName.includes('spd') || testName.includes('surge protective device');
  const isLAVal = testName.includes('lightning arrestor') || testName.includes('lightning protection');
  const isEarthVal = testName.includes('earth station') || testName.includes('earth continuity');
  const isSPOFVal = testName.includes('single point of failure');
  const isPowerVal = testName.includes('power system study');
  const isPFVal = testName.includes('power factor');
  const isTGVal = testName.includes('thermography');
  const isPQVal = testName.includes('power quality');
  const isRCIVal = testName.includes('rack cooling index');
  const isCFMVal = testName.includes('cfm') || testName.includes('airflow');
  const isELVGapVal = testName.includes('elv gap assessment');
  const isDGEnduranceVal = testName.includes('dg endurance');
  const isCapacityVal = testName.includes('capacity assessment') || testName.includes('pahu') || testName.includes('pac');
  const isCouponVal = testName.includes('coupon test') || testName.includes('corrosion');
  const isBatteryVal = testName.includes('battery') && (testName.includes('impedance') || testName.includes('impedence'));
  const isLifeCycleVal = testName.includes('life cycle assessment');
  const isVibrationVal = testName.includes('vibration analysis');

  return (
    <div className="w-full max-w-full mx-auto space-y-8 animate-fade-in pb-20 box-border">
        {/* Incomplete Form Warning */}
        <IncompleteFormModal 
          isOpen={showIncompleteModal} 
          onClose={() => setShowIncompleteModal(false)} 
          missingFields={missingFields}
          onSubmitAnyway={() => handleSubmitForPM(true)}
        />

        {/* PM Rejection Feedback Banner */}
        {assignment.workflowStatus === WorkflowStatus.REJECTED && (
          <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-6 flex items-start gap-4 shadow-xl shadow-red-100/50 animate-bounce-in">
             <div className="w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-2xl flex-shrink-0">⚠️</div>
             <div>
                <h4 className="font-black text-red-900 uppercase text-sm tracking-widest">PM Revision Required</h4>
                <p className="text-red-700 text-sm mt-1 italic font-medium leading-relaxed">"{assignment.pmComments}"</p>
                <p className="text-red-500 text-[10px] font-black uppercase mt-3 tracking-tighter">Edit mode re-enabled for corrections.</p>
             </div>
          </div>
        )}

        <div className="flex justify-between items-center bg-white p-6 rounded-2xl border border-slate-200 shadow-sm sticky top-4 z-30">
            <div className="flex items-center gap-4">
                <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">←</button>
                <div>
                    {project && (
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.15em]">{project.clientName}</span>
                        <span className="text-slate-300">|</span>
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.15em]">{project.name}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-3 group/title">
                      <h2 className="text-2xl font-black text-slate-800 leading-tight">{assignment.testName}</h2>
                      <button 
                        onClick={handleTogglePin}
                        className={`p-1.5 rounded-lg transition-all ${
                          assignment.pinnedBy?.includes(user?.uid || '') 
                            ? 'bg-amber-100 text-amber-600 shadow-inner' 
                            : 'bg-slate-50 text-slate-300 hover:text-amber-500 hover:bg-amber-50'
                        }`}
                        title={assignment.pinnedBy?.includes(user?.uid || '') ? 'Unpin Test' : 'Pin Test'}
                      >
                        <Pin size={18} className={assignment.pinnedBy?.includes(user?.uid || '') ? 'fill-amber-600' : ''} />
                      </button>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 mt-1">
                      <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                        <MapPin size={12} className="text-slate-400" />
                        <input 
                          type="text"
                          value={locationValue}
                          onChange={(e) => handleLocationUpdate(e.target.value)}
                          placeholder="Colo / Floor Name"
                          disabled={isDataLocked}
                          className="bg-transparent text-[10px] font-black text-slate-600 uppercase tracking-widest outline-none border-none p-0 w-28 placeholder:text-slate-300"
                        />
                      </div>

                      <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-100">
                        <span className="text-[10px] font-black shrink-0 text-emerald-500">DOC NO:</span>
                        <input 
                          type="text"
                          value={docNoValue}
                          onChange={(e) => handleDocNoUpdate(e.target.value)}
                          placeholder="Doc No"
                          disabled={isDataLocked}
                          className="bg-transparent text-[10px] font-black text-slate-700 placeholder:text-emerald-300 uppercase tracking-widest outline-none border-none p-0 w-44"
                        />
                      </div>
                      
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Protocol Execution</p>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter border
                        ${assignment.workflowStatus === WorkflowStatus.APPROVED ? 'bg-green-50 text-green-700 border-green-200' :
                          assignment.workflowStatus === WorkflowStatus.SUBMITTED ? 'bg-blue-50 text-blue-700 border-blue-200' :
                          assignment.workflowStatus === WorkflowStatus.REJECTED ? 'bg-red-50 text-red-700 border-red-200' :
                          assignment.workflowStatus === WorkflowStatus.DELETION_PENDING ? 'bg-amber-50 text-amber-700 border-amber-200' :
                          'bg-slate-50 text-slate-500 border-slate-200'}`}>
                        {assignment.workflowStatus}
                      </span>
                      <div className="flex items-center gap-1.5 ml-2">
                        <div className={`w-1.5 h-1.5 rounded-full ${isSaving ? 'bg-indigo-500 animate-pulse' : 'bg-green-500'}`}></div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                          {isSaving ? 'Saving...' : 'Saved'}
                        </span>
                      </div>
                    </div>
                </div>
            </div>

            <div className="flex items-center gap-3">
                {isDeletionPending || isDeletionApproved ? (
                  <div className={`px-6 py-2.5 ${isDeletionApproved ? 'bg-red-50 text-red-700 border-red-200' : 'bg-amber-50 text-amber-700 border-amber-200'} border rounded-xl text-xs font-black uppercase tracking-widest animate-pulse`}>
                    {isDeletionApproved ? '🚨 Deletion Approved - Data Locked' : '⚠️ Deletion Pending - Data Locked'}
                  </div>
                ) : (
                  <>
                    {isEngineer && (
                      <>
                        {!isDataLocked && (
                          <button onClick={() => handleSave(true)} disabled={isSaving} className="px-5 py-2.5 text-sm font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-lg transition-all">
                            {isSaving ? 'Saving...' : (assignment.workflowStatus === WorkflowStatus.APPROVED ? 'Update' : 'Save Draft')}
                          </button>
                        )}
                        {!isDataLocked && assignment.workflowStatus !== WorkflowStatus.APPROVED && (
                          <button onClick={handleSubmitForPM} disabled={isWorkflowProcessing} className="px-6 py-2.5 text-sm font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-2">
                            {isWorkflowProcessing ? 'Submitting...' : 'Submit for PM Approval'}
                          </button>
                        )}
                      </>
                    )}

                    {isPM && assignment.workflowStatus === WorkflowStatus.SUBMITTED && (
                      <>
                        <button onClick={() => setShowRejectModal(true)} disabled={isWorkflowProcessing} className="px-5 py-2.5 text-sm font-bold text-red-700 bg-red-50 border border-red-200 rounded-xl hover:bg-red-100 transition-all">
                            Reject with Comments
                        </button>
                        <button onClick={handleApproveByPM} disabled={isWorkflowProcessing} className="px-6 py-2.5 text-sm font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-100 transition-all">
                            {isWorkflowProcessing ? 'Processing...' : 'Approve Data'}
                        </button>
                      </>
                    )}

                    {assignment.workflowStatus !== WorkflowStatus.APPROVED && (
                      <button onClick={handleGenerateReport} disabled={isGeneratingReport} className="px-6 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-sm transition-all flex items-center justify-center gap-2">
                          {isGeneratingReport ? 'Processing...' : 'Generate Draft Report'}
                      </button>
                    )}

                    {assignment.workflowStatus === WorkflowStatus.APPROVED && (
                      <>
                        {isPM && isSpecialUser && (
                          <button onClick={() => handleSave(true)} disabled={isSaving} className="px-5 py-2.5 text-sm font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-lg transition-all">
                            {isSaving ? 'Updating...' : 'Update'}
                          </button>
                        )}
                        <button onClick={handleGenerateReport} disabled={isGeneratingReport} className="px-6 py-2.5 text-sm font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2">
                          {isGeneratingReport ? 'Processing...' : 'Generate Final Report'}
                        </button>
                      </>
                    )}
                  </>
                )}
            </div>
        </div>

        <div className="w-full space-y-10">
            <div className="w-full space-y-10">
                {isArcFlashVal ? (
                    <ArcFlashTables data={arcFlashData} onChange={setArcFlashData} readOnly={isDataLocked} />
                ) : isSPDVal ? (
                    <SPDHealthCheckTables data={spdData} onChange={setSpdData} readOnly={isDataLocked} />
                ) : isLAVal ? (
                    <LightningArrestorTables 
                        data={laData} 
                        onChange={setLaData} 
                        readOnly={isDataLocked} 
                        aiEnabled={testDef?.aiEnabled} 
                        liveCaptureConfig={testDef?.liveCaptureConfig} 
                    />
                ) : isEarthVal ? (
                    <EarthStationTables 
                      data={earthData} 
                      onChange={setEarthData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled}
                      liveCaptureConfig={testDef?.liveCaptureConfig}
                    />
                ) : isSPOFVal ? (
                    <SPOFTables data={spofData} onChange={setSpofData} templateName={testDef?.linkedTemplate?.name} readOnly={isDataLocked} />
                ) : isPowerVal ? (
                    <PowerSystemStudyTables data={powerSystemData} onChange={setPowerSystemData} readOnly={isDataLocked} />
                ) : isPFVal ? (
                    <PowerFactorTables 
                      data={powerFactorData} 
                      onChange={setPowerFactorData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig}
                    />
                ) : isTGVal ? (
                    <ThermographyTables 
                      data={thermographyData} 
                      onChange={setThermographyData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig}
                    />
                ) : isPQVal ? (
                    <PowerQualityTables data={powerQualityData} onChange={setPowerQualityData} readOnly={isDataLocked} />
                ) : isRCIVal ? (
                    <RackCoolingIndexTables 
                      data={rciData} 
                      onChange={setRciData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig || RCI_LIVE_CAPTURE_CONFIG}
                    />
                ) : isCFMVal ? (
                    <CFMTables 
                      data={cfmData} 
                      onChange={setCfmData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig || CFM_LIVE_CAPTURE_CONFIG}
                    />
                ) : isELVGapVal ? (

                    <ELVGapAssessmentTables data={elvGapData} onChange={setElvGapData} readOnly={isDataLocked} />
                ) : isDGEnduranceVal ? (
                    <DGEnduranceTables 
                      data={dgEnduranceData} 
                      onChange={setDgEnduranceData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig}
                    />
                ) : isCapacityVal ? (
                    <CapacityAssessmentTables 
                      data={capacityData} 
                      onChange={setCapacityData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig || CAPACITY_LIVE_CAPTURE_CONFIG}
                    />
                ) : isCouponVal ? (
                    <CouponTestTables data={couponData} onChange={setCouponData} readOnly={isDataLocked} />
                ) : isBatteryVal ? (
                    <BatteryImpedanceTables 
                      data={batteryImpedanceData} 
                      onChange={setBatteryImpedanceData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig}
                    />
                ) : isLifeCycleVal ? (
                    <LifeCycleAssessmentTables 
                      data={lifeCycleData} 
                      onChange={setLifeCycleData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                      liveCaptureConfig={testDef?.liveCaptureConfig || LCA_LIVE_CAPTURE_CONFIG}
                    />
                ) : isVibrationVal ? (
                    <VibrationAnalysisTables 
                      data={vibrationData} 
                      onChange={setVibrationData} 
                      readOnly={isDataLocked} 
                      aiEnabled={testDef?.aiEnabled !== false}
                    />
                ) : (
                        <div className="space-y-10">
                            <EquipmentTable data={equipmentData} onChange={setEquipmentData} readOnly={isDataLocked} />
                            {testDef?.schema && testDef.schema.length > 0 && (
                                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                                    <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
                                        <span className="text-xl">📊</span>
                                        <h4 className="font-black text-slate-800 uppercase text-sm tracking-tight">{assignment.testName} Measurements</h4>
                                    </div>
                                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                                        {testDef.schema.map(field => (
                                            <div key={field.id} className="space-y-2">
                                                <label className="text-xs font-black text-slate-500 uppercase tracking-widest">{field.label} {field.unit ? `(${field.unit})` : ''}</label>
                                                <input type={field.type === 'number' ? 'number' : 'text'} value={dynamicReadings[field.id] || ''} onChange={e => setDynamicReadings(prev => ({ ...prev, [field.id]: e.target.value }))} className="w-full border-slate-200 rounded-xl p-3.5 bg-slate-50 border focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm outline-none" placeholder={`Enter ${field.label}...`} disabled={isDataLocked} />
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                            <MeasurementTemplate units={upsData} onChange={setUpsData} title="Sub-Readings & Battery Matrix" readOnly={isDataLocked} />
                            
                            <TechnicalAuditSummary 
                                data={dynamicReadings.observationsAndRecommendations || INITIAL_OBSERVATIONS}
                                onChange={(d) => setDynamicReadings(prev => ({ ...prev, observationsAndRecommendations: d }))}
                                readOnly={isDataLocked}
                            />
                        </div>
                )}

                {reportUrl && (
                    <div className="bg-emerald-50 border-2 border-emerald-100 rounded-2xl p-6 flex flex-col items-center gap-4 text-center animate-bounce-in shadow-lg shadow-emerald-50 max-w-md mx-auto">
                        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-3xl">📄</div>
                        <h4 className="font-black text-emerald-900 text-sm uppercase">Report Ready</h4>
                        <a 
                            href={reportUrl} 
                            download={docNoValue ? `${docNoValue}.docx` : `${assignment?.workflowStatus === WorkflowStatus.APPROVED ? 'Report' : 'Draft_Report'}_${assignmentId}.docx`} 
                            className="w-full py-3 bg-emerald-600 text-white rounded-xl font-bold text-sm shadow-md hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                        >
                            <span>⬇️</span> Download DOCX
                        </a>
                    </div>
                )}
            </div>
        </div>

        {/* Reject Modal */}
        {showRejectModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
             <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl animate-bounce-in">
                <h3 className="text-xl font-black text-slate-900 mb-2 uppercase tracking-tighter">Reject Assignment</h3>
                <p className="text-slate-500 text-sm mb-6">Explain why the data is being rejected. This will unlock the report for the Engineer to edit.</p>
                <textarea 
                  value={rejectComments}
                  onChange={e => setRejectComments(e.target.value)}
                  className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-red-100 focus:border-red-500 transition-all text-sm italic mb-6 resize-none"
                  placeholder="Specify corrections needed..."
                />
                <div className="flex gap-4">
                   <button onClick={() => setShowRejectModal(false)} className="flex-1 py-3 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200">Cancel</button>
                   <button onClick={handleRejectByPM} disabled={!rejectComments.trim() || isWorkflowProcessing} className="flex-1 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-100">Send to Engineer</button>
                </div>
             </div>
          </div>
        )}
    </div>
  );
};

export default TestExecution;
