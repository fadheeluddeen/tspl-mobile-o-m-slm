
import React, { useState, useEffect } from 'react';
import { ExecutionService, ProjectService } from '../../services/mockDatabase';
import { TestAssignment, WorkflowStatus } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Pin, FileText, Download, MapPin, Building2, ExternalLink } from 'lucide-react';

const PinnedItems: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [pinnedTests, setPinnedTests] = useState<TestAssignment[]>([]);

    useEffect(() => {
        const loadPinned = async () => {
            if (!user) return;
            try {
                const all = await ExecutionService.fetchAssignmentsByEngineer(user.uid);
                const pinned = (all || []).filter(a => a.pinnedBy?.includes(user.uid));
                
                // Fetch project names and client names for each pinned test
                const enriched = await Promise.all(pinned.map(async (test) => {
                    if (test.projectName && test.projectName !== 'Internal Asset' && test.clientName) return test;
                    try {
                        const proj = await ProjectService.fetchProjectById(test.projectId);
                        return { 
                            ...test, 
                            projectName: proj?.name || 'Internal Asset',
                            clientName: proj?.clientName || ''
                        };
                    } catch (e) {
                        return test;
                    }
                }));

                setPinnedTests(enriched);
            } catch (e) {
                console.error("Failed to load pinned tests", e);
            } finally {
                setLoading(false);
            }
        };
        loadPinned();
    }, [user]);

    const handleUnpin = async (e: React.MouseEvent, assignmentId: string) => {
        e.stopPropagation();
        if (!user) return;
        try {
            await ExecutionService.togglePin(assignmentId, user.uid, user);
            setPinnedTests(prev => prev.filter(t => t.id !== assignmentId));
        } catch (e) {
            console.error("Unpin failed", e);
        }
    };

    const handleDownload = async (e: React.MouseEvent, test: TestAssignment) => {
        e.stopPropagation();
        try {
            const isDraft = test.workflowStatus !== WorkflowStatus.APPROVED;
            const url = await ExecutionService.generateReport(test.id, undefined, undefined, isDraft);
            
            // Trigger download
            const link = document.createElement('a');
            link.href = url;
            const customDocNo = test.docNo || test.readings?.docNo || test.readings?.doc_no;
            link.setAttribute('download', customDocNo ? `${customDocNo}.docx` : `${isDraft ? 'Draft_Report' : 'Final_Report'}_${test.id}.docx`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (e) {
            alert("Report generation failed");
        }
    };

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center py-32 gap-4">
                <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Accessing Pinned Data Vault...</p>
            </div>
        );
    }

    return (
        <div className="space-y-8 animate-fade-in max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
                    <Pin size={120} className="text-amber-500 -rotate-12" />
                </div>
                <div className="relative z-10">
                    <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                        <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center shadow-inner">
                            <Pin size={28} className="text-amber-500 fill-amber-500" />
                        </div>
                        Pinned Collections
                    </h1>
                    <p className="text-slate-500 font-medium mt-2">Quick access to your most critical and frequently referenced field test protocols.</p>
                </div>
                <div className="relative z-10 flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-2xl border border-slate-100">
                    <span className="text-xs font-black text-slate-500 uppercase tracking-widest">{pinnedTests.length} Items Locked</span>
                </div>
            </div>

            {pinnedTests.length === 0 ? (
                <div className="bg-white rounded-3xl border border-slate-200 p-24 flex flex-col items-center justify-center text-center gap-5 shadow-sm">
                    <div className="w-24 h-24 bg-slate-50 rounded-[40px] flex items-center justify-center text-4xl shadow-inner animate-pulse">📌</div>
                    <div className="space-y-1">
                        <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">No References Found</h3>
                        <p className="text-slate-500 max-w-sm text-sm font-medium">Tests you pin during execution or review will be consolidated here for mission-critical access.</p>
                    </div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {pinnedTests.map(test => (
                        <div 
                            key={test.id} 
                            onClick={() => navigate(`/execute/${test.id}`)}
                            className="bg-white p-7 rounded-[32px] border border-slate-200 shadow-sm hover:shadow-2xl hover:border-amber-300 transition-all group relative cursor-pointer flex flex-col overflow-hidden"
                        >
                            {/* Pin Indicator */}
                            <button 
                                onClick={(e) => handleUnpin(e, test.id)}
                                className="absolute top-5 right-5 p-2.5 bg-amber-50 text-amber-500 rounded-2xl hover:bg-rose-50 hover:text-rose-500 transition-all z-10 border border-amber-100/50 active:scale-90"
                                title="Unpin from collection"
                            >
                                <Pin size={18} className="fill-amber-500" />
                            </button>

                            <div className="flex items-center gap-4 mb-6">
                                <div className="w-14 h-14 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center text-xl shadow-inner group-hover:bg-amber-600 group-hover:text-white transition-all transform group-hover:scale-110">
                                    <FileText size={28} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-1.5 mb-1 overflow-hidden">
                                            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest shrink-0">{test.clientName || 'Internal'}</span>
                                            <span className="text-[10px] font-black text-slate-300">|</span>
                                            <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest truncate">{test.projectName || 'Asset'}</span>
                                        </div>
                                        <h4 className="font-black text-slate-900 leading-tight truncate group-hover:text-amber-600 transition-colors uppercase tracking-tight text-[15px]">
                                            {test.testName}
                                        </h4>
                                    </div>
                                    <div className="flex flex-wrap items-center gap-2 mt-2">
                                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-[0.1em] border
                                            ${test.workflowStatus === WorkflowStatus.APPROVED ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                                              test.workflowStatus === WorkflowStatus.SUBMITTED ? 'bg-blue-50 text-blue-700 border-blue-100' :
                                              test.workflowStatus === WorkflowStatus.REJECTED ? 'bg-rose-50 text-rose-700 border-rose-100' :
                                              'bg-slate-50 text-slate-500 border-slate-200'}`}>
                                            {test.workflowStatus}
                                        </span>
                                        {test.location && (
                                            <span className="text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-[0.1em] border bg-indigo-50 text-indigo-700 border-indigo-100">
                                                {test.location}
                                            </span>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="flex-1">
                                {/* Optional: Add brief summary or recent values if needed */}
                            </div>

                            <div className="mt-auto pt-6 border-t border-slate-50 flex gap-3">
                                {test.workflowStatus === WorkflowStatus.APPROVED && (
                                    <button 
                                        onClick={(e) => handleDownload(e, test)}
                                        className="flex-1 py-3 bg-emerald-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.15em] hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-100 active:translate-y-0.5 animate-in fade-in zoom-in duration-300"
                                    >
                                        <Download size={14} strokeWidth={3} /> Get Report
                                    </button>
                                )}
                                <button 
                                    onClick={() => navigate(`/execute/${test.id}`)}
                                    className={`px-5 py-3 bg-white text-slate-600 rounded-2xl font-black text-[10px] uppercase tracking-[0.15em] hover:bg-slate-50 transition-all border border-slate-200 group-hover:border-amber-200 ${test.workflowStatus !== WorkflowStatus.APPROVED ? 'flex-1' : ''}`}
                                >
                                    {test.workflowStatus !== WorkflowStatus.APPROVED ? (
                                        <span className="flex items-center justify-center gap-2">
                                            <ExternalLink size={14} strokeWidth={3} /> View Protocol
                                        </span>
                                    ) : (
                                        <ExternalLink size={14} strokeWidth={3} />
                                    )}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default PinnedItems;
