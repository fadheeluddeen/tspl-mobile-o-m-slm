
import React, { useState, useRef, useEffect } from 'react';
import { TestDefinition, TestField, TestTemplateMetadata, ArcFlashReading, LightningArrestorReading, EarthStationReading, SPOFReading, PowerSystemReading, PowerFactorReading, SPDReading, ThermographyReading, PowerQualityReading, RackCoolingIndexReading, ELVGapAssessmentReading, DGEnduranceReading, CapacityAssessmentReading, CouponTestReading, BatteryImpedanceReading, LifeCycleReading, CFMReading, UserRole, VibrationAnalysisReading, LiveCaptureConfig } from '../../types';
import TemplateCard from '../../components/TemplateCard';
import { TestLibraryService, ExecutionService } from '../../services/mockDatabase';
import { TemplateGeneratorService } from '../../services/templateGenerator';
import { useAuth } from '../../context/AuthContext';
import { 
    EquipmentTable, 
    MeasurementTemplate, 
    TechnicalAuditSummary,
    EquipmentRow, 
    UpsUnit, 
    INITIAL_EQUIPMENT, 
    INITIAL_UPS_DATA,
    INITIAL_OBSERVATIONS
} from '../../components/TestTables';
import { ArcFlashTables, INITIAL_ARC_FLASH_DATA } from '../../components/ArcFlashTables';
import { LightningArrestorTables, INITIAL_LA_DATA } from '../../components/LightningArrestorTables';
import { EarthStationTables, INITIAL_EARTH_STATION_DATA } from '../../components/EarthStationTables';
import { SPOFTables, INITIAL_SPOF_DATA } from '../../components/SPOFTables';
import { PowerSystemStudyTables, INITIAL_POWER_SYSTEM_DATA } from '../../components/PowerSystemStudyTables';
import { PowerFactorTables, INITIAL_POWER_FACTOR_DATA } from '../../components/PowerFactorTables';
import { SPDHealthCheckTables, INITIAL_SPD_HEALTH_DATA } from '../../components/SPDHealthCheckTables';
import { ThermographyTables, INITIAL_THERMOGRAPHY_DATA } from '../../components/ThermographyTables';
import { exportThermographyToExcel } from '../../utils/excelExport';
import { PowerQualityTables, INITIAL_POWER_QUALITY_DATA } from '../../components/PowerQualityTables';
import { RackCoolingIndexTables, INITIAL_RCI_DATA } from '../../components/RackCoolingIndexTables';
import { CFMTables, INITIAL_CFM_DATA } from '../../components/CFMTables';
import { ELVGapAssessmentTables, INITIAL_ELV_GAP_DATA } from '../../components/ELVGapAssessmentTables';
import { DGEnduranceTables, INITIAL_DG_ENDURANCE_DATA } from '../../components/DGEnduranceTables';
import { CapacityAssessmentTables, INITIAL_CAPACITY_DATA } from '../../components/CapacityAssessmentTables';
import { CouponTestTables, INITIAL_COUPON_DATA } from '../../components/CouponTestTables';
import { BatteryImpedanceTables, INITIAL_BATTERY_IMPEDANCE_DATA } from '../../components/BatteryImpedanceTables';
import { LifeCycleAssessmentTables, INITIAL_LIFE_CYCLE_DATA } from '../../components/LifeCycleAssessmentTables';
import { VibrationAnalysisTables, INITIAL_VIBRATION_DATA } from '../../components/VibrationAnalysisTables';

const POWER_FACTOR_LIVE_CAPTURE_CONFIG = {
  tables: [
    {
      tableKey: 'balanceRows',
      tableName: 'Temperature & Phase Current Readings',
      fields: [
        {
          key: 'caseTemp',
          label: 'Case Temperature',
          unit: '°C',
          readingGuidance: 'Read the temperature value shown on the meter or thermal scanner in °C for case temperature. Preserve decimals. Ignore secondary readouts, range text, battery icon, and limit values.',
          group: 'balance'
        },
        {
          key: 'currentR',
          label: 'R Phase Current',
          unit: 'A',
          readingGuidance: 'Read the live AC current measurement shown in Amperes (A) on the MECO 1080 clamp meter for R phase. Preserve decimals. Ignore range/mode text, MIN/MAX/HOLD annunciators, secondary readouts, battery icon, and limit values.',
          group: 'balance'
        },
        {
          key: 'currentY',
          label: 'Y Phase Current',
          unit: 'A',
          readingGuidance: 'Read the live AC current measurement shown in Amperes (A) on the MECO 1080 clamp meter for Y phase. Preserve decimals. Ignore range/mode text, MIN/MAX/HOLD annunciators, secondary readouts, battery icon, and limit values.',
          group: 'balance'
        },
        {
          key: 'currentB',
          label: 'B Phase Current',
          unit: 'A',
          readingGuidance: 'Read the live AC current measurement shown in Amperes (A) on the MECO 1080 clamp meter for B phase. Preserve decimals. Ignore range/mode text, MIN/MAX/HOLD annunciators, secondary readouts, battery icon, and limit values.',
          group: 'balance'
        }
      ]
    },
    {
      tableKey: 'bankRows',
      tableName: 'Capacitor Bank Metrics',
      fields: [
        {
          key: 'measuredKvar',
          label: 'Measured kVAR',
          unit: 'kVAR',
          readingGuidance: 'Read the live reactive power measurement in kVAR shown on the meter display. Preserve decimals. Ignore ratings, limit thresholds, secondary readouts, range text, and battery icon.',
          group: 'bank'
        },
        {
          key: 'actualRY',
          label: 'Actual RY Capacitance',
          unit: 'µF',
          readingGuidance: 'Read the live RY phase capacitance value in microfarads (µF) shown on the meter display. Preserve decimals. Ignore nominal ratings, limits, range text, and battery icon.',
          group: 'bank'
        },
        {
          key: 'actualYB',
          label: 'Actual YB Capacitance',
          unit: 'µF',
          readingGuidance: 'Read the live YB phase capacitance value in microfarads (µF) shown on the meter display. Preserve decimals. Ignore nominal ratings, limits, range text, and battery icon.',
          group: 'bank'
        },
        {
          key: 'actualBR',
          label: 'Actual BR Capacitance',
          unit: 'µF',
          readingGuidance: 'Read the live BR phase capacitance value in microfarads (µF) shown on the meter display. Preserve decimals. Ignore nominal ratings, limits, range text, and battery icon.',
          group: 'bank'
        }
      ]
    }
  ],
  jsonShape: { value: '' },
  keepPhotoAsEvidence: false
};

export const DG_ENDURANCE_LIVE_CAPTURE_CONFIG: LiveCaptureConfig = {
  tables: [
    {
      tableKey: 'params',
      tableName: 'T1 Parameter Matrix',
      matrix: { rowsKey: 'loadReadings', colsKey: 'loads' },
      fields: [
        {
          key: 'electrical',
          label: 'Electrical Parameters',
          readingGuidance: 'Read from the Power Quality Analyzer / Clamp Meter (MECO 1080) — read the single labelled value in its shown unit. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values. One value per photo.'
        },
        {
          key: 'mechanical',
          label: 'Mechanical Parameters',
          readingGuidance: 'Read from the DG panel/gauge display — read the single labelled value in its shown unit. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values. One value per photo.'
        }
      ]
    },
    {
      tableKey: 'noise',
      tableName: 'T3 Noise Level Measurement',
      fields: [
        {
          key: 'open',
          label: 'Doors Open Noise Level',
          unit: 'dB',
          readingGuidance: 'Read from the Sound Level Meter (WINTACT WT85B) — the dB(A) value. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.'
        },
        {
          key: 'closed',
          label: 'Doors Closed Noise Level',
          unit: 'dB',
          readingGuidance: 'Read from the Sound Level Meter (WINTACT WT85B) — the dB(A) value. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.'
        }
      ]
    },
    {
      tableKey: 'vibration',
      tableName: 'T4 Vibration Level Measurement',
      matrix: { rowsKey: 'vibrationLevels', colsKey: 'points' },
      fields: [
        {
          key: 'vibration',
          label: 'Vibration Level',
          unit: 'm/s²',
          readingGuidance: 'Read from the Vibration Meter (WINTACT WT63B) — the overall velocity/vibration value in the shown unit. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.'
        }
      ]
    },
    {
      tableKey: 'fuel',
      tableName: 'T5 Fuel Consumption Summary',
      fields: [
        {
          key: 'kwhInitial',
          label: 'kWh Generated Initial',
          unit: 'kWh',
          readingGuidance: 'Read the numeric totalizer/gauge value shown on the meter for initial kWh. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.'
        },
        {
          key: 'kwhFinal',
          label: 'kWh Generated Final',
          unit: 'kWh',
          readingGuidance: 'Read the numeric totalizer/gauge value shown on the meter for final kWh. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.'
        },
        {
          key: 'fuelInitial',
          label: 'Fuel in Litres Initial',
          unit: 'Litres',
          readingGuidance: 'Read the numeric fuel level gauge value shown for initial fuel in litres. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.'
        },
        {
          key: 'fuelFinal',
          label: 'Fuel in Litres Final',
          unit: 'Litres',
          readingGuidance: 'Read the numeric fuel level gauge value shown for final fuel in litres. Preserve decimals, ignore mode/range/min-max/hold text, secondary readouts, battery and status icons, and any limit values.'
        }
      ]
    }
  ],
  jsonShape: { value: '' },
  keepPhotoAsEvidence: false
};

export const RCI_LIVE_CAPTURE_CONFIG: LiveCaptureConfig = {
  tables: [
    {
      tableKey: 'temperatureRows',
      tableName: 'Temperature Measurement Portfolio',
      fields: [
        {
          key: 'front15U',
          label: 'Front End Temp (15U)',
          unit: '°C',
          readingGuidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text. Return single temperature value.',
          group: 'front15'
        },
        {
          key: 'front22U_group',
          label: 'Front End Temp & RH% (22U)',
          readingGuidance: 'Read BOTH the temperature value and relative humidity (%RH) value shown on the FLUKE 971 display. Preserve decimals exactly. Ignore dew point, min/max/hold annunciators, battery icon, and mode/range text.',
          group: 'front22'
        },
        {
          key: 'front35U',
          label: 'Front End Temp (35U)',
          unit: '°C',
          readingGuidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text. Return single temperature value.',
          group: 'front35'
        },
        {
          key: 'rear15U',
          label: 'Rear End Temp (15U)',
          unit: '°C',
          readingGuidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text. Return single temperature value.',
          group: 'rear15'
        },
        {
          key: 'rear22U_group',
          label: 'Rear End Temp & RH% (22U)',
          readingGuidance: 'Read BOTH the temperature value and relative humidity (%RH) value shown on the FLUKE 971 display. Preserve decimals exactly. Ignore dew point, min/max/hold annunciators, battery icon, and mode/range text.',
          group: 'rear22'
        },
        {
          key: 'rear35U',
          label: 'Rear End Temp (35U)',
          unit: '°C',
          readingGuidance: 'Read the temperature value shown on the FLUKE 971 display in °C or °F. Preserve decimals. Ignore relative humidity, dew point, min/max/hold annunciators, battery icon, and mode/range text. Return single temperature value.',
          group: 'rear35'
        }
      ]
    }
  ],
  jsonShape: { value: '' },
  keepPhotoAsEvidence: false
};

export const CAPACITY_LIVE_CAPTURE_CONFIG: LiveCaptureConfig = {
  tables: [
    {
      tableKey: 'pahuTables',
      tableName: '6.1 PAHU Capacity Assessment',
      fields: [
        {
          key: 'measuredAirflow',
          label: 'Airflow (Volume Flow Hood)',
          unit: 'CFM',
          readingGuidance: 'Read ONLY the airflow value in its shown unit (CFM or m³/h) from the Volume Flow Hood display (testo 420). Ignore velocity and temperature. Preserve decimals.'
        },
        {
          key: 'measuredSaTemp',
          label: 'SA Temp (Temperature Humidity Meter)',
          unit: '°C',
          readingGuidance: 'Read ONLY the Supply Air (SA) temperature value in °C from the Temperature Humidity Meter (FLUKE 971). Ignore relative humidity and dew point. Preserve decimals.'
        },
        {
          key: 'measuredRaTemp',
          label: 'RA Temp (Temperature Humidity Meter)',
          unit: '°C',
          readingGuidance: 'Read ONLY the Return Air (RA) temperature value in °C from the Temperature Humidity Meter (FLUKE 971). Ignore relative humidity and dew point. Preserve decimals.'
        },
        {
          key: 'measuredWaterFlowRate',
          label: 'Water Flow (Ultrasonic Flow Meter)',
          unit: 'GPM',
          readingGuidance: 'Read ONLY the water flow rate value in its shown unit (GPM, m³/h, or L/min) from the Ultrasonic Flow Meter (EIS TUF-2000H). Ignore flow velocity and totalizer. Preserve decimals.'
        }
      ]
    }
  ],
  jsonShape: { value: '' },
  keepPhotoAsEvidence: false
};

export const LCA_LIVE_CAPTURE_CONFIG: LiveCaptureConfig = {
  tables: [
    {
      tableKey: 'lifeCycleRows',
      tableName: '4.1 Table-1 Equipment Summary & Factor Calculation',
      fields: [
        {
          key: 'surfaceTemp',
          label: 'Surface Temp (°C)',
          unit: '°C',
          keepPhotoAsEvidence: true,
          readingGuidance: 'Read ONLY the spot temperature value shown on the display in °C from the Thermal Imager / Visual IR (FLUKE VT08), preserving decimals. Ignore emissivity settings, colour-scale bar numbers, battery icon, and mode text. Keep the photo as evidence.'
        },
        {
          key: 'vibrationVelocity',
          label: 'Vibration Velocity (mm/s)',
          unit: 'mm/s',
          keepPhotoAsEvidence: false,
          readingGuidance: 'Read ONLY the overall vibration velocity value shown on the display in mm/s from the Vibration Meter (WINTACT WT63B), preserving decimals. Ignore acceleration or displacement readouts if display cycles, and any mode/hold indicators.'
        }
      ]
    }
  ],
  jsonShape: { value: '' },
  keepPhotoAsEvidence: false
};

export const CFM_LIVE_CAPTURE_CONFIG: LiveCaptureConfig = {
  tables: [
    {
      tableKey: 'cacTables',
      tableName: 'CFM CAC Airflow Analysis',
      fields: [
        {
          key: 'actualCFM',
          label: 'Actual Airflow (CFM)',
          unit: 'CFM',
          readingGuidance: 'Read the single airflow value shown, in its displayed unit (CFM, CMM, or m³/h — read exactly as shown, do not convert). If using the anemometer (G-tech AVM-02) or flow hood (Testo 420): ignore air-velocity (m/s, ft/min) and temperature readouts; read only the airflow/CFM figure. Ignore mode/range text, min/max/hold indicators, and battery icons on either instrument.'
        }
      ]
    }
  ],
  jsonShape: { value: '' },
  keepPhotoAsEvidence: false
};




const DynamicFieldTable: React.FC<{ fields: TestField[]; title: string }> = ({ fields, title }) => {
  return (
    <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden mt-6">
      <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
         <h4 className="text-sm font-bold text-slate-700 uppercase tracking-tight">{title}</h4>
         <span className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded font-bold uppercase">Field Preview</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-slate-800 text-white divide-x divide-slate-700">
              <th className="px-4 py-3 w-12 text-center">#</th>
              {(fields || []).map(f => (
                <th key={f.id} className="px-4 py-3 font-semibold">
                  {f.label} {f.unit ? `(${f.unit})` : ''}
                </th>
              ))}
              <th className="px-4 py-3 w-24">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {[1, 2].map(i => (
              <tr key={i} className="divide-x divide-slate-100">
                <td className="px-4 py-3 text-center bg-slate-50 text-slate-400 font-mono">{i}</td>
                {(fields || []).map(f => (
                  <td key={f.id} className="px-4 py-3">
                    <input 
                      disabled 
                      placeholder={f.type === 'number' ? '0.00' : '...'} 
                      className="w-full bg-transparent outline-none italic text-slate-400"
                    />
                  </td>
                ))}
                <td className="px-4 py-3 bg-green-50 text-green-700 font-bold text-center">Pass</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

interface SchemaBuilderProps {
  fields: TestField[];
  onChange: (fields: TestField[]) => void;
}

const SchemaBuilder: React.FC<SchemaBuilderProps> = ({ fields, onChange }) => {
  const addField = () => {
    onChange([
      ...(fields || []), 
      { id: `field-${Date.now()}`, label: '', type: 'text', required: true, unit: '' }
    ]);
  };

  const updateField = (index: number, key: keyof TestField, value: any) => {
    const newFields = [...(fields || [])];
    newFields[index] = { ...newFields[index], [key]: value };
    onChange(newFields);
  };

  const removeField = (index: number) => {
    const newFields = (fields || []).filter((_, i) => i !== index);
    onChange(newFields);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
          <div>
            <h3 className="font-semibold text-slate-800">Data Tables & Input Schema</h3>
            <p className="text-xs text-slate-500">Define the columns and data types engineers will collect.</p>
          </div>
        </div>
        
        {(!fields || fields.length === 0) ? (
          <div className="p-12 text-center">
            <div className="mx-auto w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center mb-3">
               <span className="text-xl">📊</span>
            </div>
            <p className="text-slate-500 italic mb-4 font-medium">Your data table is currently empty.</p>
            <button 
               onClick={addField}
               className="px-6 py-2 bg-slate-100 text-slate-700 text-sm font-bold rounded-lg hover:bg-slate-200 transition-colors"
            >
               Add First Column
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase tracking-tighter text-[11px]">
                <tr>
                  <th className="px-4 py-3 w-8">#</th>
                  <th className="px-4 py-3">Column Label</th>
                  <th className="px-4 py-3 w-32">Type</th>
                  <th className="px-4 py-3 w-24">Unit</th>
                  <th className="px-4 py-3 w-24 text-center">Required</th>
                  <th className="px-4 py-3 w-16"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(fields || []).map((field, idx) => (
                    <tr key={field.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-slate-400 font-mono text-xs">{idx + 1}</td>
                      <td className="px-4 py-3">
                        <input 
                          type="text" 
                          value={field.label}
                          onChange={e => updateField(idx, 'label', e.target.value)}
                          placeholder="e.g. Phase A Voltage"
                          className="w-full border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 px-3 py-1.5 border"
                        />
                      </td>
                      <td className="px-4 py-3">
                        <select 
                          value={field.type}
                          onChange={e => updateField(idx, 'type', e.target.value)}
                          className="w-full border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 px-2 py-1.5 border"
                        >
                          <option value="text">Text</option>
                          <option value="number">Number</option>
                          <option value="boolean">Yes/No</option>
                          <option value="date">Date</option>
                        </select>
                      </td>
                      <td className="px-4 py-3">
                        <input 
                          type="text" 
                          value={field.unit || ''}
                          onChange={e => updateField(idx, 'unit', e.target.value)}
                          placeholder="e.g. V"
                          className="w-full border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 px-3 py-1.5 border"
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        <input 
                          type="checkbox" 
                          checked={field.required}
                          onChange={e => updateField(idx, 'required', e.target.checked)}
                          className="rounded text-indigo-600 focus:ring-indigo-500 h-5 w-5 border-slate-300"
                        />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button 
                          onClick={() => removeField(idx)}
                          className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-all"
                          title="Remove Field"
                        >
                          🗑️
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-center">
                <button 
                   onClick={addField}
                   className="text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-100 px-4 py-2 rounded-lg transition-colors uppercase tracking-wide"
                >
                   + Add Column
                </button>
            </div>
          </div>
        )}
      </div>

      {fields && fields.length > 0 && (
        <DynamicFieldTable fields={fields} title="Execution Table Preview" />
      )}
    </div>
  );
};

interface TestEditorPageProps {
  test: TestDefinition;
  onBack: () => void;
  onSave: (updatedTest: TestDefinition) => void;
  initialTab?: 'SCHEMA' | 'TEMPLATE' | 'SETTINGS' | 'PREVIEW';
}

const TestEditorPage: React.FC<TestEditorPageProps> = ({ test, onBack, onSave, initialTab = 'SCHEMA' }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'SCHEMA' | 'TEMPLATE' | 'SETTINGS' | 'PREVIEW'>(initialTab);
  const [localTest, setLocalTest] = useState<TestDefinition>(test);
  const [isSaving, setIsSaving] = useState(false);
  const [isDownloadingTemplate, setIsDownloadingTemplate] = useState(false);

  const [equipment, setEquipment] = useState<EquipmentRow[]>(INITIAL_EQUIPMENT);
  const [units, setUnits] = useState<UpsUnit[]>(INITIAL_UPS_DATA);
  const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  const testNameLower = (localTest.name || '').toLowerCase();
  const isArcFlash = testNameLower.includes('arc flash');
  const isLA = testNameLower.includes('lightning arrestor') || testNameLower.includes('lightning protection');
  const isEarthStation = testNameLower.includes('earth station') || testNameLower.includes('earth continuity');
  const isSPOF = testNameLower.includes('single point of failure');
  const isPowerSystem = testNameLower.includes('power system study');
  const isPowerFactor = testNameLower.includes('power factor');
  const isSPD = testNameLower.includes('spd');
  const isThermography = testNameLower.includes('thermography');
  const isPowerQuality = testNameLower.includes('power quality analysis');
  const isRCI = testNameLower.includes('rack cooling index');
  const isCFM = testNameLower.includes('cfm') || testNameLower.includes('airflow');
  const isELVGap = testNameLower.includes('elv gap assessment');
  const isDGEndurance = testNameLower.includes('dg endurance');
  const isCapacity = testNameLower.includes('capacity assessment') || testNameLower.includes('pahu') || testNameLower.includes('pac');
  const isCoupon = testNameLower.includes('coupon test') || testNameLower.includes('corrosion');
  const isBatteryImpedance = testNameLower.includes('battery') && (testNameLower.includes('impedance') || testNameLower.includes('impedence'));
  const isLifeCycle = testNameLower.includes('life cycle assessment');
  const isVibrationAnalysis = testNameLower.includes('vibration analysis');

  const [arcFlashTemplateData, setArcFlashTemplateData] = useState<ArcFlashReading>(
    localTest.arcFlashTemplate || INITIAL_ARC_FLASH_DATA
  );
  const [laTemplateData, setLaTemplateData] = useState<LightningArrestorReading>(
    localTest.laTemplate || INITIAL_LA_DATA
  );
  const [earthStationTemplateData, setEarthStationTemplateData] = useState<EarthStationReading>(
    localTest.earthStationTemplate || INITIAL_EARTH_STATION_DATA
  );
  const [spofTemplateData, setSpofTemplateData] = useState<SPOFReading>(
    localTest.spofTemplate || INITIAL_SPOF_DATA
  );
  const [powerSystemTemplateData, setPowerSystemTemplateData] = useState<PowerSystemReading>(
    localTest.powerSystemTemplate || INITIAL_POWER_SYSTEM_DATA
  );
  const [powerFactorTemplateData, setPowerFactorTemplateData] = useState<PowerFactorReading>(
    localTest.powerFactorTemplate || INITIAL_POWER_FACTOR_DATA
  );
  const [spdTemplateData, setSpdTemplateData] = useState<SPDReading>(
    localTest.spdTemplate || INITIAL_SPD_HEALTH_DATA
  );
  const [thermographyTemplateData, setThermographyTemplateData] = useState<ThermographyReading>(
    localTest.thermographyTemplate || INITIAL_THERMOGRAPHY_DATA
  );
  const [powerQualityTemplateData, setPowerQualityTemplateData] = useState<PowerQualityReading>(
    localTest.powerQualityTemplate || INITIAL_POWER_QUALITY_DATA
  );
  const [rciTemplateData, setRciTemplateData] = useState<RackCoolingIndexReading>(
    localTest.rciTemplate || INITIAL_RCI_DATA
  );
  const [cfmTemplateData, setCfmTemplateData] = useState<CFMReading>(
    localTest.cfmTemplate || INITIAL_CFM_DATA
  );
  const [elvGapTemplateData, setElvGapTemplateData] = useState<ELVGapAssessmentReading>(
    localTest.elvGapTemplate || INITIAL_ELV_GAP_DATA
  );
  const [dgEnduranceTemplateData, setDgEnduranceTemplateData] = useState<DGEnduranceReading>(
    localTest.dgEnduranceTemplate || INITIAL_DG_ENDURANCE_DATA
  );
  const [capacityTemplateData, setCapacityTemplateData] = useState<CapacityAssessmentReading>(
    localTest.capacityAssessmentTemplate || INITIAL_CAPACITY_DATA
  );
  const [couponTemplateData, setCouponTemplateData] = useState<CouponTestReading>(
    localTest.couponTestTemplate || INITIAL_COUPON_DATA
  );
  const [batteryImpedanceTemplateData, setBatteryImpedanceTemplateData] = useState<BatteryImpedanceReading>(
    localTest.batteryImpedanceTemplate || INITIAL_BATTERY_IMPEDANCE_DATA
  );
  const [lifeCycleTemplateData, setLifeCycleTemplateData] = useState<LifeCycleReading>(
    localTest.lifeCycleTemplate || INITIAL_LIFE_CYCLE_DATA
  );
  const [vibrationAnalysisTemplateData, setVibrationAnalysisTemplateData] = useState<VibrationAnalysisReading>(
    localTest.vibrationAnalysisTemplate || INITIAL_VIBRATION_DATA
  );

  const handleSchemaChange = (newSchema: TestField[]) => {
    setLocalTest(prev => ({ ...prev, schema: newSchema }));
  };

  const handleTemplateUploadSuccess = (metadata: TestTemplateMetadata) => {
    setLocalTest(prev => ({ ...prev, linkedTemplate: metadata }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const finalTest = { ...localTest };
      if (isArcFlash) finalTest.arcFlashTemplate = arcFlashTemplateData;
      else if (isLA) {
        finalTest.laTemplate = laTemplateData;
        if (!finalTest.liveCaptureConfig) {
          finalTest.liveCaptureConfig = {
            fields: [
              {
                key: 'groundingValue',
                label: 'Grounding Value',
                unit: 'Ω',
                readingGuidance: 'Read the primary earth-resistance value shown, in ohms (Ω). Preserve decimals exactly. Ignore: range selector text (0–30 / 1000Ω), test-in-progress and battery indicators, any secondary/limit readouts, and mode annunciators. Read only the live primary measurement.'
              }
            ],
            jsonShape: {
              groundingValue: ''
            },
            keepPhotoAsEvidence: false
          };
        }
      }
      else if (isEarthStation) {
        finalTest.earthStationTemplate = earthStationTemplateData;
        finalTest.liveCaptureConfig = {
          fields: [
            {
              key: 'measuredValue',
              label: 'Measured Value',
              unit: 'Ω',
              readingGuidance: 'Read the primary resistance/impedance value displayed, in ohms (Ω) (it may show mΩ or µΩ on contact-resistance meters — read the number and its unit exactly as shown; preserve decimals). Ignore range/mode text, test-current readouts, pass/fail indicators, memory/hold annunciators, battery icon, and any secondary/limit values. Read only the live primary measurement.',
              group: 'reading'
            }
          ],
          jsonShape: {
            measuredValue: ''
          },
          keepPhotoAsEvidence: false
        };
      }
      else if (isSPOF) finalTest.spofTemplate = spofTemplateData;
      else if (isPowerSystem) finalTest.powerSystemTemplate = powerSystemTemplateData;
      else if (isPowerFactor) {
        finalTest.powerFactorTemplate = powerFactorTemplateData;
        finalTest.liveCaptureConfig = POWER_FACTOR_LIVE_CAPTURE_CONFIG;
      }
      else if (isSPD) finalTest.spdTemplate = spdTemplateData;
      else if (isThermography) {
        finalTest.thermographyTemplate = thermographyTemplateData;
        finalTest.liveCaptureConfig = {
          fields: [
            {
              key: 'maxTemp',
              label: 'Max Temp',
              unit: '°C',
              readingGuidance: 'Read the MAX temperature value (the higher of the two overlaid °C numbers, usually labelled or positioned as max/hot) in °C. Ignore emissivity, centre-spot, scale bar, and battery.',
              group: 'temps'
            },
            {
              key: 'minTemp',
              label: 'Min Temp',
              unit: '°C',
              readingGuidance: 'Read the MIN temperature value (the lower of the two overlaid °C numbers, usually labelled or positioned as min/cold) in °C. Ignore emissivity, centre-spot, scale bar, and battery.',
              group: 'temps'
            },
            {
              key: 'criticalImage',
              label: 'Critical Image',
              readingGuidance: 'Capture the visual/thermal image of the equipment.',
              group: 'images'
            }
          ],
          jsonShape: {
            maxTemp: '',
            minTemp: ''
          },
          keepPhotoAsEvidence: true
        };
      }
      else if (isPowerQuality) finalTest.powerQualityTemplate = powerQualityTemplateData;
      else if (isRCI) {
        finalTest.rciTemplate = rciTemplateData;
        finalTest.liveCaptureConfig = RCI_LIVE_CAPTURE_CONFIG;
      }
      else if (isCFM) {
        finalTest.cfmTemplate = cfmTemplateData;
        finalTest.liveCaptureConfig = CFM_LIVE_CAPTURE_CONFIG;
      }
      else if (isELVGap) finalTest.elvGapTemplate = elvGapTemplateData;

      else if (isDGEndurance) {
        finalTest.dgEnduranceTemplate = dgEnduranceTemplateData;
        finalTest.liveCaptureConfig = DG_ENDURANCE_LIVE_CAPTURE_CONFIG;
      }
      else if (isCapacity) {
        finalTest.capacityAssessmentTemplate = capacityTemplateData;
        finalTest.liveCaptureConfig = CAPACITY_LIVE_CAPTURE_CONFIG;
      }
      else if (isCoupon) finalTest.couponTestTemplate = couponTemplateData;
      else if (isBatteryImpedance) {
        finalTest.batteryImpedanceTemplate = batteryImpedanceTemplateData;
        finalTest.liveCaptureConfig = {
          fields: [
            {
              key: 'measuredIr',
              label: 'Measured IR',
              unit: 'mΩ',
              readingGuidance: 'Read the internal-resistance value shown with the mΩ unit on the HIOKI BT3554 display. Preserve decimals exactly. Ignore comparator indicators, range/mode text, memory number, battery icon, and secondary/small annunciators. Do not confuse limit/threshold readout with the live measurement.',
              group: 'reading'
            },
            {
              key: 'voltage',
              label: 'Voltage',
              unit: 'V',
              readingGuidance: 'Read the DC voltage value shown with the V unit on the HIOKI BT3554 display. Preserve decimals exactly. Ignore comparator indicators, range/mode text, memory number, battery icon, and secondary/small annunciators. Do not confuse limit/threshold readout with the live measurement.',
              group: 'reading'
            }
          ],
          jsonShape: {
            measuredIr: '',
            voltage: ''
          },
          keepPhotoAsEvidence: false
        };
      }
      else if (isLifeCycle) {
        finalTest.lifeCycleTemplate = lifeCycleTemplateData;
        finalTest.liveCaptureConfig = LCA_LIVE_CAPTURE_CONFIG;
      }
      else if (isVibrationAnalysis) finalTest.vibrationAnalysisTemplate = vibrationAnalysisTemplateData;
      
      await onSave(finalTest);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDownloadTaggedTemplate = async () => {
    setIsDownloadingTemplate(true);
    try {
      const blob = await TemplateGeneratorService.generate(localTest);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${localTest.name}_Tagged_Template.docx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Template generation error:", err);
      alert("Failed to generate tagged template.");
    } finally {
      setIsDownloadingTemplate(false);
    }
  };

  const handleRunPreview = async () => {
    setIsGeneratingPreview(true);
    setPreviewUrl(null);
    try {
        const currentData = isArcFlash ? arcFlashTemplateData : 
                            isLA ? laTemplateData : 
                            isEarthStation ? earthStationTemplateData : 
                            isSPOF ? spofTemplateData : 
                            isPowerSystem ? powerSystemTemplateData : 
                            isPowerFactor ? powerFactorTemplateData : 
                            isSPD ? spdTemplateData : 
                            isThermography ? thermographyTemplateData : 
                            isPowerQuality ? powerQualityTemplateData : 
                            isRCI ? rciTemplateData : 
                            isCFM ? cfmTemplateData : 
                            isELVGap ? elvGapTemplateData :
                            isDGEndurance ? dgEnduranceTemplateData :
                            isCapacity ? capacityTemplateData :
                            isCoupon ? couponTemplateData :
                            isBatteryImpedance ? batteryImpedanceTemplateData :
                            isLifeCycle ? lifeCycleTemplateData :
                            isVibrationAnalysis ? vibrationAnalysisTemplateData :
                            { equipment, measurements: units };
        
        await new Promise(r => setTimeout(r, 1000));
        const url = await ExecutionService.generateReport('PREVIEW_ID', currentData, localTest);
        setPreviewUrl(url);
    } catch (e: any) {
        alert(e.message || 'Preview generation failed. Check if a template is linked.');
    } finally {
        setIsGeneratingPreview(false);
    }
  };

  return (
    <div className="animate-fade-in space-y-6">
      <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm flex justify-between items-center sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack} 
            className="p-2 rounded-full hover:bg-slate-100 text-slate-500 transition-colors"
            title="Back to Library"
          >
            ←
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-800 leading-none">{localTest.name}</h1>
            <div className="flex items-center gap-2 mt-1.5">
              <span className={`text-xs font-bold px-2 py-0.5 rounded uppercase tracking-wide
                ${localTest.department === 'ELECTRICAL' ? 'bg-amber-100 text-amber-700' : 
                  localTest.department === 'MECHANICAL' ? 'bg-blue-100 text-blue-700' : 
                  'bg-purple-100 text-purple-700'}`}>
                {localTest.department}
              </span>
              <span className="text-xs text-slate-400 font-medium">Version {localTest.version}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="px-4 py-2 text-sm text-slate-600 hover:text-slate-900 font-medium"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className={`px-6 py-2 rounded-lg text-sm font-bold text-white shadow-sm transition-all flex items-center gap-2
              ${isSaving ? 'bg-indigo-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 hover:shadow-md'}`}
          >
            {isSaving ? 'Processing...' : 'Save Changes'}
          </button>
        </div>
      </div>

      <div className="border-b border-slate-200">
        <nav className="flex space-x-8" aria-label="Tabs">
          {['SCHEMA', 'TEMPLATE', 'SETTINGS', 'PREVIEW'].map((tab) => (
             <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`whitespace-nowrap py-4 px-1 border-b-2 font-bold text-sm transition-colors ${
                activeTab === tab 
                    ? 'border-indigo-600 text-indigo-600' 
                    : 'border-transparent text-slate-400 hover:text-slate-700 hover:border-slate-300'
                }`}
             >
                {tab === 'SCHEMA' ? '📋 Data Schema' : 
                 tab === 'TEMPLATE' ? '📄 Report Template' : 
                 tab === 'SETTINGS' ? '⚙️ Governance' : '👁️ Preview Execution'}
             </button>
          ))}
        </nav>
      </div>

      <div className="min-h-[400px]">
        {activeTab === 'SCHEMA' && (
          <div className="max-w-6xl space-y-8 animate-fade-in">
             {isArcFlash ? (
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <ArcFlashTables data={arcFlashTemplateData} onChange={setArcFlashTemplateData} />
               </div>
             ) : isLA ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <LightningArrestorTables 
                    data={laTemplateData} 
                    onChange={setLaTemplateData} 
                    aiEnabled={localTest.aiEnabled !== false}
                    liveCaptureConfig={localTest.liveCaptureConfig}
                  />
                </div>
             ) : isEarthStation ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <EarthStationTables 
                    data={earthStationTemplateData} 
                    onChange={setEarthStationTemplateData} 
                    aiEnabled={localTest.aiEnabled !== false}
                    liveCaptureConfig={localTest.liveCaptureConfig}
                  />
                </div>
             ) : isSPOF ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <SPOFTables data={spofTemplateData} onChange={setSpofTemplateData} templateName={localTest.linkedTemplate?.name} />
                </div>
             ) : isPowerSystem ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <PowerSystemStudyTables data={powerSystemTemplateData} onChange={setPowerSystemTemplateData} />
                </div>
             ) : isPowerFactor ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <PowerFactorTables data={powerFactorTemplateData} onChange={setPowerFactorTemplateData} />
                </div>
             ) : isSPD ? (
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                 <SPDHealthCheckTables data={spdTemplateData} onChange={setSpdTemplateData} />
               </div>
             ) : isThermography ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                   <ThermographyTables 
                     data={thermographyTemplateData} 
                     onChange={setThermographyTemplateData} 
                     aiEnabled={localTest.aiEnabled !== false}
                     liveCaptureConfig={localTest.liveCaptureConfig}
                   />
                </div>
             ) : isPowerQuality ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                   <PowerQualityTables data={powerQualityTemplateData} onChange={setPowerQualityTemplateData} />
                </div>
             ) : isRCI ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                   <RackCoolingIndexTables 
                     data={rciTemplateData} 
                     onChange={setRciTemplateData} 
                     aiEnabled={localTest.aiEnabled !== false}
                     liveCaptureConfig={localTest.liveCaptureConfig || RCI_LIVE_CAPTURE_CONFIG}
                   />
                </div>
             ) : isCFM ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                   <CFMTables 
                     data={cfmTemplateData} 
                     onChange={setCfmTemplateData} 
                     aiEnabled={localTest.aiEnabled !== false}
                     liveCaptureConfig={localTest.liveCaptureConfig || CFM_LIVE_CAPTURE_CONFIG}
                   />
                </div>
             ) : isELVGap ? (

                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                   <ELVGapAssessmentTables data={elvGapTemplateData} onChange={setElvGapTemplateData} />
                </div>
             ) : isDGEndurance ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                   <DGEnduranceTables 
                     data={dgEnduranceTemplateData} 
                     onChange={setDgEnduranceTemplateData} 
                     aiEnabled={localTest.aiEnabled !== false}
                     liveCaptureConfig={localTest.liveCaptureConfig || DG_ENDURANCE_LIVE_CAPTURE_CONFIG}
                   />
                </div>
             ) : isCapacity ? (
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <CapacityAssessmentTables 
                    data={capacityTemplateData} 
                    onChange={setCapacityTemplateData} 
                    aiEnabled={localTest.aiEnabled !== false}
                    liveCaptureConfig={localTest.liveCaptureConfig || CAPACITY_LIVE_CAPTURE_CONFIG}
                  />
               </div>
             ) : isCoupon ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <CouponTestTables data={couponTemplateData} onChange={setCouponTemplateData} />
                </div>
             ) : isBatteryImpedance ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <BatteryImpedanceTables 
                    data={batteryImpedanceTemplateData} 
                    onChange={setBatteryImpedanceTemplateData} 
                    aiEnabled={localTest.aiEnabled !== false}
                    liveCaptureConfig={localTest.liveCaptureConfig}
                  />
                </div>
             ) : isLifeCycle ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <LifeCycleAssessmentTables 
                    data={lifeCycleTemplateData} 
                    onChange={setLifeCycleTemplateData} 
                    aiEnabled={localTest.aiEnabled !== false}
                    liveCaptureConfig={localTest.liveCaptureConfig || LCA_LIVE_CAPTURE_CONFIG}
                  />
                </div>
             ) : isVibrationAnalysis ? (
               <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                 <VibrationAnalysisTables data={vibrationAnalysisTemplateData} onChange={setVibrationAnalysisTemplateData} />
               </div>
             ) : (
               <SchemaBuilder fields={localTest.schema || []} onChange={handleSchemaChange} />
             )}
          </div>
        )}

        {activeTab === 'TEMPLATE' && (
          <div className="max-w-2xl space-y-6 animate-fade-in">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 flex items-center justify-between shadow-sm">
               <div>
                  <h4 className="text-blue-900 font-bold text-sm uppercase tracking-tight">Need a tagged template?</h4>
                  <p className="text-blue-700 text-xs mt-1">Download a Word file containing all technical tags for this protocol.</p>
               </div>
               <button 
                onClick={handleDownloadTaggedTemplate}
                disabled={isDownloadingTemplate}
                className="px-5 py-2.5 bg-blue-600 text-white rounded-lg font-black text-xs uppercase shadow-md hover:bg-blue-700 transition-all active:scale-95 disabled:opacity-50"
               >
                 {isDownloadingTemplate ? 'Generating...' : '📥 Download Tagged Template'}
               </button>
            </div>
            
            <TemplateCard 
              testId={localTest.id}
              testName={localTest.name}
              template={localTest.linkedTemplate}
              onUploadSuccess={handleTemplateUploadSuccess}
            />
          </div>
        )}

        {activeTab === 'SETTINGS' && (
          <div className="max-w-2xl bg-white rounded-lg border border-slate-200 shadow-sm p-6 space-y-6 animate-fade-in">
            <div>
               <h3 className="font-semibold text-slate-800">Governance & AI</h3>
               <p className="text-sm text-slate-500">Configure search grounding and insight generation settings.</p>
            </div>
            <div className="space-y-4">
              <label className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-slate-50 transition-colors cursor-pointer">
                <input type="checkbox" checked={localTest.aiEnabled !== false} onChange={e => setLocalTest(prev => ({...prev, aiEnabled: e.target.checked}))} className="mt-1 rounded text-indigo-600 h-5 w-5" />
                <div>
                  <span className="block text-sm font-bold text-slate-900">Enable AI Insight Generation</span>
                  <span className="block text-xs text-slate-500 mt-1">Allows engineers to generate automated technical analysis based on field readings.</span>
                </div>
              </label>
            </div>
          </div>
        )}

        {activeTab === 'PREVIEW' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 animate-fade-in">
             <div className="lg:col-span-4 space-y-6">
                <div className="bg-amber-50 border border-amber-200 p-4 rounded-lg flex items-center justify-between shadow-sm">
                    <div>
                        <h4 className="text-amber-800 font-bold text-sm">FIELD EXECUTION SIMULATOR</h4>
                        <p className="text-amber-700 text-xs mt-0.5 font-medium">Test your dynamic table and logic as they appear to an Engineer.</p>
                    </div>
                    <div className="flex items-center gap-3">
                        {previewUrl && (
                            <a href={previewUrl} download="Preview_Report.docx" className="text-xs font-bold text-indigo-600 bg-white px-3 py-1.5 rounded-lg border border-indigo-200 hover:bg-indigo-50">
                                ⬇️ Download Preview DOCX
                            </a>
                        )}
                        <button 
                            onClick={handleRunPreview}
                            disabled={isGeneratingPreview}
                            className={`px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold text-sm shadow-sm hover:bg-indigo-700 transition-all ${isGeneratingPreview ? 'opacity-50' : ''}`}
                        >
                            {isGeneratingPreview ? 'Generating...' : 'Generate Mock Report'}
                        </button>
                        {isThermography && (
                            <button
                                onClick={() => exportThermographyToExcel(thermographyTemplateData, "Thermography_Mock_Report.xlsx")}
                                className="px-4 py-2 bg-green-600 text-white rounded-lg font-bold text-sm shadow-sm hover:bg-green-700 transition-all"
                            >
                                Export Excel
                            </button>
                        )}
                    </div>
                </div>

                <div className="space-y-6">
                    {isArcFlash ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                             <ArcFlashTables data={arcFlashTemplateData} onChange={setArcFlashTemplateData} />
                        </div>
                    ) : isLA ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <LightningArrestorTables 
                              data={laTemplateData} 
                              onChange={setLaTemplateData} 
                              aiEnabled={localTest.aiEnabled !== false}
                              liveCaptureConfig={localTest.liveCaptureConfig}
                            />
                        </div>
                    ) : isEarthStation ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <EarthStationTables 
                     data={earthStationTemplateData} 
                     onChange={setEarthStationTemplateData} 
                     aiEnabled={localTest.aiEnabled !== false}
                     liveCaptureConfig={localTest.liveCaptureConfig}
                   />
                        </div>
                    ) : isSPOF ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                             <SPOFTables data={spofTemplateData} onChange={setSpofTemplateData} templateName={localTest.linkedTemplate?.name} />
                        </div>
                    ) : isPowerSystem ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                             <PowerSystemStudyTables data={powerSystemTemplateData} onChange={setPowerSystemTemplateData} />
                        </div>
                    ) : isPowerFactor ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                             <PowerFactorTables data={powerFactorTemplateData} onChange={setPowerFactorTemplateData} />
                        </div>
                    ) : isSPD ? (
                      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                        <SPDHealthCheckTables data={spdTemplateData} onChange={setSpdTemplateData} />
                      </div>
                    ) : isThermography ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <ThermographyTables 
                      data={thermographyTemplateData} 
                      onChange={setThermographyTemplateData} 
                      aiEnabled={localTest.aiEnabled !== false}
                      liveCaptureConfig={localTest.liveCaptureConfig}
                    />
                        </div>
                    ) : isPowerQuality ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <PowerQualityTables data={powerQualityTemplateData} onChange={setPowerQualityTemplateData} />
                        </div>
                    ) : isRCI ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <RackCoolingIndexTables 
                              data={rciTemplateData} 
                              onChange={setRciTemplateData} 
                              aiEnabled={localTest.aiEnabled !== false}
                              liveCaptureConfig={localTest.liveCaptureConfig || RCI_LIVE_CAPTURE_CONFIG}
                            />
                        </div>
                    ) : isCFM ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <CFMTables 
                              data={cfmTemplateData} 
                              onChange={setCfmTemplateData} 
                              aiEnabled={localTest.aiEnabled !== false}
                              liveCaptureConfig={localTest.liveCaptureConfig || CFM_LIVE_CAPTURE_CONFIG}
                            />
                        </div>
                    ) : isELVGap ? (

                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <ELVGapAssessmentTables data={elvGapTemplateData} onChange={setElvGapTemplateData} />
                        </div>
                    ) : isDGEndurance ? (
                        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                            <DGEnduranceTables 
                              data={dgEnduranceTemplateData} 
                              onChange={setDgEnduranceTemplateData} 
                              aiEnabled={localTest.aiEnabled !== false}
                              liveCaptureConfig={localTest.liveCaptureConfig || DG_ENDURANCE_LIVE_CAPTURE_CONFIG}
                            />
                        </div>
                    ) : isCapacity ? (
                      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                          <CapacityAssessmentTables 
                            data={capacityTemplateData} 
                            onChange={setCapacityTemplateData} 
                            aiEnabled={localTest.aiEnabled !== false}
                            liveCaptureConfig={localTest.liveCaptureConfig || CAPACITY_LIVE_CAPTURE_CONFIG}
                          />
                      </div>
                    ) : isCoupon ? (
                      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                          <CouponTestTables data={couponTemplateData} onChange={setCouponTemplateData} />
                      </div>
                    ) : isBatteryImpedance ? (
                      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                          <BatteryImpedanceTables 
                            data={batteryImpedanceTemplateData} 
                            onChange={setBatteryImpedanceTemplateData} 
                            aiEnabled={localTest.aiEnabled !== false}
                            liveCaptureConfig={localTest.liveCaptureConfig}
                          />
                      </div>
                    ) : isLifeCycle ? (
                      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                        <LifeCycleAssessmentTables data={lifeCycleTemplateData} onChange={setLifeCycleTemplateData} />
                      </div>
                    ) : isVibrationAnalysis ? (
                      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                        <VibrationAnalysisTables 
                          data={vibrationAnalysisTemplateData} 
                          onChange={setVibrationAnalysisTemplateData} 
                          aiEnabled={localTest.aiEnabled !== false}
                        />
                      </div>
                    ) : (
                                <div className="space-y-10">
                                    <EquipmentTable data={equipment} onChange={setEquipment} />
                                    <DynamicFieldTable fields={localTest.schema || []} title={`${localTest.name} Data Points`} />
                                    <TechnicalAuditSummary 
                                        data={INITIAL_OBSERVATIONS}
                                        onChange={() => {}}
                                        title="Observation & Recommendations (Preview)"
                                    />
                                </div>
                    )}
                </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface TestLibraryProps {
    initialView?: 'LIST' | 'CREATE_METADATA';
    forcePreviewMode?: boolean;
}

const TestLibrary: React.FC<TestLibraryProps> = ({ initialView = 'LIST', forcePreviewMode = false }) => {
  const { user } = useAuth();
  const [tests, setTests] = useState<TestDefinition[]>([]);
  const [view, setView] = useState<'LIST' | 'CREATE_METADATA'>(initialView);
  const [selectedTestId, setSelectedTestId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [activeDropdownId, setActiveDropdownId] = useState<string | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [testToDelete, setTestToDelete] = useState<TestDefinition | null>(null);
  const [showToast, setShowToast] = useState(false);

  const [newTestName, setNewTestName] = useState('');
  const [newTestDept, setNewTestDept] = useState<'ELECTRICAL'|'MECHANICAL'|'ELV'>('ELECTRICAL');

  useEffect(() => {
    loadTests();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (activeDropdownId && !(event.target as Element).closest('.dropdown-trigger')) {
            setActiveDropdownId(null);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [activeDropdownId]);

  const loadTests = async () => {
    setLoading(true);
    try {
      const data = await TestLibraryService.fetchTests();
      setTests(data || []);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateMetadata = async () => {
    if (!newTestName.trim() || !user) return;
    
    const initialSchema: TestField[] = [];
    const testNameLower = newTestName.toLowerCase();
    const isArcFlash = testNameLower.includes('arc flash');
    const isLA = testNameLower.includes('lightning arrestor') || testNameLower.includes('lightning protection');
    const isEarthStation = testNameLower.includes('earth station') || testNameLower.includes('earth continuity');
    const isSPOF = testNameLower.includes('single point of failure');
    const isPowerSystem = testNameLower.includes('power system study');
    const isPowerFactor = testNameLower.includes('power factor');
    const isSPD = testNameLower.includes('spd');
    const isThermography = testNameLower.includes('thermography');
    const isPowerQuality = testNameLower.includes('power quality analysis');
    const isRCI = testNameLower.includes('rack cooling index');
    const isCFM = testNameLower.includes('cfm') || testNameLower.includes('airflow');
    const isELVGap = testNameLower.includes('elv gap assessment');
    const isDGEndurance = testNameLower.includes('dg endurance');
    const isCapacity = testNameLower.includes('capacity assessment') || testNameLower.includes('pahu') || testNameLower.includes('pac');
    const isCoupon = testNameLower.includes('coupon test') || testNameLower.includes('corrosion');
    const isBatteryImpedance = testNameLower.includes('battery') && (testNameLower.includes('impedance') || testNameLower.includes('impedence'));
    const isLifeCycle = testNameLower.includes('life cycle assessment');
    const isVibrationAnalysis = testNameLower.includes('vibration analysis');

    const newTestPayload: any = {
        id: '', 
        name: newTestName, 
        department: newTestDept, 
        version: 1, 
        schema: initialSchema, 
        aiEnabled: true,
    };

    if (isArcFlash) {
        newTestPayload.arcFlashTemplate = INITIAL_ARC_FLASH_DATA;
    } else if (isLA) {
        newTestPayload.laTemplate = INITIAL_LA_DATA;
    } else if (isEarthStation) {
        newTestPayload.earthStationTemplate = INITIAL_EARTH_STATION_DATA;
        newTestPayload.liveCaptureConfig = {
          fields: [
            {
              key: 'measuredValue',
              label: 'Measured Value',
              unit: 'Ω',
              readingGuidance: 'Read the primary resistance/impedance value displayed, in ohms (Ω) (it may show mΩ or µΩ on contact-resistance meters — read the number and its unit exactly as shown; preserve decimals). Ignore range/mode text, test-current readouts, pass/fail indicators, memory/hold annunciators, battery icon, and any secondary/limit values. Read only the live primary measurement.',
              group: 'reading'
            }
          ],
          jsonShape: {
            measuredValue: ''
          },
          keepPhotoAsEvidence: false
        };
    } else if (isSPOF) {
        newTestPayload.spofTemplate = INITIAL_SPOF_DATA;
    } else if (isPowerSystem) {
        newTestPayload.powerSystemTemplate = INITIAL_POWER_SYSTEM_DATA;
    } else if (isPowerFactor) {
        newTestPayload.powerFactorTemplate = INITIAL_POWER_FACTOR_DATA;
        newTestPayload.liveCaptureConfig = POWER_FACTOR_LIVE_CAPTURE_CONFIG;
    } else if (isSPD) {
      newTestPayload.spdTemplate = INITIAL_SPD_HEALTH_DATA;
    } else if (isThermography) {
      newTestPayload.thermographyTemplate = INITIAL_THERMOGRAPHY_DATA;
      newTestPayload.liveCaptureConfig = {
        fields: [
          {
            key: 'maxTemp',
            label: 'Max Temp',
            unit: '°C',
            readingGuidance: 'Read the MAX temperature value (the higher of the two overlaid °C numbers, usually labelled or positioned as max/hot) in °C. Ignore emissivity, centre-spot, scale bar, and battery.',
            group: 'temps'
          },
          {
            key: 'minTemp',
            label: 'Min Temp',
            unit: '°C',
            readingGuidance: 'Read the MIN temperature value (the lower of the two overlaid °C numbers, usually labelled or positioned as min/cold) in °C. Ignore emissivity, centre-spot, scale bar, and battery.',
            group: 'temps'
          },
          {
            key: 'criticalImage',
            label: 'Critical Image',
            readingGuidance: 'Capture the visual/thermal image of the equipment.',
            group: 'images'
          }
        ],
        jsonShape: {
          maxTemp: '',
          minTemp: ''
        },
        keepPhotoAsEvidence: true
      };
    } else if (isPowerQuality) {
      newTestPayload.powerQualityTemplate = INITIAL_POWER_QUALITY_DATA;
    } else if (isRCI) {
      newTestPayload.rciTemplate = INITIAL_RCI_DATA;
    } else if (isCFM) {
      newTestPayload.cfmTemplate = INITIAL_CFM_DATA;
    } else if (isELVGap) {
      newTestPayload.elvGapTemplate = INITIAL_ELV_GAP_DATA;
    } else if (isDGEndurance) {
      newTestPayload.dgEnduranceTemplate = INITIAL_DG_ENDURANCE_DATA;
      newTestPayload.liveCaptureConfig = DG_ENDURANCE_LIVE_CAPTURE_CONFIG;
    } else if (isCapacity) {
      newTestPayload.capacityAssessmentTemplate = INITIAL_CAPACITY_DATA;
      newTestPayload.liveCaptureConfig = CAPACITY_LIVE_CAPTURE_CONFIG;
    } else if (isCoupon) {
      newTestPayload.couponTestTemplate = INITIAL_COUPON_DATA;
    } else if (isBatteryImpedance) {
      newTestPayload.batteryImpedanceTemplate = INITIAL_BATTERY_IMPEDANCE_DATA;
      newTestPayload.liveCaptureConfig = {
        fields: [
          {
            key: 'measuredIr',
            label: 'Measured IR',
            unit: 'mΩ',
            readingGuidance: 'Read the internal-resistance value shown with the mΩ unit on the HIOKI BT3554 display. Preserve decimals exactly. Ignore comparator indicators, range/mode text, memory number, battery icon, and secondary/small annunciators. Do not confuse limit/threshold readout with the live measurement.',
            group: 'reading'
          },
          {
            key: 'voltage',
            label: 'Voltage',
            unit: 'V',
            readingGuidance: 'Read the DC voltage value shown with the V unit on the HIOKI BT3554 display. Preserve decimals exactly. Ignore comparator indicators, range/mode text, memory number, battery icon, and secondary/small annunciators. Do not confuse limit/threshold readout with the live measurement.',
            group: 'reading'
          }
        ],
        jsonShape: {
          measuredIr: '',
          voltage: ''
        },
        keepPhotoAsEvidence: false
      };
    } else if (isLifeCycle) {
      newTestPayload.lifeCycleTemplate = INITIAL_LIFE_CYCLE_DATA;
    } else if (isVibrationAnalysis) {
      newTestPayload.vibrationAnalysisTemplate = INITIAL_VIBRATION_DATA;
    }

    const newId = await TestLibraryService.createTest(newTestPayload, user);
    
    await loadTests();
    setNewTestName('');
    setView('LIST');
    setSelectedTestId(newId);
  };

  const handleUpdateTest = async (updatedTest: TestDefinition) => {
    if (!user) return;
    try {
        await TestLibraryService.updateTest(updatedTest.id, updatedTest, user);
        setTests(prev => (prev || []).map(t => t.id === updatedTest.id ? updatedTest : t));
        setSelectedTestId(null); 
    } catch (e) {
        console.error("Update failed:", e);
        alert("Failed to save changes to the library.");
    }
  };

  const handleDeleteClick = async (e: React.MouseEvent, test: TestDefinition) => {
    e.stopPropagation();
    setActiveDropdownId(null);

    const inUse = await TestLibraryService.isTestInUse(test.id);
    if (inUse) {
        alert("This test is currently linked to active projects or reports and cannot be deleted.");
        return;
    }

    setTestToDelete(test);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    if (!testToDelete || !user) return;
    try {
        await TestLibraryService.deleteTest(testToDelete.id, user);
        setTests(prev => prev.filter(t => t.id !== testToDelete.id));
        setShowDeleteModal(false);
        setTestToDelete(null);
        
        setShowToast(true);
        setTimeout(() => setShowToast(false), 3000);
    } catch (e) {
        console.error("Delete failed:", e);
        alert("Failed to delete test.");
    }
  };

  const selectedTest = (tests || []).find(t => t.id === selectedTestId);

  if (selectedTest) {
    return (
      <TestEditorPage 
        test={selectedTest} 
        onBack={() => setSelectedTestId(null)} 
        onSave={handleUpdateTest} 
        initialTab={forcePreviewMode ? 'PREVIEW' : 'SCHEMA'}
      />
    );
  }

  const displayTests = tests || [];
  const canModify = user?.role === UserRole.ADMIN || user?.role === UserRole.DEVELOPER;

  return (
    <div className="space-y-8 animate-fade-in relative">
      {showToast && (
        <div className="fixed bottom-6 right-6 bg-slate-900 text-white px-6 py-3 rounded-lg shadow-2xl flex items-center gap-3 animate-fade-in-up z-50">
           <span className="text-green-400 text-xl">✓</span>
           <span className="font-bold text-sm">Test deleted successfully.</span>
        </div>
      )}

      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
           <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl transform transition-all scale-100">
               <div className="w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-4 text-xl">🗑️</div>
               <h3 className="text-xl font-bold text-slate-900 mb-2">Delete Test</h3>
               <p className="text-slate-500 text-sm mb-8 leading-relaxed">
                   Are you sure you want to delete <span className="font-bold text-slate-800">"{testToDelete?.name}"</span>? This action cannot be undone.
               </p>
               <div className="flex gap-3">
                   <button onClick={() => setShowDeleteModal(false)} className="flex-1 px-4 py-3 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-colors">Cancel</button>
                   <button onClick={confirmDelete} className="flex-1 px-4 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 transition-colors shadow-lg shadow-red-100">Delete</button>
               </div>
           </div>
        </div>
      )}

      <div className="flex justify-between items-end border-b border-slate-200 pb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">{forcePreviewMode ? 'Preview Engine' : 'Test Design Library'}</h2>
          <p className="text-slate-500 mt-1 font-medium italic">
            {forcePreviewMode ? 'Select a protocol to launch the field execution simulator.' : 'Standardize your Field O&M execution protocols.'}
          </p>
        </div>
        {!forcePreviewMode && view === 'LIST' && (
          <button onClick={() => setView('CREATE_METADATA')} className="px-5 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 shadow-md font-bold transition-all active:scale-95">Add New Test</button>
        )}
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="w-10 h-10 border-[3px] border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-[10px]">Syncing Library...</p>
        </div>
      ) : view === 'LIST' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayTests.map(test => (
            <div 
                key={test.id} 
                className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all group overflow-visible cursor-pointer flex flex-col relative"
                onClick={() => setSelectedTestId(test.id)}
            >
              <div className="p-6 border-b border-slate-50 bg-white group-hover:bg-indigo-50/30 transition-colors flex-1">
                <div className="flex justify-between items-start mb-3 relative">
                   <div className="pr-6">
                        <h3 className="font-bold text-lg text-slate-800 group-hover:text-indigo-600 leading-tight">{test.name}</h3>
                   </div>
                   
                   <div className="flex items-center gap-2 absolute top-0 right-0">
                        <span className="text-[10px] text-slate-400 font-bold font-mono bg-slate-50 px-2 py-0.5 rounded">V{test.version || 1}</span>
                        {canModify && !forcePreviewMode && (
                            <div className="relative dropdown-trigger">
                                <button 
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        setActiveDropdownId(activeDropdownId === test.id ? null : test.id);
                                    }}
                                    className="p-1 rounded-full hover:bg-slate-100 text-slate-400 font-bold leading-none"
                                >
                                    ⋮
                                </button>
                                {activeDropdownId === test.id && (
                                    <div className="absolute right-0 top-6 w-48 bg-white shadow-xl rounded-xl border border-slate-100 z-50 overflow-hidden animate-fade-in-up origin-top-right">
                                        <button onClick={(e) => { e.stopPropagation(); setActiveDropdownId(null); setSelectedTestId(test.id); }} className="w-full text-left px-4 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50 border-b border-slate-50">Manage Protocol</button>
                                        <button onClick={(e) => handleDeleteClick(e, test)} className="w-full text-left px-4 py-3 text-sm font-bold text-red-600 hover:bg-red-50">Delete Test</button>
                                    </div>
                                )}
                            </div>
                        )}
                   </div>
                </div>
                <div className="flex items-center gap-2">
                    <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-black tracking-wider uppercase ${test.department === 'ELECTRICAL' ? 'bg-amber-100 text-amber-800' : test.department === 'MECHANICAL' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                        {test.department}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                        Specialized Protocol
                    </span>
                </div>
              </div>
              <div className="px-6 py-4 bg-slate-50 flex justify-between items-center group-hover:bg-indigo-600 group-hover:text-white transition-all rounded-b-2xl">
                 <span className="text-xs font-bold uppercase tracking-widest group-hover:text-white text-slate-400">
                    {forcePreviewMode ? 'Launch Simulator' : 'Manage Protocol'}
                 </span>
                 <span className="text-lg">→</span>
              </div>
            </div>
          ))}
          {displayTests.length === 0 && (
            <div className="col-span-full py-24 text-center border-2 border-dashed border-slate-200 rounded-3xl bg-white/50">
                <span className="text-5xl block mb-6 grayscale opacity-50">📖</span>
                <p className="text-slate-400 font-bold text-lg">No protocols found in your library.</p>
                <button onClick={() => setView('CREATE_METADATA')} className="mt-4 text-indigo-600 font-black hover:underline tracking-tight">ADD NEW TEST NOW</button>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl p-8 max-w-xl mx-auto shadow-2xl animate-fade-in-down">
          <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
            <span className="p-2 bg-indigo-100 rounded-lg">📋</span> Initialize Test Protocol
          </h3>
          <div className="space-y-6">
             <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Protocol Name</label>
                <input type="text" value={newTestName} onChange={e => setNewTestName(e.target.value)} placeholder="e.g. Earth Station Resistance Test" className="w-full border-slate-200 bg-slate-50 rounded-xl p-3.5 border outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium" autoFocus />
             </div>
             <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Responsible Department</label>
                <select value={newTestDept} onChange={e => setNewTestDept(e.target.value as any)} className="w-full border-slate-200 bg-slate-50 rounded-xl p-3.5 border outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium appearance-none">
                    <option value="ELECTRICAL">Electrical Operations</option>
                    <option value="MECHANICAL">Mechanical Systems</option>
                    <option value="ELV">ELV & Security</option>
                </select>
             </div>
          </div>
          <div className="mt-8 flex justify-end gap-3">
             <button onClick={() => setView('LIST')} className="px-4 py-2 text-slate-500 font-bold hover:text-slate-700">Cancel</button>
             <button onClick={handleCreateMetadata} disabled={!newTestName.trim()} className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all">Save Test</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TestLibrary;
