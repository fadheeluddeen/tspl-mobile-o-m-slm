
import React, { useState, useEffect } from 'react';
import { Project, TestAssignment, TestDefinition, User, UserRole, WorkflowStatus } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { ExecutionService, TestLibraryService, ProjectService, SystemService } from '../../services/mockDatabase';
import { 
    EquipmentTable, 
    MeasurementTemplate, 
    EquipmentRow, 
    UpsUnit, 
    INITIAL_EQUIPMENT, 
    INITIAL_UPS_DATA 
} from '../../components/TestTables';
import { ArcFlashTables, INITIAL_ARC_FLASH_DATA } from '../../components/ArcFlashTables';
import { SPDInspectionTable, INITIAL_SPD_DATA } from '../../components/SPDInspectionTable';
import { LightningArrestorTables, INITIAL_LA_DATA } from '../../components/LightningArrestorTables';
import { EarthStationTables, INITIAL_EARTH_STATION_DATA } from '../../components/EarthStationTables';
import { SPOFTables, INITIAL_SPOF_DATA } from '../../components/SPOFTables';
import { ELVGapAssessmentTables, INITIAL_ELV_GAP_DATA } from '../../components/ELVGapAssessmentTables';
import { DGEnduranceTables, INITIAL_DG_ENDURANCE_DATA } from '../../components/DGEnduranceTables';
import { CapacityAssessmentTables, INITIAL_CAPACITY_DATA } from '../../components/CapacityAssessmentTables';
import { CouponTestTables, INITIAL_COUPON_DATA } from '../../components/CouponTestTables';
import { BatteryImpedanceTables, INITIAL_BATTERY_IMPEDANCE_DATA } from '../../components/BatteryImpedanceTables';
import { LifeCycleAssessmentTables, INITIAL_LIFE_CYCLE_DATA } from '../../components/LifeCycleAssessmentTables';
import { useNavigate, useSearchParams } from 'react-router-dom';

const EngineerDashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [assignments, setAssignments] = useState<TestAssignment[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [loadingTasks, setLoadingTasks] = useState(true);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [showAssignmentDeleteConfirm, setShowAssignmentDeleteConfirm] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  useEffect(() => {
    if (user?.uid) {
      setLoadingTasks(true);
      Promise.all([
        ExecutionService.fetchAssignmentsByEngineer(user.uid),
        ProjectService.fetchProjects(),
        SystemService.fetchAllUsers()
      ])
        .then(([assignmentsData, projectsData, usersData]) => {
          setAssignments(assignmentsData || []);
          setProjects(projectsData || []);
          setEngineers(usersData.filter(u => u.role === UserRole.ENGINEER) || []);
          
          if (assignmentsData && assignmentsData.length > 0) {
            const qProjectId = searchParams.get('projectId');
            if (qProjectId) {
              setActiveProjectId(qProjectId);
            } else {
              const projectIds = Array.from(new Set(assignmentsData.map(a => a.projectId)));
              if (projectIds.length > 0) {
                setActiveProjectId(projectIds[0]);
              }
            }
          }
        })
        .finally(() => setLoadingTasks(false));
    }
  }, [user]);

  useEffect(() => {
    const qProjectId = searchParams.get('projectId');
    if (qProjectId) {
      setActiveProjectId(qProjectId);
    }
  }, [searchParams]);

  const getEngineerName = (uid: string) => {
    const eng = engineers.find(e => e.uid === uid);
    if (!eng) return 'Unassigned';
    if (eng.displayName && eng.displayName !== 'User') return eng.displayName;
    return eng.email.split('@')[0].toUpperCase();
  };

  const handleReassign = async (assignmentId: string, newEngineerId: string) => {
    if (!user) return;
    try {
        await ExecutionService.updateAssignmentEngineer(assignmentId, newEngineerId, user);
        setAssignments(prev => prev.map(a => a.id === assignmentId ? { ...a, assignedEngineerId: newEngineerId } : a));
    } catch (e) {
        console.error("Re-assignment failed:", e);
    }
  };

  const getProjectDetails = (projectId: string) => {
    return projects.find(p => p.id === projectId);
  };

  const openTask = (id: string) => {
    navigate(`/execute/${id}`);
  };

  const handleDeleteAssignment = async () => {
    if (!showAssignmentDeleteConfirm || !user) return;
    
    setIsProcessing(true);
    try {
      // Engineers always request deletion
      await ExecutionService.requestAssignmentDeletion(showAssignmentDeleteConfirm, user);
      setAssignments(prev => prev.map(a => a.id === showAssignmentDeleteConfirm ? { ...a, workflowStatus: WorkflowStatus.DELETION_PENDING } : a));
      setShowAssignmentDeleteConfirm(null);
    } catch (error) {
      alert("Request failed.");
    } finally {
      setIsProcessing(false);
    }
  };

  // Get unique projects that have assignments for this engineer
  const engineerProjectIds = Array.from(new Set(assignments.map(a => a.projectId)));
  const engineerProjects = projects.filter(p => engineerProjectIds.includes(p.id));
  
  const activeProject = projects.find(p => p.id === activeProjectId);
  const activeAssignments = assignments.filter(a => a.projectId === activeProjectId && a.workflowStatus !== WorkflowStatus.DELETION_PENDING && a.workflowStatus !== WorkflowStatus.DELETION_APPROVED);

  const [showQuickGuide, setShowQuickGuide] = useState(false);

  if (loadingTasks) return (
    <div className="flex flex-col items-center justify-center py-24 gap-4">
      <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Synchronizing Field Hub...</p>
    </div>
  );

  return (
    <div className="space-y-6 font-sans animate-fade-in">
      {/* Assignment Delete Confirmation Modal */}
      {showAssignmentDeleteConfirm && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-fade-in">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center animate-bounce-in border border-red-100">
            <div className="w-20 h-20 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl shadow-inner">🗑️</div>
            <h3 className="text-2xl font-black text-slate-900 mb-2">Request Deletion</h3>
            <p className="text-slate-500 text-sm mb-8 leading-relaxed">
              Are you sure you want to request deletion for this test? An Admin must approve this request before the test is removed from your dashboard.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setShowAssignmentDeleteConfirm(null)} className="flex-1 px-4 py-4 bg-slate-100 text-slate-700 font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-slate-200">Cancel</button>
              <button onClick={handleDeleteAssignment} disabled={isProcessing} className="flex-1 px-4 py-4 bg-red-600 text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-red-700 shadow-xl shadow-red-100">Request Deletion</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tight">Project Management Hub</h2>
          <p className="text-slate-500 font-medium text-sm mt-1">Orchestrate field operations and test protocols.</p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowQuickGuide(!showQuickGuide)}
            className={`px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-widest transition-all flex items-center gap-2 border
              ${showQuickGuide ? 'bg-indigo-600 text-white border-indigo-700' : 'bg-white text-indigo-600 border-indigo-200 hover:bg-indigo-50'}`}
          >
            <span>💡</span> {showQuickGuide ? 'Hide Guide' : 'Quick Guide'}
          </button>
          <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-xl border border-indigo-100 uppercase tracking-widest">
            Engineer Mode
          </span>
        </div>
      </div>

      {/* Quick Guide Panel */}
      {showQuickGuide && (
        <div className="bg-indigo-50 border border-indigo-100 rounded-3xl p-8 animate-fade-in space-y-6 shadow-sm">
          <div className="flex justify-between items-center">
            <h3 className="text-indigo-900 font-black uppercase tracking-widest text-sm flex items-center gap-2">
              <span>🚀</span> Field Engineer Quick Start Guide
            </h3>
            <button onClick={() => setShowQuickGuide(false)} className="text-indigo-400 hover:text-indigo-600">✕</button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-indigo-100 shadow-sm">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Step 1: Select Project</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Choose an active project from the left sidebar to see your assigned technical protocols.
              </p>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-indigo-100 shadow-sm">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Step 2: Data Entry</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Click on a test card (📋) to open the execution interface. Fill in measurements and use AI insights.
              </p>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-indigo-100 shadow-sm">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Step 3: Submit</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                Once data is complete, click <strong>"Submit to PM"</strong>. If rejected, check comments and re-submit.
              </p>
            </div>
          </div>
          
          <div className="flex justify-center">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Refer to the sidebar menu for the full User Manual.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Project List Sidebar */}
        <div className="lg:col-span-4 space-y-4">
            <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] px-2">PROJECT INVENTORY</p>
            <div className="space-y-3">
              {engineerProjects.map(p => (
                  <div 
                      key={p.id} 
                      onClick={() => setActiveProjectId(p.id)}
                      className={`p-5 rounded-2xl border-2 cursor-pointer transition-all ${activeProjectId === p.id ? 'bg-white border-emerald-500 shadow-xl scale-[1.02]' : 'bg-white border-slate-100 hover:border-emerald-200 hover:bg-slate-50/50'}`}
                  >
                      <div className="flex justify-between items-start">
                          <h3 className="font-bold text-slate-800 leading-tight truncate mr-2">{p.name}</h3>
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase whitespace-nowrap ${p.status === 'ACTIVE' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>{p.status}</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-3 flex items-center gap-2 font-medium truncate">🏢 {p.clientName}</p>
                  </div>
              ))}
              {engineerProjects.length === 0 && (
                <div className="p-10 text-center bg-slate-50 border-2 border-dashed rounded-3xl text-slate-400 font-medium">
                  No active projects assigned.
                </div>
              )}
            </div>
        </div>

        {/* Project Detail & Assignment Area */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-sm min-h-[600px] flex flex-col relative">
            {activeProject ? (
                <div className="flex flex-col h-full">
                    <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex justify-between items-start">
                        <div className="space-y-1 flex-1">
                            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">ACTIVE FILE</span>
                            <h3 className="text-3xl font-black text-slate-900 tracking-tight">{activeProject.name}</h3>
                            <p className="text-slate-500 text-sm font-medium">Customer: {activeProject.clientName}</p>
                            <p className="text-pink-500 text-xs mt-2 italic flex items-center gap-2 font-bold uppercase tracking-widest">📍 UAT</p>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <button className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors text-slate-600">
                            ⚙️
                          </button>
                          <button className="px-5 py-2.5 rounded-xl font-bold text-sm bg-indigo-50 text-indigo-700 border border-indigo-200 shadow-sm">
                            Assign Tests
                          </button>
                        </div>
                    </div>

                    <div className="p-8 space-y-6 flex-1 overflow-y-auto">
                        <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">ACTIVE SITE PROTOCOLS ({activeAssignments.length})</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-12">
                            {activeAssignments.map(a => (
                                <div 
                                    key={a.id} 
                                    onClick={() => openTask(a.id)}
                                    className={`p-6 bg-white border rounded-2xl cursor-pointer hover:shadow-2xl transition-all group relative overflow-hidden flex flex-col
                                      ${a.workflowStatus === WorkflowStatus.SUBMITTED ? 'border-blue-400 ring-2 ring-blue-50' : 
                                        a.workflowStatus === WorkflowStatus.REJECTED ? 'border-red-400 ring-2 ring-red-50' : 'border-slate-200'}`}
                                >
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                            <span className="text-xl">📋</span>
                                        </div>
                                        <div className="flex items-start gap-3">
                                          <div className="flex flex-col items-end gap-1">
                                            <span className={`text-[9px] font-black px-2 py-1 rounded-full uppercase tracking-widest ${a.status === 'COMPLETED' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                                {a.status}
                                            </span>
                                            <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter border
                                              ${a.workflowStatus === WorkflowStatus.APPROVED ? 'bg-green-50 text-green-600 border-green-200' :
                                                a.workflowStatus === WorkflowStatus.SUBMITTED ? 'bg-blue-50 text-blue-600 border-blue-200' :
                                                a.workflowStatus === WorkflowStatus.REJECTED ? 'bg-red-50 text-red-600 border-red-200' :
                                                a.workflowStatus === WorkflowStatus.DELETION_PENDING ? 'bg-amber-50 text-amber-600 border-amber-200' :
                                                'bg-slate-50 text-slate-400 border-slate-200'}`}>
                                              {a.workflowStatus}
                                            </span>
                                          </div>
                                        </div>
                                    </div>
                                    <h5 className="font-black text-slate-800 text-lg group-hover:text-indigo-600 leading-tight mb-4">{a.testName}</h5>
                                    
                                    {a.workflowStatus === WorkflowStatus.REJECTED && (
                                      <div className="mt-4 p-3 bg-red-50 rounded-xl border border-red-100">
                                        <p className="text-[10px] font-black text-red-700 uppercase tracking-widest mb-1">Feedback:</p>
                                        <p className="text-[11px] text-red-600 italic font-medium truncate">"{a.pmComments}"</p>
                                      </div>
                                    )}

                                    {a.workflowStatus === WorkflowStatus.DELETION_PENDING && (
                                      <div className="mt-4 p-2 bg-amber-50 text-amber-700 text-[10px] font-black uppercase tracking-widest text-center rounded-lg border border-amber-100">
                                         Deletion Requested - Pending Admin Approval
                                      </div>
                                    )}

                                    <div className="mt-auto border-t border-slate-50 pt-4 flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                          <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-500">
                                            i
                                          </div>
                                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter truncate max-w-[100px]">
                                            {getEngineerName(a.assignedEngineerId)}
                                          </span>
                                        </div>
                                        
                                        {(user?.role === UserRole.ADMIN || user?.role === UserRole.PROJECT_MANAGER) && (
                                          <select 
                                            onClick={e => e.stopPropagation()}
                                            value={a.assignedEngineerId}
                                            onChange={e => handleReassign(a.id, e.target.value)}
                                            className="text-[9px] font-black uppercase text-indigo-600 bg-indigo-50 border-none rounded px-2 py-1 outline-none cursor-pointer hover:bg-indigo-100"
                                          >
                                            {engineers.map(eng => (
                                              <option key={eng.uid} value={eng.uid}>
                                                REASSIGN TO: {eng.displayName && eng.displayName !== 'User' ? eng.displayName : eng.email.split('@')[0].toUpperCase()}
                                              </option>
                                            ))}
                                          </select>
                                        )}
                                    </div>
                                    <div className="absolute bottom-0 left-0 h-1 w-0 bg-indigo-500 group-hover:w-full transition-all duration-300"></div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-4 py-20">
                    <span className="text-5xl">📁</span>
                    <p className="font-bold">Select a project to view assigned protocols.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default EngineerDashboard;
