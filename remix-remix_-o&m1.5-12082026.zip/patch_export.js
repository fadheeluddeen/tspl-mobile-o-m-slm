const fs = require('fs');

const path = 'utils/excelExport.ts';
let code = fs.readFileSync(path, 'utf8');

if (!code.includes('DGEnduranceReading')) {
  code = code.replace(/import \{([^}]+)\} from '\.\.\/types';/, (match, group1) => {
    return `import {\n${group1},\n  DGEnduranceReading,\n  DGUnit,\n  DGLoadReadingRow,\n  DGFuelSummaryRow\n} from '../types';`;
  });
}

const exportFunc = `

export const exportDGEnduranceToExcel = async (data: DGEnduranceReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const themeColor = 'FF0F172A'; // Slate 900
  
  if (!data.dgUnits || data.dgUnits.length === 0) {
    // Empty state
    workbook.addWorksheet('No Data');
  } else {
    data.dgUnits.forEach((unit, uIdx) => {
      const prefix = \`DG\${uIdx + 1}\`;
      
      // T1: Parameter matrix
      const wsT1 = workbook.addWorksheet(\`\${prefix} - Parameters\`);
      wsT1.columns = [
        { header: 'Parameter', key: 'parameter', width: 25 },
        { header: 'Unit', key: 'unit', width: 10 },
        { header: '0', key: 'v0', width: 12 },
        { header: '25', key: 'v25', width: 12 },
        { header: '50', key: 'v50', width: 12 },
        { header: '75', key: 'v75', width: 12 },
        { header: '100', key: 'v100', width: 12 },
        { header: 'Remarks', key: 'remarks', width: 30 }
      ];
      wsT1.getRow(1).eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.loadReadings || []).forEach(r => {
        const row = wsT1.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T2: Transient Load Test Summary
      const wsT2 = workbook.addWorksheet(\`\${prefix} - Transient Load\`);
      wsT2.columns = [
        { header: 'Sr No', key: 'srNo', width: 10 },
        { header: 'Transient Load', key: 'load', width: 25 },
        { header: 'Result', key: 'result', width: 15 }
      ];
      wsT2.getRow(1).eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.transientSummary || []).forEach(r => {
        const row = wsT2.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T3: Noise Level Measurement
      const wsT3 = workbook.addWorksheet(\`\${prefix} - Noise Level\`);
      wsT3.columns = [
        { header: 'Load in %', key: 'load', width: 15 },
        { header: 'Doors Open', key: 'open', width: 15 },
        { header: 'Doors Closed', key: 'closed', width: 15 }
      ];
      wsT3.getRow(1).eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.noiseLevels || []).forEach(r => {
        const row = wsT3.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T4: Vibration Measurement Values
      const wsT4 = workbook.addWorksheet(\`\${prefix} - Vibration\`);
      wsT4.columns = [
        { header: 'Load %', key: 'load', width: 10 },
        { header: 'A', key: 'a', width: 10 },
        { header: 'B', key: 'b', width: 10 },
        { header: 'C', key: 'c', width: 10 },
        { header: 'D', key: 'd', width: 10 },
        { header: 'E', key: 'e', width: 10 },
        { header: 'F', key: 'f', width: 10 },
        { header: 'G', key: 'g', width: 10 },
        { header: 'H', key: 'h', width: 10 }
      ];
      wsT4.getRow(1).eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.vibrationLevels || []).forEach(r => {
        const row = wsT4.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T5: Fuel Consumption Summary
      const wsT5 = workbook.addWorksheet(\`\${prefix} - Fuel Consumption\`);
      wsT5.columns = [
        { header: 'Sr No', key: 'srNo', width: 10 },
        { header: 'kWh Generated Initial', key: 'kwhInitial', width: 25 },
        { header: 'kWh Generated Final', key: 'kwhFinal', width: 25 },
        { header: 'kWh Generated Consumed', key: 'kwhUnits', width: 25 },
        { header: 'Fuel in Litres Initial', key: 'fuelInitial', width: 25 },
        { header: 'Fuel in Litres Final', key: 'fuelFinal', width: 25 },
        { header: 'Fuel in Litres Consumed', key: 'fuelConsum', width: 25 },
        { header: 'OEM Std (L/H)', key: 'oemStd', width: 20 },
        { header: 'Efficiency (kWh/L)', key: 'efficiency', width: 25 }
      ];
      wsT5.getRow(1).eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.fuelSummary || []).forEach(r => {
        const initKwh = parseFloat(r.kwhInitial) || 0;
        const finalKwh = parseFloat(r.kwhFinal) || 0;
        const consKwh = finalKwh - initKwh;
        const initF = parseFloat(r.fuelInitial) || 0;
        const finalF = parseFloat(r.fuelFinal) || 0;
        const consF = finalF - initF;
        const eff = consF > 0 ? (consKwh / consF).toFixed(2) : '0.00';
        
        const row = wsT5.addRow({
          ...r,
          kwhUnits: consKwh.toString(),
          fuelConsum: consF.toString(),
          efficiency: eff
        });
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });
    });
  }

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  saveAs(blob, fileName);
};
`;

if (!code.includes('exportDGEnduranceToExcel')) {
  code += exportFunc;
  fs.writeFileSync(path, code);
}
