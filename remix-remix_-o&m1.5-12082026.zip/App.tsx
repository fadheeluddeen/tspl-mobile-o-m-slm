
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { UserRole } from './types';
import Layout from './components/Layout';
import Login from './pages/Login';

// Role Dashboards
import AdminDashboard from './pages/admin/AdminDashboard';
import AdoptionDashboard from './pages/admin/AdoptionDashboard';
import UserManagement from './pages/admin/UserManagement';
import AuditLogs from './pages/admin/AuditLogs';
import Privileges from './pages/admin/Privileges';
import TestLibrary from './pages/developer/TestLibrary';
import ProjectManager from './pages/pm/ProjectManager';
import PMDashboard from './pages/pm/PMDashboard';
import EngineerDashboard from './pages/engineer/EngineerDashboard';
import TestExecution from './pages/execution/TestExecution';
import PinnedItems from './pages/execution/PinnedItems';
import FinalReports from './pages/execution/FinalReports';
import UserManual from './pages/help/UserManual';
import OperationalDashboard from './pages/OperationalDashboard';
import LiveCaptureLabPage from './pages/sandbox/LiveCaptureLab';

// Route Guard Component
const ProtectedRoute: React.FC<{ allowedRoles: UserRole[]; children: React.ReactNode }> = ({ allowedRoles, children }) => {
  const { user, loading, logout } = useAuth();
  
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-4">
        <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Verifying Authorization...</p>
      </div>
    </div>
  );
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const hasAccess = user.role && allowedRoles.includes(user.role);

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-center">
        <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-2xl border border-red-50 flex flex-col items-center">
          <div className="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-6 text-4xl shadow-inner">🚫</div>
          <h2 className="text-2xl font-black text-slate-900 mb-3 tracking-tight">Access Restricted</h2>
          <div className="space-y-4 mb-8">
            <p className="text-slate-500 text-sm leading-relaxed">
              Your account role <span className="px-2 py-0.5 bg-slate-100 rounded font-bold text-slate-700">{user.role || 'NONE'}</span> is not authorized to access this module.
            </p>
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-100 text-[10px] text-amber-700 uppercase font-bold tracking-widest leading-4">
              Authorized Roles: {allowedRoles.join(', ')}
            </div>
          </div>
          <div className="flex flex-col w-full gap-3">
            <button 
              onClick={() => window.location.href = '/'}
              className="w-full py-3.5 bg-slate-900 text-white text-sm font-bold rounded-xl hover:bg-slate-800 transition-all shadow-lg active:scale-95"
            >
              Return to Master Hub
            </button>
            <button 
              onClick={logout}
              className="w-full py-3.5 text-red-600 text-sm font-bold rounded-xl hover:bg-red-50 transition-all"
            >
              Switch Account
            </button>
          </div>
        </div>
      </div>
    );
  }

  return <Layout>{children}</Layout>;
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN, UserRole.PROJECT_MANAGER, UserRole.ENGINEER]}>
                <OperationalDashboard />
              </ProtectedRoute>
            } 
          />

          {/* Admin Routes */}
          <Route 
            path="/admin/dashboard" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
                <AdoptionDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/users" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
                <UserManagement />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/privileges" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
                <Privileges />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/audit" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
                <AuditLogs />
              </ProtectedRoute>
            } 
          />
           <Route 
            path="/admin/library" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
                <TestLibrary />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/projects" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
                <ProjectManager />
              </ProtectedRoute>
            } 
          />

          {/* Developer Routes */}
          <Route 
            path="/developer" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.DEVELOPER]}>
                <TestLibrary />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/developer/preview" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.DEVELOPER, UserRole.ADMIN]}>
                <TestLibrary initialView="LIST" forcePreviewMode={true} />
              </ProtectedRoute>
            } 
          />

          {/* Project Manager Routes */}
          <Route 
            path="/pm/dashboard" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.PROJECT_MANAGER, UserRole.ADMIN]}>
                <PMDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/pm" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.PROJECT_MANAGER, UserRole.ENGINEER, UserRole.ADMIN]}>
                <ProjectManager />
              </ProtectedRoute>
            } 
          />

          {/* Execution Routes */}
          <Route 
            path="/engineer" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ENGINEER, UserRole.ADMIN]}>
                <EngineerDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/execute/pinned" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ENGINEER, UserRole.PROJECT_MANAGER, UserRole.ADMIN]}>
                <PinnedItems />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/execute/reports" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ENGINEER, UserRole.PROJECT_MANAGER, UserRole.ADMIN]}>
                <FinalReports />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/execute/:assignmentId" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ENGINEER, UserRole.PROJECT_MANAGER, UserRole.ADMIN]}>
                <TestExecution />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/sandbox/live-capture" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ENGINEER, UserRole.PROJECT_MANAGER, UserRole.ADMIN]}>
                <LiveCaptureLabPage />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/help/manual" 
            element={
              <ProtectedRoute allowedRoles={[UserRole.ENGINEER, UserRole.PROJECT_MANAGER, UserRole.ADMIN]}>
                <UserManual />
              </ProtectedRoute>
            } 
          />

          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </HashRouter>
    </AuthProvider>
  );
};

export default App;
