const fs = require('fs');

const path = 'components/DGEnduranceTables.tsx';
let code = fs.readFileSync(path, 'utf8');

if (!code.includes('import * as XLSX')) {
  code = code.replace(/import React from 'react';/, "import React, { useRef } from 'react';\nimport * as XLSX from 'xlsx';\nimport { Download, Upload } from 'lucide-react';\nimport { exportDGEnduranceToExcel } from '../utils/excelExport';");
}

if (!code.includes('const fileInputRef')) {
  code = code.replace(/const \{ modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast \} = useConfirmDelete\(\);/, 
    "const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast, showToast } = useConfirmDelete();\n  const fileInputRef = useRef<HTMLInputElement>(null);\n");
}

fs.writeFileSync(path, code);
