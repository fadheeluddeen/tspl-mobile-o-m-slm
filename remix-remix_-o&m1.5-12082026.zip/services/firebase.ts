
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore, enableIndexedDbPersistence } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAnalytics, isSupported } from "firebase/analytics";

export const firebaseConfig = {
  apiKey: "AIzaSyBaUnLKWwFTXWua-NtniF2HFtS75mYTmZY",
  authDomain: "omtspl01022026.firebaseapp.com",
  projectId: "omtspl01022026",
  storageBucket: "omtspl01022026.firebasestorage.app",
  messagingSenderId: "860778225856",
  appId: "1:860778225856:web:61bd7a81f6bf286c05cd25",
  measurementId: "G-FX6ZCRF4GF"
};

// Initialize Firebase App (Singleton)
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Services with explicit app instance
export const auth = getAuth(app);
export const db = getFirestore(app);

// Enable offline persistence
if (typeof window !== "undefined") {
  enableIndexedDbPersistence(db).catch((err) => {
    if (err.code === 'failed-precondition') {
      // Multiple tabs open, persistence can only be enabled in one tab at a time.
      console.warn('Firestore persistence failed: multiple tabs open');
    } else if (err.code === 'unimplemented') {
      // The current browser does not support all of the features required to enable persistence
      console.warn('Firestore persistence is not supported by this browser');
    }
  });
}

export const storage = getStorage(app);

// Initialize Analytics conditionally (only in browser and if supported)
export const analytics = typeof window !== "undefined" 
  ? isSupported().then(yes => yes ? getAnalytics(app) : null)
  : Promise.resolve(null);

export default app;
