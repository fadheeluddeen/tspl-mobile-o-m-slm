import {
  SystemConfig,
  TestDefinition,
  Project,
  TestAssignment,
  UserRole,
  WorkflowStatus,
  TestTemplateMetadata,
  TestField,
  ArcFlashReading,
  SPDReading,
  LightningArrestorReading,
  EarthStationReading,
  SPOFReading,
  PowerSystemReading,
  PowerFactorReading,
  ThermographyReading,
  PowerQualityReading,
  RackCoolingIndexReading,
  DGEnduranceReading,
  CapacityAssessmentReading,
  CouponTestReading,
  BatteryImpedanceReading,
  LifeCycleReading,
  User,
  AuditLog,
  RolePermission,
  PQAnalysisGroup,
  CFMReading,
  VibrationAnalysisReading,
} from "../types";
import { GoogleGenAI } from "@google/genai";
import { db, storage, auth, firebaseConfig } from "./firebase";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
} from "firebase/auth";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  addDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  onSnapshot,
} from "firebase/firestore";
import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
  uploadBytes,
  getBlob,
} from "firebase/storage";
// @ts-ignore
import PizZip from "pizzip";
// @ts-ignore
import Docxtemplater from "docxtemplater";
// @ts-ignore
import ImageModule from "docxtemplater-image-module-free";
// @ts-ignore
import { Buffer } from "buffer";
import { TemplateGeneratorService } from "./templateGenerator";

// Ensure Buffer is available globally for ESM modules that expect it
if (typeof window !== "undefined") {
  (window as any).Buffer = Buffer;
}

const COLLECTIONS = {
  PROJECTS: "projects",
  ASSIGNMENTS: "assignments",
  CONFIG: "system",
  DEFINITIONS: "testDefinitions",
  USERS: "users",
  AUDIT_LOGS: "auditLogs",
  PERMISSIONS: "permissions",
};

const scrub = (obj: any): any => {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(scrub);

  const newObj: any = {};
  Object.keys(obj).forEach((key) => {
    if (obj[key] !== undefined) {
      newObj[key] = scrub(obj[key]);
    }
  });
  return newObj;
};

export const SystemService = {
  fetchConfig: async (): Promise<SystemConfig> => {
    try {
      const configDoc = await getDoc(doc(db, COLLECTIONS.CONFIG, "config"));
      if (configDoc.exists()) {
        return configDoc.data() as SystemConfig;
      }
    } catch (e) {
      console.warn("Permission restricted on config fetch.");
    }
    return {
      aiGlobalEnabled: true,
      aiEngineerAccess: true,
      lastHeartbeat: new Date().toISOString(),
      maintenanceMode: false,
    };
  },

  updateConfig: async (
    config: Partial<SystemConfig>,
    caller: User,
  ): Promise<void> => {
    await updateDoc(doc(db, COLLECTIONS.CONFIG, "config"), {
      ...scrub(config),
      lastHeartbeat: new Date().toISOString(),
    });
    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "SYSTEM",
      action: "SYSTEM_CONFIG_UPDATED",
      status: "SUCCESS",
      details: "Modified AI or maintenance settings",
      payload: JSON.stringify(scrub(config)),
    });
  },

  getHealthStatus: async () => {
    return {
      firestore: "CLOUD_ACTIVE",
      storage: "STORAGE_READY",
      functions: "READY",
      errors: 0,
    };
  },

  fetchAllUsers: async (): Promise<User[]> => {
    const snapshot = await getDocs(collection(db, COLLECTIONS.USERS));
    return snapshot.docs.map(
      (d) =>
        ({
          uid: d.id,
          ...d.data(),
        }) as User,
    );
  },

  adminCreateUser: async (
    email: string,
    pass: string,
    name: string,
    role: UserRole,
    caller: User,
  ): Promise<string> => {
    const secondaryApp = initializeApp(firebaseConfig, "SecondaryAuthApp");
    const secondaryAuth = getAuth(secondaryApp);

    try {
      const { user: newUser } = await createUserWithEmailAndPassword(
        secondaryAuth,
        email,
        pass,
      );

      const userData = {
        email,
        displayName: name,
        role: role,
        status: "ACTIVE" as const,
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, COLLECTIONS.USERS, newUser.uid), userData);

      await SystemService.createAuditLog({
        userEmail: caller.email,
        userName: caller.displayName,
        userRole: caller.role,
        module: "USERS",
        action: "USER_CREATED",
        status: "SUCCESS",
        details: `Provisioned new account for ${name} (${role})`,
        payload: JSON.stringify({ uid: newUser.uid, email, role }),
      });

      await signOut(secondaryAuth);

      return newUser.uid;
    } finally {
      // @ts-ignore
      if (secondaryApp) await secondaryApp.delete();
    }
  },

  updateUserRole: async (
    userId: string,
    newRole: UserRole,
    caller: User,
  ): Promise<void> => {
    const userDocRef = doc(db, COLLECTIONS.USERS, userId);
    const oldSnap = await getDoc(userDocRef);
    await updateDoc(userDocRef, { role: newRole });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "USERS",
      action: "USER_ROLE_UPDATED",
      status: "SUCCESS",
      details: `Updated role for UID: ${userId} to ${newRole}`,
      payload: JSON.stringify({
        userId,
        oldRole: oldSnap.data()?.role,
        newRole,
      }),
    });
  },

  updateUserStatus: async (
    userId: string,
    newStatus: "ACTIVE" | "DISABLED",
    caller: User,
  ): Promise<void> => {
    const userDocRef = doc(db, COLLECTIONS.USERS, userId);
    await updateDoc(userDocRef, { status: newStatus });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "USERS",
      action: "USER_STATUS_UPDATED",
      status: "SUCCESS",
      details: `Account ${newStatus} for UID: ${userId}`,
      payload: JSON.stringify({ userId, newStatus }),
    });
  },

  resetUserPassword: async (userEmail: string, caller: User): Promise<void> => {
    await sendPasswordResetEmail(auth, userEmail);

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "USERS",
      action: "PASSWORD_RESET_TRIGGERED",
      status: "SUCCESS",
      details: `Password reset email sent to: ${userEmail}`,
    });
  },

  subscribeAuditLogs: (onUpdate: (logs: AuditLog[]) => void) => {
    const q = query(
      collection(db, COLLECTIONS.AUDIT_LOGS),
      orderBy("timestamp", "desc"),
    );
    return onSnapshot(q, (snapshot) => {
      const logs = snapshot.docs.map(
        (d) => ({ id: d.id, ...d.data() }) as AuditLog,
      );
      onUpdate(logs);
    });
  },

  createAuditLog: async (log: Omit<AuditLog, "id" | "timestamp">) => {
    try {
      await addDoc(collection(db, COLLECTIONS.AUDIT_LOGS), {
        ...log,
        timestamp: serverTimestamp(),
      });
    } catch (e) {
      console.error("Audit logging failed:", e);
    }
  },

  fetchPermissions: async (): Promise<RolePermission[]> => {
    const snapshot = await getDocs(collection(db, COLLECTIONS.PERMISSIONS));
    return snapshot.docs.map(
      (d) => ({ id: d.id, actions: d.data().actions || [] }) as RolePermission,
    );
  },

  updatePermissions: async (
    roleId: string,
    actions: string[],
    caller: User,
  ): Promise<void> => {
    const docRef = doc(db, COLLECTIONS.PERMISSIONS, roleId);
    await setDoc(docRef, { actions });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "PRIVILEGES",
      action: "ROLE_PERMISSIONS_UPDATED",
      status: "SUCCESS",
      details: `Modified actions for role: ${roleId}`,
      payload: JSON.stringify({ roleId, actions }),
    });
  },
};

export const TestLibraryService = {
  fetchTests: async (): Promise<TestDefinition[]> => {
    const snapshot = await getDocs(collection(db, COLLECTIONS.DEFINITIONS));
    return snapshot.docs
      .map((d) => ({ ...d.data(), id: d.id }) as TestDefinition)
      .filter((t) => t.status !== "DELETED");
  },

  createTest: async (test: TestDefinition, caller: User): Promise<string> => {
    const scrubbedTest = scrub(test);
    const docRef = await addDoc(collection(db, COLLECTIONS.DEFINITIONS), {
      ...scrubbedTest,
      status: "ACTIVE",
      createdAt: serverTimestamp(),
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "LIBRARY",
      action: "TEST_DEFINITION_CREATED",
      status: "SUCCESS",
      details: `Created new protocol: ${test.name}`,
      payload: JSON.stringify(scrubbedTest),
    });

    return docRef.id;
  },

  updateTest: async (
    testId: string,
    updates: Partial<TestDefinition>,
    caller: User,
  ): Promise<void> => {
    const docRef = doc(db, COLLECTIONS.DEFINITIONS, testId);
    const scrubbedUpdates = scrub(updates);
    await updateDoc(docRef, {
      ...scrubbedUpdates,
      updatedAt: serverTimestamp(),
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "LIBRARY",
      action: "TEST_UPDATED",
      status: "SUCCESS",
      details: `Modified protocol configuration: ${testId}`,
      payload: JSON.stringify(scrubbedUpdates),
    });
  },

  deleteTest: async (testId: string, caller: User): Promise<void> => {
    const docRef = doc(db, COLLECTIONS.DEFINITIONS, testId);
    await updateDoc(docRef, { status: "DELETED" });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "LIBRARY",
      action: "TEST_DELETED",
      status: "SUCCESS",
      details: `Archived/Deleted protocol: ${testId}`,
    });
  },

  isTestInUse: async (testId: string): Promise<boolean> => {
    const q = query(
      collection(db, COLLECTIONS.ASSIGNMENTS),
      where("testDefinitionId", "==", testId),
    );
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  },

  uploadTemplateChunked: async (
    file: File,
    testId: string,
    caller: User,
    onProgress?: (p: number) => void,
  ): Promise<TestTemplateMetadata> => {
    const templateId = `tmpl-${Date.now()}`;
    const filePath = `templates/${testId}/${templateId}_${file.name}`;
    const storageRef = ref(storage, filePath);
    const uploadTask = uploadBytesResumable(storageRef, file);

    return new Promise((resolve, reject) => {
      uploadTask.on(
        "state_changed",
        (snap) =>
          onProgress?.(
            Math.round((snap.bytesTransferred / snap.totalBytes) * 100),
          ),
        reject,
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          const metadata: TestTemplateMetadata = {
            id: templateId,
            name: file.name,
            version: 1,
            fileType: file.type,
            storagePath: filePath,
            downloadUrl: downloadURL,
            uploadedBy: caller.email,
            updatedAt: new Date().toISOString(),
            sizeBytes: file.size,
          };
          await updateDoc(doc(db, COLLECTIONS.DEFINITIONS, testId), {
            linkedTemplate: metadata,
          });

          await SystemService.createAuditLog({
            userEmail: caller.email,
            userName: caller.displayName,
            userRole: caller.role,
            module: "LIBRARY",
            action: "TEMPLATE_UPLOADED",
            status: "SUCCESS",
            details: `Uploaded new DOCX template for test ${testId}`,
            payload: JSON.stringify(metadata),
          });

          resolve(metadata);
        },
      );
    });
  },
};

export const ProjectService = {
  fetchProjects: async (): Promise<Project[]> => {
    const snapshot = await getDocs(collection(db, COLLECTIONS.PROJECTS));
    return snapshot.docs.map((d) => ({ ...d.data(), id: d.id }) as Project);
  },

  fetchProjectById: async (projectId: string): Promise<Project | null> => {
    const docRef = doc(db, COLLECTIONS.PROJECTS, projectId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return { ...snap.data(), id: snap.id } as Project;
    }
    return null;
  },

  createProject: async (project: Project, caller: User): Promise<string> => {
    const scrubbed = scrub(project);
    const docRef = await addDoc(collection(db, COLLECTIONS.PROJECTS), {
      ...scrubbed,
      createdAt: serverTimestamp(),
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "PROJECTS",
      action: "PROJECT_CREATED",
      status: "SUCCESS",
      projectId: docRef.id,
      details: `Initialized new project: ${project.name}`,
      payload: JSON.stringify(scrubbed),
    });

    return docRef.id;
  },

  updateProject: async (
    projectId: string,
    updates: Partial<Project>,
    caller: User,
  ): Promise<void> => {
    const docRef = doc(db, COLLECTIONS.PROJECTS, projectId);
    const scrubbed = scrub(updates);
    await updateDoc(docRef, scrubbed);

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "PROJECTS",
      action: "PROJECT_UPDATED",
      status: "SUCCESS",
      projectId: projectId,
      details: `Modified project settings for ID: ${projectId}`,
      payload: JSON.stringify(scrubbed),
    });
  },

  deleteProject: async (projectId: string, caller: User): Promise<void> => {
    const assignmentsQ = query(
      collection(db, COLLECTIONS.ASSIGNMENTS),
      where("projectId", "==", projectId),
    );
    const assignmentsSnap = await getDocs(assignmentsQ);
    for (const d of assignmentsSnap.docs) {
      await deleteDoc(doc(db, COLLECTIONS.ASSIGNMENTS, d.id));
    }
    await deleteDoc(doc(db, COLLECTIONS.PROJECTS, projectId));

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "PROJECTS",
      action: "PROJECT_DELETED",
      status: "SUCCESS",
      projectId: projectId,
      details: `Permanently removed project and all associated assignments.`,
    });
  },

  assignTestToProject: async (
    projectId: string,
    testDefId: string,
    testName: string,
    engineerId: string,
    caller: User,
  ): Promise<string> => {
    // Fetch project name for better reporting
    let projectName = 'Unknown Project';
    try {
      const projectDoc = await getDoc(doc(db, COLLECTIONS.PROJECTS, projectId));
      if (projectDoc.exists()) {
        projectName = projectDoc.data().name || 'Unknown Project';
      }
    } catch (e) {
      console.error("Error fetching project name for assignment:", e);
    }

    const newAssignment: Partial<TestAssignment> = {
      projectId,
      projectName, // Save project name for robust reporting
      testDefinitionId: testDefId,
      testName,
      assignedEngineerId: engineerId,
      status: "IN_PROGRESS",
      workflowStatus: WorkflowStatus.DRAFT,
      readings: {},
      rejectionCount: 0,
      createdAt: new Date().toISOString(),
    };
    const docRef = await addDoc(
      collection(db, COLLECTIONS.ASSIGNMENTS),
      newAssignment,
    );

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "PROJECTS",
      action: "TEST_ASSIGNED_TO_PROJECT",
      status: "SUCCESS",
      projectId: projectId,
      details: `Linked protocol ${testName} to project. Target Engineer UID: ${engineerId}`,
      payload: JSON.stringify(newAssignment),
    });

    return docRef.id;
  },
};

export const ExecutionService = {
  fetchAssignmentsByEngineer: async (
    engineerId: string,
  ): Promise<TestAssignment[]> => {
    const coll = collection(db, COLLECTIONS.ASSIGNMENTS);
    const q = engineerId
      ? query(coll, where("assignedEngineerId", "==", engineerId))
      : query(coll);
    const snapshot = await getDocs(q);
    return snapshot.docs.map(
      (d) => ({ ...d.data(), id: d.id }) as TestAssignment,
    );
  },

  saveReadings: async (assignmentId: string, readings: any, caller: User) => {
    if (assignmentId === "PREVIEW_ID") return;
    
    // Check if deletion is pending
    const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    const snap = await getDoc(assignmentRef);
    const status = snap.exists() ? snap.data().workflowStatus : null;
    if (status === WorkflowStatus.DELETION_PENDING || status === WorkflowStatus.DELETION_APPROVED) {
      throw new Error("Cannot update readings: Deletion process is active for this test.");
    }

    const scrubbed = scrub(readings);
    
    // Detailed logging for all users
    let auditDetails = `Draft data updated for assignment: ${assignmentId}`;
    let auditPayload = undefined;

    try {
      const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
      const oldSnap = await getDoc(assignmentRef);
      const oldData = oldSnap.exists() ? oldSnap.data() as TestAssignment : null;
      const oldReadings = oldData?.readings || {};

      const changedTables: string[] = [];
      const changeSummary: string[] = [];

      for (const key in scrubbed) {
        const oldVal = JSON.stringify(oldReadings[key]);
        const newVal = JSON.stringify(scrubbed[key]);
        
        if (oldVal !== newVal) {
          changedTables.push(key);
          if (Array.isArray(scrubbed[key])) {
            changeSummary.push(`${key} (${scrubbed[key].length} rows)`);
          } else {
            changeSummary.push(`${key} updated`);
          }
        }
      }

      if (changedTables.length > 0) {
        auditDetails = `Updated tables: ${changedTables.join(", ")}. Details: ${changeSummary.join("; ")}`;
      } else {
        auditDetails = `Saved readings (no structural changes detected)`;
      }
      
      auditPayload = JSON.stringify({
        assignmentId,
        changedTables,
        newReadings: scrubbed,
        oldReadings
      });
    } catch (err) {
      console.error("Audit log detail generation failed:", err);
    }

    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      readings: scrubbed,
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "READINGS_SAVED",
      status: "SUCCESS",
      details: auditDetails,
      payload: auditPayload,
    });
  },

  submitForReview: async (assignmentId: string, caller: User) => {
    const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    const snap = await getDoc(assignmentRef);
    const status = snap.exists() ? snap.data().workflowStatus : null;
    if (status === WorkflowStatus.DELETION_PENDING || status === WorkflowStatus.DELETION_APPROVED) {
      throw new Error("Action blocked: Deletion process is active for this test.");
    }

    let auditDetails = `Protocol ${assignmentId} submitted for PM review.`;
    let auditPayload = undefined;

    try {
      const assignmentDoc = await getDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId));
      if (assignmentDoc.exists()) {
        const data = assignmentDoc.data() as TestAssignment;
        auditDetails = `Protocol ${data.testName} SUBMITTED for PM review.`;
        auditPayload = JSON.stringify({
          assignmentId,
          testName: data.testName,
          readings: data.readings,
          submittedBy: caller.email
        });
      }
    } catch (err) {
      console.error("Audit log detail generation failed:", err);
    }

    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      workflowStatus: WorkflowStatus.SUBMITTED,
      status: "COMPLETED",
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "PROTOCOL_SUBMITTED",
      status: "SUCCESS",
      details: auditDetails,
      payload: auditPayload,
    });
  },

  approveAssignment: async (assignmentId: string, caller: User) => {
    const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    const snap = await getDoc(assignmentRef);
    const status = snap.exists() ? snap.data().workflowStatus : null;
    if (status === WorkflowStatus.DELETION_PENDING || status === WorkflowStatus.DELETION_APPROVED) {
      throw new Error("Action blocked: Deletion process is active for this test.");
    }

    let auditDetails = `PM Approval granted for assignment: ${assignmentId}`;
    let auditPayload = undefined;

    try {
      const assignmentDoc = await getDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId));
      if (assignmentDoc.exists()) {
        const data = assignmentDoc.data() as TestAssignment;
        auditDetails = `PM Approval granted for ${data.testName} (${assignmentId})`;
        auditPayload = JSON.stringify({
          assignmentId,
          testName: data.testName,
          finalReadings: data.readings,
          approvedBy: caller.email
        });
      }
    } catch (err) {
      console.error("Audit log detail generation failed:", err);
    }

    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      workflowStatus: WorkflowStatus.APPROVED,
      reviewedBy: caller.uid,
      reviewedAt: new Date().toISOString(),
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "PROTOCOL_APPROVED",
      status: "SUCCESS",
      details: auditDetails,
      payload: auditPayload,
    });
  },

  rejectAssignment: async (
    assignmentId: string,
    comments: string,
    caller: User,
  ) => {
    const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    const snap = await getDoc(assignmentRef);
    const status = snap.exists() ? snap.data().workflowStatus : null;
    if (status === WorkflowStatus.DELETION_PENDING || status === WorkflowStatus.DELETION_APPROVED) {
      throw new Error("Action blocked: Deletion process is active for this test.");
    }

    let auditDetails = `Data rejected by PM. Comments: ${comments}`;
    let auditPayload = undefined;

    try {
      const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
      const assignmentDoc = await getDoc(assignmentRef);
      if (assignmentDoc.exists()) {
        const data = assignmentDoc.data() as TestAssignment;
        auditDetails = `Protocol ${data.testName} REJECTED. Comments: ${comments}`;
        auditPayload = JSON.stringify({
          assignmentId,
          testName: data.testName,
          rejectionComments: comments,
          rejectedBy: caller.email
        });

        // Increment rejection count
        const currentCount = data.rejectionCount || 0;
        await updateDoc(assignmentRef, {
          workflowStatus: WorkflowStatus.REJECTED,
          pmComments: comments,
          status: "IN_PROGRESS",
          rejectionCount: currentCount + 1,
        });
      }
    } catch (err) {
      console.error("Audit log detail generation failed or rejection update failed:", err);
    }

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "PROTOCOL_REJECTED",
      status: "SUCCESS",
      details: auditDetails,
      payload: auditPayload,
    });
  },

  revertToDraft: async (assignmentId: string, caller: User) => {
    const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    const snap = await getDoc(assignmentRef);
    const status = snap.exists() ? snap.data().workflowStatus : null;
    if (status === WorkflowStatus.DELETION_PENDING || status === WorkflowStatus.DELETION_APPROVED) {
      throw new Error("Action blocked: Deletion process is active for this test.");
    }

    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      workflowStatus: WorkflowStatus.DRAFT,
      status: "IN_PROGRESS",
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "PROTOCOL_REVERTED_TO_DRAFT",
      status: "SUCCESS",
      details: `Assignment ${assignmentId} reverted to DRAFT for re-submission.`,
    });
  },

  requestAssignmentDeletion: async (assignmentId: string, caller: User) => {
    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      workflowStatus: WorkflowStatus.DELETION_PENDING,
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "DELETION_REQUESTED",
      status: "SUCCESS",
      details: `Deletion request initiated for assignment ${assignmentId}`,
    });
  },

  rejectAssignmentDeletion: async (assignmentId: string, caller: User) => {
    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      workflowStatus: WorkflowStatus.DRAFT,
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "DELETION_REJECTED",
      status: "SUCCESS",
      details: `Admin rejected deletion for assignment ${assignmentId}`,
    });
  },

  updateAssignmentEngineer: async (
    assignmentId: string,
    newEngineerId: string,
    caller: User,
  ) => {
    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      assignedEngineerId: newEngineerId,
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "PROJECTS",
      action: "ENGINEER_REASSIGNED",
      status: "SUCCESS",
      details: `Reassigned assignment ${assignmentId} to engineer UID: ${newEngineerId}`,
    });
  },

  togglePin: async (assignmentId: string, userId: string, caller: User) => {
    const docRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) return;
    
    const data = snap.data() as TestAssignment;
    const pinnedBy = data.pinnedBy || [];
    const isPinned = pinnedBy.includes(userId);
    
    const nextPinnedBy = isPinned 
      ? pinnedBy.filter(id => id !== userId)
      : [...pinnedBy, userId];

    await updateDoc(docRef, { pinnedBy: nextPinnedBy });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: isPinned ? "TEST_UNPINNED" : "TEST_PINNED",
      status: "SUCCESS",
      details: `${isPinned ? "Unpinned" : "Pinned"} test ${assignmentId}`,
    });
  },

  updateAssignmentLocation: async (assignmentId: string, location: string, caller: User) => {
    const docRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    await updateDoc(docRef, { location });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "LOCATION_UPDATED",
      status: "SUCCESS",
      details: `Updated location for assignment ${assignmentId} to ${location}`,
    });
  },

  updateAssignmentDocNo: async (assignmentId: string, docNo: string, caller: User) => {
    const docRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
    await updateDoc(docRef, { docNo });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "DOC_NO_UPDATED",
      status: "SUCCESS",
      details: `Updated Document No for assignment ${assignmentId} to ${docNo}`,
    });
  },

  approveAssignmentDeletionRequest: async (assignmentId: string, caller: User) => {
    await updateDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId), {
      workflowStatus: WorkflowStatus.DELETION_APPROVED,
    });

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "EXECUTION",
      action: "DELETION_APPROVED_BY_ADMIN",
      status: "SUCCESS",
      details: `Admin approved deletion request for assignment ${assignmentId}. Pending final PM deletion.`,
    });
  },

  deleteAssignment: async (assignmentId: string, caller: User) => {
    let auditDetails = `Assignment ${assignmentId} deleted.`;
    try {
      const assignmentRef = doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId);
      const assignmentDoc = await getDoc(assignmentRef);
      if (assignmentDoc.exists()) {
        const data = assignmentDoc.data() as TestAssignment;
        auditDetails = `Assignment ${data.testName} (${assignmentId}) DELETED from project.`;
      }
    } catch (err) {
      console.error("Audit log detail generation failed:", err);
    }

    await deleteDoc(doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId));

    await SystemService.createAuditLog({
      userEmail: caller.email,
      userName: caller.displayName,
      userRole: caller.role,
      module: "PROJECTS",
      action: "ASSIGNMENT_DELETED",
      status: "SUCCESS",
      details: auditDetails,
    });
  },

  prepareReportContext: (
    data: Partial<TestAssignment>,
    testDef: TestDefinition | null,
    proj: Project | null,
    assignmentId: string,
  ): any => {
    const readings = (data.readings || {}) as any;
    const testNameLower = (data.testName || "").toLowerCase();
    const n = (val: string | undefined) => parseFloat(val || "0") || 0;
    const f = (val: number) => val % 1 === 0 ? val.toFixed(0) : val.toFixed(2);

    const getStatusXml = (status: string) => {
      const s = (status || "").toUpperCase();
      let bgColor = "";
      if (s === "PASS") bgColor = "198754";
      else if (s === "WARN" || s === "WARNING") bgColor = "F59E0B";
      else if (s === "FAIL") bgColor = "DC2626";

      const fillAttr = bgColor
        ? `<w:shd w:val="clear" w:color="auto" w:fill="${bgColor}"/>`
        : "";
      const colorAttr = bgColor ? `<w:color w:val="FFFFFF"/>` : "";
      const boldAttr = bgColor ? `<w:b/>` : "";

      return `<w:p><w:pPr><w:jc w:val="center"/>${fillAttr}</w:pPr><w:r><w:rPr>${boldAttr}${colorAttr}<w:sz w:val="18"/></w:rPr><w:t>${status || ""}</w:t></w:r></w:p>`;
    };
    
    const getColorXml = (val: string, type: 'blue' | 'green' | 'orange') => {
      let color = '2563EB'; // blue-600
      let bgColor = 'EBF5FF'; // blue-50
      if (type === 'green') { color = '059669'; bgColor = 'ECFDF5'; } // emerald-600 / emerald-50
      if (type === 'orange') { color = 'EA580C'; bgColor = 'FFF7ED'; } // orange-600 / orange-50
      
      const fillAttr = `<w:shd w:val="clear" w:color="auto" w:fill="${bgColor}"/>`;

      return `<w:p><w:pPr><w:jc w:val="center"/>${fillAttr}</w:pPr><w:r><w:rPr><w:b/><w:color w:val="${color}"/><w:sz w:val="18"/></w:rPr><w:t>${val}</w:t></w:r></w:p>`;
    };

    const getDeltaTXml = (delta: number) => {
      let bgColor = "";
      let textColor = "000000";
      if (delta < 5) bgColor = "FFFF00";
      else if (delta > 15) {
        bgColor = "FF0000";
        textColor = "FFFFFF";
      }

      const fillAttr = bgColor
        ? `<w:shd w:val="clear" w:color="auto" w:fill="${bgColor}"/>`
        : "";
      const colorAttr = `<w:color w:val="${textColor}"/>`;
      const boldAttr = `<w:b/>`;

      return `<w:p><w:pPr><w:jc w:val="center"/>${fillAttr}</w:pPr><w:r><w:rPr>${boldAttr}${colorAttr}<w:sz w:val="22"/></w:rPr><w:t>${delta.toFixed(2)}</w:t></w:r></w:p>`;
    };

    const getDeficitXml = (val: number | string) => {
      const nVal = typeof val === "string" ? parseFloat(val) : val;
      if (isNaN(nVal)) return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>---</w:t></w:r></w:p>`;
      const color = nVal < 0 ? "DC2626" : "059669";
      return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="${color}"/><w:sz w:val="22"/></w:rPr><w:t>${f(nVal)}</w:t></w:r></w:p>`;
    };

    const getSubtotalDeficitXml = (val: number | string) => {
      const nVal = typeof val === "string" ? parseFloat(val) : val;
      if (isNaN(nVal)) return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>---</w:t></w:r></w:p>`;
      const color = nVal < 0 ? "DC2626" : "059669";
      return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="${color}"/><w:sz w:val="22"/></w:rPr><w:t>${Math.round(nVal).toFixed(0)}</w:t></w:r></w:p>`;
    };

    const getMeasuredCfmXml = (measured: number | string, required: number | string) => {
      const mVal = typeof measured === "string" ? parseFloat(measured) : measured;
      const rVal = typeof required === "string" ? parseFloat(required) : required;
      if (isNaN(mVal)) return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>---</w:t></w:r></w:p>`;
      const color = mVal >= rVal ? "2563EB" : "DC2626"; // BLUE if >= required, RED if < required
      return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="${color}"/><w:sz w:val="22"/></w:rPr><w:t>${Math.round(mVal).toFixed(0)}</w:t></w:r></w:p>`;
    };

    const getSubtotalXml = (val: number | string) => {
      const nVal = typeof val === "string" ? parseFloat(val) : val;
      const display = isNaN(nVal) ? val : Math.round(nVal).toFixed(0);
      return `<w:p><w:pPr><w:jc w:val="center"/><w:shd w:val="clear" w:color="auto" w:fill="DAEAF7"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="18"/></w:rPr><w:t>${display}</w:t></w:r></w:p>`;
    };
    
    const clientLogo = proj?.clientLogo || "";

    const getTestShortName = (name: string): string => {
      const n = name.toLowerCase();
      if (n.includes('cfm')) return 'CFM';
      if (n.includes('rack cooling index') || n.includes('rci')) return 'RCI';
      if (n.includes('capacity assessment')) return 'CAPACITY';
      if (n.includes('life cycle')) return 'LIFE_CYCLE';
      if (n.includes('vibration')) return 'VIBRATION';
      return name.split(' ')[0].toUpperCase();
    };

    const doc_no = data.docNo || readings?.docNo || readings?.doc_no || (
      testDef?.department === 'MECHANICAL' 
        ? `TSPL-${(proj?.clientName || "").toUpperCase()}-${proj?.projectId || ""}-ME-${getTestShortName(data.testName || "")}`
        : `TSPL-${(proj?.clientName || "").toUpperCase()}-${proj?.projectId || ""}-${getTestShortName(data.testName || "")}`
    );

    const finalObsRecs = (() => {
      if (testNameLower.includes("life cycle")) {
        const LCA_STATUSES = [
          'Fit for Service',
          'Degrading Stage',
          'Approaching Replacement',
          'Reaching End-of-Life',
          'End-of-Life'
        ];
        
        const rulRows = readings?.rulRows || [];
        
        const getRowStatus = (r: any) => {
          const designLife = r.designLifeYrs || '';
          const age = r.ageYrs || '';
          const ageNum = Number(age) || 0;
          const hi = r.healthIndex || '';
          const hiNum = Number(hi) || 0;
          const uf = r.utilizationFactor || '';
          const ufNum = Number(uf) || 1;

          const dlNum = Number(designLife) || 0;
          const computedAL = (dlNum > 0 && hiNum > 0) 
            ? ((dlNum * hiNum) * ufNum).toFixed(1) 
            : '';
          const alNum = Number(computedAL) || 0;

          const computedRulYrs = (alNum > 0) 
            ? (alNum - ageNum).toFixed(1) 
            : '';
          const rulYrsNum = Number(computedRulYrs) || 0;

          const computedRulPct = (alNum > 0) 
            ? ((rulYrsNum / alNum) * 100).toFixed(1) 
            : '';
          const rulPctNum = Number(computedRulPct) || 0;

          let autoStatus = '';
          if (alNum > 0) {
            if (rulPctNum > 50) {
              autoStatus = 'Fit for Service';
            } else if (rulPctNum >= 25) {
              autoStatus = 'Degrading Stage';
            } else if (rulPctNum >= 10) {
              autoStatus = 'Approaching Replacement';
            } else if (rulPctNum > 0) {
              autoStatus = 'Reaching End-of-Life';
            } else {
              autoStatus = 'End-of-Life';
            }
          }
          return r.lifeCycleStatus && r.lifeCycleStatus !== '' && r.lifeCycleStatus !== '-' ? r.lifeCycleStatus : autoStatus;
        };

        const dbObsAndRecs = readings?.observationsAndRecommendations || [];

        const mappedStatuses = LCA_STATUSES.map((status) => {
          const existing = dbObsAndRecs.find((row: any) => row.lifeCycleStatus === status);

          let defaultObs = '';
          let defaultRec = '';
          if (status === 'Fit for Service') {
            defaultObs = "Equipment is in good operating condition with sufficient remaining life.";
            defaultRec = "Continue normal operations. Maintain routine preventive maintenance schedule.";
          } else if (status === 'Degrading Stage') {
            defaultObs = "Early signs of ageing, performance still acceptable but degradation may begin.";
            defaultRec = "Increase preventive maintenance frequency and closely monitor performance.";
          } else if (status === 'Approaching Replacement') {
            defaultObs = "Significant life consumption, Increases risk of low performance.";
            defaultRec = "Initiate replacement planning, allocate budget, and define shutdown schedule.";
          } else if (status === 'Reaching End-of-Life') {
            defaultObs = "Equipment is near end of usable life, high risk of failure.";
            defaultRec = "Immediate replacement planning required. Prepare procurement and execution plan.";
          } else if (status === 'End-of-Life') {
            defaultObs = "1. Equipment has exceeded its estimated useful life.";
            defaultRec = "Urgent replacement required. Operate only if critical, with contingency support.";
          }

          const matchingRulRows = (rulRows || []).filter((r: any) => getRowStatus(r) === status);
          const count = matchingRulRows.length;
          const tagsStr = count > 0 
            ? matchingRulRows.map((r: any) => r.equipmentTag || 'Unnamed').join('\n') 
            : '-';

          return {
            lifeCycleStatus: status,
            noOfEquipment: String(count),
            equipmentTag: tagsStr,
            observation: existing ? existing.observation : defaultObs,
            recommendation: existing ? existing.recommendation : defaultRec
          };
        });

        return mappedStatuses.filter((item: any) => Number(item.noOfEquipment) > 0);
      }

      return readings?.observationsAndRecommendations || [];
    })();

    const reportContext: any = {
      clientLogo,
      dc_name: proj?.name || "---",
      projectId: proj?.projectId || "---",
      doc_no,
      customer_name: proj?.clientName || "---",
      address: proj?.address || "---",
      revision_no: readings?.revisionNo || "---",
      revisionNo: readings?.revisionNo || "---",
      prepared_by: readings?.preparedBy || "---",
      preparedBy: readings?.preparedBy || "---",
      testedBy: readings?.testedBy || "---",
      witnessedBy: readings?.witnessedBy || "---",
      approved_by: readings?.approvedBy || proj?.approvedBy || "---",
      approvedBy: readings?.approvedBy || proj?.approvedBy || "---",
      tester_email: readings?.testerEmail || "---",
      testerEmail: readings?.testerEmail || "---",
      TestDate: (() => {
        if (!readings?.testDate) return "---";
        const d = new Date(readings.testDate);
        if (isNaN(d.getTime())) return "---";
        return d.toLocaleDateString("en-GB").replace(/\//g, "-");
      })(),
      testDate: (() => {
        if (!readings?.testDate) return "---";
        const d = new Date(readings.testDate);
        if (isNaN(d.getTime())) return "---";
        return d.toLocaleDateString("en-GB").replace(/\//g, "-");
      })(),
      observations: finalObsRecs.length > 0
        ? finalObsRecs.map((r: any, idx: number) => `${idx + 1}. ${r.observation}`).join('\n')
        : (readings?.observations || readings?.remarks || "---"),
      recommendations: finalObsRecs.length > 0
        ? finalObsRecs.map((r: any, idx: number) => `${idx + 1}. ${r.recommendation}`).join('\n')
        : (readings?.recommendations || "---"),
      obs_list: finalObsRecs.length > 0
        ? finalObsRecs.map((r: any) => ({ line: r.observation }))
        : (readings?.observations || readings?.remarks || "---")
            .split(/\r?\n/)
            .map((l: any) => l.trim())
            .filter((l: any) => l.length > 0 && l !== "---")
            .map((l: any) => ({ line: l })),
      rec_list: finalObsRecs.length > 0
        ? finalObsRecs.map((r: any) => ({ line: r.recommendation }))
        : (readings?.recommendations || "---")
            .split(/\r?\n/)
            .map((l: any) => l.trim())
            .filter((l: any) => l.length > 0 && l !== "---")
            .map((l: any) => ({ line: l })),
      ObservationsTable: finalObsRecs.map((r: any, idx: number) => ({
        srNo: idx + 1,
        lifeCycleStatus: r.lifeCycleStatus || "",
        noOfEquipment: r.noOfEquipment || "",
        equipmentTag: r.equipmentTag || "",
        observation: r.observation || "",
        recommendation: r.recommendation || ""
      })),
      TestName: data.testName,
      ReportId: (assignmentId || "PREVIEW").toUpperCase().slice(0, 8),
      AIInsight: data.aiInsight || "No AI analysis available.",
      CurrentDate: new Date().toLocaleDateString("en-GB"),
      scopeDescription: readings?.scopeDescription || "---",
      status: readings?.status || "---",
      thermalUnits: readings?.thermalUnits || [],
      airflowUnits: readings?.airflowUnits || [],
      inspections: (readings?.inspections || []).map((item: any, idx: number) => ({
        ...item,
        sNo: idx + 1,
      })),
      images: (readings?.images || []).map((item: any, idx: number) => ({
        ...item,
        sNo: idx + 1,
      })),
      equipmentList: (readings?.equipmentList || []).map(
        (item: any, idx: number) => ({ ...item, srNo: idx + 1 }),
      ),
      EquipmentTable: (readings?.equipmentList || []).map(
        (item: any, idx: number) => ({ ...item, srNo: idx + 1 }),
      ),
      LocationBlock: readings?.locations || [],
      OnSiteTests: readings?.onSiteTests || [],
      DGEquipmentUsed: readings?.equipmentList || [],
      DGUnits: readings?.dgUnits || [],
      EarthEquipmentTable: readings?.equipmentList || [],
      EarthMeasuringTable: readings?.readings || [],
      itLoad: readings?.itLoad || "N/A",
      measuredPue: (() => {
        const it = parseFloat(readings?.itLoad || '0');
        const pu = (readings?.pacTables || []).reduce((sum: number, t: any) => sum + (t.entries || []).reduce((s: number, ent: any) => s + (parseFloat(ent.measuredPower) || 0), 0), 0);
        return it > 0 ? ((it + pu) / it).toFixed(2) : "N/A";
      })(),
      pahuTables: (readings?.pahuTables || []).map((table: any) => {
        const entries = (table.entries || []).map((ent: any) => {
          const d_tra =
            (1.06 *
              n(ent.designAirflow) *
              (n(ent.designRaTemp) - n(ent.designSaTemp)) *
              1.8) /
            12000;
          const m_tra =
            (1.06 *
              n(ent.measuredAirflow) *
              (n(ent.measuredRaTemp) - n(ent.measuredSaTemp)) *
              1.8) /
            12000;
          const gpmVal = parseFloat(ent.measuredWaterFlowRate) || 0;
          const inVal = parseFloat(ent.measuredChwIn) || 0;
          const outVal = parseFloat(ent.measuredChwOut) || 0;
          const deltaC = Math.abs(outVal - inVal);
          const waterTr = (gpmVal * deltaC * 1.8) / 24;

          return {
            ...ent,
            d_tra: d_tra.toFixed(1),
            m_tra: m_tra.toFixed(1),
            measuredWaterCoolingTonnage_xml: getColorXml(waterTr > 0 ? waterTr.toFixed(1) : "0.0", 'green')
          };
        });

        const totalDesignAirflow = entries.reduce((sum: number, ent: any) => sum + n(ent.designAirflow), 0).toFixed(1);
        const totalDesignPower = entries.reduce((sum: number, ent: any) => sum + n(ent.designPower), 0).toFixed(1);
        const d_tra_sum = entries.reduce((sum: number, ent: any) => {
          const d_tra = (1.06 * n(ent.designAirflow) * (n(ent.designRaTemp) - n(ent.designSaTemp)) * 1.8) / 12000;
          return sum + d_tra;
        }, 0);
        const totalDesignTr = d_tra_sum.toFixed(1);
        const totalDesignTr_xml = getColorXml(d_tra_sum.toFixed(1), 'blue');

        const totalMeasuredAirflow = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredAirflow), 0).toFixed(1);
        const totalMeasuredRaTemp = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredRaTemp), 0).toFixed(1);
        const totalMeasuredSaTemp = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredSaTemp), 0).toFixed(1);
        const totalMeasuredPower = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredPower), 0).toFixed(1);
        const m_tra_sum = entries.reduce((sum: number, ent: any) => {
          const m_tra = (1.06 * n(ent.measuredAirflow) * (n(ent.measuredRaTemp) - n(ent.measuredSaTemp)) * 1.8) / 12000;
          return sum + m_tra;
        }, 0);
        const totalMeasuredTr = m_tra_sum.toFixed(1);
        const totalMeasuredTr_xml = getColorXml(m_tra_sum.toFixed(1), 'blue');
        const totalMeasuredFanSpeed = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredFanSpeed), 0).toFixed(1);

        const totalMeasuredChwIn = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredChwIn), 0).toFixed(1);
        const totalMeasuredChwOut = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredChwOut), 0).toFixed(1);
        const totalMeasuredValveOpening = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredValveOpening), 0).toFixed(1);
        const totalMeasuredWaterFlowRate = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredWaterFlowRate), 0).toFixed(1);
        
        const totalWaterTr_sum = entries.reduce((sum: number, ent: any) => {
          const gpmVal = parseFloat(ent.measuredWaterFlowRate) || 0;
          const inVal = parseFloat(ent.measuredChwIn) || 0;
          const outVal = parseFloat(ent.measuredChwOut) || 0;
          const deltaC = Math.abs(outVal - inVal);
          const waterTr = (gpmVal * deltaC * 1.8) / 24;
          return sum + waterTr;
        }, 0);
        const totalMeasuredWaterTr_xml = getColorXml(totalWaterTr_sum.toFixed(1), 'green');

        return {
          ...table,
          entries,
          totalDesignAirflow,
          totalDesignPower,
          totalDesignTr,
          totalDesignTr_xml,
          totalMeasuredAirflow,
          totalMeasuredRaTemp,
          totalMeasuredSaTemp,
          totalMeasuredPower,
          totalMeasuredTr,
          totalMeasuredTr_xml,
          totalMeasuredFanSpeed,
          totalMeasuredChwIn,
          totalMeasuredChwOut,
          totalMeasuredValveOpening,
          totalMeasuredWaterFlowRate,
          totalMeasuredWaterTr_xml,
        };
      }),
      pacTables: (readings?.pacTables || []).map((table: any) => {
        const entries = (table.entries || []).map((ent: any) => {
          const d_tra =
            (1.06 *
              n(ent.designAirflow) *
              (n(ent.designRaTemp) - n(ent.designSaTemp)) *
              1.8) /
            12000;
          const m_tra =
            (1.06 *
              n(ent.measuredAirflow) *
              (n(ent.measuredRaTemp) - n(ent.measuredSaTemp)) *
              1.8) /
            12000;
          const cop =
            n(ent.measuredPower) > 0 ? (m_tra * 3.517) / n(ent.measuredPower) : 0;
          return {
            ...ent,
            d_tra: d_tra.toFixed(1),
            m_tra: m_tra.toFixed(1),
            cop: cop.toFixed(2),
          };
        });

        const totalDesignAirflow = entries.reduce((sum: number, ent: any) => sum + n(ent.designAirflow), 0).toFixed(1);
        const totalDesignPower = entries.reduce((sum: number, ent: any) => sum + n(ent.designPower), 0).toFixed(1);
        const d_tra_sum = entries.reduce((sum: number, ent: any) => {
          const d_tra = (1.06 * n(ent.designAirflow) * (n(ent.designRaTemp) - n(ent.designSaTemp)) * 1.8) / 12000;
          return sum + d_tra;
        }, 0);
        const totalDesignTr = d_tra_sum.toFixed(1);
        const totalDesignTr_xml = getColorXml(d_tra_sum.toFixed(1), 'blue');

        const totalMeasuredAirflow = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredAirflow), 0).toFixed(1);
        const totalMeasuredRaTemp = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredRaTemp), 0).toFixed(1);
        const totalMeasuredSaTemp = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredSaTemp), 0).toFixed(1);
        const totalMeasuredPower = entries.reduce((sum: number, ent: any) => sum + n(ent.measuredPower), 0).toFixed(1);
        const m_tra_sum = entries.reduce((sum: number, ent: any) => {
          const m_tra = (1.06 * n(ent.measuredAirflow) * (n(ent.measuredRaTemp) - n(ent.measuredSaTemp)) * 1.8) / 12000;
          return sum + m_tra;
        }, 0);
        const totalMeasuredTr = m_tra_sum.toFixed(1);
        const totalMeasuredTr_xml = getColorXml(m_tra_sum.toFixed(1), 'blue');
        const totalFanSpeed = entries.reduce((sum: number, ent: any) => sum + n(ent.fanSpeed), 0).toFixed(1);

        const cop_calc = n(totalMeasuredPower) > 0 ? (m_tra_sum * 3.517) / n(totalMeasuredPower) : 0;
        const totalCop = cop_calc.toFixed(2);
        const totalCop_xml = getColorXml(cop_calc.toFixed(2), 'green');

        return {
          ...table,
          entries,
          totalDesignAirflow,
          totalDesignPower,
          totalDesignTr,
          totalDesignTr_xml,
          totalFanSpeed,
          totalMeasuredAirflow,
          totalMeasuredRaTemp,
          totalMeasuredSaTemp,
          totalMeasuredPower,
          totalMeasuredTr,
          totalMeasuredTr_xml,
          totalCop,
          totalCop_xml,
        };
      }),
      ToolsTable: readings?.toolsUsed || [],
      ToolTable: readings?.toolsUsed || [],
      dcSections: readings?.dcSections || [],
      ppeCategories: readings?.ppeCategories || [],
      studyResults: readings?.studyResults || [],
      UpsHierarchy: readings?.upsSystems || [],
      ProblematicReadings: [],
      analysisGroups: readings?.analysisGroups || [],
      ag: [],
      transformers: [
        "SPECIFICATION REFERENCE",
        "MAKE",
        "RATED IN KVA",
        "HV VOLTAGE IN VOLTS",
        "LV VOLTAGE IN VOLTS",
        "HV CURRENT IN AMPS",
        "LV CURRENT IN AMPS",
        "NO. OF PHASES",
        "FREQUENCY IN HZ",
        "TYPES OF COOLING",
        "IMPEDANCE VOLTAGE %",
        "CONNECTION SYMBOLS",
      ]
        .map((param, rowIdx) => {
          const row: any = {
            sNo: (rowIdx + 1).toString(),
            paramName: param,
          };
          let hasData = false;
          (readings?.transformers || []).forEach((col: any, colIdx: number) => {
            const val = col.values[rowIdx] || "";
            row[`tf${colIdx + 1}`] = val;
            if (val.trim() !== "") hasData = true;
          });
          return hasData ? row : null;
        })
        .filter(Boolean),
      loadFlow: (readings?.loadFlow || []).filter(
        (r: any) =>
          !r.isHeader &&
          (!!r.location ||
            !!r.busVoltKv ||
            !!r.powerMva ||
            !!r.realPowerMw ||
            !!r.reactivePowerMvar ||
            !!r.pf),
      ),
      shortCircuit: (readings?.shortCircuit || []).filter(
        (r: any) =>
          !!r.location ||
          !!r.busVoltKv ||
          !!r.threePhaseKa ||
          !!r.lineToGroundKa ||
          !!r.busRatingKa,
      ),
      relayPhase: (readings?.relayPhase || [])
        .filter(
          (r: any) =>
            !r.isHeader &&
            (!!r.feeder ||
              !!r.relayNo ||
              !!r.ratedCurrent ||
              !!r.relayType ||
              !!r.ctRatio),
        )
        .map((r: any) => ({
          ...r,
          opTimeCloseInFault: r.existing?.opTimeCloseInFault || "",
          e_curve: r.existing?.curve || "",
          e_plug: r.existing?.plug || "",
          e_tms: r.existing?.tms || "",
          e_hiI: r.existing?.hiI || "",
          e_hiT: r.existing?.hiT || "",
          s_curve: r.suggested?.curve || "",
          s_plug: r.suggested?.plug || "",
          s_tms: r.suggested?.tms || "",
          s_hiI: r.suggested?.hiI || "",
          s_hiT: r.suggested?.hiT || "",
        })),
      relayEarth: (readings?.relayEarth || [])
        .filter(
          (r: any) =>
            !r.isHeader &&
            (!!r.feeder ||
              !!r.relayNo ||
              !!r.ratedCurrent ||
              !!r.relayType ||
              !!r.ctRatio),
        )
        .map((r: any) => ({
          ...r,
          opTimeCloseInFault: r.existing?.opTimeCloseInFault || "",
          e_curve: r.existing?.curve || "",
          e_plug: r.existing?.plug || "",
          e_tms: r.existing?.tms || "",
          e_hiI: r.existing?.hiI || "",
          e_hiT: r.existing?.hiT || "",
          s_curve: r.suggested?.curve || "",
          s_plug: r.suggested?.plug || "",
          s_tms: r.suggested?.tms || "",
          s_hiI: r.suggested?.hiI || "",
          s_hiT: r.suggested?.hiT || "",
        })),
      releaseSettings: (readings?.releaseSettings || [])
        .filter(
          (r: any) =>
            !r.isHeader &&
            (!!r.feederName || !!r.slNo || !!r.ratedCurrent || !!r.relayMakeType),
        )
        .map((r: any) => ({
          ...r,
          e_ltP: r.existing?.longTimePickup || "",
          e_ltT: r.existing?.longTimeTime || "",
          e_stP: r.existing?.shortTimePickup || "",
          e_stT: r.existing?.shortTimeTime || "",
          e_inst: r.existing?.instantaneous || "",
          e_eP: r.existing?.earthPickup || "",
          e_eT: r.existing?.earthTime || "",
          p_ltP: r.proposed?.longTimePickup || "",
          p_ltT: r.proposed?.longTimeTime || "",
          p_stP: r.proposed?.shortTimePickup || "",
          p_stT: r.proposed?.shortTimeTime || "",
          p_inst: r.proposed?.instantaneous || "",
          p_eP: r.proposed?.earthPickup || "",
          p_eT: r.proposed?.earthTime || "",
        })),
      arcFlashAnalysis: (readings?.arcFlashAnalysis || []).filter(
        (r: any) =>
          !r.isHeader &&
          (!!r.locationName || !!r.nominalKv || !!r.boltedKa || !!r.arcingKa),
      ),
      panels: readings?.panels || [],
      laReadings: readings?.laReadings || [],
      lifeCycleRows: readings?.lifeCycleRows || [],
      rulRows: readings?.rulRows || [],
      gapAnalysisRows: readings?.gapAnalysisRows || [],
      totalRackKW: "---",
      totalRackTR: "---",
      totalActualCFM: readings?.totalActualCFM || "---",
      totalDesignCFM: readings?.totalDesignCFM || "---",
      totalDeficit: "---",
      complianceSummary: [],
      systems: [],
      ReadingRow: readings?.readings || [],
      AbbreviationTable: readings?.abbreviations || [],
      VibrationSummaryTable: (readings?.summaryGroups || []).map((group: any) => ({
        ...group,
        groupName: (group.groupName || "").toUpperCase(),
      })),
    };

    if (testNameLower.includes("vibration analysis")) {
      const counts = { GOOD: 0, SATISFACTORY: 0, UNSATISFACTORY: 0, UNACCEPTABLE: 0 };
      const tags: Record<string, string[]> = { GOOD: [], SATISFACTORY: [], UNSATISFACTORY: [], UNACCEPTABLE: [] };
      
      (readings.summaryGroups || []).forEach((group: any) => {
        (group.rows || []).forEach((row: any) => {
          const rawCondition = (row.condition || "GOOD").toUpperCase();
          if (counts.hasOwnProperty(rawCondition)) {
            const conditionKey = rawCondition as keyof typeof counts;
            counts[conditionKey]++;
            if (row.equipmentId) tags[conditionKey].push(row.equipmentId);
          }
        });
      });

      reportContext.GoodCount = counts.GOOD;
      reportContext.SatisfactoryCount = counts.SATISFACTORY;
      reportContext.UnsatisfactoryCount = counts.UNSATISFACTORY;
      reportContext.UnacceptableCount = counts.UNACCEPTABLE;
      
      reportContext.GoodTags = tags.GOOD.length > 0 ? tags.GOOD.join('\n') : '-';
      reportContext.SatisfactoryTags = tags.SATISFACTORY.length > 0 ? tags.SATISFACTORY.join('\n') : '-';
      reportContext.UnsatisfactoryTags = tags.UNSATISFACTORY.length > 0 ? tags.UNSATISFACTORY.join('\n') : '-';
      reportContext.UnacceptableTags = tags.UNACCEPTABLE.length > 0 ? tags.UNACCEPTABLE.join('\n') : '-';

      reportContext.hasGood = counts.GOOD > 0;
      reportContext.hasSatisfactory = counts.SATISFACTORY > 0;
      reportContext.hasUnsatisfactory = counts.UNSATISFACTORY > 0;
      reportContext.hasUnacceptable = counts.UNACCEPTABLE > 0;

      reportContext.VibrationSummaryRows = [];
      if (counts.GOOD > 0) {
        reportContext.VibrationSummaryRows.push({
          condition: "Good",
          count: counts.GOOD,
          tags: tags.GOOD.join('\n'),
          obs1: "1. All units are within ISO acceptable vibration limits.",
          obs2: "2. No abnormal vibration trend observed in H/V/A directions.",
          obs3: "3. Equipment operating in stable dynamic condition.",
          rec1: "1. Continue routine condition monitoring as per PM schedule.",
          rec2: "2. Record baseline trends for future comparison.",
          hasObs3: true,
          hasRec2: true
        });
      }
      if (counts.SATISFACTORY > 0) {
        reportContext.VibrationSummaryRows.push({
          condition: "Satisfactory",
          count: counts.SATISFACTORY,
          tags: tags.SATISFACTORY.join('\n'),
          obs1: "1. Vibration levels are within permissible ISO limits but approaching upper band.",
          obs2: "2. Slight increase observed in one or more measurement directions (H/V/A).",
          obs3: "3. No immediate mechanical fault indication.",
          rec1: "1. Monitor vibration trend closely.",
          rec2: "2. Inspect during next planned shutdown.",
          rec3: "3. Check for early signs of misalignment or looseness.",
          hasObs3: true,
          hasRec2: true,
          hasRec3: true
        });
      }
      if (counts.UNSATISFACTORY > 0) {
        reportContext.VibrationSummaryRows.push({
          condition: "Unsatisfactory",
          count: counts.UNSATISFACTORY,
          tags: tags.UNSATISFACTORY.join('\n'),
          obs1: "1. Vibration levels exceed satisfactory range as per ISO limits.",
          obs2: "2. Indicates early mechanical degradation (possible imbalance, misalignment, or looseness).",
          obs3: "3. Trend shows increasing deviation from baseline.",
          rec1: "1. Conduct detailed vibration analysis.",
          rec2: "2. Inspect coupling alignment, foundation tightness, and bearing condition.",
          rec3: "3. Plan corrective maintenance in nearest shutdown window.",
          hasObs3: true,
          hasRec2: true,
          hasRec3: true
        });
      }
      if (counts.UNACCEPTABLE > 0) {
        reportContext.VibrationSummaryRows.push({
          condition: "Unacceptable",
          count: counts.UNACCEPTABLE,
          tags: tags.UNACCEPTABLE.join('\n'),
          obs1: "1. Vibration levels exceed permissible ISO limits indicating critical condition.",
          obs2: "2. High risk of mechanical failure if operation continues.",
          obs3: "3. Abnormal vibration detected in one or more directions (H/V/A).",
          rec1: "1. Immediate corrective action required.",
          rec2: "2. Reduce load or shut down equipment if possible.",
          rec3: "3. Perform urgent inspection: alignment correction, bearing replacement, structural tightening before restart.",
          hasObs3: true,
          hasRec2: true,
          hasRec3: true
        });
      }
    }

    if (testNameLower.includes("life cycle")) {
      reportContext.equipmentList = (readings.equipmentList || []).map(
        (r: any, idx: number) => ({
          ...r,
          sNo: idx + 1,
        }),
      );
      reportContext.lifeCycleRows = (readings.lifeCycleRows || []).map(
        (r: any, idx: number) => {
          const valCurrentYear = r.currentYear || String(new Date().getFullYear());
          const valInstallYear = r.installYear || '';
          const autoAge = (valInstallYear && valCurrentYear && !isNaN(Number(valCurrentYear)) && !isNaN(Number(valInstallYear))) 
            ? String(Number(valCurrentYear) - Number(valInstallYear)) 
            : '';
          const age = r.ageYrs !== '' && r.ageYrs !== undefined ? r.ageYrs : autoAge;
          const ageNum = Number(age) || 0;

          let autoHI = '';
          if (r.vibrationScore !== '' || r.corrosionScore !== '' || r.maintScore !== '') {
            const vs = Number(r.vibrationScore) || 0;
            const cs = Number(r.corrosionScore) || 0;
            const ms = Number(r.maintScore) || 0;
            const count = [r.vibrationScore, r.corrosionScore, r.maintScore].filter(v => v !== '' && v !== undefined).length;
            if (count > 0) {
              autoHI = ((vs + cs + ms) / count).toFixed(1);
            }
          }
          const hi = r.healthIndex !== '' && r.healthIndex !== undefined ? r.healthIndex : autoHI;
          const hiNum = Number(hi) || 0;

          const uf = r.utilizationFactor || '';
          const ufNum = Number(uf) || 1;

          const dlNum = Number(r.designLifeYrs) || 0;
          const computedAL = (dlNum > 0 && hiNum > 0) 
            ? ((dlNum * hiNum) * ufNum).toFixed(1) 
            : '';
          const al = computedAL;
          const alNum = Number(al) || 0;

          const computedRulYrs = (alNum > 0) 
            ? (alNum - ageNum).toFixed(1) 
            : '';
          const rulYrs = computedRulYrs;
          const rulYrsNum = Number(rulYrs) || 0;

          const computedRulPct = (alNum > 0) 
            ? ((rulYrsNum / alNum) * 100).toFixed(1) 
            : '';
          const rulPct = computedRulPct;
          const rulPctNum = Number(rulPct) || 0;

          let autoStatus = '';
          if (alNum > 0) {
            if (rulPctNum > 50) autoStatus = 'Fit for Service';
            else if (rulPctNum >= 25) autoStatus = 'Degrading Stage';
            else if (rulPctNum >= 10) autoStatus = 'Approaching Replacement';
            else if (rulPctNum > 0) autoStatus = 'Reaching End-of-Life';
            else autoStatus = 'End-of-Life';
          }
          const statusVal = r.lifeCycleStatus || autoStatus;

          return {
            ...r,
            sNo: idx + 1,
            ageYrs: age || '-',
            healthIndex: hi || '-',
            adjustedLifeAL: al || '-',
            rulYrs: rulYrs || '-',
            rulPct: rulPct ? `${rulPct}%` : '-',
            lifeCycleStatus: statusVal || '-',
            remarksRul: r.remarksRul || ''
          };
        }
      );

      reportContext.rulRows = (readings.rulRows || []).map(
        (r: any, idx: number) => {
          const designLife = r.designLifeYrs || '';
          const age = r.ageYrs || '';
          const ageNum = Number(age) || 0;

          const hi = r.healthIndex || '';
          const hiNum = Number(hi) || 0;

          const uf = r.utilizationFactor || '';
          const ufNum = Number(uf) || 1;

          // Calculate Adjusted Life: Design Life (yrs) * Health Index (HI) * Utilization Factor (UF)
          const dlNum = Number(designLife) || 0;
          const computedAL = (dlNum > 0 && hiNum > 0) 
            ? ((dlNum * hiNum) * ufNum).toFixed(1) 
            : '';
          const al = computedAL;
          const alNum = Number(al) || 0;

          // Calculate RUL (yrs): AL - Age
          const computedRulYrs = (alNum > 0) 
            ? (alNum - ageNum).toFixed(1) 
            : '';
          const rulYrs = computedRulYrs;
          const rulYrsNum = Number(rulYrs) || 0;

          // Calculate RUL (%): (RUL (yrs) / Adjusted Life (AL)) * 100
          const computedRulPct = (alNum > 0) 
            ? ((rulYrsNum / alNum) * 100).toFixed(1) 
            : '';
          const rulPct = computedRulPct;
          const rulPctNum = Number(rulPct) || 0;

          // Determine Life Cycle Status automatically
          let autoStatus = '';
          if (alNum > 0) {
            if (rulPctNum > 50) {
              autoStatus = 'Fit for Service';
            } else if (rulPctNum >= 25) {
              autoStatus = 'Degrading Stage';
            } else if (rulPctNum >= 10) {
              autoStatus = 'Approaching Replacement';
            } else if (rulPctNum > 0) {
              autoStatus = 'Reaching End-of-Life';
            } else {
              autoStatus = 'End-of-Life';
            }
          }
          const statusStr = r.lifeCycleStatus !== '' && r.lifeCycleStatus !== undefined ? r.lifeCycleStatus : autoStatus;

          return {
            ...r,
            sNo: idx + 1,
            designLifeYrs: designLife || '-',
            ageYrs: age || '-',
            healthIndex: hi || '-',
            utilizationFactor: uf || '1.0',
            adjustedLifeAL: al || '-',
            rulYrs: rulYrs || '-',
            rulPct: rulPct ? `${rulPct}%` : '-',
            lifeCycleStatus: statusStr || '-',
            remarksRul: r.remarksRul || ''
          };
        }
      );
    }

    if (testNameLower.includes("earth station") || testNameLower.includes("earth continuity")) {
      reportContext.equipmentList = (readings.equipmentList || []).map(
        (r: any, idx: number) => ({
          ...r,
          sNo: idx + 1,
        }),
      );
      reportContext.readings = (readings.readings || []).map(
        (r: any, idx: number) => {
          let bgColor = "";
          if (r.remarks === 'ok' || r.remarks === 'OK' || r.remarks === 'Ok') {
             bgColor = "198754";
          } else if (r.remarks?.toLowerCase()?.includes('high') || r.remarks?.toLowerCase()?.includes('fail')) {
             bgColor = "DC2626";
          }
          const fillAttr = bgColor ? `<w:shd w:val="clear" w:color="auto" w:fill="${bgColor}"/>` : "";
          const colorAttr = bgColor ? `<w:color w:val="FFFFFF"/>` : "";
          const boldAttr = bgColor ? `<w:b/>` : "";
          const remarks_xml = `<w:p><w:pPr><w:jc w:val="center"/>${fillAttr}</w:pPr><w:r><w:rPr>${boldAttr}${colorAttr}</w:rPr><w:t>${r.remarks || ""}</w:t></w:r></w:p>`;

          return {
            ...r,
            sNo: idx + 1,
            remarks_xml,
          };
        }
      );
    }

    if (testNameLower.includes("lightning") || testNameLower.includes("arrestor")) {
      reportContext.equipmentList = (readings.equipmentList || []).map(
        (r: any, idx: number) => ({
          ...r,
          sNo: idx + 1,
        }),
      );
      reportContext.laReadings = (readings.laReadings || []).map(
        (r: any, idx: number) => ({
          ...r,
          sNo: idx + 1,
          result_xml: getStatusXml(r.result)
        }),
      );
    }

    // Specialized Logic for DG Endurance
    if (testNameLower.includes("dg endurance")) {
      reportContext.OnSiteTests = (readings.onSiteTests || []).map((t: any) => ({
        ...t,
        result: t.result ? "PASS" : "FAIL",
      }));

      // Explicitly map DGUnits to ensure nested loops work
      reportContext.DGUnits = (readings.dgUnits || []).map((unit: any) => ({
        ...unit,
        loadReadings: unit.loadReadings || [],
        transientSummary: unit.transientSummary || [],
        noiseLevels: unit.noiseLevels || [],
        vibrationLevels: unit.vibrationLevels || [],
        fuelSummary: unit.fuelSummary || [],
      }));
    }

    if (testNameLower.includes("elv gap")) {
      reportContext.elvSystems = Object.entries(readings.systems || {}).map(
        ([name, rows]) => ({
          systemName: name,
          ReadingRow: rows,
        }),
      );

      const summary: any[] = [];
      let counter = 1;
      Object.entries(readings.systems || {}).forEach(
        ([systemName, rows]: [string, any]) => {
          rows.forEach((row: any) => {
            if (row.result === "No") {
              summary.push({
                sNo: counter++,
                infrastructure: systemName,
                compliance: "No",
                remarks: row.remarks,
                correctiveActions: row.correctiveActions,
              });
            }
          });
        },
      );
      reportContext.complianceSummary = summary;
      reportContext.gapAnalysisRows = readings.gapAnalysisRows || [];
    }

    if (testNameLower.includes("battery")) {
      reportContext.UpsHierarchy = (readings.upsSystems || []).map((ups: any) => ({
        ...ups,
        strings: (ups.strings || []).map((str: any) => ({
          ...str,
          ReadingRow: (str.readings || []).map((r: any) => ({
            ...r,
            remarks: getStatusXml(r.remarks),
          })),
        })),
      }));

      // Summarize problematic readings (FAIL/WARN)
      reportContext.ProblematicReadings = (readings.upsSystems || []).flatMap(
        (u: any) =>
          (u.strings || []).flatMap((s: any) =>
            (s.readings || [])
              .filter(
                (r: any) =>
                  r.remarks !== "PASS" && r.remarks !== "..." && r.remarks !== "",
              )
              .map((r: any) => ({
                ...r,
                upsName: u.name,
                strName: s.name,
                remarks: getStatusXml(r.remarks),
              })),
          ),
      );
    }

    // Specialized Logic for RCI Aggregation
    if (testNameLower.includes("rack cooling index")) {
      const processCacGroups = (groups: any[]) => {
        return (groups || []).map((group) => ({
          ...group,
          temperatureRows: (group.temperatureRows || []).map(
            (r: any, idx: number) => {
              const f15 = n(r.front15U);
              const f22 = n(r.front22U);
              const f35 = n(r.front35U);
              const r15 = n(r.rear15U);
              const r22 = n(r.rear22U);
              const r35 = n(r.rear35U);

              const getAvg = (v1: number, v2: number, v3: number) => {
                const vals = [v1, v2, v3].filter((v) => v !== 0);
                if (vals.length === 0) return 0;
                return vals.reduce((a, b) => a + b, 0) / vals.length;
              };

              const fAvg = getAvg(f15, f22, f35);
              const rAvg = getAvg(r15, r22, r35);
              const delta = Math.abs(rAvg - fAvg);

              let inletResult = "";
              let inletColorClass = "1E3A8A"; // blue-900 approx
              let excessInletTempCalc = "";
              let deficitInletTempCalc = "";

              if (fAvg > 0) { // Assuming 0 means not filled if we filter above
                if (fAvg >= 18 && fAvg <= 27) {
                  inletResult = "PASS";
                  inletColorClass = "22C55E"; // green-500
                } else if (fAvg < 18) {
                  inletResult = "FAIL";
                  inletColorClass = "F97316"; // orange-500
                  deficitInletTempCalc = (18 - fAvg).toFixed(2);
                } else if (fAvg > 27) {
                  inletResult = "FAIL";
                  inletColorClass = "DC2626"; // red-600
                  excessInletTempCalc = (fAvg - 27).toFixed(2);
                }
              }

              const getInletResultXml = (res: string, hex: string) => {
                if (!res) return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="22"/></w:rPr><w:t>-</w:t></w:r></w:p>`;
                return `<w:p><w:pPr><w:jc w:val="center"/><w:shd w:val="clear" w:color="auto" w:fill="${hex}"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/><w:sz w:val="22"/></w:rPr><w:t>${res}</w:t></w:r></w:p>`;
              };

              const getExcessDeficitXml = (val: string, colorHex: string, bgHex: string) => {
                if (!val) return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:color w:val="94A3B8"/><w:sz w:val="22"/></w:rPr><w:t>-</w:t></w:r></w:p>`;
                return `<w:p><w:pPr><w:jc w:val="center"/><w:shd w:val="clear" w:color="auto" w:fill="${bgHex}"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="${colorHex}"/><w:sz w:val="22"/></w:rPr><w:t>${val}</w:t></w:r></w:p>`;
              };

              return {
                ...r,
                sNo: r.sNo ? r.sNo : (idx + 1).toString(),
                frontAvg: fAvg ? fAvg.toFixed(2) : "-",
                rearAvg: rAvg ? rAvg.toFixed(2) : "-",
                deltaT: delta ? delta.toFixed(2) : "-",
                deltaT_xml: delta > 0 ? getDeltaTXml(delta) : "-",
                inletResult_xml: getInletResultXml(inletResult, inletColorClass),
                excessInletTemp_xml: getExcessDeficitXml(excessInletTempCalc, "DC2626", "FEF2F2"),
                deficitInletTemp_xml: getExcessDeficitXml(deficitInletTempCalc, "EA580C", "FFF7ED")
              };
            },
          ),
        }));
      };

      const allGroups = processCacGroups(readings.dc1Groups);
      reportContext.dc1Groups = allGroups;

      const allRows = allGroups.flatMap(g => g.temperatureRows);
      let sumExcess = 0;
      let sumDeficit = 0;
      let countAbove27 = 0;
      let countBelow18 = 0;
      let countAbove15Delta = 0;
      let countBelow5Delta = 0;
      let activeMeasurements = 0;

      allRows.forEach(row => {
          if (row.frontAvg && row.frontAvg !== "-") {
              activeMeasurements++;
              const temp = parseFloat(row.frontAvg);
              if (temp > 27) {
                  sumExcess += (temp - 27);
                  countAbove27++;
              } else if (temp < 18) {
                  sumDeficit += (18 - temp);
                  countBelow18++;
              }
          }
          if (row.frontAvg && row.frontAvg !== "-" && row.rearAvg && row.rearAvg !== "-") {
              const delta = Math.abs(parseFloat(row.rearAvg) - parseFloat(row.frontAvg));
              if (delta > 15) {
                  countAbove15Delta++;
              } else if (delta < 5) {
                  countBelow5Delta++;
              }
          }
      });

      const N = activeMeasurements || 1;
      const rciHi = (1 - (sumExcess / (N * 5))) * 100;
      const rciLo = (1 - (sumDeficit / (N * 3))) * 100;
      const overallRci = (rciHi + rciLo) / 2;

      const getRciRating = (val: number) => {
        if (val === 100) return "Excellent";
        if (val >= 96) return "Good";
        if (val >= 91) return "Fair";
        return "Poor";
      };

      reportContext.rciTable1 = [
          { parameter: "Total No. of Racks (N)", result: activeMeasurements.toString() },
          { parameter: "Summation of excess temperature (Ti − Tr, Hi)", result: sumExcess.toFixed(2) },
          { parameter: "No. of Racks above 27 deg C (Nhi)", result: countAbove27.toString() },
          { parameter: "Summation of deficit temperature (Tr, Lo − Ti)", result: sumDeficit.toFixed(2) },
          { parameter: "No. of Racks below 18 deg C (Nlo)", result: countBelow18.toString() },
          { parameter: "No. of Racks above 15 deg C Delta T", result: countAbove15Delta.toString() },
          { parameter: "No. of Racks below 5 deg C Delta T", result: countBelow5Delta.toString() }
      ];

      reportContext.rciTable2 = [
          { parameter: "RCI Hi — High Side (Over-Temperature)", result: `${rciHi.toFixed(1)}%`, rating: getRciRating(rciHi) },
          { parameter: "RCI Lo — Low Side (Under-Temperature)", result: `${rciLo.toFixed(1)}%`, rating: getRciRating(rciLo) },
          { parameter: "Overall RCI ((RCI Hi + RCI Lo)/2)", result: `${overallRci.toFixed(1)}%`, rating: getRciRating(overallRci) }
      ];

      reportContext.toolCalibrationDate = readings.toolCalibrationDate || "-";
      reportContext.toolExpiryDate = readings.toolExpiryDate || "-";
    }

    // Specialized Logic for Coupon Test Subheadings
    if (
      testNameLower.includes("coupon test") ||
      testNameLower.includes("corrosion")
    ) {
      reportContext.LocationBlock = (readings.locations || []).map(
        (loc: any, idx: number) => ({
          ...loc,
          tableSubheading: `8.${idx * 2 + 1} Corrosion film thickness`,
          graphSubheading: `8.${idx * 2 + 2} Graphical Representation of corrosion film thickness`,
          results: (loc.results || []).map((res: any) => {
            const val = res.totalAngstroms !== undefined && res.totalAngstroms !== null ? Number(res.totalAngstroms).toFixed(2) : "0.00";
            const xml = `<w:p><w:pPr><w:jc w:val="center"/><w:shd w:val="clear" w:color="auto" w:fill="ECFDF5"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="059669"/></w:rPr><w:t>${val}</w:t></w:r></w:p>`;
            return {
              ...res,
              totalAngstroms_xml: xml
            };
          })
        }),
      );
    }

    // Specialized Logic for CFM Aggregation
    if (testNameLower.includes("cfm") || testNameLower.includes("airflow")) {
      const calculateReqCFM = (watts: any, deltaT: any, multiplier: any) => {
        const w = n(watts);
        const dt = n(deltaT);
        const m = n(multiplier) || 1;
        if (w === 0 || dt === 0) return 0;
        return (w * 3.412969 * m) / (1.8 * 1.08 * dt);
      };

      // 1. Process CAC Tables
      const cacTables = (readings.cacTables || []).map((cac: any) => {
        const processRows = (rows: any[]) =>
          (rows || []).map((r) => {
            const req = calculateReqCFM(r.loadW, readings.deltaT || cac.deltaT, readings.multiplier || cac.multiplier);
            const deficit = Math.round(n(r.actualCFM) - req);
            return {
              ...r,
              reqCFM: Math.round(req).toString(),
              deficit: deficit.toString(),
              deficit_xml: getDeficitXml(deficit),
            };
          });

        const left = processRows(cac.leftRows);
        const right = processRows(cac.rightRows);

        const previewRows = [];
        const pairedRows = [];
        const maxLen = Math.max(left.length, right.length);
        for (let i = 0; i < maxLen; i++) {
          if (left[i])
            previewRows.push({ grill: `${cac.cacName}-L${i + 1}`, ...left[i] });
          if (right[i])
            previewRows.push({
              grill: `${cac.cacName}-R${i + 1}`,
              ...right[i],
            });
          pairedRows.push({
            sNo: (i + 1).toString(),
            l_ref: left[i]?.rackRef || "",
            l_load: left[i]?.loadW || "0",
            l_act: left[i]?.actualCFM || "0",
            l_req: left[i]?.reqCFM || "0",
            l_def: left[i]?.deficit || "0",
            l_def_xml: left[i]?.deficit_xml || "",
            r_ref: right[i]?.rackRef || "",
            r_load: right[i]?.loadW || "0",
            r_act: right[i]?.actualCFM || "0",
            r_req: right[i]?.reqCFM || "0",
            r_def: right[i]?.deficit || "0",
            r_def_xml: right[i]?.deficit_xml || "",
          });
        }

        const val_l_load = Math.round(left.reduce((s, r) => s + n(r.loadW), 0));
        const val_l_act = Math.round(left.reduce((s, r) => s + n(r.actualCFM), 0));
        const val_l_req = Math.round(left.reduce((s, r) => s + n(r.reqCFM), 0));
        const val_l_def = val_l_act - val_l_req;

        const val_r_load = Math.round(right.reduce((s, r) => s + n(r.loadW), 0));
        const val_r_act = Math.round(right.reduce((s, r) => s + n(r.actualCFM), 0));
        const val_r_req = Math.round(right.reduce((s, r) => s + n(r.reqCFM), 0));
        const val_r_def = val_r_act - val_r_req;

        const sub_l_load = val_l_load.toFixed(0);
        const sub_l_act = val_l_act.toFixed(0);
        const sub_l_req = val_l_req.toFixed(0);
        const sub_l_def = val_l_def;

        const sub_r_load = val_r_load.toFixed(0);
        const sub_r_act = val_r_act.toFixed(0);
        const sub_r_req = val_r_req.toFixed(0);
        const sub_r_def = val_r_def;

        return {
          ...cac,
          deltaT: readings.deltaT || cac.deltaT || "13",
          multiplier: readings.multiplier || cac.multiplier || "1",
          envelopePercent: Math.round((n(readings.multiplier || cac.multiplier || "1") - 1) * 100).toString(),
          leftRows: left,
          rightRows: right,
          previewRows,
          pairedRows,
          sub_l_load,
          sub_l_load_xml: getSubtotalXml(sub_l_load),
          sub_l_act,
          sub_l_act_xml: getSubtotalXml(sub_l_act),
          sub_l_req,
          sub_l_req_xml: getSubtotalXml(sub_l_req),
          sub_l_def: sub_l_def.toString(),
          sub_l_def_xml: getSubtotalDeficitXml(sub_l_def),
          sub_r_load,
          sub_r_load_xml: getSubtotalXml(sub_r_load),
          sub_r_act,
          sub_r_act_xml: getSubtotalXml(sub_r_act),
          sub_r_req,
          sub_r_req_xml: getSubtotalXml(sub_r_req),
          sub_r_def: sub_r_def.toString(),
          sub_r_def_xml: getSubtotalDeficitXml(sub_r_def),
          unit_load: (val_l_load + val_r_load).toFixed(0),
          unit_act: (val_l_act + val_r_act).toFixed(0),
          unit_req: (val_l_req + val_r_req).toFixed(0),
          unit_def: (val_l_def + val_r_def).toFixed(0),
          unit_def_xml: getSubtotalDeficitXml(val_l_def + val_r_def),
        };
      });
      reportContext.cacTables = cacTables;

      // 2. Summary Analysis Rows
      const unitSummaries = cacTables.map((cac) => {
        const totalW =
          cac.leftRows.reduce((sum: number, r: any) => sum + n(r.loadW), 0) +
          cac.rightRows.reduce((sum: number, r: any) => sum + n(r.loadW), 0);
        const totalReq =
          cac.leftRows.reduce((sum: number, r: any) => sum + n(r.reqCFM), 0) +
          cac.rightRows.reduce((sum: number, r: any) => sum + n(r.reqCFM), 0);
        const totalAct =
          cac.leftRows.reduce((sum: number, r: any) => sum + n(r.actualCFM), 0) +
          cac.rightRows.reduce((sum: number, r: any) => sum + n(r.actualCFM), 0);
        return {
          kw: totalW / 1000,
          tr: totalW / 3517,
          req: totalReq,
          act: totalAct,
          def: totalAct - totalReq,
        };
      });

      const totals = unitSummaries.reduce(
        (acc, curr) => ({
          kw: acc.kw + curr.kw,
          tr: acc.tr + curr.tr,
          req: acc.req + curr.req,
          act: acc.act + curr.act,
          def: acc.def + curr.def,
        }),
        { kw: 0, tr: 0, req: 0, act: 0, def: 0 },
      );

      const summaryRows = unitSummaries.map((s, i) => ({
        category: `CAC-${(i + 1).toString().padStart(2, "0")}`,
        value: s.kw.toFixed(2),
        rackTR: s.tr.toFixed(2),
        unit: "kW",
        reqCFM: f(s.req),
        availCFM: f(s.act),
        deficit: f(s.def),
        deficit_xml: getDeficitXml(s.def),
      }));

      reportContext.summaryAnalysisRows = summaryRows;

      // 3. High-Level Summary Rows
      const pahuAvailable = readings.importedPahuCfm ? parseFloat(readings.importedPahuCfm) : totals.act;
      const pacAvailable = readings.importedPacCfm ? parseFloat(readings.importedPacCfm) : totals.act;

      reportContext.airflowSummaryRows = [
        {
          label: "Supply Airflow for DC Hall (Grills)",
          measured: Math.round(totals.act).toFixed(0),
          measured_xml: getMeasuredCfmXml(totals.act, totals.req),
          required: Math.round(totals.req).toFixed(0),
          deficit: Math.round(totals.act - totals.req).toFixed(0),
          deficit_xml: getSubtotalDeficitXml(totals.act - totals.req)
        },
        {
          label: "Return Airflow for DC Hall",
          measured: Math.round(pahuAvailable + pacAvailable).toFixed(0),
          measured_xml: getMeasuredCfmXml(pahuAvailable + pacAvailable, totals.req),
          required: Math.round(totals.req).toFixed(0),
          deficit: Math.round((pahuAvailable + pacAvailable) - totals.req).toFixed(0),
          deficit_xml: getSubtotalDeficitXml((pahuAvailable + pacAvailable) - totals.req)
        }
      ];

      const multiplier = n(readings.multiplier || "1");
      const pahuAvailableTr = readings.importedPahuTr ? parseFloat(readings.importedPahuTr) : (totals.tr * 1.07877);
      const pacAvailableTr = readings.importedPacTr ? parseFloat(readings.importedPacTr) : (totals.tr * 0.66579);

      const loadRows = [
        { label: "Total Rack Load", value: totals.kw.toFixed(2), unit: "kW" },
        { label: "Total Rack TR", value: totals.tr.toFixed(2), unit: "TR" },
        { label: `Adding Room Load of ${Math.round((multiplier - 1) * 100)}%`, value: (totals.tr * multiplier).toFixed(2), unit: "TR" }
      ];
      if (pahuAvailableTr !== 0 && pahuAvailableTr.toFixed(2) !== "0.00") {
        loadRows.push({ label: "Total TR Measured for PAHU", value: pahuAvailableTr.toFixed(2), unit: "TR" });
      }
      if (pacAvailableTr !== 0 && pacAvailableTr.toFixed(2) !== "0.00") {
        loadRows.push({ label: "Total TR Measured for PAC", value: pacAvailableTr.toFixed(2), unit: "TR" });
      }
      reportContext.loadSummaryRows = loadRows;

      reportContext.totalKW = totals.kw.toFixed(2);
      reportContext.totalTR = totals.tr.toFixed(2);
      reportContext.totalDesignCFM = Math.round(totals.req).toFixed(0);
      reportContext.totalActualCFM = Math.round(totals.act).toFixed(0);
      reportContext.totalDeficit = Math.round(totals.act - totals.req).toFixed(0);
      reportContext.totalDeficit_xml = getSubtotalDeficitXml(totals.act - totals.req);
      reportContext.deltaT = readings.deltaT || "13";
      reportContext.multiplier = multiplier.toString();
      reportContext.envelopePercent = Math.round((multiplier - 1) * 100).toString();

      reportContext.airflowUnits = [];
      reportContext.ToolsTable = readings?.toolsUsed || [];
      reportContext.ToolTable = readings?.toolsUsed || [];
    }

    // Specialized Logic for Capacity Assessment
    if (testNameLower.includes("capacity assessment")) {
      const calcTR = (cfm: string, ra: string, sa: string) => {
        const cfmVal = parseFloat(cfm);
        const raVal = parseFloat(ra);
        const saVal = parseFloat(sa);
        if (isNaN(cfmVal) || isNaN(raVal) || isNaN(saVal)) return 0;
        return (1.06 * cfmVal * (raVal - saVal) * 1.8) / 12000;
      };
      const calcCop = (tra: number, kw: string) => {
        const kwVal = parseFloat(kw);
        if (isNaN(tra) || isNaN(kwVal) || kwVal === 0) return 0;
        return (tra * 3.517) / kwVal;
      };

      reportContext.PahuCapacityTable = (readings.pahuTables || []).flatMap(
        (t: any) =>
          (t.entries || []).map((e: any, idx: number) => {
            const d_tra = calcTR(e.designAirflow, e.designRaTemp, e.designSaTemp);
            const m_tra = calcTR(
              e.measuredAirflow,
              e.measuredRaTemp,
              e.measuredSaTemp,
            );
            const gpmVal = parseFloat(e.measuredWaterFlowRate) || 0;
            const inVal = parseFloat(e.measuredChwIn) || 0;
            const outVal = parseFloat(e.measuredChwOut) || 0;
            const deltaC = Math.abs(outVal - inVal);
            const waterTr = (gpmVal * deltaC * 1.8) / 24;

            return {
              ...e,
              sNo: (idx + 1).toString(),
              equipmentId: e.equipmentId || "---",
              modelNo: e.modelNo || "---",
              serialNo: e.serialNo || "---",
              designAirflow: e.designAirflow || "---",
              designRaTemp: e.designRaTemp || "---",
              designSaTemp: e.designSaTemp || "---",
              designPower: e.designPower || "---",
              designWaterFlowRate: e.designWaterFlowRate || "---",
              d_tra: getColorXml(d_tra.toFixed(2), 'blue'),
              measuredAirflow: e.measuredAirflow || "---",
              measuredSaTemp: e.measuredSaTemp || "---",
              measuredRaTemp: e.measuredRaTemp || "---",
              measuredFanSpeed: e.measuredFanSpeed || "---",
              m_tra: getColorXml(m_tra.toFixed(2), 'blue'),
              measuredPower: e.measuredPower || "---",
              measuredChwIn: e.measuredChwIn || "---",
              measuredChwOut: e.measuredChwOut || "---",
              measuredValveOpening: e.measuredValveOpening || "---",
              measuredWaterFlowRate: e.measuredWaterFlowRate || "---",
              measuredWaterCoolingTonnage_xml: getColorXml(waterTr.toFixed(2), 'green'),
            };
          }),
      );

      reportContext.PacCapacityTable = (readings.pacTables || []).flatMap(
        (t: any) =>
          (t.entries || []).map((e: any, idx: number) => {
            const d_tra = calcTR(e.designAirflow, e.designRaTemp, e.designSaTemp);
            const m_tra = calcTR(
              e.measuredAirflow,
              e.measuredRaTemp,
              e.measuredSaTemp,
            );
            const cop = calcCop(m_tra, e.measuredPower);
            return {
              ...e,
              sNo: (idx + 1).toString(),
              equipmentId: e.equipmentId || "---",
              modelNo: e.modelNo || "---",
              serialNo: e.serialNo || "---",
              designAirflow: e.designAirflow || "---",
              designRaTemp: e.designRaTemp || "---",
              designSaTemp: e.designSaTemp || "---",
              designPower: e.designPower || "---",
              d_tra: getColorXml(d_tra.toFixed(2), 'blue'),
              fanSpeed: e.fanSpeed || "---",
              measuredAirflow: e.measuredAirflow || "---",
              measuredRaTemp: e.measuredRaTemp || "---",
              measuredSaTemp: e.measuredSaTemp || "---",
              m_tra: getColorXml(m_tra.toFixed(2), 'blue'),
              measuredPower: e.measuredPower || "---",
              cop: getColorXml(cop.toFixed(2), 'green'),
            };
          }),
      );
    }

    // Specialized Logic for Power Quality Flattening
    if (testNameLower.includes("power quality")) {
      reportContext.ag = (readings.analysisGroups || []).map((g: any) => ({
        title: g.title,
        type: g.type,
        dateFrom: g.dateFrom || "-",
        dateTo: g.dateTo || "-",
        f_avg: g.frequency?.average || "-",
        f_lim: g.frequency?.limits || "-",
        f_rem: getStatusXml(g.frequency?.remark || "-"),
        f_img: g.frequency?.imageUrl || "",
        v_ry: g.voltage?.ry || "",
        v_rn: g.voltage?.rn
          ? g.voltage?.ry
            ? `/${g.voltage.rn}`
            : g.voltage.rn
          : !g.voltage?.ry
            ? "-"
            : "",
        v_yb: g.voltage?.yb || "",
        v_yn: g.voltage?.yn
          ? g.voltage?.yb
            ? `/${g.voltage.yn}`
            : g.voltage.yn
          : !g.voltage?.yb
            ? "-"
            : "",
        v_br: g.voltage?.br || "",
        v_bn: g.voltage?.bn
          ? g.voltage?.br
            ? `/${g.voltage.bn}`
            : g.voltage.bn
          : !g.voltage?.br
            ? "-"
            : "",
        v_lim: g.voltage?.limits || "-",
        v_rem: getStatusXml(g.voltage?.remark || "-"),
        v_img: g.voltage?.imageUrl || "",
        c_r: g.current?.r || "-",
        c_y: g.current?.y || "-",
        c_b: g.current?.b || "-",
        c_note: g.current?.note || "-",
        c_img: g.current?.imageUrl || "",
        p_avg: g.activePower?.average || "-",
        p_rem: getStatusXml(g.activePower?.remark || "-"),
        p_img: g.activePower?.imageUrl || "",
        ap_avg: g.apparentPower?.average || "-",
        ap_rem: getStatusXml(g.apparentPower?.remark || "-"),
        ap_img: g.apparentPower?.imageUrl || "",
        rp_avg: g.reactivePower?.average || "-",
        rp_rem: getStatusXml(g.reactivePower?.remark || "-"),
        rp_img: g.reactivePower?.imageUrl || "",
        pf_avg: g.powerFactor?.average || "-",
        pf_lim: g.powerFactor?.limits || "-",
        pf_rem: getStatusXml(g.powerFactor?.remark || "-"),
        pf_img: g.powerFactor?.imageUrl || "",
        // THDv Detailed
        dv_max_r: g.thdv?.r?.max || "-",
        dv_min_r: g.thdv?.r?.min || "-",
        dv_avg_r: g.thdv?.r?.avg || "-",
        dv_max_y: g.thdv?.y?.max || "-",
        dv_min_y: g.thdv?.y?.min || "-",
        dv_avg_y: g.thdv?.y?.avg || "-",
        dv_max_b: g.thdv?.b?.max || "-",
        dv_min_b: g.thdv?.b?.min || "-",
        dv_avg_b: g.thdv?.b?.avg || "-",
        dv_lim: g.thdv?.limits || "-",
        dv_rem: getStatusXml(g.thdv?.remark || "-"),
        dv_img: g.thdv?.imageUrl || "",
        // THDi Detailed
        di_max_r: g.thdi?.r?.max || "-",
        di_min_r: g.thdi?.r?.min || "-",
        di_avg_r: g.thdi?.r?.avg || "-",
        di_max_y: g.thdi?.y?.max || "-",
        di_min_y: g.thdi?.y?.min || "-",
        di_avg_y: g.thdi?.y?.avg || "-",
        di_max_b: g.thdi?.b?.max || "-",
        di_min_b: g.thdi?.b?.min || "-",
        di_avg_b: g.thdi?.b?.avg || "-",
        di_lim: g.thdi?.limits || "-",
        di_rem: getStatusXml(g.thdi?.remark || "-"),
        di_img: g.thdi?.imageUrl || "",
        // Unbalance
        uv_avg: g.voltageUnbalance?.average || "-",
        uv_lim: g.voltageUnbalance?.limits || "-",
        uv_rem: getStatusXml(g.voltageUnbalance?.remark || "-"),
        uv_img: g.voltageUnbalance?.imageUrl || "",
        uc_avg: g.currentUnbalance?.average || "-",
        uc_lim: g.currentUnbalance?.limits || "-",
        uc_rem: getStatusXml(g.currentUnbalance?.remark || "-"),
        uc_img: g.currentUnbalance?.imageUrl || "",
        // Compatibility
        dv_r: g.thdv?.r?.avg || "-",
        dv_y: g.thdv?.y?.avg || "-",
        dv_b: g.thdv?.b?.avg || "-",
        di_r: g.thdi?.r?.avg || "-",
        di_y: g.thdi?.y?.avg || "-",
        di_b: g.thdi?.b?.avg || "-",
      }));
    }

    return reportContext;
  },

  mergeProjectReports: async (projectId: string, onProgress?: (p: number) => void): Promise<string> => {
    if (onProgress) onProgress(5);
    const assignmentsQ = query(
      collection(db, COLLECTIONS.ASSIGNMENTS),
      where("projectId", "==", projectId),
      where("workflowStatus", "==", WorkflowStatus.APPROVED),
    );
    const assignmentsSnap = await getDocs(assignmentsQ);
    const approvedAssignments = assignmentsSnap.docs.map(
      (d) => ({ ...d.data(), id: d.id }) as TestAssignment,
    );

    if (approvedAssignments.length === 0) {
      throw new Error("No approved tests found for this project.");
    }

    if (onProgress) onProgress(10);

    const projDoc = await getDoc(doc(db, COLLECTIONS.PROJECTS, projectId));
    const proj = projDoc.exists() ? (projDoc.data() as Project) : null;

    const reportSections: any[] = [];
    const templateCache: Record<string, ArrayBuffer> = {};
    const testDefCache: Record<string, TestDefinition> = {};

    let processed = 0;
    for (const assignment of approvedAssignments) {
      let testDef: TestDefinition | null = null;
      const defId = assignment.testDefinitionId!;
      
      if (testDefCache[defId]) {
        testDef = testDefCache[defId];
      } else {
        const defDoc = await getDoc(doc(db, COLLECTIONS.DEFINITIONS, defId));
        testDef = defDoc.exists() ? (defDoc.data() as TestDefinition) : null;
        if (testDef) testDefCache[defId] = testDef;
      }

      if (!testDef?.linkedTemplate?.storagePath) {
        processed++;
        continue;
      }

      const reportContext = ExecutionService.prepareReportContext(
        assignment,
        testDef,
        proj,
        assignment.id,
      );

      // Fetch template content with caching
      let templateContent: ArrayBuffer;
      const tmpl = testDef.linkedTemplate!;
      const path = tmpl.storagePath;

      if (templateCache[path]) {
        templateContent = templateCache[path];
      } else {
        try {
          // Use getBlob for more reliable download
          const blob = await getBlob(ref(storage, path));
          templateContent = await blob.arrayBuffer();
          templateCache[path] = templateContent;
        } catch (fetchErr: any) {
          console.error(`Failed to fetch template ${path}:`, fetchErr);
          processed++;
          continue;
        }
      }

      reportSections.push({
        template: templateContent,
        context: reportContext,
      });

      processed++;
      if (onProgress) {
        // Fetching is 10% to 50%
        const fetchProgress = 10 + (processed / approvedAssignments.length) * 40;
        onProgress(Math.round(fetchProgress));
      }
    }

    if (reportSections.length === 0) {
      throw new Error("Could not generate any report sections.");
    }

    if (onProgress) onProgress(55);

    // Use TemplateGeneratorService to merge
    const mergedBlob = await TemplateGeneratorService.mergeReports(reportSections);
    
    if (onProgress) onProgress(70);

    // Upload the merged report to Firebase Storage using resumable upload (chunked)
    // This helps with stability for large files and avoids local URL limits
    const timestamp = Date.now();
    const fileName = `merged_report_${projectId}_${timestamp}.docx`;
    const storagePath = `reports/merged/${projectId}/${fileName}`;
    const storageRef = ref(storage, storagePath);
    
    const uploadTask = uploadBytesResumable(storageRef, mergedBlob, {
      contentType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    });

    return new Promise((resolve, reject) => {
      uploadTask.on('state_changed', 
        (snapshot) => {
          const uploadProgress = (snapshot.bytesTransferred / snapshot.totalBytes) * 30;
          if (onProgress) onProgress(Math.round(70 + uploadProgress));
        }, 
        (error) => {
          console.error("Upload failed:", error);
          reject(error);
        }, 
        async () => {
          if (onProgress) onProgress(100);
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          resolve(downloadUrl);
        }
      );
    });
  },

  generateReport: async (
    assignmentId: string,
    overrideData?: any,
    overrideTestDef?: TestDefinition,
    isDraft?: boolean
  ): Promise<string> => {
    let data: Partial<TestAssignment> = {};
    let testDef: TestDefinition | null = null;
    let proj: Project | null = null;

    if (assignmentId === "PREVIEW_ID" && overrideData && overrideTestDef) {
      data = {
        testName: overrideTestDef.name,
        readings: overrideData,
        aiInsight: overrideData.aiInsight || "Preview AI Content",
      };
      testDef = overrideTestDef;
    } else {
      const assignmentDoc = await getDoc(
        doc(db, COLLECTIONS.ASSIGNMENTS, assignmentId),
      );
      if (!assignmentDoc.exists())
        throw new Error("Assignment record not found in cloud database.");
      data = assignmentDoc.data() as TestAssignment;

      if (
        assignmentId !== "PREVIEW_ID" &&
        data.workflowStatus !== WorkflowStatus.APPROVED &&
        !isDraft
      ) {
        throw new Error(
          "REPORT LOCKED: This protocol must be 'APPROVED' by a Project Manager before final report generation is permitted.",
        );
      }

      const [defDoc, projDoc] = await Promise.all([
        getDoc(doc(db, COLLECTIONS.DEFINITIONS, data.testDefinitionId!)),
        getDoc(doc(db, COLLECTIONS.PROJECTS, data.projectId!)),
      ]);
      testDef = defDoc.exists() ? (defDoc.data() as TestDefinition) : null;
      proj = projDoc.exists() ? (projDoc.data() as Project) : null;
    }

    if (!testDef?.linkedTemplate?.storagePath) {
      throw new Error(
        `MISSING TEMPLATE: The protocol "${data.testName}" does not have an uploaded Word template (.docx). Please upload one in the Test Library.`,
      );
    }

    const reportContext = ExecutionService.prepareReportContext(data, testDef, proj, assignmentId);

    try {
      let content: ArrayBuffer;
      const tmpl = testDef.linkedTemplate!;

      try {
        const downloadUrl =
          tmpl.downloadUrl ||
          (await getDownloadURL(ref(storage, tmpl.storagePath)));
        const resp = await fetch(downloadUrl, {
          mode: "cors",
          referrerPolicy: "no-referrer",
        });
        if (!resp.ok) throw new Error("CORS_FETCH_DENIED");
        content = await resp.arrayBuffer();
      } catch (fetchErr: any) {
        const blob = await getBlob(ref(storage, tmpl.storagePath));
        content = await blob.arrayBuffer();
      }

      const imageOptions = {
        centered: false,
        getImage: (tagValue: string) => {
          const actualValue = tagValue ? tagValue.split('|')[0] : "";
          if (!actualValue || !actualValue.startsWith("data:image")) {
            // Return a 1x1 transparent pixel to prevent docxtemplater errors
            return Buffer.from(
              "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
              "base64",
            );
          }
          try {
            const base64 = actualValue.split(",")[1];
            return Buffer.from(base64, "base64");
          } catch (e) {
            return Buffer.from(
              "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
              "base64",
            );
          }
        },
        getSize: (img: any, tagValue: string, tagName: string) => {
          if (tagName === "clientLogo" || tagName === "logo") {
            if (tagValue && tagValue.includes('|w:')) {
              const parts = tagValue.split('|');
              const wStr = parts.find(p => p.startsWith('w:'));
              const hStr = parts.find(p => p.startsWith('h:'));
              if (wStr && hStr) {
                const w = parseInt(wStr.substring(2), 10);
                const h = parseInt(hStr.substring(2), 10);
                if (!isNaN(w) && !isNaN(h) && w > 0 && h > 0) {
                  const maxH = 40; // elegant header logo height
                  const maxW = 180; // sleek header width bounds
                  let targetH = maxH;
                  let targetW = Math.round(w * (maxH / h));
                  if (targetW > maxW) {
                    targetW = maxW;
                    targetH = Math.round(h * (maxW / w));
                  }
                  return [targetW, targetH];
                }
              }
            }
            return [150, 40]; // Default tidy rectangular bounds
          }
          return [200, 200];
        },
      };

      const zip = new PizZip(content);
      const doc = new Docxtemplater(zip, {
        paragraphLoop: true,
        linebreaks: true,
        nullGetter: () => "",
        modules: [new ImageModule(imageOptions)],
      });

      doc.render(reportContext);

      const out = doc.getZip().generate({
        type: "blob",
        mimeType:
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      });
      return URL.createObjectURL(out);
    } catch (err: any) {
      throw new Error(err.message || "Unknown report generation error.");
    }
  },

  fetchDashboardSummary: async () => {
    const assignmentsSnap = await getDocs(collection(db, COLLECTIONS.ASSIGNMENTS));
    const assignments = assignmentsSnap.docs.map(d => ({ ...d.data(), id: d.id }) as TestAssignment);
    
    const projectsSnap = await getDocs(collection(db, COLLECTIONS.PROJECTS));
    const projects = projectsSnap.docs.map(d => ({ ...d.data(), id: d.id }) as Project);

    const openTasks = assignments.filter(a => a.status === 'IN_PROGRESS');
    const completedTasks = assignments.filter(a => a.status === 'COMPLETED').sort((a, b) => {
      const dateA = a.reviewedAt || a.createdAt;
      const dateB = b.reviewedAt || b.createdAt;
      return new Date(dateB).getTime() - new Date(dateA).getTime();
    });

    const alerts = assignments.filter(a => 
      a.workflowStatus === WorkflowStatus.REJECTED || 
      (a.status === 'IN_PROGRESS' && (new Date().getTime() - new Date(a.createdAt).getTime()) > 172800000) // 48h
    );

    const statusCounts = assignments.reduce((acc, a) => {
      const status = a.workflowStatus || 'UNKNOWN';
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      openTasksCount: openTasks.length,
      completedTasksCount: completedTasks.length,
      recentCompleted: completedTasks.slice(0, 5),
      alerts: alerts.slice(0, 5),
      totalProjects: projects.length,
      statusDistribution: Object.entries(statusCounts).map(([name, value]) => ({ name, value }))
    };
  },
};
