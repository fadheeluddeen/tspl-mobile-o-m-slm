
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, HeadingLevel, AlignmentType, WidthType, PageOrientation, BorderStyle, VerticalAlign, TableOfContents, PageBreak, Header } from "docx";
import Docxtemplater from "docxtemplater";
import PizZip from "pizzip";
// @ts-ignore
import DocxMerger from "docx-merger";
// @ts-ignore
import { Buffer } from "buffer";
import ImageModule from "docxtemplater-image-module-free";
import { TestDefinition, RCICacGroup } from "../types";

// Ensure Buffer is available globally for ESM modules that expect it
if (typeof window !== "undefined") {
  (window as any).Buffer = Buffer;
}

export const TemplateGeneratorService = {
  generate: async (test: TestDefinition): Promise<Blob> => {
    const testNameLower = test.name.toLowerCase();
    
    // Define the common header tags
    const commonTags = [
      { label: "Data Center Name", tag: "{dc_name}" },
      { label: "Project ID", tag: "{projectId}" },
      { label: "Document No", tag: "{doc_no}" },
      { label: "Customer Name", tag: "{customer_name}" },
      { label: "Site Address", tag: "{address}" },
      { label: "Revision No", tag: "{revision_no}" },
      { label: "Report Reference ID", tag: "{ReportId}" },
      { label: "Test Date", tag: "{TestDate}" },
      { label: "Prepared By", tag: "{prepared_by}" },
      { label: "Tested By", tag: "{tested_by}" },
      { label: "Witnessed By", tag: "{witnessed_by}" },
      { label: "Approved By", tag: "{approved_by}" },
      { label: "Tester Email", tag: "{tester_email}" },
    ];

    const children: any[] = [
      new TableOfContents("Table of Contents", {
        hyperlink: true,
        headingStyleRange: "1-3",
      }),
      new Paragraph({ text: "" }),
      new Paragraph({
        children: [
          new TextRun({ text: "PROTOCOL METADATA TAGS", bold: true, size: 24, color: "111827" }),
        ],
      }),
    ];

    // Add Metadata Tags
    commonTags.forEach(t => {
      children.push(new Paragraph({
        children: [
          new TextRun({ text: `${t.label}: `, bold: true, color: "4B5563" }),
          new TextRun({ text: t.tag, color: "2563EB", bold: true }),
        ],
      }));
    });

    children.push(new Paragraph({ text: "" }));

    const createRowLoopTable = (loopTag: string, headers: string[], tags: string[], sectionHeaderField?: string, totals?: { colSpan: number, tags: string[] }) => {
      const headerRow = new TableRow({
        children: headers.map(h => new TableCell({ 
          children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, size: 14, color: "FFFFFF" })] })],
          shading: { fill: "1F2937" }
        })),
      });

      const rows = [headerRow];

      if (sectionHeaderField) {
        // 1. Merged Header Row (Conditional)
        // We put the opening loop tag and the header condition here
        rows.push(new TableRow({
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  children: [new TextRun({ text: `{#${loopTag}}{#isHeader}{${sectionHeaderField}}{/isHeader}`, bold: true, size: 14, color: "B91C1C" })],
                  alignment: AlignmentType.CENTER,
                })
              ],
              columnSpan: headers.length,
              shading: { fill: "F3F4F6" }
            })
          ]
        }));

        // 2. Data Row (Conditional)
        // We put the data condition and the closing loop tag here
        rows.push(new TableRow({
          children: tags.map((t, idx) => {
            const isRaw = t.startsWith('{@');
            const cellChildren: any[] = [];
            
            let startTag = "";
            let endTag = "";

            // Wrap the data row in {^isHeader} and close the main loop {/loopTag}
            if (isRaw) {
              let startTagStr = "";
              let endTagStr = "";
              if (idx === 0) startTagStr = `{^isHeader}`;
              if (idx === tags.length - 1) endTagStr = `{/isHeader}{/${loopTag}}`;

              if (startTagStr) cellChildren.push(new Paragraph({ children: [new TextRun({ text: startTagStr, size: 1, color: "FFFFFF" })] }));
              cellChildren.push(new Paragraph({
                children: [new TextRun({ text: t, size: 14, color: "B91C1C" })],
                alignment: AlignmentType.CENTER
              }));
              if (endTagStr) cellChildren.push(new Paragraph({ children: [new TextRun({ text: endTagStr, size: 1, color: "FFFFFF" })] }));
            } else {
              let startTag = "";
              let endTag = "";

              if (idx === 0) startTag = `{^isHeader}`;
              if (idx === tags.length - 1) endTag = `{/isHeader}{/${loopTag}}`;

              cellChildren.push(new Paragraph({ 
                children: [new TextRun({ text: `${startTag}${t}${endTag}`, size: 14, color: "B91C1C" })],
                alignment: AlignmentType.CENTER 
              }));
            }
            
            return new TableCell({ children: cellChildren });
          }),
        }));
      } else {
        // Standard loop for tables without section headers
        rows.push(new TableRow({
          children: tags.map((t, idx) => {
            const isRaw = t.startsWith('{@');
            const cellChildren: any[] = [];
            
            let startTag = "";
            let endTag = "";

            if (isRaw) {
              let startTagStr = "";
              let endTagStr = "";
              if (idx === 0) startTagStr = `{#${loopTag}}`;
              if (idx === tags.length - 1) endTagStr = `{/${loopTag}}`;

              if (startTagStr) cellChildren.push(new Paragraph({ children: [new TextRun({ text: startTagStr, size: 1, color: "FFFFFF" })] }));
              cellChildren.push(new Paragraph({
                children: [new TextRun({ text: t, size: 14, color: "B91C1C" })],
                alignment: AlignmentType.CENTER
              }));
              if (endTagStr) cellChildren.push(new Paragraph({ children: [new TextRun({ text: endTagStr, size: 1, color: "FFFFFF" })] }));
            } else {
              let startTag = "";
              let endTag = "";

              if (idx === 0) startTag = `{#${loopTag}}`;
              if (idx === tags.length - 1) endTag = `{/${loopTag}}`;

              cellChildren.push(new Paragraph({ 
                children: [new TextRun({ text: `${startTag}${t}${endTag}`, size: 14, color: "B91C1C" })],
                alignment: AlignmentType.CENTER 
              }));
            }
            
            return new TableCell({ children: cellChildren });
          }),
        }));
      }

      if (totals) {
        const totalCells: TableCell[] = [];
        totalCells.push(new TableCell({
          children: [new Paragraph({ children: [new TextRun({ text: "Total", bold: true, size: 14, color: "1F2937" })] })],
          columnSpan: totals.colSpan,
          shading: { fill: "F3F4F6" }
        }));

        totals.tags.forEach(t => {
          const isRaw = t.startsWith('{@');
          const cellChildren: any[] = [];
          if (isRaw) {
            cellChildren.push(new Paragraph({
              children: [new TextRun({ text: t, size: 14, color: "2563EB", bold: true })],
              alignment: AlignmentType.CENTER
            }));
          } else {
            cellChildren.push(new Paragraph({
              children: [new TextRun({ text: t, size: 14, color: "1F2937", bold: true })],
              alignment: AlignmentType.CENTER
            }));
          }
          totalCells.push(new TableCell({
            children: cellChildren,
            shading: { fill: "F3F4F6" }
          }));
        });

        rows.push(new TableRow({
          children: totalCells
        }));
      }

      return [
        new Paragraph({
          children: [new TextRun({ text: `LOOP TABLE: ${loopTag}`, color: "B91C1C" , bold: true, size: 20 })],
        }),
        new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: rows,
        }),
        new Paragraph({ text: "" }),
      ];
    };

    if (testNameLower.includes('rack cooling index')) {
        // High Fidelity RCI Manual Fallback Logic
        children.push(new Paragraph({ text: "1.0 TECHNICAL BACKGROUND", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ text: "The Rack Cooling Index (RCI) is a performance metric defined by ASHRAE to measure how effectively the IT equipment is being cooled within its recommended and allowable temperature ranges. A value of 100% indicates perfect conformity to the specified thermal limits." }));
        
        children.push(new Paragraph({ children: [new TextRun({ text: "RCI INFRASTRUCTURE LOOPS", bold: true, color: "B91C1C" })] }));
        
        // --- TEMPERATURE MEASUREMENT PORTFOLIO ---
        children.push(new Paragraph({ text: "2.0 TEMPERATURE MEASUREMENT PORTFOLIO", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#dc1Groups}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "CAC UNIT: {cacName}", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("temperatureRows", 
            ["S.No", "CAC Ref", "Rack Ref", "F-15U", "F-22U", "F-35U", "F-Avg", "F-RH%", "R-15U", "R-22U", "R-35U", "R-Avg", "R-RH%", "Delta T (C)", "Inlet Temp Result (18-27)", "Excess Inlet Temp", "Deficit Inlet Temp"], 
            ["{sNo}", "{cacRef}", "{rackRef}", "{front15U}", "{front22U}", "{front35U}", "{frontAvg}", "{rhFront}", "{rear15U}", "{rear22U}", "{rear35U}", "{rearAvg}", "{rhRear}", "{@deltaT_xml}", "{@inletResult_xml}", "{@excessInletTemp_xml}", "{@deficitInletTemp_xml}"]
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "{/dc1Groups}", bold: true, color: "2563EB" })] }));

        children.push(new Paragraph({ text: "3.0 SUMMARY RESULTS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("rciTable1", 
           ["Parameter", "Result"], 
           ["{parameter}", "{result}"]
        ));
        children.push(...createRowLoopTable("rciTable2", 
           ["Parameter", "Result", "RCI Rating"], 
           ["{parameter}", "{result}", "{rating}"]
        ));

        children.push(new Paragraph({ text: "3.5 TOOLS USED FOR AUDIT", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({
            children: [
                new TextRun({ text: "Calibration Date: ", bold: true }),
                new TextRun({ text: "{toolCalibrationDate}", color: "B91C1C" })
            ]
        }));
        children.push(new Paragraph({
            children: [
                new TextRun({ text: "Expiry Date: ", bold: true }),
                new TextRun({ text: "{toolExpiryDate}", color: "B91C1C" })
            ]
        }));

        children.push(new Paragraph({ text: "4.0 AUDIT OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ObservationsTable", 
            ["SI. No", "Observation", "Recommendation"], 
            ["{srNo}", "{observation}", "{recommendation}"]
        ));
    } else if (testNameLower.includes('cfm') || testNameLower.includes('airflow')) {
        children.push(new Paragraph({ text: "1.0 CFM DATA SUMMARY", heading: HeadingLevel.HEADING_2 }));
        
        // 1. Basic Airflow Units (Equipment List)
        children.push(new Paragraph({ text: "1.1 Airflow Units (Equipment List)", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("airflowUnits", 
            ["Asset ID", "Design CFM", "Actual CFM", "Speed (%)", "Remarks"], 
            ["{assetName}", "{designCFM}", "{measuredCFM}", "{fanSpeedPercent}", "{remarks}"]
        ));

        // 2. CAC Tables & Detailed Analysis
        children.push(new Paragraph({ text: "1.2 CAC UNIT MEASUREMENTS & ANALYSIS", heading: HeadingLevel.HEADING_3 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#cacTables}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "CAC UNIT: {cacName} (Rack Delta: {deltaT}, Envelop Multiplier: {multiplier})", heading: HeadingLevel.HEADING_3 }));
        
        children.push(new Paragraph({ children: [new TextRun({ text: "CAC Measurements & Detailed Analysis (Left & Right Rows)", bold: true })] }));
        children.push(new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
                new TableRow({
                    children: ["S.No", "L-Ref", "L-Load", "L-Act", "L-Req", "L-Def", "R-Ref", "R-Load", "R-Act", "R-Req", "R-Def"].map(h => new TableCell({
                        children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, size: 12, color: "FFFFFF" })], alignment: AlignmentType.CENTER })],
                        shading: { fill: "1F2937" }
                    })),
                }),
                new TableRow({
                    children: ["{#pairedRows}{sNo}", "{l_ref}", "{l_load}", "{l_act}", "{l_req}", "{@l_def_xml}", "{r_ref}", "{r_load}", "{r_act}", "{r_req}", "{@r_def_xml}{/pairedRows}"].map(t => {
                        const isRaw = t.startsWith('{@');
                        return new TableCell({
                            children: [new Paragraph({ children: [new TextRun({ text: t, size: isRaw ? 1 : 11 })], alignment: AlignmentType.CENTER })]
                        });
                    }),
                }),
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "SUBTOTAL", bold: true, size: 11 })], alignment: AlignmentType.CENTER })], shading: { fill: "DAEAF7" } }),
                        new TableCell({ children: [new Paragraph({ text: "" })], shading: { fill: "DAEAF7" } }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_l_load_xml}", alignment: AlignmentType.CENTER })] }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_l_act_xml}", alignment: AlignmentType.CENTER })] }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_l_req_xml}", alignment: AlignmentType.CENTER })] }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_l_def_xml}", alignment: AlignmentType.CENTER })] }),
                        new TableCell({ children: [new Paragraph({ text: "" })], shading: { fill: "DAEAF7" } }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_r_load_xml}", alignment: AlignmentType.CENTER })] }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_r_act_xml}", alignment: AlignmentType.CENTER })] }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_r_req_xml}", alignment: AlignmentType.CENTER })] }),
                        new TableCell({ children: [new Paragraph({ text: "{@sub_r_def_xml}", alignment: AlignmentType.CENTER })] }),
                    ]
                })
            ]
        }));
        children.push(new Paragraph({ text: "" }));

        children.push(new Table({
            width: { size: 60, type: WidthType.PERCENTAGE },
            alignment: AlignmentType.RIGHT,
            rows: [
                new TableRow({
                    children: ["RACK LOAD", "ACTUAL CFM", "REQUIRED CFM", "UNIT DEFICIT"].map(h => new TableCell({
                        children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, size: 12, color: "FFFFFF" })], alignment: AlignmentType.CENTER })],
                        shading: { fill: "B91C1C" }
                    })),
                }),
                new TableRow({
                    children: ["{unit_load}", "{unit_act}", "{unit_req}", "{@unit_def_xml}"].map(t => new TableCell({
                        children: [new Paragraph({ children: [new TextRun({ text: t, size: 12, bold: true })], alignment: AlignmentType.CENTER })]
                    })),
                })
            ]
        }));
        children.push(new Paragraph({ text: "" }));

        children.push(new Paragraph({ children: [new TextRun({ text: "Unit Preview (Grill-wise)", bold: true })] }));
        children.push(...createRowLoopTable("previewRows", 
            ["Grill", "Rack Load", "Actual", "Required", "Deficit"], 
            ["{grill}", "{loadW}", "{actualCFM}", "{reqCFM}", "{@deficit_xml}"]
        ));
        
        children.push(new Paragraph({ children: [new TextRun({ text: "{/cacTables}", bold: true, color: "2563EB" })] }));

        // 3. Summary Analysis
        children.push(new Paragraph({ text: "2.0 CFM SUMMARY ANALYSIS", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Dynamic parameters available: Delta T ({deltaT}), Envelop Multiplier ({multiplier}), Envelop Percent ({envelopePercent})", italics: true, size: 18 })] }));
        children.push(...createRowLoopTable("summaryAnalysisRows", 
            ["REF", "RACK (KW)", "RACK (TR)", "REQUIRED MINIMUM AIRFLOW @ {deltaT} DEG C RACK DELTA & {envelopePercent}% ENVELOPE MULTIPLIER", "ACTUAL CFM", "DEFICIT"], 
            ["{category}", "{value}", "{rackTR}", "{reqCFM}", "{availCFM}", "{@deficit_xml}"]
        ));

        // 4. Data Center Airflow Summary
        children.push(new Paragraph({ text: "3.0 DATA CENTER AIRFLOW SUMMARY", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("airflowSummaryRows", 
            ["Parameter", "Measured (CFM)", "Required (CFM)", "Deficit (CFM)"], 
            ["{label}", "{@measured_xml}", "{required}", "{@deficit_xml}"]
        ));

        // 5. Load Summary
        children.push(new Paragraph({ text: "4.0 LOAD SUMMARY", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("loadSummaryRows", 
            ["Parameter", "Value", "Unit"], 
            ["{label}", "{value}", "{unit}"]
        ));

        // 6. Tools and Totals
        children.push(new Paragraph({ text: "5.0 TOOLS USED FOR AUDIT", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ToolsTable", 
            ["Instrument Name", "Purpose", "Make", "Model", "Calibration Issue", "Calibration Expiry"], 
            ["{instrumentName}", "{purpose}", "{make}", "{model}", "{calibrationIssue}", "{calibrationExpiry}"]
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "Total Design CFM: {totalDesignCFM}" })] }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Total Actual CFM: {totalActualCFM}" })] }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Total Deficit: {totalDeficit}" })] }));

        children.push(new Paragraph({ text: "6.0 AUDIT OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ObservationsTable", 
            ["SI. No", "Observation", "Recommendation"], 
            ["{srNo}", "{observation}", "{recommendation}"]
        ));
    } else if (testNameLower.includes('battery')) {
        children.push(...createRowLoopTable("EquipmentTable", 
            ["Equipment", "Make", "Model", "Serial", "Cal. Date", "Exp. Date"], 
            ["{name}", "{make}", "{model}", "{serialNo}", "{calDate}", "{expDate}"]
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "UPS LOOP START: {#UpsHierarchy}", bold: true, color: "F97316" })] }));
        children.push(new Paragraph({ children: [new TextRun({ text: "UPS Name: {name}", bold: true })] }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Location: {location} | Make: {make} | Type: {batteryType}", size: 18 })] }));
        
        children.push(new Paragraph({ children: [new TextRun({ text: "{#strings}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "String: {name}", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("ReadingRow", 
            ["No", "Measured IR (mΩ)", "Fail Thresh", "Warn Thresh", "Voltage (V)", "Volt Thresh", "Status"], 
            ["{batteryNo}", "{measuredIr}", "{irFailThresh}", "{irWarnThresh}", "{measuredVolt}", "{voltThresh}", "{@remarks}"]
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "{/strings}", bold: true, color: "2563EB" })] }));
        
        children.push(new Paragraph({ children: [new TextRun({ text: "UPS LOOP END: {/UpsHierarchy}", bold: true, color: "F97316" })] }));

        children.push(new Paragraph({ text: "SUMMARY OF PROBLEMATIC READINGS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ProblematicReadings", 
            ["UPS System", "String", "Cell No", "Measured IR", "Measured Volt", "Condition"], 
            ["{upsName}", "{strName}", "{batteryNo}", "{measuredIr}", "{measuredVolt}", "{@remarks}"]
        ));
    } else if (testNameLower.includes('power quality')) {
        children.push(new Paragraph({ text: "Power Quality Analysis Groups", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#ag}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "Group: {title} ({type})", heading: HeadingLevel.HEADING_3 }));
        children.push(new Paragraph({ text: "Monitoring Period: {dateFrom} to {dateTo}" }));
        
        children.push(new Paragraph({ text: "1. Power Frequency", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Avg", "Limits", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{f_avg}", "{f_lim}", "{@f_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%f_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "2. Voltage Trend", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["RY/RN", "YB/YN", "BR/BN", "Limits", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{v_ry}{v_rn}", "{v_yb}{v_yn}", "{v_br}{v_bn}", "{v_lim}", "{@v_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%v_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "3. Current Trend in Ampere", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["R Phase", "Y Phase", "B Phase", "Note"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{c_r}", "{c_y}", "{c_b}", "{c_note}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%c_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "4. Actual Power Trend in KW", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Average", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{p_avg}", "{@p_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%p_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "5. Apparent Power Trend in KVA", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Average", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{ap_avg}", "{@ap_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%ap_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "6. Reactive Power Trend in KVAR", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Average", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{rp_avg}", "{@rp_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%rp_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "7. Power Factor Trend", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Average", "Limits", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{pf_avg}", "{pf_lim}", "{@pf_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%pf_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "8. THDv Trend", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Phase", "Max %", "Min %", "Avg %", "Limits", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["R", "{dv_max_r}", "{dv_min_r}", "{dv_avg_r}", "{dv_lim}", "{@dv_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) }),
            new TableRow({ children: ["Y", "{dv_max_y}", "{dv_min_y}", "{dv_avg_y}", "{dv_lim}", "{@dv_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) }),
            new TableRow({ children: ["B", "{dv_max_b}", "{dv_min_b}", "{dv_avg_b}", "{dv_lim}", "{@dv_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%dv_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "9. THDi Trend", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Phase", "Max %", "Min %", "Avg %", "Limits", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["R", "{di_max_r}", "{di_min_r}", "{di_avg_r}", "{di_lim}", "{@di_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) }),
            new TableRow({ children: ["Y", "{di_max_y}", "{di_min_y}", "{di_avg_y}", "{di_lim}", "{@di_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) }),
            new TableRow({ children: ["B", "{di_max_b}", "{di_min_b}", "{di_avg_b}", "{di_lim}", "{@di_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%di_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "10. Unbalance Voltage Trend", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Average", "Limits", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{uv_avg}", "{uv_lim}", "{@uv_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%uv_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ text: "11. Unbalance Current Trend", heading: HeadingLevel.HEADING_4 }));
        children.push(new Table({
          width: { size: 100, type: WidthType.PERCENTAGE },
          rows: [
            new TableRow({ children: ["Average", "Limits", "Remark"].map(h => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: h, bold: true })] })], shading: { fill: "F3F4F6" } })) }),
            new TableRow({ children: ["{uc_avg}", "{uc_lim}", "{@uc_rem}"].map(t => new TableCell({ children: [new Paragraph({ text: t, alignment: AlignmentType.CENTER })] })) })
          ]
        }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{%uc_img}", bold: true })], alignment: AlignmentType.CENTER }));

        children.push(new Paragraph({ children: [new TextRun({ text: "{/ag}", bold: true, color: "2563EB" })] }));

        children.push(new Paragraph({ text: "12.0 OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Observations:", bold: true })] }));
        children.push(new Paragraph({ text: "{#obs_list}" }));
        children.push(new Paragraph({ text: "{line}" }));
        children.push(new Paragraph({ text: "{/obs_list}" }));
        children.push(new Paragraph({ text: "" }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Recommendations:", bold: true })] }));
        children.push(new Paragraph({ text: "{#rec_list}" }));
        children.push(new Paragraph({ text: "{line}" }));
        children.push(new Paragraph({ text: "{/rec_list}" }));
    } else if (testNameLower.includes('coupon test') || testNameLower.includes('corrosion')) {
        children.push(new Paragraph({ text: "1.0 TOOLS USED FOR AUDIT", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ToolsTable", 
            ["Equipment Name", "Make", "Parameter Measured"], 
            ["{name}", "{make}", "{parameter}"]
        ));

        children.push(new Paragraph({ text: "2.0 TEST RESULTS & ANALYSIS", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#LocationBlock}", bold: true, color: "2563EB" })] }));
        
        children.push(new Paragraph({ 
            children: [
                new TextRun({ text: "Location: ", bold: true }),
                new TextRun({ text: "{locationName}", color: "B91C1C" })
            ]
        }));

        children.push(new Paragraph({ children: [new TextRun({ text: "{tableSubheading}", bold: true, color: "B91C1C" })] }));
        children.push(...createRowLoopTable("results", 
            ["Type", "Oxide", "Chloride", "Sulfide", "Other", "Total (Å)", "Level", "Remarks"], 
            ["{couponType}", "{oxide}", "{chloride}", "{sulfide}", "{other}", "{@totalAngstroms_xml}", "{isaLevel}", "{remarks}"]
        ));

        children.push(new Paragraph({ children: [new TextRun({ text: "{graphSubheading}", bold: true, color: "B91C1C" })] }));
        children.push(new Paragraph({ 
            children: [
                new TextRun({ text: "{%graphImage}", color: "B91C1C", bold: true }) 
            ],
            alignment: AlignmentType.CENTER
        }));

        children.push(new Paragraph({ children: [new TextRun({ text: "{/LocationBlock}", bold: true, color: "2563EB" })] }));

        children.push(new Paragraph({ text: "3.0 AUDIT OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ObservationsTable", 
            ["SI. No", "Observation", "Recommendation"], 
            ["{srNo}", "{observation}", "{recommendation}"]
        ));
    } else if (testNameLower.includes('capacity assessment')) {
        children.push(new Paragraph({ text: "6.0 CAPACITY ASSESSMENT OF PAHU & PAC", heading: HeadingLevel.HEADING_2 }));
        
        children.push(new Paragraph({
             children: [
                 new TextRun({ text: "IT Load (kW): ", bold: true, color: "4B5563" }),
                 new TextRun({ text: "{itLoad}", color: "2563EB", bold: true }),
             ]
        }));
        children.push(new Paragraph({
             children: [
                 new TextRun({ text: "Measured PUE: ", bold: true, color: "4B5563" }),
                 new TextRun({ text: "{measuredPue}", color: "2563EB", bold: true }),
             ]
        }));
        children.push(new Paragraph({ text: "" }));

        children.push(new Paragraph({ text: "6.1 PAHU Capacity Assessment", heading: HeadingLevel.HEADING_3 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#pahuTables}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "{tableNumber} {title}", heading: HeadingLevel.HEADING_4 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "A. DESIGN", bold: true })] }));
        children.push(...createRowLoopTable("entries", 
            ["Eq. ID", "Model", "Serial", "Airflow (CFM)", "RA Temp (°C)", "SA Temp (°C)", "Power (kW)", "Water Flow (GPM)", "Cooling Tonnage (TR)"], 
            ["{equipmentId}", "{modelNo}", "{serialNo}", "{designAirflow}", "{designRaTemp}", "{designSaTemp}", "{designPower}", "{designWaterFlowRate}", "{@d_tra}"]
        ));
        children.push(new Paragraph({ text: "" }));
        children.push(new Paragraph({ children: [new TextRun({ text: "B. MEASURED", bold: true })] }));
        children.push(...createRowLoopTable("entries", 
            ["S. No.", "Eq. ID", "Airflow (CFM)", "SA Temp (°C)", "RA Temp (°C)", "Fan Speed (%)", "Cooling Tonnage (TR)", "Power (kW)", "CHW In (°C)", "CHW Out (°C)", "Valve (%)", "Water Flow (GPM)", "Water Cooling Tonnage (TR)"], 
            ["{sNo}", "{equipmentId}", "{measuredAirflow}", "{measuredSaTemp}", "{measuredRaTemp}", "{measuredFanSpeed}", "{@m_tra}", "{measuredPower}", "{measuredChwIn}", "{measuredChwOut}", "{measuredValveOpening}", "{measuredWaterFlowRate}", "{@measuredWaterCoolingTonnage_xml}"],
            undefined,
            { colSpan: 2, tags: ["{totalMeasuredAirflow}", "{totalMeasuredSaTemp}", "{totalMeasuredRaTemp}", "{totalMeasuredFanSpeed}", "{@totalMeasuredTr_xml}", "{totalMeasuredPower}", "{totalMeasuredChwIn}", "{totalMeasuredChwOut}", "{totalMeasuredValveOpening}", "{totalMeasuredWaterFlowRate}", "{@totalMeasuredWaterTr_xml}"] }
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "{/pahuTables}", bold: true, color: "2563EB" })] }));

        children.push(new Paragraph({ text: "6.2 PAC Capacity Assessment", heading: HeadingLevel.HEADING_3 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#pacTables}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "{tableNumber} {title}", heading: HeadingLevel.HEADING_4 }));
        children.push(...createRowLoopTable("entries", 
            ["Eq. ID", "Model", "Serial", "D-CFM", "D-RA", "D-SA", "D-kW", "D-TR", "Fan %", "M-CFM", "M-RA", "M-SA", "M-TR", "M-kW", "COP"], 
            ["{equipmentId}", "{modelNo}", "{serialNo}", "{designAirflow}", "{designRaTemp}", "{designSaTemp}", "{designPower}", "{@d_tra}", "{fanSpeed}", "{measuredAirflow}", "{measuredRaTemp}", "{measuredSaTemp}", "{@m_tra}", "{measuredPower}", "{@cop}"],
            undefined,
            { colSpan: 9, tags: ["{totalMeasuredAirflow}", "{totalMeasuredRaTemp}", "{totalMeasuredSaTemp}", "{@totalMeasuredTr_xml}", "{totalMeasuredPower}", "{@totalCop_xml}"] }
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "{/pacTables}", bold: true, color: "2563EB" })] }));

        children.push(new Paragraph({ text: "6.3 Tools Used", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("ToolsTable", 
            ["Instrument Name", "Make", "Model", "Serial No", "Calibration Issue", "Calibration Expiry"], 
            ["{instrumentName}", "{make}", "{model}", "{serialNumber}", "{calibrationIssue}", "{calibrationExpiry}"]
        ));

        children.push(new Paragraph({ text: "6.4 AUDIT OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ObservationsTable", 
            ["SI. No", "Observation", "Recommendation"], 
            ["{srNo}", "{observation}", "{recommendation}"]
        ));
    } else if (testNameLower.includes('life cycle')) {
        children.push(new Paragraph({ text: "5.0 LIFE CYCLE ASSESSMENT OF PAHU & PAC", heading: HeadingLevel.HEADING_2 }));
        
        children.push(new Paragraph({ text: "5.1 List of Testing Equipment", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("equipmentList", 
            ["S. No", "Instrument Name", "Make", "Model", "Serial No", "Cal. Date", "Exp. Date"], 
            ["{sNo}", "{name}", "{make}", "{model}", "{serialNo}", "{calDate}", "{expDate}"]
        ));

        children.push(new Paragraph({ text: "4.0 Equipment Remaining Useful Life (RUL) Estimation", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ text: "4.1 Table-1 (Equipment Summary & Factor Calculation)", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("lifeCycleRows", 
            [
              "Sl No", "Equipment Tag / Name", "Make & Model No", "Serial No", "Location", 
              "Install Year", "Current Year", "Age (yrs)", "Vibration Score (VS)", "Corrosion Score (CS)", 
              "Maint. Score (MS)", "Health Index (HI)", "Running Life (yrs)", "Utilization Ratio (UR)", "Utilization Factor (UF)"
            ], 
            [
              "{sNo}", "{equipmentTag}", "{makeModel}", "{serialNo}", "{location}", 
              "{installYear}", "{currentYear}", "{ageYrs}", "{vibrationScore}", "{corrosionScore}", 
              "{maintScore}", "{healthIndex}", "{runningLifeYrs}", "{utilizationRatio}", "{utilizationFactor}"
            ]
        ));

        children.push(new Paragraph({ text: "4.2 Table-2 (RUL Calculation)", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("rulRows", 
            [
              "Sl. No", "Equipment Tag / Name", "Design Life (yrs)", "Age (yrs)", "Health Index (HI)", "Utilization Factor (UF)", "Adjusted Life (AL)", "RUL (yrs)", "RUL (%)", "Life cycle Status", "Remarks"
            ], 
            [
              "{sNo}", "{equipmentTag}", "{designLifeYrs}", "{ageYrs}", "{healthIndex}", "{utilizationFactor}", "{adjustedLifeAL}", "{rulYrs}", "{rulPct}", "{lifeCycleStatus}", "{remarksRul}"
            ]
        ));

        children.push(new Paragraph({ text: "5.3 AUDIT OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ObservationsTable", 
            ["Life cycle Status", "No. of Equipment", "Equipment Tag / Name", "Observation", "Recommendation"], 
            ["{lifeCycleStatus}", "{noOfEquipment}", "{equipmentTag}", "{observation}", "{recommendation}"]
        ));
    } else if (testNameLower.includes('dg endurance')) {
        children.push(new Paragraph({ text: "1.0 ON SITE TEST DESCRIPTION", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("OnSiteTests", ["Sr. No.", "Test Description", "Result"], ["{srNo}", "{description}", "{result}"]));

        children.push(new Paragraph({ text: "2.0 TESTING & COMMISSIONING EQUIPMENT", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("DGEquipmentUsed", ["Equipment Name", "Model", "Serial No.", "Cal. Date", "Exp. Date"], ["{name}", "{model}", "{serialNo}", "{calDate}", "{expDate}"]));

        children.push(new Paragraph({ children: [new TextRun({ text: "{#DGUnits}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "DG UNIT: {unitName}", heading: HeadingLevel.HEADING_2 }));
        
        children.push(new Paragraph({ text: "3.0 STANDARD INFORMATION", heading: HeadingLevel.HEADING_3 }));
        children.push(new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Standard Number")] }), new TableCell({ children: [new Paragraph("{standardInfo.standardNumber}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Author")] }), new TableCell({ children: [new Paragraph("{standardInfo.author}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Performed Date")] }), new TableCell({ children: [new Paragraph("{standardInfo.performedDate}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Category")] }), new TableCell({ children: [new Paragraph("{standardInfo.category}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Subcategory")] }), new TableCell({ children: [new Paragraph("{standardInfo.subcategory}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Description")] }), new TableCell({ children: [new Paragraph("{standardInfo.description}")] })] }),
            ]
        }));

        children.push(new Paragraph({ text: "4.0 EQUIPMENT DETAILS", heading: HeadingLevel.HEADING_3 }));
        children.push(new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Nomenclature")] }), new TableCell({ children: [new Paragraph("{equipmentDetails.nomenclature}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Engine Number")] }), new TableCell({ children: [new Paragraph("{equipmentDetails.engineNumber}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Make")] }), new TableCell({ children: [new Paragraph("{equipmentDetails.make}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Alternator Serial")] }), new TableCell({ children: [new Paragraph("{equipmentDetails.alternatorSerial}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Location")] }), new TableCell({ children: [new Paragraph("{equipmentDetails.location}")] })] }),
                new TableRow({ children: [new TableCell({ children: [new Paragraph("Model")] }), new TableCell({ children: [new Paragraph("{equipmentDetails.model}")] })] }),
            ]
        }));

        children.push(new Paragraph({ text: "5.0 LOAD TEST READINGS", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("loadReadings", 
            ["Parameter", "Unit", "0%", "25%", "50%", "75%", "100%", "Remarks"], 
            ["{parameter}", "{unit}", "{v0}", "{v25}", "{v50}", "{v75}", "{v100}", "{remarks}"]
        ));

        children.push(new Paragraph({ text: "6.0 TRANSIENT LOAD TEST SUMMARY", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("transientSummary", ["Sr. No.", "Transient Load", "Result"], ["{srNo}", "{load}", "{result}"]));

        children.push(new Paragraph({ text: "7.0 NOISE LEVEL MEASUREMENT", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("noiseLevels", ["Load %", "Doors Open", "Doors Closed"], ["{load}", "{open}", "{closed}"]));

        children.push(new Paragraph({ text: "8.0 VIBRATION MEASUREMENT", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("vibrationLevels", ["Load %", "A", "B", "C", "D", "E", "F", "G", "H"], ["{load}", "{a}", "{b}", "{c}", "{d}", "{e}", "{f}", "{g}", "{h}"]));

        children.push(new Paragraph({ text: "9.0 FUEL CONSUMPTION SUMMARY", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("fuelSummary", 
            ["Sr.No", "% Load", "Time", "kWh Initial", "kWh Final", "kWh Units", "Fuel Initial", "Fuel Final", "Fuel Consum.", "OEM Std", "Efficiency"], 
            ["{srNo}", "{percentLoad}", "{time}", "{kwhInitial}", "{kwhFinal}", "{kwhUnits}", "{fuelInitial}", "{fuelFinal}", "{fuelConsum}", "{oemStd}", "{efficiency}"]
        ));

        children.push(new Paragraph({ children: [new TextRun({ text: "{/DGUnits}", bold: true, color: "2563EB" })] }));
    } else if (testNameLower.includes('elv gap')) {
        children.push(new Paragraph({ text: "ELV GAP ASSESSMENT CHECKLISTS", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#elvSystems}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "System: {systemName}", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("ReadingRow", 
            ["No", "Description", "Result", "Remarks", "Corrective Actions"], 
            ["{no}", "{description}", "{result}", "{remarks}", "{correctiveActions}"]
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "{/elvSystems}", bold: true, color: "2563EB" })] }));

        children.push(new Paragraph({ text: "INFRASTRUCTURE COMPLIANCE SUMMARY", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("complianceSummary", 
            ["S.No", "Infrastructure", "Compliance", "Remarks", "Corrective Actions"], 
            ["{sNo}", "{infrastructure}", "{compliance}", "{remarks}", "{correctiveActions}"]
        ));

        children.push(new Paragraph({ text: "GAP ANALYSIS – SAFETY AND SECURITY INFRASTRUCTURE", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("gapAnalysisRows", 
            ["No", "Standard", "Section", "Requirement", "System", "Implementation", "Compliance", "Corrective Actions"], 
            ["{no}", "{standard}", "{section}", "{requirement}", "{system}", "{implementation}", "{compliance}", "{correctiveActions}"]
        ));
    } else if (testNameLower.includes('vibration analysis')) {
        children.push(new Paragraph({ text: "1.0 TOOLS USED FOR AUDIT", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ToolTable", 
            ["Instrument Name", "Purpose", "Make", "Model", "Calibration Issue", "Calibration Expiry"], 
            ["{instrumentName}", "{purpose}", "{make}", "{model}", "{calibrationIssue}", "{calibrationExpiry}"]
        ));

        children.push(new Paragraph({ text: "2.0 VIBRATION MEASUREMENT SUMMARY", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "{#VibrationSummaryTable}", bold: true, color: "2563EB" })] }));
        children.push(new Paragraph({ text: "GROUP: {groupName}", heading: HeadingLevel.HEADING_3 }));
        children.push(...createRowLoopTable("rows", 
            ["EQUIPMENT ID", "CLASS", "VERTICAL", "HORIZONTAL", "AXIAL", "MAX VALUE", "CONDITION"], 
            ["{equipmentId}", "{classDetails}", "{vertical}", "{horizontal}", "{axial}", "{maxValue}", "{condition}"]
        ));
        children.push(new Paragraph({ children: [new TextRun({ text: "{/VibrationSummaryTable}", bold: true, color: "2563EB" })] }));

        children.push(new Paragraph({ text: "3.0 OBSERVATIONS & RECOMMENDATIONS SUMMARY", heading: HeadingLevel.HEADING_2 }));
        children.push(new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "CONDITION", bold: true, color: "FFFFFF" })], alignment: AlignmentType.CENTER })], shading: { fill: "1A3043" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "NO. OF UNITS", bold: true, color: "FFFFFF" })], alignment: AlignmentType.CENTER })], shading: { fill: "1A3043" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "UNIT TAGS", bold: true, color: "FFFFFF" })], alignment: AlignmentType.CENTER })], shading: { fill: "1A3043" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "OBSERVATION", bold: true, color: "FFFFFF" })], alignment: AlignmentType.CENTER })], shading: { fill: "1A3043" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "RECOMMENDATION", bold: true, color: "FFFFFF" })], alignment: AlignmentType.CENTER })], shading: { fill: "1A3043" }, verticalAlign: VerticalAlign.CENTER }),
                    ],
                }),
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ text: "{#hasGood}Good", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{GoodCount}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{GoodTags}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. All units are within ISO acceptable vibration limits.\n2. No abnormal vibration trend observed in H/V/A directions.\n3. Equipment operating in stable dynamic condition." })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. Continue routine condition monitoring as per PM schedule.\n2. Record baseline trends for future comparison.{/hasGood}" })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                    ],
                }),
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ text: "{#hasSatisfactory}Satisfactory", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{SatisfactoryCount}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{SatisfactoryTags}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. Vibration levels are within permissible ISO limits but approaching upper band.\n2. Slight increase observed in one or more measurement directions (H/V/A).\n3. No immediate mechanical fault indication." })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. Monitor vibration trend closely.\n2. Inspect during next planned shutdown.\n3. Check for early signs of misalignment or looseness.{/hasSatisfactory}" })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                    ],
                }),
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ text: "{#hasUnsatisfactory}Unsatisfactory", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{UnsatisfactoryCount}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{UnsatisfactoryTags}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. Vibration levels exceed satisfactory range as per ISO limits.\n2. Indicates early mechanical degradation (possible imbalance, misalignment, or looseness).\n3. Trend shows increasing deviation from baseline." })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. Conduct detailed vibration analysis.\n2. Inspect coupling alignment, foundation tightness, and bearing condition.\n3. Plan corrective maintenance in nearest shutdown window.{/hasUnsatisfactory}" })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                    ],
                }),
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ text: "{#hasUnacceptable}Unacceptable", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{UnacceptableCount}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [new Paragraph({ text: "{UnacceptableTags}", alignment: AlignmentType.CENTER })], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. Vibration levels exceed permissible ISO limits indicating critical condition.\n2. High risk of mechanical failure if operation continues.\n3. Abnormal vibration detected in one or more directions (H/V/A)." })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                        new TableCell({ children: [
                            new Paragraph({ text: "1. Immediate corrective action required.\n2. Reduce load or shut down equipment if possible.\n3. Perform urgent inspection: alignment correction, bearing replacement, structural tightening before restart.{/hasUnacceptable}" })
                        ], shading: { fill: "D6EAF8" }, verticalAlign: VerticalAlign.CENTER }),
                    ],
                }),
            ],
        }));

        children.push(new Paragraph({ text: "4.0 AUDIT OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("ObservationsTable", 
            ["SI. No", "Observation", "Recommendation"], 
            ["{srNo}", "{observation}", "{recommendation}"]
        ));
    } else if (testNameLower.includes('thermography')) {
        children.push(new Paragraph({ text: "1.0 TEST METADATA", heading: HeadingLevel.HEADING_2 }));
        children.push(new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "PREPARED BY", bold: true })] })], shading: { fill: "F3F4F6" } }),
                        new TableCell({ children: [new Paragraph({ text: "{preparedBy}" })] }),
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "TESTED BY", bold: true })] })], shading: { fill: "F3F4F6" } }),
                        new TableCell({ children: [new Paragraph({ text: "{testedBy}" })] }),
                    ]
                }),
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "WITNESSED BY", bold: true })] })], shading: { fill: "F3F4F6" } }),
                        new TableCell({ children: [new Paragraph({ text: "{witnessedBy}" })] }),
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "TEST DATE", bold: true })] })], shading: { fill: "F3F4F6" } }),
                        new TableCell({ children: [new Paragraph({ text: "{testDate}" })] }),
                    ]
                }),
                new TableRow({
                    children: [
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "TESTER EMAIL", bold: true })] })], shading: { fill: "F3F4F6" } }),
                        new TableCell({ children: [new Paragraph({ text: "{testerEmail}" })] }),
                        new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "STATUS", bold: true })] })], shading: { fill: "F3F4F6" } }),
                        new TableCell({ children: [new Paragraph({ text: "{status}" })] }),
                    ]
                })
            ]
        }));
        children.push(new Paragraph({ text: "" }));

        children.push(new Paragraph({ text: "2.0 TOOLS USED & CALIBRATION DETAILS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("equipmentList", 
            ["SR. NO", "INSTRUMENT NAME", "MAKE", "MODEL", "SERIAL NUMBER", "CALIBRATION ISSUE", "CALIBRATION EXPIRY"], 
            ["{srNo}", "{instrumentName}", "{make}", "{model}", "{serialNumber}", "{calibrationIssue}", "{calibrationExpiry}"]
        ));

        children.push(new Paragraph({ text: "3.0 THERMOGRAPHY INSPECTION", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("inspections", 
            ["S.NO", "ROOM NAME", "PANEL NAME", "FEEDER NAME", "MAX TEMP °C", "MIN TEMP °C", "REMARKS"], 
            ["{sNo}", "{roomName}", "{panelName}", "{feederName}", "{maxTemp}", "{minTemp}", "{remarks}"]
        ));

        children.push(new Paragraph({ text: "4.0 CRITICAL IMAGES", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("images", 
            ["S.NO", "ROOM NAME", "PANEL NAME", "FEEDER NAME", "CRITICAL IMAGES", "REMARKS"], 
            ["{sNo}", "{roomName}", "{panelName}", "{feederName}", "{%imageUrl}", "{remarks}"]
        ));

        children.push(new Paragraph({ text: "5.0 OBSERVATIONS & RECOMMENDATIONS", heading: HeadingLevel.HEADING_2 }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Observations:", bold: true })] }));
        children.push(new Paragraph({ text: "{#obs_list}" }));
        children.push(new Paragraph({ text: "{line}" }));
        children.push(new Paragraph({ text: "{/obs_list}" }));
        children.push(new Paragraph({ text: "" }));
        children.push(new Paragraph({ children: [new TextRun({ text: "Recommendations:", bold: true })] }));
        children.push(new Paragraph({ text: "{#rec_list}" }));
        children.push(new Paragraph({ text: "{line}" }));
        children.push(new Paragraph({ text: "{/rec_list}" }));
    } else if (testNameLower.includes('power system study')) {
        children.push(new Paragraph({ text: "1.0 TRANSFORMER NAME PLATE DETAILS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("transformers", 
            ["S.No", "Parameters", "Transformer 1", "Transformer 2", "Transformer 3"], 
            ["{sNo}", "{paramName}", "{tf1}", "{tf2}", "{tf3}"]
        ));

        children.push(new Paragraph({ text: "2.0 LOAD FLOW CASE", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("loadFlow", 
            ["Location", "Bus Voltage (kV)", "Power (MVA)", "Real Power (MW)", "Reactive Power (MVAR)", "PF"], 
            ["{location}", "{busVoltKv}", "{powerMva}", "{realPowerMw}", "{reactivePowerMvar}", "{pf}"]
        ));

        children.push(new Paragraph({ text: "3.0 SHORT CIRCUIT ANALYSIS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("shortCircuit", 
            ["Location", "Bus Voltage (kV)", "3 Phase (kA)", "L-G (kA)", "Bus Rating (kA)"], 
            ["{location}", "{busVoltKv}", "{threePhaseKa}", "{lineToGroundKa}", "{busRatingKa}"]
        ));

        children.push(new Paragraph({ text: "4.0 RELAY COORDINATION - PHASE SETTINGS", heading: HeadingLevel.HEADING_2, alignment: AlignmentType.CENTER }));
        children.push(...createRowLoopTable("relayPhase", 
            ["No", "Feeder", "Rated Current (A)", "Type", "CT", "Operating time (s)", "E-Curve", "E-Plug", "E-TMS", "E-HiI", "E-HiT", "S-Curve", "S-Plug", "S-TMS", "S-HiI", "S-HiT", "Remarks"], 
            ["{relayNo}", "{feeder}", "{ratedCurrent}", "{relayType}", "{ctRatio}", "{opTimeCloseInFault}", "{e_curve}", "{e_plug}", "{e_tms}", "{e_hiI}", "{e_hiT}", "{s_curve}", "{s_plug}", "{s_tms}", "{s_hiI}", "{s_hiT}", "{remarks}"]
        ));

        children.push(new Paragraph({ text: "5.0 RELAY COORDINATION - EARTH FAULT SETTINGS", heading: HeadingLevel.HEADING_2, alignment: AlignmentType.CENTER }));
        children.push(...createRowLoopTable("relayEarth", 
            ["No", "Feeder", "Rated Current (A)", "Type", "CT", "Operating time (s)", "E-Curve", "E-Plug", "E-TMS", "E-HiI", "E-HiT", "S-Curve", "S-Plug", "S-TMS", "S-HiI", "S-HiT", "Remarks"], 
            ["{relayNo}", "{feeder}", "{ratedCurrent}", "{relayType}", "{ctRatio}", "{opTimeCloseInFault}", "{e_curve}", "{e_plug}", "{e_tms}", "{e_hiI}", "{e_hiT}", "{s_curve}", "{s_plug}", "{s_tms}", "{s_hiI}", "{s_hiT}", "{remarks}"]
        ));

        children.push(new Paragraph({ text: "6.0 415V RELEASE SETTINGS", heading: HeadingLevel.HEADING_2, alignment: AlignmentType.CENTER }));
        children.push(...createRowLoopTable("releaseSettings", 
            ["Sl. No.", "Feeder Name", "Rated current (A)", "Relay Make/ type", "E-LT Pickup (xIn)", "E-LT Time (s) at 3xIr", "E-ST Pickup (xIn)", "E-ST Time (s)", "E-Inst (xIn)", "E-Earth Pickup (xIn)", "E-Earth Time (s)", "P-LT Pickup (xIn)", "P-LT Time (s) at 6xIr", "P-ST Pickup (xIn)", "P-ST Time (s)", "P-Inst (xIn)", "P-Earth Pickup (xIn)", "P-Earth Time (s)", "Remarks"], 
            ["{slNo}", "{feederName}", "{ratedCurrent}", "{relayMakeType}", "{e_ltP}", "{e_ltT}", "{e_stP}", "{e_stT}", "{e_inst}", "{e_eP}", "{e_eT}", "{p_ltP}", "{p_ltT}", "{p_stP}", "{p_stT}", "{p_inst}", "{p_eP}", "{p_eT}", "{remarks}"]
        ));

        children.push(new Paragraph({ text: "7.0 ARC FLASH ANALYSIS RESULTS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("arcFlashAnalysis", 
            ["Location", "kV", "Bolted", "Arcing", "FCT", "Energy", "AFB", "Dist", "Level", "Remarks"], 
            ["{locationName}", "{nominalKv}", "{boltedKa}", "{arcingKa}", "{fctSecs}", "{incidentEnergy}", "{afbM}", "{workingDistanceCm}", "{energyLevel}", "{remarks}"]
        ));
    } else if (testNameLower.includes('earth station') || testNameLower.includes('earth continuity')) {
        children.push(new Paragraph({ text: "1.0 EQUIPMENT USED FOR AUDIT", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("equipmentList", 
            ["Sr.No.", "Equipment", "Make", "Serial no", "Model no", "Cal. Date", "Due Date"], 
            ["{sNo}", "{name}", "{make}", "{serial}", "{model}", "{calDate}", "{expDate}"]
        ));

        children.push(new Paragraph({ text: "2.0 MEASURING DETAILS (READINGS)", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("readings", 
            ["Earth pit no", "Earthing description", "Measured value (Ω)", "Limit value (Ω)", "Remarks"], 
            ["{pitNo}", "{description}", "{measuredValue}", "{limitValue}", "{@remarks_xml}"]
        ));
    } else if (testNameLower.includes('lightning') || testNameLower.includes('arrestor')) {
        children.push(new Paragraph({ text: "1.0 EQUIPMENT USED FOR AUDIT", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("equipmentList", 
            ["Sr.No.", "Equipment", "Make", "Serial no", "Model no", "Cal. Date", "Due Date"], 
            ["{sNo}", "{name}", "{make}", "{serial}", "{model}", "{calDate}", "{dueDate}"]
        ));

        children.push(new Paragraph({ text: "2.0 GROUNDING RESISTANCE MEASUREMENTS", heading: HeadingLevel.HEADING_2 }));
        children.push(...createRowLoopTable("laReadings", 
            ["Sr.no", "Earth pit names", "Arrester Location", "Conductor Size & Type", "Grounding Value (Ω)", "Accept Value (Ω)", "Remarks", "Result"], 
            ["{sNo}", "{pitName}", "{location}", "{conductorType}", "{groundingValue}", "{acceptValue}", "{remarks}", "{@result_xml}"]
        ));
    } else {
        children.push(...createRowLoopTable("ReadingRow", ["Parameter", "Value"], ["{label}", "{value}"]));
    }

    // Footer Tags
    children.push(new Paragraph({ text: "" }));
    children.push(new Paragraph({ children: [new TextRun({ text: "Observations:", bold: true })] }));
    children.push(new Paragraph({ text: "{#obs_list}" }));
    children.push(new Paragraph({ text: "{line}" }));
    children.push(new Paragraph({ text: "{/obs_list}" }));
    children.push(new Paragraph({ text: "" }));
    children.push(new Paragraph({ children: [new TextRun({ text: "Recommendations:", bold: true })] }));
    children.push(new Paragraph({ text: "{#rec_list}" }));
    children.push(new Paragraph({ text: "{line}" }));
    children.push(new Paragraph({ text: "{/rec_list}" }));
    children.push(new Paragraph({ children: [new TextRun({ text: "AI Analysis: {AIInsight}", italics: true })] }));
    children.push(new Paragraph({ children: [new TextRun({ text: `Generated: {CurrentDate}` })], alignment: AlignmentType.RIGHT }));

    const doc = new Document({
      sections: [{
        properties: {
          page: {
            size: {
              orientation: testNameLower.includes('power quality') || testNameLower.includes('rack cooling index') || testNameLower.includes('coupon test') || testNameLower.includes('dg endurance') || testNameLower.includes('power system study') || testNameLower.includes('thermography') || testNameLower.includes('lightning') || testNameLower.includes('arrestor') ? PageOrientation.LANDSCAPE : PageOrientation.PORTRAIT,
            },
          },
        },
        headers: {
          default: new Header({
            children: [
              new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                borders: {
                    top: { style: BorderStyle.NONE, size: 0, color: "auto" },
                    bottom: { style: BorderStyle.NONE, size: 0, color: "auto" },
                    left: { style: BorderStyle.NONE, size: 0, color: "auto" },
                    right: { style: BorderStyle.NONE, size: 0, color: "auto" },
                    insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "auto" },
                    insideVertical: { style: BorderStyle.NONE, size: 0, color: "auto" },
                },
                rows: [
                  new TableRow({
                    children: [
                      new TableCell({
                        shading: { fill: "0F172A" }, // Dark blue/slate-900 like example
                        margins: { top: 200, bottom: 200, left: 400, right: 200 },
                        verticalAlign: VerticalAlign.CENTER,
                        children: [
                          new Paragraph({
                            children: [
                              new TextRun({ text: "{%clientLogo}" })
                            ],
                          })
                        ]
                      }),
                      new TableCell({
                        shading: { fill: "0F172A" },
                        verticalAlign: VerticalAlign.CENTER,
                        margins: { right: 400 },
                        children: [
                          new Paragraph({
                            alignment: AlignmentType.RIGHT,
                            children: [
                              new TextRun({ text: "Blueprint to Benchmark for Data Centers", color: "FFFFFF", bold: true, size: 24 })
                            ]
                          })
                        ]
                      })
                    ]
                  })
                ]
              })
            ]
          })
        },
        children: children,
      }],
    });

    return await Packer.toBlob(doc);
  },

  mergeReports: async (sections: { template: ArrayBuffer; context: any }[]): Promise<Blob> => {
    if (sections.length === 0) throw new Error("No sections to merge");

    const renderedFiles: ArrayBuffer[] = [];

    const imageOptions = {
      centered: false,
      getImage: (tagValue: string) => {
        const actualValue = tagValue ? tagValue.split('|')[0] : "";
        if (!actualValue || !actualValue.startsWith("data:image")) {
          // Return a 1x1 transparent pixel if no logo uploaded
          return Buffer.from(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuMTnU1rJDAAAADUlEQVQYV2NgYGD4DwABBAEAcCBlCwAAAABJRU5ErkJggg==",
            "base64",
          );
        }
        try {
          const base64 = actualValue.split(",")[1];
          return Buffer.from(base64, "base64");
        } catch (e) {
          return Buffer.from(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
            "base64",
          );
        }
      },
      getSize: (img: any, tagValue: string, tagName: string) => {
        if (tagName === "clientLogo" || tagName === "logo") {
          if (tagValue && tagValue.includes('|w:')) {
            const parts = tagValue.split('|');
            const wStr = parts.find(p => p.startsWith('w:'));
            const hStr = parts.find(p => p.startsWith('h:'));
            if (wStr && hStr) {
               const w = parseInt(wStr.substring(2), 10);
               const h = parseInt(hStr.substring(2), 10);
               if (!isNaN(w) && !isNaN(h) && w > 0 && h > 0) {
                 const maxH = 40; // elegant header logo height
                 const maxW = 180; // sleek header width bounds
                 let targetH = maxH;
                 let targetW = Math.round(w * (maxH / h));
                 if (targetW > maxW) {
                   targetW = maxW;
                   targetH = Math.round(h * (maxW / w));
                 }
                 return [targetW, targetH];
               }
            }
          }
          return [1, 1]; // Size of 1x1 default pixel
        }
        return [200, 200];
      },
    };

    for (const section of sections) {
      const zip = new PizZip(Buffer.from(section.template));
      const doc = new Docxtemplater(zip, {
        paragraphLoop: true,
        linebreaks: true,
        nullGetter: () => "",
        modules: [new ImageModule(imageOptions)],
      });
      doc.render(section.context);
      const out = doc.getZip().generate({ type: "arraybuffer" });
      renderedFiles.push(Buffer.from(out));
    }

    if (renderedFiles.length === 1) {
      return new Blob([renderedFiles[0]], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
    }

    // Merge using docx-merger
    console.log(`Merging ${renderedFiles.length} files...`);
    return new Promise((resolve, reject) => {
      try {
        const merger = new DocxMerger({}, renderedFiles);
        console.log("Merger initialized");
        merger.save("blob", (data: Blob) => {
          console.log("Merge complete, blob generated");
          resolve(data);
        });
      } catch (err) {
        console.error("Merge failed:", err);
        reject(err);
      }
    });
  }
};
