import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function readVibrationDisplay(
  base64Jpeg: string
): Promise<{ vertical: string; horizontal: string; axial: string }>;

export async function readVibrationDisplay(
  base64Jpeg: string,
  axisLabel: string
): Promise<string>;

export async function readVibrationDisplay(
  base64Jpeg: string,
  axisLabel?: string
): Promise<any> {
  const isSingleAxis = axisLabel !== undefined;
  
  const textPrompt = isSingleAxis
    ? `This is a photo of a vibration meter display. 
Read ONLY the ${axisLabel} axis velocity reading in mm/s. 
Return ONLY the number exactly as shown, preserving decimal points. 
If the value is not visible or unreadable, return an empty string. 
Do NOT guess or estimate. 
Respond with ONLY valid JSON, no markdown fences, no explanation. 

Required JSON shape:
{"value":""}`
    : `This is a photo of a vibration meter display. 
Read the vertical, horizontal, and axial axis velocity readings in mm/s. 
Return ONLY the numbers exactly as shown on the screen, preserving decimal points. 
If any value is not visible or unreadable, return an empty string for that field. 
Do NOT guess or estimate. 
Respond with ONLY valid JSON, no markdown fences, no explanation. 

Required JSON shape:
{
  "vertical": "",
  "horizontal": "",
  "axial": ""
}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.6-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    if (isSingleAxis) {
      return String(parsed.value ?? "");
    } else {
      return {
        vertical: String(parsed.vertical ?? ""),
        horizontal: String(parsed.horizontal ?? ""),
        axial: String(parsed.axial ?? ""),
      };
    }
  } catch {
    if (isSingleAxis) {
      return "";
    } else {
      return {
        vertical: "",
        horizontal: "",
        axial: "",
      };
    }
  }
}

export async function readThermographyDisplay(
  base64Jpeg: string
): Promise<{ maxTemp: string; minTemp: string }> {
  const textPrompt = `This is a photo of a Fluke VT08 Visual IR Thermometer screen. 
Its screen shows a thermal image with two numeric readouts overlaid: a MAX temperature and a MIN temperature, each in °C, typically with one decimal place.

Reading guidance:
- Read the MAX temperature value (the higher of the two overlaid °C numbers, usually labelled or positioned as max/hot) and the MIN temperature value (the lower, min/cold) — both in °C.
- Ignore: the emissivity value, the centre-spot crosshair reading, the colour scale bar numbers, battery icon, and any mode text. Do not confuse the colour-scale end labels with the max/min readouts.
- Return ONLY the numbers exactly as shown, preserving decimal points.
- If any value is not visible or unreadable, return an empty string for that field. 
- Do NOT guess or estimate. 
- Respond with ONLY valid JSON, no markdown fences, no explanation. 

Required JSON shape:
{
  "maxTemp": "",
  "minTemp": ""
}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    return {
      maxTemp: String(parsed.maxTemp ?? ""),
      minTemp: String(parsed.minTemp ?? ""),
    };
  } catch {
    throw new Error("Failed to parse Gemini response: " + raw);
  }
}

export async function readBatteryImpedanceDisplay(
  base64Jpeg: string
): Promise<{ measuredIr: string; voltage: string }> {
  const textPrompt = `This is a photo of a HIOKI BT3554 battery tester LCD screen.
The display shows two primary values: internal resistance in milliohms (mΩ) and DC voltage in volts (V).

Reading guidance:
- Read the internal-resistance value shown with the mΩ unit, and the DC voltage value shown with the V unit. Preserve decimals exactly.
- Ignore: the comparator/PASS-FAIL indicators, range/mode text, memory number, battery icon, and any secondary/small annunciators. Do not confuse a threshold/limit readout with the live measurement.
- If any value is not visible, is unreadable, or missing, return an empty string for that field. 
- Do NOT guess or estimate.
- Respond with ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{
  "measuredIr": "",
  "voltage": ""
}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    return {
      measuredIr: String(parsed.measuredIr ?? ""),
      voltage: String(parsed.voltage ?? ""),
    };
  } catch {
    throw new Error("Failed to parse Gemini response: " + raw);
  }
}

export async function readEarthContinuityDisplay(
  base64Jpeg: string
): Promise<{ measuredValue: string }> {
  const textPrompt = `This is a photo of an instrument display (e.g., Earth Resistance Tester (WACO), HIOKI RM-3548, SCOPE CRM-100B, or SEW 8025LP).
The instrument displays a resistance/impedance value in ohms (Ω), which may also be mΩ or µΩ.

Reading guidance:
- Read the primary resistance/impedance value displayed, in ohms (Ω) (it may show mΩ or µΩ on contact-resistance meters — read the number and its unit exactly as shown; preserve decimals).
- Ignore: range/mode text, test-current readouts, pass/fail indicators, memory/hold annunciators, battery icon, and any secondary/limit values. Read only the live primary measurement.
- Return ONLY the primary value with its unit if visible, exactly as shown on the screen, preserving decimal points.
- If the value is not visible, is unreadable, or missing, return an empty string. 
- Do NOT guess or estimate.
- Respond with ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{
  "measuredValue": ""
}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    return {
      measuredValue: String(parsed.measuredValue ?? ""),
    };
  } catch {
    throw new Error("Failed to parse Gemini response: " + raw);
  }
}

export async function readSingleInstrumentDisplay(
  base64Jpeg: string,
  fieldLabel: string,
  unit?: string,
  guidance?: string
): Promise<string> {
  const textPrompt = `This is a photo of an instrument display (such as a MECO 1080 clamp meter or digital multi-meter / power factor meter).
Target field: ${fieldLabel}${unit ? ` (${unit})` : ''}.

Reading guidance:
${guidance || '- Read the single primary value shown on the display in its shown unit. Preserve decimals.'}
- Read ONLY the live primary measurement.
- Ignore: mode/range text, MIN/MAX/HOLD annunciators, secondary readouts, battery icon, and any limit/threshold values.
- If the value is not visible, unreadable, or missing, return an empty string.
- Do NOT guess or estimate.
- Respond with ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{"value":""}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    return String(parsed.value ?? "");
  } catch {
    throw new Error("Failed to parse Gemini response: " + raw);
  }
}

export async function readRciDisplay(
  base64Jpeg: string,
  isGrouped22U: boolean,
  guidance?: string
): Promise<{ temp: string; rh: string }> {
  const textPrompt = isGrouped22U
    ? `This is a photo of a FLUKE 971 Temperature Humidity Meter display.
Read BOTH the temperature value and relative humidity (%RH) value shown on the display.
Reading guidance:
${guidance || '- Read the temperature value in whichever unit is shown on the display (°C or °F — read it exactly as shown, do not convert), and read the relative humidity value (%RH) shown alongside it.'}
- Ignore: dew point reading, min/max/hold annunciators, battery icon, mode/range text, and any other secondary readout on the screen.
- Preserve decimals exactly as shown.
- If any value is not visible or unreadable, return an empty string for that field.
- Do NOT guess or estimate.
- Respond with ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{
  "temp": "",
  "rh": ""
}`
    : `This is a photo of a FLUKE 971 Temperature Humidity Meter display.
Read ONLY the temperature value shown on the display.
Reading guidance:
${guidance || '- Read the temperature value in whichever unit is shown on the display (°C or °F — read it exactly as shown, do not convert).'}
- Ignore: relative humidity, dew point reading, min/max/hold annunciators, battery icon, mode/range text, and any other secondary readout on the screen.
- Preserve decimals exactly as shown.
- If the value is not visible or unreadable, return an empty string.
- Do NOT guess or estimate.
- Respond with ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{
  "value": ""
}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.6-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    if (isGrouped22U) {
      return {
        temp: String(parsed.temp ?? parsed.value ?? ""),
        rh: String(parsed.rh ?? ""),
      };
    } else {
      return {
        temp: String(parsed.value ?? parsed.temp ?? ""),
        rh: "",
      };
    }
  } catch {
    return { temp: "", rh: "" };
  }
}

export async function readPahuDisplay(
  base64Jpeg: string,
  fieldLabel: string,
  guidance?: string
): Promise<string> {
  const textPrompt = `This is a photo of an HVAC test instrument display.
Target field: ${fieldLabel}.

Reading guidance:
${guidance || '- Read the single target numeric value shown on the display in its shown unit. Preserve decimals.'}

General rules:
- Read ONLY the target numeric value in its shown unit, preserving decimals.
- Ignore secondary readouts, velocity/dew point/totalizer values, mode/range/min-max/hold text, and status/battery icons.
- If the value is not visible, unreadable, or missing, return an empty string.
- Do NOT guess or estimate.
- Respond with ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{"value":""}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.6-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    return String(parsed.value ?? "");
  } catch {
    return "";
  }
}

export async function readLcaDisplay(
  base64Jpeg: string,
  fieldLabel: string,
  guidance?: string
): Promise<string> {
  const textPrompt = `This is a photo of a test instrument or equipment display during a Life Cycle Assessment inspection.
Target field: ${fieldLabel}.

Reading guidance:
${guidance || '- Read the single target numeric value shown on the display in its shown unit, preserving decimals.'}

General rules:
- Read ONLY the target numeric value in its shown unit, preserving decimals.
- For Thermal Imager / Visual IR: Read ONLY the spot temperature value in °C. Ignore emissivity, color scale numbers, battery icon, and mode text.
- For Vibration Meter: Read ONLY the overall vibration velocity value in mm/s. Ignore acceleration/displacement readouts and mode/hold indicators.
- If the value is not visible, unreadable, or missing, return an empty string.
- Do NOT guess or estimate.
- Respond with ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{"value":""}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.6-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    return String(parsed.value ?? "");
  } catch {
    return "";
  }
}

export async function readCfmDisplay(
  base64Jpeg: string,
  guidance?: string
): Promise<string> {
  const textPrompt = `This is a photo of an airflow measurement instrument display (such as a Digital Anemometer G-tech AVM-02 or Volume Flow Hood Testo 420).
Target field: Actual Airflow (CFM).

Reading guidance:
${guidance || 'Read the single airflow value shown, in its displayed unit (CFM, CMM, or m³/h — read exactly as shown, do not convert). If using the anemometer or flow hood: ignore air-velocity (m/s, ft/min) and temperature readouts; read only the airflow/CFM figure. Ignore mode/range text, min/max/hold indicators, and battery icons.'}

General rules:
- Read ONLY the single airflow value shown, preserving decimals.
- Return ONLY valid JSON, no markdown fences, no explanation.

Required JSON shape:
{"value":""}`;

  const response = await ai.models.generateContent({
    model: "gemini-3.6-flash",
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Jpeg,
            },
          },
          {
            text: textPrompt,
          },
        ],
      },
    ],
  });

  const raw = (response.text ?? "").replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(raw);
    return String(parsed.value ?? "");
  } catch {
    return "";
  }
}


