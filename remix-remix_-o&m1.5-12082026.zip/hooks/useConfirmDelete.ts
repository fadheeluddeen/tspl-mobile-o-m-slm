
import { useState, useCallback } from 'react';

interface ModalConfig {
  isOpen: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
}

export const useConfirmDelete = () => {
  const [modalConfig, setModalConfig] = useState<ModalConfig>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });
  const [isDeleting, setIsDeleting] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error') => {
    setToast({ message, type });
  }, []);

  const hideToast = useCallback(() => {
    setToast(null);
  }, []);

  const confirmDelete = useCallback(({ 
    title = "Delete Confirmation", 
    message = "Are you sure you want to delete this pair?", 
    onConfirm 
  }: { 
    title?: string; 
    message?: string; 
    onConfirm: () => Promise<void> | void;
  }) => {
    setModalConfig({
      isOpen: true,
      title,
      message,
      onConfirm: async () => {
        setIsDeleting(true);
        try {
          // Add a small artificial delay for better UX
          await new Promise(resolve => setTimeout(resolve, 350));
          await onConfirm();
          showToast("Item deleted successfully.", "success");
          setModalConfig(prev => ({ ...prev, isOpen: false }));
        } catch (error) {
          showToast("Unable to delete item. Please try again.", "error");
        } finally {
          setIsDeleting(false);
        }
      },
    });
  }, [showToast]);

  const closeModal = useCallback(() => {
    setModalConfig(prev => ({ ...prev, isOpen: false }));
  }, []);

  return {
    modalConfig,
    isDeleting,
    toast,
    confirmDelete,
    closeModal,
    showToast,
    hideToast
  };
};
