const fs = require('fs');

const path = 'components/DGEnduranceTables.tsx';
let code = fs.readFileSync(path, 'utf8');

code = code.replace(/const kiIdx = headers\.indexOf\('kWh Generated Initial'\);/, 
  "const pLIdx = headers.indexOf('% LOAD');\n            const tIdx = headers.indexOf('TIME');\n            const kiIdx = headers.indexOf('kWh Generated Initial');");

code = code.replace(/percentLoad: '---',\n\s*time: '---',/, 
  "percentLoad: pLIdx >= 0 ? String(rowData[pLIdx] ?? '---') : '---',\n                time: tIdx >= 0 ? String(rowData[tIdx] ?? '---') : '---',");

fs.writeFileSync(path, code);
