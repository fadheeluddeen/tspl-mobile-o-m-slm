
export enum UserRole {
  ADMIN = 'ADMIN',
  DEVELOPER = 'DEVELOPER',
  PROJECT_MANAGER = 'PROJECT_MANAGER',
  ENGINEER = 'ENGINEER'
}

export enum WorkflowStatus {
  DRAFT = 'DRAFT',
  SUBMITTED = 'SUBMITTED',
  REJECTED = 'REJECTED',
  APPROVED = 'APPROVED',
  DELETION_PENDING = 'DELETION_PENDING',
  DELETION_APPROVED = 'DELETION_APPROVED'
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  status?: 'ACTIVE' | 'DISABLED';
}

export interface RolePermission {
  id: string; // The UserRole string
  actions: string[];
}

export interface AuditLog {
  id: string;
  timestamp: any;
  userEmail: string;
  userName: string;
  userRole: string;
  module: 'AUTH' | 'PROJECTS' | 'LIBRARY' | 'EXECUTION' | 'SYSTEM' | 'USERS' | 'PRIVILEGES';
  action: string;
  projectId?: string;
  status: 'SUCCESS' | 'FAILED' | 'INFO';
  details?: string;
  payload?: string; // Serialized JSON of changed data
}

export interface TestField {
  id: string;
  label: string;
  type: 'text' | 'number' | 'boolean' | 'date';
  required: boolean;
  unit?: string;
}

export interface TestTemplateMetadata {
  id: string;
  name: string;
  version: number;
  fileType: string;
  storagePath: string;
  uploadedBy: string;
  updatedAt: string;
  sizeBytes: number;
  downloadUrl?: string;
}

export interface TestDefinition {
  id: string;
  name: string;
  department: 'ELECTRICAL' | 'MECHANICAL' | 'ELV';
  version: number;
  schema: TestField[];
  linkedTemplate?: TestTemplateMetadata;
  aiEnabled: boolean;
  arcFlashTemplate?: ArcFlashReading;
  spdTemplate?: SPDReading;
  laTemplate?: LightningArrestorReading;
  earthStationTemplate?: EarthStationReading;
  spofTemplate?: SPOFReading;
  powerSystemTemplate?: PowerSystemReading;
  powerFactorTemplate?: PowerFactorReading;
  thermographyTemplate?: ThermographyReading;
  powerQualityTemplate?: PowerQualityReading;
  rciTemplate?: RackCoolingIndexReading;
  cfmTemplate?: CFMReading;
  dgEnduranceTemplate?: DGEnduranceReading;
  capacityAssessmentTemplate?: CapacityAssessmentReading;
  couponTestTemplate?: CouponTestReading;
  batteryImpedanceTemplate?: BatteryImpedanceReading;
  lifeCycleTemplate?: LifeCycleReading;
  elvGapTemplate?: ELVGapAssessmentReading;
  vibrationAnalysisTemplate?: VibrationAnalysisReading;
  liveCaptureConfig?: LiveCaptureConfig;
  status?: 'ACTIVE' | 'DELETED';
}

export interface LiveCaptureField {
  key: string;
  label: string;
  unit?: string;
  readingGuidance: string;
  group?: string;
  keepPhotoAsEvidence?: boolean;
}

export interface LiveCaptureTableConfig {
  tableKey: string;
  tableName?: string;
  matrix?: { rowsKey: string; colsKey: string };
  fields?: LiveCaptureField[];
}

export interface LiveCaptureConfig {
  fields?: LiveCaptureField[];
  tables?: LiveCaptureTableConfig[];
  jsonShape: Record<string, string>;
  keepPhotoAsEvidence: boolean;
}

export interface Project {
  id: string;
  projectId?: string;
  name: string;
  clientName: string;
  address: string;
  managerId: string;
  status: 'ACTIVE' | 'ARCHIVED';
  createdAt: string;
  approvedBy?: string;
  clientLogo?: string | null;
}

export interface TestAssignment {
  id: string;
  projectId: string;
  projectName?: string; // Added for robust reporting
  clientName?: string; // Customer name
  location?: string; // Colo/Floor name
  docNo?: string; // Editable Document Number
  testDefinitionId: string;
  testName: string;
  assignedEngineerId: string;
  status: 'IN_PROGRESS' | 'COMPLETED';
  workflowStatus: WorkflowStatus;
  pmComments?: string;
  readings: any;
  aiInsight?: string;
  aiInsightTimestamp?: string;
  rejectionCount?: number;
  pinnedBy?: string[]; // Array of user UIDs who pinned this test
  createdAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface SystemConfig {
  aiGlobalEnabled: boolean;
  aiEngineerAccess: boolean;
  lastHeartbeat: string;
  maintenanceMode: boolean;
}

// --- COMMON TYPES ---

export interface ObservationRecommendationRow {
  id: string;
  observation: string;
  recommendation: string;
  lifeCycleStatus?: string;
  noOfEquipment?: string;
  equipmentTag?: string;
}

// --- LIFE CYCLE ASSESSMENT ---

export interface LifeCycleAssessmentRow {
  id: string;
  equipmentTag: string;
  makeModel: string;
  serialNo: string;
  location: string;
  installYear: string;
  currentYear: string;
  ageYrs: string;
  vibrationScore: string;
  corrosionScore: string;
  maintScore: string;
  healthIndex: string;
  runningLifeYrs: string;
  utilizationRatio: string;
  utilizationFactor: string;
  // Table 2 (RUL Calculation) fields
  designLifeYrs?: string;
  adjustedLifeAL?: string;
  rulYrs?: string;
  rulPct?: string;
  lifeCycleStatus?: string;
  remarksRul?: string;
  // Raw condition-monitoring captured readings
  surfaceTemp?: string;       // Surface temperature (°C) from Thermal Imager
  thermalImageUrl?: string;   // Firebase Storage URL for thermal evidence photo
  vibrationVelocity?: string; // Overall vibration velocity (mm/s) from Vibration Meter
}

export interface LifeCycleReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  equipmentList: SPOFEquipmentRow[];
  lifeCycleRows: LifeCycleAssessmentRow[];
  rulRows?: LifeCycleAssessmentRow[];
  observationsAndRecommendations: ObservationRecommendationRow[];
  pahuPacInfoRows?: any[];
  pahuPacPerformanceRows?: any[];
}

// --- BATTERY IMPEDANCE HIERARCHY ---

export interface BatteryReading {
  id: string;
  batteryNo: number;
  measuredIr: string;      // mΩ
  irFailThresh: string;
  irWarnThresh: string;
  measuredVolt: string;    // V
  voltThresh: string;
  remarks: string;         // Calculated: PASS/FAIL/WARN
}

export interface BatteryString {
  id: string;
  name: string;
  isCollapsed: boolean;
  readings: BatteryReading[];
}

export interface BatteryUPS {
  id: string;
  name: string;
  location: string;
  make: string;
  batteryType: string;
  strings: BatteryString[];
}

export interface BatteryImpedanceReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  equipmentList: SPOFEquipmentRow[];
  upsSystems: BatteryUPS[];
  recommendations: string;
}

// --- SPECIALIZED TEST TYPES ---

export interface ArcFlashPPE {
  id: string;
  category: string;
  minEnergy: string;
  clothing: string;
}

export interface GloveClassReading {
  id: string;
  class: string;
  acProof: string;
  maxAc: string;
  dcProof: string;
  maxDc: string;
}

export interface ArcFlashWorkingDistance {
  id: string;
  equipClass: string;
  mm: string;
  inch: string;
  busGap: string;
}

export interface ArcFlashStudyResult {
  id: string;
  busId: string;
  nomKv: string;
  type: string;
  bolted: string;
  arcing: string;
  fct: string;
  energy: string;
  afb: string;
  level: string;
}

export interface ArcFlashReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  ppeCategories: ArcFlashPPE[];
  gloveClasses: GloveClassReading[];
  workingDistances: ArcFlashWorkingDistance[];
  studyResults: ArcFlashStudyResult[];
  observations: string;
  recommendations: string;
}

export interface SPDInspectionRow {
  id: string;
  location: string;
  panelName: string;
  make: string;
  model: string;
  rating: string;
  remark: string;
}

export interface SPDReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  inspections: SPDInspectionRow[];
  equipmentList: SPOFEquipmentRow[];
  observations: string;
  recommendations: string;
}

export interface LAEquipmentRow {
  id: string;
  name: string;
  make: string;
  serial: string;
  model: string;
  calDate: string;
  dueDate: string;
}

export interface LAReadingRow {
  id: string;
  pitName: string;
  location: string;
  conductorType: string;
  groundingValue: string;
  acceptValue: string;
  remarks: string;
  result: string;
}

export interface LightningArrestorReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  equipmentList: LAEquipmentRow[];
  laReadings: LAReadingRow[];
  remarks: string;
  recommendations: string;
  status: 'PENDING' | 'PASS' | 'FAIL';
}

export interface EarthEquipmentRow {
  id: string;
  name: string;
  make: string;
  serial: string;
  model: string;
  calDate: string;
  expDate: string;
}

export interface EarthMeasuringRow {
  id: string;
  pitNo: string;
  description: string;
  measuredValue: string;
  limitValue: string;
  remarks: string;
}

export interface EarthStationReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  equipmentList: EarthEquipmentRow[];
  readings: EarthMeasuringRow[];
  observations: string;
  recommendations: string;
}

export interface SPOFEquipmentRow {
  id: string;
  name: string;
  make: string;
  model: string;
  serialNo: string;
  calDate: string;
  expDate: string;
}

export interface SPOFInspectionRow {
  id: string;
  criticalEquipment: string;
  source: string;
  redundant: string;
  remarks: string;
}

export interface SPOFDCSection {
  id: string;
  name: string;
  rows: SPOFInspectionRow[];
}

export interface SPOFReading {
  status: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  approvedBy: string;
  testDate: string;
  scopeDescription: string;
  equipmentList: SPOFEquipmentRow[];
  dcSections: SPOFDCSection[];
  observationsAndRecommendations: ObservationRecommendationRow[];
}

export interface ELVChecklistRow {
  id: string;
  no: string;
  description: string;
  result: 'Yes' | 'No' | 'N/A' | '';
  remarks: string;
  correctiveActions: string;
  isHeader?: boolean;
}

export interface ELVGapAnalysisRow {
  id: string;
  no: number;
  standard: string;
  section: string;
  requirement: string;
  system: string;
  implementation: string;
  compliance: 'Yes' | 'No' | 'N/A' | '-';
  correctiveActions: string;
}

export interface ELVGapAssessmentReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  systems: {
    [key: string]: ELVChecklistRow[];
  };
  gapAnalysisRows?: ELVGapAnalysisRow[];
  observationsAndRecommendations: ObservationRecommendationRow[];
}

export interface DGOnSiteTestRow {
  id: string;
  srNo: string;
  description: string;
  result: boolean;
}

export interface DGLoadReadingRow {
  id: string;
  parameter: string;
  unit: string;
  v0: string;
  v25: string;
  v50: string;
  v75: string;
  v100: string;
  remarks: string;
}

export interface DGFuelSummaryRow {
  id: string;
  srNo: string;
  percentLoad: string;
  time: string;
  kwhInitial: string;
  kwhFinal: string;
  kwhUnits: string;
  fuelInitial: string;
  fuelFinal: string;
  fuelConsum: string;
  oemStd: string;
  efficiency: string;
}

export interface DGUnit {
  id: string;
  unitName: string;
  standardInfo: {
    description: string;
    standardNumber: string;
    author: string;
    category: string;
    subcategory: string;
    performedDate: string;
  };
  equipmentDetails: {
    make: string;
    model: string;
    nomenclature: string;
    engineNumber: string;
    alternatorSerial: string;
    location: string;
  };
  loadReadings: DGLoadReadingRow[];
  transientSummary: { id: string, srNo: string, load: string, result: string }[];
  noiseLevels: { load: string, open: string, closed: string }[];
  vibrationLevels: { load: string, a: string, b: string, c: string, d: string, e: string, f: string, g: string, h: string }[];
  fuelSummary: DGFuelSummaryRow[];
}

export interface DGEnduranceReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  onSiteTests: DGOnSiteTestRow[];
  equipmentList: SPOFEquipmentRow[];
  dgUnits: DGUnit[];
  observations: string;
  recommendations: string;
}

export interface PowerTfColumn {
  id: string;
  header: string;
  values: string[]; 
}

export interface PowerBranchLoadRow {
  id: string;
  cableId: string;
  from: string;
  to: string;
  type: string;
  size: string;
  ampacity: string;
  loadingAmp: string;
  percent: string;
  mkr: string;
}

export interface PowerTfLoadRow {
  id: string;
  branchId: string;
  equipment: string;
  inputKw: string;
  outputKw: string;
  losses: string;
  percentLoss: string;
}

export interface PowerBusVoltageRow {
  id: string;
  busId: string;
  nominalKv: string;
  operatingKv: string;
  percentVolt: string;
  remark: string;
}

export interface PowerShortCircuitRow {
  id: string;
  location: string;
  busVoltKv: string;
  threePhaseKa: string;
  lineToGroundKa: string;
  busRatingKa: string;
  isHeader?: boolean;
}

export interface LoadFlowRow {
  id: string;
  location: string;
  busVoltKv: string;
  powerMva: string;
  realPowerMw: string;
  reactivePowerMvar: string;
  pf: string;
  isHeader?: boolean;
}

export interface RelayCoordRow {
  id: string;
  relayNo: string;
  feeder: string;
  ratedCurrent?: string;
  relayType: string;
  ctRatio: string;
  isHeader?: boolean;
  existing: {
    curve: string;
    plug: string;
    tms: string;
    opTimeCloseInFault?: string;
    hiI: string;
    hiT: string;
  };
  suggested: {
    curve: string;
    plug: string;
    tms: string;
    hiI: string;
    hiT: string;
  };
  remarks: string;
}

export interface ReleaseSettingsRow {
  id: string;
  slNo: string;
  feederName: string;
  ratedCurrent: string;
  breakerType: string;
  relayMakeType: string;
  isHeader?: boolean;
  existing: {
    longTimePickup: string;
    longTimeTime: string;
    shortTimePickup: string;
    shortTimeTime: string;
    instantaneous: string;
    earthPickup: string;
    earthTime: string;
  };
  proposed: {
    longTimePickup: string;
    longTimeTime: string;
    shortTimePickup: string;
    shortTimeTime: string;
    instantaneous: string;
    earthPickup: string;
    earthTime: string;
  };
  remarks: string;
}

export interface PowerArcFlashRow {
  id: string;
  locationName: string;
  nominalKv: string;
  boltedKa: string;
  arcingKa: string;
  fctSecs: string;
  incidentEnergy: string;
  afbM: string;
  workingDistanceCm: string;
  energyLevel: string;
  remarks: string;
  isHeader?: boolean;
}

export interface PowerSystemReading {
  revisionNo: string;
  preparedBy: string;
  testedBy: string;
  approvedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  transformers: PowerTfColumn[];
  loadFlow: LoadFlowRow[];
  busVoltages: PowerBusVoltageRow[];
  shortCircuit: PowerShortCircuitRow[];
  relayPhase: RelayCoordRow[];
  relayEarth: RelayCoordRow[];
  releaseSettings: ReleaseSettingsRow[];
  arcFlashAnalysis: PowerArcFlashRow[];
  observations: string;
  recommendations: string;
}

export interface PowerFactorBankRow {
  id: string;
  feederName: string;
  bankKvar: string;
  breakerRating: string;
  contactorRating: string;
  obtainedCap: string;
  actualRY: string;
  actualYB: string;
  actualBR: string;
  measuredKvar: string;
  acceptableLimit: string;
  remarks: string;
}

export interface PowerFactorBalanceRow {
  id: string;
  feederName: string;
  caseTemp: string;
  currentR: string;
  currentY: string;
  currentB: string;
  remarks: string;
}

export interface PowerFactorPanel {
  id: string;
  panelName: string;
  bankRows: PowerFactorBankRow[];
  balanceRows: PowerFactorBalanceRow[];
}

export interface PowerFactorReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  equipmentList: SPOFEquipmentRow[];
  panels: PowerFactorPanel[];
  observations: string;
  recommendations: string;
}

export interface ThermographyToolRow {
  id: string;
  instrumentName: string;
  make: string;
  model: string;
  serialNumber: string;
  calibrationIssue: string;
  calibrationExpiry: string;
}

export interface ThermographyInspectionRow {
  id: string;
  roomName: string;
  panelName: string;
  feederName: string;
  maxTemp: string;
  minTemp: string;
  remarks: string;
}

export interface ThermographyImageRow {
  id: string;
  roomName: string;
  panelName: string;
  feederName: string;
  imageUrl: string;
  remarks: string;
}

export interface ThermographyReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  equipmentList: ThermographyToolRow[];
  inspections: ThermographyInspectionRow[];
  images: ThermographyImageRow[];
  observations: string;
  recommendations: string;
}

export interface PQHarmonicPhase {
  max: string;
  min: string;
  avg: string;
}

export interface PQAnalysisGroup {
  id: string;
  title: string;
  type: 'MLTP' | 'CHILLER' | 'UPS';
  dateFrom: string;
  dateTo: string;
  frequency: { average: string; limits: string; remark: string; imageUrl: string };
  voltage: { ry: string; yb: string; br: string; rn: string; yn: string; bn: string; limits: string; remark: string; imageUrl: string };
  current: { r: string; y: string; b: string; note: string; imageUrl: string };
  activePower: { average: string; remark: string; note: string; imageUrl: string };
  apparentPower: { average: string; remark: string; note: string; imageUrl: string };
  reactivePower: { average: string; remark: string; note: string; imageUrl: string };
  powerFactor: { average: string; limits: string; remark: string; imageUrl: string };
  thdv: { r: PQHarmonicPhase; y: PQHarmonicPhase; b: PQHarmonicPhase; limits: string; remark: string; imageUrl: string };
  thdi: { r: PQHarmonicPhase; y: PQHarmonicPhase; b: PQHarmonicPhase; limits: string; remark: string; imageUrl: string };
  voltageUnbalance: { average: string; limits: string; remark: string; imageUrl: string };
  currentUnbalance: { average: string; limits: string; remark: string; imageUrl: string };
}

export interface PowerQualityReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  status?: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  equipmentList: ThermographyToolRow[];
  analysisGroups: PQAnalysisGroup[];
  observations: string;
  recommendations: string;
}

// --- RACK COOLING INDEX (HIGH FIDELITY) ---

export interface RCITemperatureRow {
  id: string;
  sNo: string;
  cacRef: string;
  rackRef: string;
  front15U: string;
  front22U: string;
  front35U: string;
  rear15U: string;
  rear22U: string;
  rear35U: string;
  rhFront: string;
  rhRear: string;
  inletTempResult: string;
  excessInletTemp: string;
  deficitInletTemp: string;
}

export interface RCICacGroup {
  id: string;
  cacName: string;
  temperatureRows: RCITemperatureRow[];
}

export interface RCIAuditToolRow {
  id: string;
  calibrationDate: string;
  expiryDate: string;
}

export interface RackCoolingIndexReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  toolCalibrationDate?: string;
  toolExpiryDate?: string;
  status?: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  equipmentList: SPOFEquipmentRow[];
  toolsUsedForAudit?: RCIAuditToolRow[];
  dc1Groups: RCICacGroup[];
  observationsAndRecommendations: ObservationRecommendationRow[];
}

// --- CFM (HIGH FIDELITY AIRFLOW CAPACITY) ---

export interface CFMCacRow {
  id: string;
  rackRef: string;
  loadW: string;
  actualCFM: string;
}

export interface CFMCacTable {
  id: string;
  cacName: string;
  deltaT: string;
  multiplier: string;
  leftRows: CFMCacRow[];
  rightRows: CFMCacRow[];
}

export interface CFMToolRow {
  id: string;
  instrumentName: string;
  purpose: string;
  make: string;
  model: string;
  calibrationIssue: string;
  calibrationExpiry: string;
}

export interface CFMReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  deltaT?: string;
  multiplier?: string;
  status?: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  equipmentList: SPOFEquipmentRow[];
  toolsUsed: CFMToolRow[];
  cacTables: CFMCacTable[];
  isVerified?: boolean;
  importedPahuCfm?: string;
  importedPacCfm?: string;
  importedPahuTr?: string;
  importedPacTr?: string;
  observationsAndRecommendations: ObservationRecommendationRow[];
}

// --- CAPACITY ASSESSMENT PAHU & PAC ---

export interface CapacityToolRow {
  id: string;
  instrumentName: string;
  make: string;
  model: string;
  serialNumber: string;
  calibrationIssue: string;
  calibrationExpiry: string;
}

export interface PahuEntry {
  id: string;
  equipmentId: string;
  modelNo: string;
  serialNo: string;
  // Design Specs
  designAirflow: string;
  designRaTemp: string;
  designSaTemp: string;
  designPower: string;
  designWaterFlowRate: string;
  designCoolingTonnage: string;
  // Measured Data
  measuredAirflow: string;
  measuredSaTemp: string;
  measuredRaTemp: string;
  measuredFanSpeed: string;
  measuredCoolingTonnage: string; // Measured Air Side cooling tonnage
  measuredPower: string;
  measuredChwIn: string;
  measuredChwOut: string;
  measuredValveOpening: string;
  measuredWaterFlowRate: string;
  measuredWaterCoolingTonnage: string; // Measured Water Side cooling tonnage
}

export interface PacEntry {
  id: string;
  equipmentId: string;
  modelNo: string;
  serialNo: string;
  // Design Specs
  designAirflow: string;
  designRaTemp: string;
  designSaTemp: string;
  designPower: string;
  designCoolingTonnage: string;
  fanSpeed: string;
  // Measured Data
  measuredAirflow: string;
  measuredRaTemp: string;
  measuredSaTemp: string;
  measuredPower: string;
  measuredCoolingTonnage: string;
  measuredFanSpeed: string;
}

export interface PahuTable {
  id: string;
  tableNumber: string;
  title: string;
  entries: PahuEntry[];
}

export interface PacTable {
  id: string;
  tableNumber: string;
  title: string;
  entries: PacEntry[];
}

export interface CapacityAssessmentReading {
  itLoad?: string;
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  toolsUsed: CapacityToolRow[];
  pahuTables: PahuTable[];
  pacTables: PacTable[];
  observationsAndRecommendations: ObservationRecommendationRow[];
}

// --- COUPON TEST (CORROSION MONITORING) ---

export interface CouponToolRow {
  id: string;
  name: string;
  make: string;
  parameter: string;
}

export interface CorrosionReadingRow {
  id: string;
  couponType: 'Copper (Cu)' | 'Silver (Ag)';
  oxide: string;
  chloride: string;
  sulfide: string;
  other: string;
  totalAngstroms: number; 
  isaLevel: string;
  remarks: string;
}

export interface CouponLocation {
  id: string;
  locationName: string;
  results: CorrosionReadingRow[]; // Cu and Ag rows
  graphImage: string; // Base64
}

export interface CouponTestReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  toolsUsed: CouponToolRow[];
  locations: CouponLocation[];
  observationsAndRecommendations: ObservationRecommendationRow[];
}

// --- VIBRATION ANALYSIS ---

export interface VibrationToolRow {
  id: string;
  instrumentName: string;
  purpose: string;
  make: string;
  model: string;
  calibrationIssue: string;
  calibrationExpiry: string;
  cellStyles?: Record<string, {
    align?: 'left' | 'center' | 'right';
    valign?: 'top' | 'middle' | 'bottom';
    colSpan?: number;
    rowSpan?: number;
  }>;
}

export interface AbbreviationRow {
  id: string;
  abbreviation: string;
  fullMeaning: string;
}

export interface VibrationSummaryRow {
  id: string;
  equipmentId: string;
  classDetails: string;
  vertical: string;
  horizontal: string;
  axial: string;
  maxValue: string;
  condition: string;
  cellStyles?: Record<string, {
    align?: 'left' | 'center' | 'right';
    valign?: 'top' | 'middle' | 'bottom';
    colSpan?: number;
    rowSpan?: number;
  }>;
}

export interface VibrationSummaryGroup {
  id: string;
  groupName: string;
  rows: VibrationSummaryRow[];
}

export interface VibrationAnalysisReading {
  preparedBy: string;
  testedBy: string;
  testerEmail: string;
  witnessedBy: string;
  testDate: string;
  status?: 'PENDING' | 'IN_PROGRESS' | 'PASS' | 'FAIL';
  toolsUsed: VibrationToolRow[];
  abbreviations: AbbreviationRow[];
  summaryGroups: VibrationSummaryGroup[];
  observationsAndRecommendations: ObservationRecommendationRow[];
}
