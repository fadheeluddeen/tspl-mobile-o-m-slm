const fs = require('fs');
const path = 'components/DGEnduranceTables.tsx';
let code = fs.readFileSync(path, 'utf8');

const importExportMethods = `
  const handleExportExcel = () => {
    exportDGEnduranceToExcel(data, \`DG_Endurance_Test_\${new Date().toISOString().split('T')[0]}.xlsx\`);
    showToast('Exported DG Endurance tables to Excel!', 'success');
  };

  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const dataContent = evt.target?.result;
        const workbook = XLSX.read(dataContent, { type: 'binary' });
        
        let newDgUnits = [...(data.dgUnits || [])];

        workbook.SheetNames.forEach(sheetName => {
          const match = sheetName.match(/^DG(\\d+) - (.*)$/);
          if (!match) return;
          const uIdx = parseInt(match[1]) - 1;
          const tableType = match[2];
          
          if (!newDgUnits[uIdx]) {
            newDgUnits[uIdx] = {
              id: \`dg-imported-\${Date.now()}-\${uIdx}\`,
              unitName: \`DC-01 DG-\${(uIdx + 1).toString().padStart(2, '0')}\`,
              standardInfo: { description: '---', standardNumber: '---', author: '---', category: '---', subcategory: '---', performedDate: '---' },
              equipmentDetails: { make: '---', model: '---', nomenclature: '---', engineNumber: '---', alternatorSerial: '---', location: '---' },
              loadReadings: [],
              transientSummary: [],
              noiseLevels: [],
              vibrationLevels: [],
              fuelSummary: []
            };
          }

          const worksheet = workbook.Sheets[sheetName];
          const rows: any[] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          if (rows.length === 0) return;

          let headerRowIndex = -1;
          for (let i = 0; i < Math.min(10, rows.length); i++) {
            if (rows[i] && rows[i].length > 0) {
              headerRowIndex = i;
              break;
            }
          }
          if (headerRowIndex === -1) return;

          const headers = rows[headerRowIndex].map((h: any) => String(h || '').trim());
          const unit = newDgUnits[uIdx];

          if (tableType === 'Parameters') {
            const pIdx = headers.indexOf('Parameter');
            const uIdxHead = headers.indexOf('Unit');
            const remIdx = headers.indexOf('Remarks');
            
            const v0Idx = headers.findIndex(h => h === '0' || h === '0%');
            const v25Idx = headers.findIndex(h => h === '25' || h === '25%');
            const v50Idx = headers.findIndex(h => h === '50' || h === '50%');
            const v75Idx = headers.findIndex(h => h === '75' || h === '75%');
            const v100Idx = headers.findIndex(h => h === '100' || h === '100%');

            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const paramName = pIdx >= 0 ? String(rowData[pIdx] || '') : '';
              if (!paramName) continue;
              
              const existingRow = unit.loadReadings.find(r => r.parameter === paramName);
              if (existingRow) {
                if (uIdxHead >= 0) existingRow.unit = String(rowData[uIdxHead] ?? existingRow.unit);
                if (v0Idx >= 0) existingRow.v0 = String(rowData[v0Idx] ?? existingRow.v0);
                if (v25Idx >= 0) existingRow.v25 = String(rowData[v25Idx] ?? existingRow.v25);
                if (v50Idx >= 0) existingRow.v50 = String(rowData[v50Idx] ?? existingRow.v50);
                if (v75Idx >= 0) existingRow.v75 = String(rowData[v75Idx] ?? existingRow.v75);
                if (v100Idx >= 0) existingRow.v100 = String(rowData[v100Idx] ?? existingRow.v100);
                if (remIdx >= 0) existingRow.remarks = String(rowData[remIdx] ?? existingRow.remarks);
              } else {
                unit.loadReadings.push({
                  id: \`row-\${Math.random()}\`,
                  parameter: paramName,
                  unit: uIdxHead >= 0 ? String(rowData[uIdxHead] || '') : '',
                  v0: v0Idx >= 0 ? String(rowData[v0Idx] || '') : '',
                  v25: v25Idx >= 0 ? String(rowData[v25Idx] || '') : '',
                  v50: v50Idx >= 0 ? String(rowData[v50Idx] || '') : '',
                  v75: v75Idx >= 0 ? String(rowData[v75Idx] || '') : '',
                  v100: v100Idx >= 0 ? String(rowData[v100Idx] || '') : '',
                  remarks: remIdx >= 0 ? String(rowData[remIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Transient Load') {
            const sIdx = headers.indexOf('Sr No');
            const lIdx = headers.indexOf('Transient Load');
            const rIdx = headers.indexOf('Result');
            
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const loadName = lIdx >= 0 ? String(rowData[lIdx] || '') : '';
              if (!loadName) continue;

              const existingRow = unit.transientSummary.find(r => r.load === loadName);
              if (existingRow) {
                if (sIdx >= 0) existingRow.srNo = String(rowData[sIdx] ?? existingRow.srNo);
                if (rIdx >= 0) existingRow.result = String(rowData[rIdx] ?? existingRow.result);
              } else {
                unit.transientSummary.push({
                  id: \`row-\${Math.random()}\`,
                  srNo: sIdx >= 0 ? String(rowData[sIdx] || '') : '',
                  load: loadName,
                  result: rIdx >= 0 ? String(rowData[rIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Noise Level') {
            const lIdx = headers.indexOf('Load in %');
            const oIdx = headers.indexOf('Doors Open');
            const cIdx = headers.indexOf('Doors Closed');
            
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const loadName = lIdx >= 0 ? String(rowData[lIdx] || '') : '';
              if (!loadName) continue;

              const existingRow = unit.noiseLevels.find(r => r.load === loadName);
              if (existingRow) {
                if (oIdx >= 0) existingRow.open = String(rowData[oIdx] ?? existingRow.open);
                if (cIdx >= 0) existingRow.closed = String(rowData[cIdx] ?? existingRow.closed);
              } else {
                unit.noiseLevels.push({
                  load: loadName,
                  open: oIdx >= 0 ? String(rowData[oIdx] || '') : '',
                  closed: cIdx >= 0 ? String(rowData[cIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Vibration') {
            const lIdx = headers.indexOf('Load %');
            const aIdx = headers.indexOf('A');
            const bIdx = headers.indexOf('B');
            const cIdx = headers.indexOf('C');
            const dIdx = headers.indexOf('D');
            const eIdx = headers.indexOf('E');
            const fIdx = headers.indexOf('F');
            const gIdx = headers.indexOf('G');
            const hIdx = headers.indexOf('H');
            
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const loadName = lIdx >= 0 ? String(rowData[lIdx] || '') : '';
              if (!loadName) continue;

              const existingRow = unit.vibrationLevels.find(r => r.load === loadName);
              if (existingRow) {
                if (aIdx >= 0) existingRow.a = String(rowData[aIdx] ?? existingRow.a);
                if (bIdx >= 0) existingRow.b = String(rowData[bIdx] ?? existingRow.b);
                if (cIdx >= 0) existingRow.c = String(rowData[cIdx] ?? existingRow.c);
                if (dIdx >= 0) existingRow.d = String(rowData[dIdx] ?? existingRow.d);
                if (eIdx >= 0) existingRow.e = String(rowData[eIdx] ?? existingRow.e);
                if (fIdx >= 0) existingRow.f = String(rowData[fIdx] ?? existingRow.f);
                if (gIdx >= 0) existingRow.g = String(rowData[gIdx] ?? existingRow.g);
                if (hIdx >= 0) existingRow.h = String(rowData[hIdx] ?? existingRow.h);
              } else {
                unit.vibrationLevels.push({
                  load: loadName,
                  a: aIdx >= 0 ? String(rowData[aIdx] || '') : '',
                  b: bIdx >= 0 ? String(rowData[bIdx] || '') : '',
                  c: cIdx >= 0 ? String(rowData[cIdx] || '') : '',
                  d: dIdx >= 0 ? String(rowData[dIdx] || '') : '',
                  e: eIdx >= 0 ? String(rowData[eIdx] || '') : '',
                  f: fIdx >= 0 ? String(rowData[fIdx] || '') : '',
                  g: gIdx >= 0 ? String(rowData[gIdx] || '') : '',
                  h: hIdx >= 0 ? String(rowData[hIdx] || '') : ''
                });
              }
            }
          } else if (tableType === 'Fuel Consum' || tableType === 'Fuel Consumption') {
            const sIdx = headers.indexOf('Sr No');
            const kiIdx = headers.indexOf('kWh Generated Initial');
            const kfIdx = headers.indexOf('kWh Generated Final');
            const fiIdx = headers.indexOf('Fuel in Litres Initial');
            const ffIdx = headers.indexOf('Fuel in Litres Final');
            const stdIdx = headers.indexOf('OEM Std (L/H)');
            
            unit.fuelSummary = []; // clear to replace or we can try to merge by srNo
            for (let i = headerRowIndex + 1; i < rows.length; i++) {
              const rowData = rows[i];
              if (!rowData || rowData.length === 0) continue;
              const srNo = sIdx >= 0 ? String(rowData[sIdx] || '') : '';
              if (!srNo && !rowData[kiIdx]) continue;
              
              const rowObj = {
                id: \`f-\${Date.now()}-\${i}\`,
                srNo: srNo,
                percentLoad: '---',
                time: '---',
                kwhInitial: kiIdx >= 0 ? String(rowData[kiIdx] ?? '0') : '0',
                kwhFinal: kfIdx >= 0 ? String(rowData[kfIdx] ?? '0') : '0',
                kwhUnits: '0',
                fuelInitial: fiIdx >= 0 ? String(rowData[fiIdx] ?? '0') : '0',
                fuelFinal: ffIdx >= 0 ? String(rowData[ffIdx] ?? '0') : '0',
                fuelConsum: '0',
                oemStd: stdIdx >= 0 ? String(rowData[stdIdx] ?? '---') : '---',
                efficiency: '0.00'
              };
              unit.fuelSummary.push(calculateFuelRow(rowObj));
            }
          }
        });
        
        updateField('dgUnits', newDgUnits);
        showToast("DG Endurance data imported successfully!", "success");
      } catch (err) {
        console.error(err);
        showToast("Failed to parse Excel file.", "error");
      }
    };
    reader.readAsBinaryString(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };
`;

const insertMarker = 'const { modalConfig, isDeleting, toast, confirmDelete, closeModal, hideToast, showToast } = useConfirmDelete();';

if (!code.includes('handleExportExcel')) {
  code = code.replace(insertMarker, insertMarker + "\n" + importExportMethods);
  fs.writeFileSync(path, code);
}
