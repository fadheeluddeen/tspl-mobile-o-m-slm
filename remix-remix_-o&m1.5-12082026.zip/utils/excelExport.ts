import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { 
  ThermographyReading, 
  CapacityAssessmentReading, 
  RackCoolingIndexReading, 
  LifeCycleReading, 
  VibrationAnalysisReading,
  BatteryImpedanceReading,
  EarthStationReading,
  PowerFactorReading,
  LightningArrestorReading,
  DGEnduranceReading,
  DGUnit,
  DGLoadReadingRow,
  DGFuelSummaryRow
} from '../types';

/**
 * Recalculate TR for O&M Excel cell matching
 */
const calculateTR = (cfm: string, ra: string, sa: string): number => {
  const cfmVal = parseFloat(String(cfm).replace(/,/g, ''));
  const raVal = parseFloat(String(ra).replace(/,/g, ''));
  const saVal = parseFloat(String(sa).replace(/,/g, ''));
  if (isNaN(cfmVal) || isNaN(raVal) || isNaN(saVal)) return 0;
  return (1.06 * cfmVal * (raVal - saVal) * 1.8) / 12000;
};

/**
 * 1. Thermography Inspection Table Export
 */
export const exportThermographyToExcel = async (data: ThermographyReading, fileName: string) => {
    const workbook = new ExcelJS.Workbook();
    
    const wsInspection = workbook.addWorksheet('Thermography Inspection');
    
    wsInspection.columns = [
        { header: 'S.NO', key: 'sNo', width: 8, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'ROOM NAME', key: 'roomName', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'PANEL NAME', key: 'panelName', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'FEEDER NAME', key: 'feederName', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'MAX TEMP °C', key: 'maxTemp', width: 15, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'MIN TEMP °C', key: 'minTemp', width: 15, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'REMARKS', key: 'remarks', width: 35, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } }
    ];

    const headerRow1 = wsInspection.getRow(1);
    headerRow1.height = 24;
    headerRow1.eachCell((cell) => {
        styleHeaderCell(cell, 'FFF97316'); // Reuse helper (Orange-500)
    });

    (data.inspections || []).forEach((r, idx) => {
        const row = wsInspection.addRow({
            sNo: idx + 1,
            roomName: r.roomName,
            panelName: r.panelName,
            feederName: r.feederName,
            maxTemp: r.maxTemp,
            minTemp: r.minTemp,
            remarks: r.remarks
        });
        row.height = 22;
        
        row.eachCell((cell, colNumber) => {
            applyBorderGrid(cell); // Reuse helper
            cell.font = {
                name: 'Arial', size: 10,
                color: colNumber === 5 ? { argb: 'FFDC2626' } : colNumber === 6 ? { argb: 'FF2563EB' } : undefined,
                bold: colNumber === 2 || colNumber === 3 || colNumber === 5 || colNumber === 6,
                italic: colNumber === 7
            } as any;
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
        });
    });

    const wsImages = workbook.addWorksheet('Critical Images');
    wsImages.columns = [
        { header: 'S.NO', key: 'sNo', width: 8, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'ROOM NAME', key: 'roomName', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'PANEL NAME', key: 'panelName', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'FEEDER NAME', key: 'feederName', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'CRITICAL IMAGES', key: 'imageUrl', width: 30, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } },
        { header: 'REMARKS', key: 'remarks', width: 35, style: { alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } }
    ];

    const headerRow2 = wsImages.getRow(1);
    headerRow2.height = 24;
    headerRow2.eachCell((cell) => {
        styleHeaderCell(cell, 'FFF97316'); // Reuse helper (Orange-500)
    });

    const imagePromises = (data.images || []).map(async (img, idx) => {
        const row = wsImages.addRow({
            sNo: idx + 1,
            roomName: img.roomName,
            panelName: img.panelName,
            feederName: img.feederName,
            imageUrl: img.imageUrl ? 'Image Loading...' : 'No Image',
            remarks: img.remarks
        });
        row.height = 22;
        
        row.eachCell((cell, colNumber) => {
            applyBorderGrid(cell); // Reuse helper
            cell.font = {
                name: 'Arial', size: 10,
                bold: colNumber === 2 || colNumber === 3,
                italic: colNumber === 6
            };
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
        });

        if (img.imageUrl) {
            if (img.imageUrl.startsWith('data:image')) {
                try {
                    const imageId = workbook.addImage({
                        base64: img.imageUrl,
                        extension: img.imageUrl.includes('png') ? 'png' : 'jpeg',
                    });
                    row.getCell(5).value = '';
                    wsImages.addImage(imageId, {
                        tl: { col: 4, row: idx + 1 },
                        ext: { width: 150, height: 100 }
                    });
                    row.height = 80;
                } catch (e) {
                    console.error("Failed to add image to Excel", e);
                    row.getCell(5).value = 'Error loading image';
                }
            } else if (img.imageUrl.startsWith('http')) {
                try {
                    const response = await fetch(img.imageUrl);
                    if (!response.ok) throw new Error(`HTTP status ${response.status}`);
                    const arrayBuffer = await response.arrayBuffer();
                    
                    let extension: 'png' | 'jpeg' = 'jpeg';
                    if (img.imageUrl.toLowerCase().includes('.png')) {
                        extension = 'png';
                    }
                    
                    const imageId = workbook.addImage({
                        buffer: new Uint8Array(arrayBuffer),
                        extension: extension,
                    });
                    row.getCell(5).value = '';
                    wsImages.addImage(imageId, {
                        tl: { col: 4, row: idx + 1 },
                        ext: { width: 150, height: 100 }
                    });
                    row.height = 80;
                } catch (e) {
                    console.error("Failed to fetch or add remote image to Excel:", img.imageUrl, e);
                    row.getCell(5).value = 'Error loading image';
                }
            }
        }
    });

    await Promise.all(imagePromises);

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), fileName);
};

/**
 * Helpers to style cells/rows elegantly
 */
export const styleHeaderCell = (cell: any, bg: string, isWhiteText: boolean = true) => {
  cell.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: bg }
  };
  cell.font = {
    color: isWhiteText ? { argb: 'FFFFFFFF' } : { argb: 'FF1E293B' },
    bold: true,
    name: 'Arial',
    size: 10
  };
  cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
  cell.border = {
    top: { style: 'thin', color: { argb: 'FFFFFFFF' } },
    left: { style: 'thin', color: { argb: 'FFFFFFFF' } },
    bottom: { style: 'thin', color: { argb: 'FFFFFFFF' } },
    right: { style: 'thin', color: { argb: 'FFFFFFFF' } }
  };
};

export const applyBorderGrid = (cell: any) => {
  cell.border = {
    top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
    left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
    bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
    right: { style: 'thin', color: { argb: 'FFCBD5E1' } }
  };
};

/**
 * 2. Capacity Assessment (PAHU / PAC) Export
 */
export const exportCapacityToExcel = async (data: CapacityAssessmentReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();

  const populatePahuCapacitySheet = (worksheet: ExcelJS.Worksheet, tables: any[]) => {
    // Column widths for 20 columns
    worksheet.columns = [
      { width: 18 }, { width: 18 }, { width: 18 }, // Equip, Model, Serial
      { width: 15 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, { width: 15 }, // Design specs
      { width: 15 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, // Measured specs Air Side
      { width: 12 }, // Power
      { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, { width: 15 } // Measured specs Water Side
    ];

    let currentRow = 1;

    (tables || []).forEach((table) => {
      // 1. Table Header Row (Merged Title)
      worksheet.mergeCells(currentRow, 1, currentRow, 20);
      const titleCell = worksheet.getCell(currentRow, 1);
      titleCell.value = `${table.tableNumber || ''} - ${table.title || 'PAHU CAPACITY TABLE'}`.toUpperCase();
      styleHeaderCell(titleCell, 'FF1E3A8A'); // Navy Blue
      titleCell.font = { ...titleCell.font, size: 11, bold: true };
      worksheet.getRow(currentRow).height = 30;
      currentRow++;

      // 2. Multi-tiered Category Headers
      worksheet.mergeCells(currentRow, 1, currentRow, 3);
      const eqDetailCell = worksheet.getCell(currentRow, 1);
      eqDetailCell.value = "EQUIPMENT DETAILS";
      styleHeaderCell(eqDetailCell, 'FFF97316'); // Orange

      worksheet.mergeCells(currentRow, 4, currentRow, 9);
      const dSpecCell = worksheet.getCell(currentRow, 4);
      dSpecCell.value = "DESIGN SPECIFICATIONS";
      styleHeaderCell(dSpecCell, 'FF2563EB'); // Blue-600

      worksheet.mergeCells(currentRow, 10, currentRow, 14);
      const mAirSpecCell = worksheet.getCell(currentRow, 10);
      mAirSpecCell.value = "MEASURED AIR SIDE";
      styleHeaderCell(mAirSpecCell, 'FF059669'); // Emerald-600

      const mPowerCell = worksheet.getCell(currentRow, 15);
      mPowerCell.value = "POWER";
      styleHeaderCell(mPowerCell, 'FFD97706'); // Amber-600

      worksheet.mergeCells(currentRow, 16, currentRow, 20);
      const mWaterSpecCell = worksheet.getCell(currentRow, 16);
      mWaterSpecCell.value = "MEASURED WATER SIDE";
      styleHeaderCell(mWaterSpecCell, 'FF14B8A6'); // Teal-500
      
      worksheet.getRow(currentRow).height = 24;
      currentRow++;

      // Variables Sub-headers
      const varHeaders = [
        "Equipment ID", "Model No", "Serial No",
        "Airflow", "RA Temp", "SA Temp", "Power", "Water Flow Rate", "Cooling Tonnage",
        "Airflow", "SA Temp", "RA Temp", "Fan Speed", "Cooling Tonnage",
        "Power",
        "CHW In", "CHW Out", "Valve Opening", "Water Flow Rate", "Cooling Tonnage"
      ];
      const subHeaders = [
        "", "", "",
        "CFM", "°C", "°C", "kW", "GPM", "TR",
        "CFM", "°C", "°C", "%", "TR",
        "kW",
        "°C", "°C", "%", "GPM", "TR"
      ];

      const rVar = worksheet.getRow(currentRow);
      rVar.height = 20;
      varHeaders.forEach((vh, idx) => {
        const cell = rVar.getCell(idx + 1);
        cell.value = vh;
        styleHeaderCell(cell, 'FFF1F5F9', false); // Light slate
      });
      currentRow++;

      const rSub = worksheet.getRow(currentRow);
      rSub.height = 18;
      subHeaders.forEach((sh, idx) => {
        const cell = rSub.getCell(idx + 1);
        cell.value = sh;
        styleHeaderCell(cell, 'FFF1F5F9', false); // Light slate
      });
      currentRow++;

      // 3. Tabular Rows
      (table.entries || []).forEach((entry: any) => {
        const row = worksheet.getRow(currentRow);
        row.height = 22;

        const dTr = calculateTR(entry.designAirflow, entry.designRaTemp, entry.designSaTemp);
        const mTr = calculateTR(entry.measuredAirflow, entry.measuredRaTemp, entry.measuredSaTemp);

        const gpmVal = parseFloat(entry.measuredWaterFlowRate) || 0;
        const inVal = parseFloat(entry.measuredChwIn) || 0;
        const outVal = parseFloat(entry.measuredChwOut) || 0;
        const deltaC = Math.abs(outVal - inVal);
        const waterTr = (gpmVal * deltaC * 1.8) / 24;

        const values = [
          entry.equipmentId,
          entry.modelNo,
          entry.serialNo,
          parseFloat(entry.designAirflow) || entry.designAirflow,
          parseFloat(entry.designRaTemp) || entry.designRaTemp,
          parseFloat(entry.designSaTemp) || entry.designSaTemp,
          parseFloat(entry.designPower) || entry.designPower,
          parseFloat(entry.designWaterFlowRate) || entry.designWaterFlowRate,
          dTr > 0 ? parseFloat(dTr.toFixed(2)) : (parseFloat(entry.designCoolingTonnage) || entry.designCoolingTonnage),
          parseFloat(entry.measuredAirflow) || entry.measuredAirflow,
          parseFloat(entry.measuredSaTemp) || entry.measuredSaTemp,
          parseFloat(entry.measuredRaTemp) || entry.measuredRaTemp,
          parseFloat(entry.measuredFanSpeed) || entry.measuredFanSpeed,
          mTr > 0 ? parseFloat(mTr.toFixed(2)) : (parseFloat(entry.measuredCoolingTonnage) || entry.measuredCoolingTonnage),
          parseFloat(entry.measuredPower) || entry.measuredPower,
          parseFloat(entry.measuredChwIn) || entry.measuredChwIn,
          parseFloat(entry.measuredChwOut) || entry.measuredChwOut,
          parseFloat(entry.measuredValveOpening) || entry.measuredValveOpening,
          parseFloat(entry.measuredWaterFlowRate) || entry.measuredWaterFlowRate,
          waterTr > 0 ? parseFloat(waterTr.toFixed(2)) : (parseFloat(entry.measuredWaterCoolingTonnage) || entry.measuredWaterCoolingTonnage)
        ];

        values.forEach((val, idx) => {
          const cell = row.getCell(idx + 1);
          cell.value = val;
          applyBorderGrid(cell);
          cell.alignment = { vertical: 'middle', horizontal: 'center' };
          cell.font = { name: 'Arial', size: 9 };
          
          if (idx === 0) {
            cell.font = { ...cell.font, bold: true };
          }
          // Highlight Design TR, Measured Air TR, Measured Water TR
          if (idx === 8 || idx === 13 || idx === 19) {
            cell.fill = {
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: 'FFF0FDF4' } // light green
            };
            cell.font = { ...cell.font, bold: true, color: { argb: 'FF166534' } };
          }
        });

        currentRow++;
      });

      currentRow += 2;
    });
  };

  const populatePacCapacitySheet = (worksheet: ExcelJS.Worksheet, tables: any[]) => {
    worksheet.columns = [
      { width: 18 }, { width: 18 }, { width: 18 }, // Equip, Model, Serial
      { width: 15 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, // Design specs
      { width: 15 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, { width: 15 } // Measured specs
    ];

    let currentRow = 1;

    (tables || []).forEach((table) => {
      worksheet.mergeCells(currentRow, 1, currentRow, 14);
      const titleCell = worksheet.getCell(currentRow, 1);
      titleCell.value = `${table.tableNumber || ''} - ${table.title || 'CAPACITY TABLE'}`.toUpperCase();
      styleHeaderCell(titleCell, 'FF1E3A8A');
      titleCell.font = { ...titleCell.font, size: 11, bold: true };
      worksheet.getRow(currentRow).height = 30;
      currentRow++;

      worksheet.mergeCells(currentRow, 1, currentRow, 3);
      const eqDetailCell = worksheet.getCell(currentRow, 1);
      eqDetailCell.value = "EQUIPMENT DETAILS";
      styleHeaderCell(eqDetailCell, 'FFF97316');

      worksheet.mergeCells(currentRow, 4, currentRow, 8);
      const dSpecCell = worksheet.getCell(currentRow, 4);
      dSpecCell.value = "DESIGN SPECIFICATIONS";
      styleHeaderCell(dSpecCell, 'FF2563EB');

      worksheet.mergeCells(currentRow, 9, currentRow, 14);
      const mSpecCell = worksheet.getCell(currentRow, 9);
      mSpecCell.value = "MEASURED PERFORMANCE";
      styleHeaderCell(mSpecCell, 'FF059669');
      
      worksheet.getRow(currentRow).height = 24;
      currentRow++;

      const varHeaders = [
        "Equipment ID", "Model No", "Serial No",
        "Airflow", "RA Temp", "SA Temp", "Power", "Tonnage",
        "Airflow", "RA Temp", "SA Temp", "Power", "Tonnage", "Fan/Comp Speed"
      ];
      const subHeaders = [
        "", "", "",
        "CFM", "°C", "°C", "kW", "TR",
        "CFM", "°C", "°C", "kW", "TR", "%"
      ];

      const rVar = worksheet.getRow(currentRow);
      rVar.height = 20;
      varHeaders.forEach((vh, idx) => {
        const cell = rVar.getCell(idx + 1);
        cell.value = vh;
        styleHeaderCell(cell, 'FFF1F5F9', false);
      });
      currentRow++;

      const rSub = worksheet.getRow(currentRow);
      rSub.height = 18;
      subHeaders.forEach((sh, idx) => {
        const cell = rSub.getCell(idx + 1);
        cell.value = sh;
        styleHeaderCell(cell, 'FFF1F5F9', false);
      });
      currentRow++;

      (table.entries || []).forEach((entry: any) => {
        const row = worksheet.getRow(currentRow);
        row.height = 22;

        const dTr = calculateTR(entry.designAirflow, entry.designRaTemp, entry.designSaTemp);
        const mTr = calculateTR(entry.measuredAirflow, entry.measuredRaTemp, entry.measuredSaTemp);

        const values = [
          entry.equipmentId,
          entry.modelNo,
          entry.serialNo,
          parseFloat(entry.designAirflow) || entry.designAirflow,
          parseFloat(entry.designRaTemp) || entry.designRaTemp,
          parseFloat(entry.designSaTemp) || entry.designSaTemp,
          parseFloat(entry.designPower) || entry.designPower,
          dTr > 0 ? parseFloat(dTr.toFixed(2)) : entry.designCoolingTonnage,
          parseFloat(entry.measuredAirflow) || entry.measuredAirflow,
          parseFloat(entry.measuredRaTemp) || entry.measuredRaTemp,
          parseFloat(entry.measuredSaTemp) || entry.measuredSaTemp,
          parseFloat(entry.measuredPower) || entry.measuredPower,
          mTr > 0 ? parseFloat(mTr.toFixed(2)) : entry.measuredCoolingTonnage,
          entry.measuredFanSpeed
        ];

        values.forEach((val, idx) => {
          const cell = row.getCell(idx + 1);
          cell.value = val;
          applyBorderGrid(cell);
          cell.alignment = { vertical: 'middle', horizontal: 'center' };
          cell.font = { name: 'Arial', size: 9 };
          
          if (idx === 0) {
            cell.font = { ...cell.font, bold: true };
          }
          if (idx === 7 || idx === 12) {
            cell.fill = {
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: 'FFF0FDF4' }
            };
            cell.font = { ...cell.font, bold: true, color: { argb: 'FF166534' } };
          }
        });

        currentRow++;
      });

      currentRow += 2;
    });
  };

  const wsPahu = workbook.addWorksheet('PAHU CAPACITY'.substring(0, 31));
  populatePahuCapacitySheet(wsPahu, data.pahuTables || []);

  const wsPac = workbook.addWorksheet('PAC CAPACITY'.substring(0, 31));
  populatePacCapacitySheet(wsPac, data.pacTables || []);

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

/**
 * 3. Rack Cooling Index (RCI) Temperature Study Export
 */
export const exportRCICACToExcel = async (group: import('../types').RCICacGroup, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet((group.cacName || 'RCI Temp Study').substring(0, 31));

  worksheet.columns = [
    { width: 8 },  // S.No
    { width: 18 }, // CAC Reference
    { width: 18 }, // Rack Reference
    { width: 12 }, // Front 15
    { width: 12 }, // Front 22
    { width: 12 }, // Front 35
    { width: 12 }, // Rear 15
    { width: 12 }, // Rear 22
    { width: 12 }, // Rear 35
    { width: 12 }, // RH Front
    { width: 12 }, // RH Rear
    { width: 15 }, // Inlet Temp Result
    { width: 15 }, // Excess Temp
    { width: 15 }  // Deficit Temp
  ];

  const headers = [
    "S.No.", "CAC Reference", "Rack Reference", 
    "Front 15U", "Front 22U", "Front 35U", "Rear 15U", "Rear 22U", "Rear 35U",
    "RH Front", "RH Rear", "Inlet Temp Result", "Excess Temp", "Deficit Temp"
  ];

  const headerRow = worksheet.getRow(1);
  headerRow.height = 28;
  headers.forEach((h, idx) => {
    const cell = headerRow.getCell(idx + 1);
    cell.value = h;
    styleHeaderCell(cell, 'FFF59E0B'); // Warm Amber
    cell.font = { ...cell.font, color: { argb: 'FFFFFFFF' } };
  });

  let rowCounter = 2;
  (group.temperatureRows || []).forEach((rowItem, idx) => {
    const row = worksheet.getRow(rowCounter);
    row.height = 20;

    const values = [
      rowItem.sNo || (rowCounter - 1),
      rowItem.cacRef || group.cacName,
      rowItem.rackRef,
      parseFloat(rowItem.front15U) || rowItem.front15U,
      parseFloat(rowItem.front22U) || rowItem.front22U,
      parseFloat(rowItem.front35U) || rowItem.front35U,
      parseFloat(rowItem.rear15U) || rowItem.rear15U,
      parseFloat(rowItem.rear22U) || rowItem.rear22U,
      parseFloat(rowItem.rear35U) || rowItem.rear35U,
      parseFloat(rowItem.rhFront) || rowItem.rhFront,
      parseFloat(rowItem.rhRear) || rowItem.rhRear,
      parseFloat(rowItem.inletTempResult || '') || rowItem.inletTempResult,
      parseFloat(rowItem.excessInletTemp || '') || rowItem.excessInletTemp,
      parseFloat(rowItem.deficitInletTemp || '') || rowItem.deficitInletTemp
    ];

    values.forEach((val, colIdx) => {
      const cell = row.getCell(colIdx + 1);
      cell.value = val !== undefined ? val : '';
      applyBorderGrid(cell);
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
      cell.font = { name: 'Arial', size: 9 };
      
      if (colIdx === 1 || colIdx === 2) {
        cell.font = { ...cell.font, bold: true };
      }
    });

    rowCounter++;
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

/**
 * 4. Life Cycle Assessment (LCA) Export
 */
export const exportLCATable1ToExcel = async (data: LifeCycleReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();

  // SHEET 1: Table-1 Summary & Factor Calculation
  const wsTable1 = workbook.addWorksheet('LCA Table-1'.substring(0, 31));
  wsTable1.columns = [
    { width: 8 },  // S.No
    { width: 22 }, // Equipment Tag / Name
    { width: 22 }, // Make & Model No
    { width: 20 }, // Serial No
    { width: 20 }, // Location
    { width: 15 }, // Install Year
    { width: 15 }, // Current Year
    { width: 12 }, // Age (yrs)
    { width: 18 }, // Vibration Score (VS)
    { width: 18 }, // Corrosion Score (CS)
    { width: 18 }, // Maint. Score (MS)
    { width: 18 }, // Health Index (HI)
    { width: 18 }, // Running Life (yrs)
    { width: 20 }, // Utilization Ratio (UR)
    { width: 20 }  // Utilization Factor (UF)
  ];

  const headersT1 = [
    "S.No", 
    "Equipment Tag / Name", 
    "Make & Model No", 
    "Serial No", 
    "Location", 
    "Install Year", 
    "Current Year", 
    "Age (yrs)", 
    "Vibration Score (VS)", 
    "Corrosion Score (CS)", 
    "Maint. Score (MS)", 
    "Health Index (HI)", 
    "Running Life (yrs)", 
    "Utilization Ratio (UR)", 
    "Utilization Factor (UF)"
  ];

  const rHeader1 = wsTable1.getRow(1);
  rHeader1.height = 26;
  headersT1.forEach((h, idx) => {
    const cell = rHeader1.getCell(idx + 1);
    cell.value = h;
    styleHeaderCell(cell, 'FF0369A1'); // Sky Blue-700
  });

  (data.lifeCycleRows || []).forEach((rowItem, idx) => {
    const installYrNum = parseInt(rowItem.installYear);
    const currentYrNum = parseInt(rowItem.currentYear) || new Date().getFullYear();
    const autoAge = (!isNaN(installYrNum) && !isNaN(currentYrNum)) ? (currentYrNum - installYrNum) : 0;
    const ageVal = rowItem.ageYrs !== '' ? parseFloat(rowItem.ageYrs) : autoAge;

    const vs = parseFloat(rowItem.vibrationScore) || 0;
    const cs = parseFloat(rowItem.corrosionScore) || 0;
    const ms = parseFloat(rowItem.maintScore) || 0;
    const scoresCount = [rowItem.vibrationScore, rowItem.corrosionScore, rowItem.maintScore].filter(v => v !== '' && v !== undefined).length;
    const computedHI = scoresCount > 0 ? ((vs + cs + ms) / scoresCount) : 0;
    const hiVal = rowItem.healthIndex !== '' ? parseFloat(rowItem.healthIndex) : computedHI;

    const row = wsTable1.addRow([
      idx + 1,
      rowItem.equipmentTag || '',
      rowItem.makeModel || '',
      rowItem.serialNo || '',
      rowItem.location || '',
      parseInt(rowItem.installYear) || rowItem.installYear || '',
      parseInt(rowItem.currentYear) || rowItem.currentYear || '',
      parseFloat(String(ageVal)) || ageVal || '',
      parseFloat(rowItem.vibrationScore) || rowItem.vibrationScore || '',
      parseFloat(rowItem.corrosionScore) || rowItem.corrosionScore || '',
      parseFloat(rowItem.maintScore) || rowItem.maintScore || '',
      parseFloat(String(hiVal)) ? parseFloat(hiVal.toFixed(1)) : (hiVal || ''),
      parseFloat(rowItem.runningLifeYrs) || rowItem.runningLifeYrs || '',
      parseFloat(rowItem.utilizationRatio) || rowItem.utilizationRatio || '',
      parseFloat(rowItem.utilizationFactor) || rowItem.utilizationFactor || ''
    ]);
    row.height = 20;
    row.eachCell((cell) => {
      applyBorderGrid(cell);
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
      cell.font = { name: 'Arial', size: 9 };
    });
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

export const exportLCATable2ToExcel = async (data: LifeCycleReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();

  // SHEET 1: Table-2 RUL Calculation
  const wsTable2 = workbook.addWorksheet('LCA Table-2'.substring(0, 31));
  wsTable2.columns = [
    { width: 8 },  // S.No
    { width: 22 }, // Equipment Tag / Name
    { width: 20 }, // Design Life (yrs)
    { width: 14 }, // Age (yrs)
    { width: 18 }, // Health Index (HI)
    { width: 22 }, // Utilization Factor (UF)
    { width: 20 }, // Adjusted Life (AL)
    { width: 18 }, // RUL (yrs)
    { width: 18 }, // RUL (%)
    { width: 22 }, // Life cycle Status
    { width: 25 }  // Remarks (RUL)
  ];

  const headersT2 = [
    "S.No", 
    "Equipment Tag / Name", 
    "Design Life (yrs)",
    "Age (yrs)",
    "Health Index (HI)",
    "Utilization Factor (UF)",
    "Adjusted Life (AL)",
    "RUL (yrs)",
    "RUL (%)",
    "Life cycle Status",
    "Remarks (RUL)"
  ];

  const rHeader2 = wsTable2.getRow(1);
  rHeader2.height = 26;
  headersT2.forEach((h, idx) => {
    const cell = rHeader2.getCell(idx + 1);
    cell.value = h;
    styleHeaderCell(cell, 'FF0369A1'); // Sky Blue-700
  });

  (data.rulRows || []).forEach((rowItem, idx) => {
    const designLife = parseFloat(rowItem.designLifeYrs || '') || 0;
    const ageVal = parseFloat(rowItem.ageYrs || '') || 0;
    const hiVal = parseFloat(rowItem.healthIndex || '') || 0;
    const ufVal = parseFloat(rowItem.utilizationFactor || '') || 1;

    const computedAL = (designLife > 0 && hiVal > 0) ? ((designLife * hiVal) * ufVal) : 0;
    const alVal = computedAL;

    const computedRul = alVal > 0 ? (alVal - ageVal) : 0;
    const rulVal = computedRul;

    const computedPct = alVal > 0 ? ((rulVal / alVal) * 100) : 0;
    const pctVal = computedPct;

    let autoStatus = '';
    if (alVal > 0) {
      if (pctVal > 50) autoStatus = 'Fit for Service';
      else if (pctVal >= 25) autoStatus = 'Degrading Stage';
      else if (pctVal >= 10) autoStatus = 'Approaching Replacement';
      else if (pctVal > 0) autoStatus = 'Reaching End-of-Life';
      else autoStatus = 'End-of-Life';
    }
    const statusVal = rowItem.lifeCycleStatus || autoStatus;

    const row = wsTable2.addRow([
      idx + 1,
      rowItem.equipmentTag || '',
      designLife || rowItem.designLifeYrs || '',
      ageVal || rowItem.ageYrs || '',
      hiVal || rowItem.healthIndex || '',
      ufVal || rowItem.utilizationFactor || '',
      parseFloat(String(alVal)) ? parseFloat(alVal.toFixed(1)) : (alVal || ''),
      parseFloat(String(rulVal)) ? parseFloat(rulVal.toFixed(1)) : (rulVal || ''),
      parseFloat(String(pctVal)) ? parseFloat(pctVal.toFixed(1)) : (pctVal || ''),
      statusVal,
      rowItem.remarksRul || ''
    ]);
    row.height = 20;
    row.eachCell((cell) => {
      applyBorderGrid(cell);
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
      cell.font = { name: 'Arial', size: 9 };
    });
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

/**
 * 5. Vibration Analysis Study Export
 */
export const exportVibrationGroupToExcel = async (group: import('../types').VibrationSummaryGroup, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet((group.groupName || 'Vibration Summary').substring(0, 31));

  worksheet.columns = [
    { width: 22 }, // Equipment ID
    { width: 15 }, // Class
    { width: 14 }, // Vertical
    { width: 14 }, // Horizontal
    { width: 14 }, // Axial
    { width: 14 }, // Max Value
    { width: 22 }  // Condition
  ];

  let currentRow = 1;

  // Subsection Header for Group
  worksheet.mergeCells(currentRow, 1, currentRow, 7);
  const titleCell = worksheet.getCell(currentRow, 1);
  titleCell.value = String(group.groupName || `GROUP 1`).toUpperCase();
  styleHeaderCell(titleCell, 'FFE04F22'); // Dynamic Orange/Red
  titleCell.font = { ...titleCell.font, color: { argb: 'FFFFFFFF' }, size: 11 };
  worksheet.getRow(currentRow).height = 28;
  currentRow++;

  // Sub-headers
  worksheet.mergeCells(currentRow, 1, currentRow + 1, 1);
  const eqCell = worksheet.getCell(currentRow, 1);
  eqCell.value = "Equipment ID";
  styleHeaderCell(eqCell, 'FF1E293B');

  worksheet.mergeCells(currentRow, 2, currentRow + 1, 2);
  const clCell = worksheet.getCell(currentRow, 2);
  clCell.value = "Class Details";
  styleHeaderCell(clCell, 'FF1E293B');

  worksheet.mergeCells(currentRow, 3, currentRow, 6);
  const mvCell = worksheet.getCell(currentRow, 3);
  mvCell.value = "Measured Vibration (mm/s)";
  styleHeaderCell(mvCell, 'FF1E293B');

  worksheet.mergeCells(currentRow, 7, currentRow + 1, 7);
  const coCell = worksheet.getCell(currentRow, 7);
  coCell.value = "Vibration Condition";
  styleHeaderCell(coCell, 'FF1E293B');

  currentRow++;

  const subHeaders = ["Vertical", "Horizontal", "Axial", "Max Value (mm/s)"];
  const rSub = worksheet.getRow(currentRow);
  rSub.height = 20;
  subHeaders.forEach((sh, sIdx) => {
    const cell = rSub.getCell(sIdx + 3);
    cell.value = sh;
    styleHeaderCell(cell, 'FF334155');
  });

  currentRow++;

  // Data rows
  (group.rows || []).forEach((rowItem) => {
    const row = worksheet.getRow(currentRow);
    row.height = 22;

    const v = parseFloat(rowItem.vertical) || 0;
    const h = parseFloat(rowItem.horizontal) || 0;
    const a = parseFloat(rowItem.axial) || 0;
    const calcMax = Math.max(v, h, a);
    const displayMax = rowItem.maxValue ? (parseFloat(rowItem.maxValue) || rowItem.maxValue) : calcMax;

    const rowValues = [
      rowItem.equipmentId,
      rowItem.classDetails,
      parseFloat(rowItem.vertical) || rowItem.vertical,
      parseFloat(rowItem.horizontal) || rowItem.horizontal,
      parseFloat(rowItem.axial) || rowItem.axial,
      displayMax,
      rowItem.condition || 'GOOD'
    ];

    rowValues.forEach((val, colIdx) => {
      const cell = row.getCell(colIdx + 1);
      cell.value = val;
      applyBorderGrid(cell);
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
      cell.font = { name: 'Arial', size: 9 };
      
      if (colIdx === 0) {
        cell.font = { ...cell.font, bold: true };
      }
      
      // Color code condition
      if (colIdx === 6) {
        const cond = String(val).toUpperCase();
        cell.font = { ...cell.font, bold: true };
        if (cond.includes('GOOD') || cond.includes('SATISFACTORY') && !cond.includes('UNSATISFACTORY')) {
          cell.font = { ...cell.font, color: { argb: 'FF156534' } }; // green
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF0FDF4' } };
        } else {
          cell.font = { ...cell.font, color: { argb: 'FF9A3412' } }; // orange/red
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF7ED' } };
        }
      }
    });

    currentRow++;
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

/**
 * 6. Battery Impedance Audit Export
 */
export const exportBatteryImpedanceToExcel = async (data: BatteryImpedanceReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Battery Impedance');

  worksheet.columns = [
    { width: 10 },  // No
    { width: 22 },  // Measured IR (mΩ)
    { width: 16 },  // Fail Thresh
    { width: 16 },  // Warn Thresh
    { width: 16 },  // Voltage (V)
    { width: 16 },  // Volt Thresh
    { width: 16 }   // Status
  ];

  let currentRow = 1;

  (data.upsSystems || []).forEach((ups) => {
    // UPS Header
    worksheet.mergeCells(currentRow, 1, currentRow, 7);
    const upsCell = worksheet.getCell(currentRow, 1);
    upsCell.value = `UPS SYSTEM: ${ups.name || ''}`;
    styleHeaderCell(upsCell, 'FFF97316'); // Orange-500
    upsCell.font = { name: 'Arial', size: 12, bold: true, color: { argb: 'FFFFFFFF' } };
    worksheet.getRow(currentRow).height = 28;
    currentRow++;

    // UPS Details (Location, Make/Model, Battery Type)
    const detailsRow = worksheet.getRow(currentRow);
    detailsRow.height = 20;
    
    detailsRow.getCell(1).value = 'Location:';
    detailsRow.getCell(1).font = { name: 'Arial', size: 10, bold: true };
    detailsRow.getCell(2).value = ups.location || '';
    detailsRow.getCell(2).font = { name: 'Arial', size: 10 };

    detailsRow.getCell(3).value = 'Make/Model:';
    detailsRow.getCell(3).font = { name: 'Arial', size: 10, bold: true };
    detailsRow.getCell(4).value = ups.make || '';
    detailsRow.getCell(4).font = { name: 'Arial', size: 10 };

    detailsRow.getCell(5).value = 'Battery Type:';
    detailsRow.getCell(5).font = { name: 'Arial', size: 10, bold: true };
    detailsRow.getCell(6).value = ups.batteryType || '';
    detailsRow.getCell(6).font = { name: 'Arial', size: 10 };
    currentRow += 2; // leave a blank row

    // Strings
    (ups.strings || []).forEach((str) => {
      // String Label
      worksheet.mergeCells(currentRow, 1, currentRow, 7);
      const strCell = worksheet.getCell(currentRow, 1);
      strCell.value = `STRING: ${str.name || ''}`;
      styleHeaderCell(strCell, 'FF1E293B'); // Slate-800
      strCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
      worksheet.getRow(currentRow).height = 24;
      currentRow++;

      // Table Headers
      const headers = ['No', 'Measured IR (mΩ)', 'Fail Thresh', 'Warn Thresh', 'Voltage (V)', 'Volt Thresh', 'Status'];
      const rHeader = worksheet.getRow(currentRow);
      rHeader.height = 22;
      headers.forEach((h, idx) => {
        const cell = rHeader.getCell(idx + 1);
        cell.value = h;
        styleHeaderCell(cell, 'FF475569'); // Slate-600
      });
      currentRow++;

      // Readings
      (str.readings || []).forEach((r) => {
        const row = worksheet.getRow(currentRow);
        row.height = 20;

        const valNo = r.batteryNo;
        const valIr = r.measuredIr !== '' ? parseFloat(r.measuredIr) : '';
        const valFail = r.irFailThresh !== '' ? parseFloat(r.irFailThresh) : '';
        const valWarn = r.irWarnThresh !== '' ? parseFloat(r.irWarnThresh) : '';
        const valVolt = r.measuredVolt !== '' ? parseFloat(r.measuredVolt) : '';
        const valVoltTh = r.voltThresh !== '' ? parseFloat(r.voltThresh) : '';
        const valStatus = r.remarks || '...';

        const rowValues = [valNo, valIr, valFail, valWarn, valVolt, valVoltTh, valStatus];

        rowValues.forEach((val, colIdx) => {
          const cell = row.getCell(colIdx + 1);
          cell.value = val;
          applyBorderGrid(cell);
          cell.alignment = { vertical: 'middle', horizontal: 'center' };
          cell.font = { name: 'Arial', size: 10 };

          if (colIdx === 0) {
            cell.font = { name: 'Arial', size: 10, bold: true };
          }

          // Status column colouring
          if (colIdx === 6) {
            cell.font = { name: 'Arial', size: 10, bold: true };
            const statusStr = String(val).toUpperCase();
            if (statusStr === 'FAIL') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDC2626' } };
              cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
            } else if (statusStr === 'WARN' || statusStr === 'WARNING') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF59E0B' } };
              cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
            } else if (statusStr === 'PASS') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF198754' } };
              cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
            }
          }
        });

        currentRow++;
      });

      currentRow += 2; // Blank spacing after each string table
    });

    currentRow += 1; // Extra blank spacing after each UPS system
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

/**
 * 7. Earth Continuity & Earth Station Test Export
 */
export const exportEarthStationToExcel = async (data: EarthStationReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Earth Continuity');

  worksheet.columns = [
    { width: 16 }, // Earth Pit No / label
    { width: 30 }, // Earthing Description / label
    { width: 22 }, // Measured Value (Ω)
    { width: 22 }, // Limit Value (Ω)
    { width: 35 }  // Remarks
  ];

  let currentRow = 1;

  // Title Row
  worksheet.mergeCells(currentRow, 1, currentRow, 5);
  const titleCell = worksheet.getCell(currentRow, 1);
  titleCell.value = 'EARTH CONTINUITY & EARTH STATION TEST';
  styleHeaderCell(titleCell, 'FFFB923C'); // #FB923C (Light orange / peach)
  titleCell.font = { name: 'Arial', size: 12, bold: true, color: { argb: 'FFFFFFFF' } };
  worksheet.getRow(currentRow).height = 28;
  currentRow++;

  // Metadata Fields
  const metaRows = [
    ['Prepared By:', data.preparedBy || '', 'Tested By:', data.testedBy || ''],
    ['Tester Email:', data.testerEmail || '', 'Witnessed By:', data.witnessedBy || ''],
    ['Test Date:', data.testDate || '', '', '']
  ];

  metaRows.forEach((rowVals) => {
    const row = worksheet.getRow(currentRow);
    row.height = 20;
    rowVals.forEach((val, idx) => {
      const cell = row.getCell(idx + 1);
      cell.value = val;
      cell.font = { name: 'Arial', size: 10, bold: idx % 2 === 0 };
      if (idx % 2 === 0) {
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
      } else {
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
        applyBorderGrid(cell);
      }
    });
    currentRow++;
  });

  currentRow += 2; // Blank spacing

  // Table 1: Test Equipment Used
  if (data.equipmentList && data.equipmentList.length > 0) {
    worksheet.mergeCells(currentRow, 1, currentRow, 5);
    const eqTitleCell = worksheet.getCell(currentRow, 1);
    eqTitleCell.value = 'TEST EQUIPMENT USED';
    styleHeaderCell(eqTitleCell, 'FFF97316'); // Orange-500
    eqTitleCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
    worksheet.getRow(currentRow).height = 24;
    currentRow++;

    const eqHeaders = ['Equipment Name', 'Make', 'Serial Number', 'Model', 'Calibration Date'];
    const eqRow = worksheet.getRow(currentRow);
    eqRow.height = 22;
    eqHeaders.forEach((h, idx) => {
      const cell = eqRow.getCell(idx + 1);
      cell.value = h;
      styleHeaderCell(cell, 'FF475569'); // Slate-600
    });
    currentRow++;

    data.equipmentList.forEach((eq) => {
      const row = worksheet.getRow(currentRow);
      row.height = 20;
      const vals = [eq.name, eq.make, eq.serial, eq.model, eq.calDate];
      vals.forEach((val, idx) => {
         const cell = row.getCell(idx + 1);
         cell.value = val || '';
         applyBorderGrid(cell);
         cell.alignment = { vertical: 'middle', horizontal: 'center' };
         cell.font = { name: 'Arial', size: 10 };
      });
      currentRow++;
    });

    currentRow += 2; // Blank spacing
  }

  // Table 2: Measuring Details (Readings)
  worksheet.mergeCells(currentRow, 1, currentRow, 5);
  const tblTitleCell = worksheet.getCell(currentRow, 1);
  tblTitleCell.value = 'MEASURING DETAILS (READINGS)';
  styleHeaderCell(tblTitleCell, 'FFFB923C'); // #FB923C
  tblTitleCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
  worksheet.getRow(currentRow).height = 24;
  currentRow++;

  const rdHeaders = ['Earth Pit No', 'Earthing Description', 'Measured Value (Ω)', 'Limit Value (Ω)', 'Remarks'];
  const rdHeaderRow = worksheet.getRow(currentRow);
  rdHeaderRow.height = 22;
  rdHeaders.forEach((h, idx) => {
    const cell = rdHeaderRow.getCell(idx + 1);
    cell.value = h;
    styleHeaderCell(cell, 'FF475569'); // Slate-600
  });
  currentRow++;

  (data.readings || []).forEach((r) => {
    const row = worksheet.getRow(currentRow);
    row.height = 20;

    const valPit = r.pitNo || '';
    const valDesc = r.description || '';
    const valMeas = r.measuredValue !== '' ? parseFloat(r.measuredValue) : '';
    const valLimit = r.limitValue !== '' ? parseFloat(r.limitValue) : '';
    const valRemarks = r.remarks || '';

    const vals = [valPit, valDesc, valMeas, valLimit, valRemarks];
    vals.forEach((val, idx) => {
      const cell = row.getCell(idx + 1);
      cell.value = val;
      applyBorderGrid(cell);
      cell.alignment = { vertical: 'middle', horizontal: idx === 1 ? 'left' : 'center' };
      cell.font = { name: 'Arial', size: 10 };

      if (idx === 0) {
        cell.font = { name: 'Arial', size: 10, bold: true };
      }

      // Coloring of Remarks
      if (idx === 4) {
        cell.font = { name: 'Arial', size: 10, bold: true };
        const statusStr = String(val).toLowerCase();
        if (statusStr === 'ok') {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2F0D9' } }; // Light green
          cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FF385723' } }; // Dark green
        } else if (statusStr !== '') {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFCE4D6' } }; // Light red/peach
          cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFC00000' } }; // Red
        }
      }
    });
    currentRow++;
  });

  // Observations & Recommendations
  if (data.observations || data.recommendations) {
    currentRow += 2;
    worksheet.mergeCells(currentRow, 1, currentRow, 5);
    const obsTitleCell = worksheet.getCell(currentRow, 1);
    obsTitleCell.value = 'OBSERVATIONS & RECOMMENDATIONS';
    styleHeaderCell(obsTitleCell, 'FFFB923C');
    worksheet.getRow(currentRow).height = 24;
    currentRow++;

    worksheet.mergeCells(currentRow, 1, currentRow, 2);
    const cellObsLbl = worksheet.getCell(currentRow, 1);
    cellObsLbl.value = 'Test Observations:';
    styleHeaderCell(cellObsLbl, 'FFF1F5F9', false);

    worksheet.mergeCells(currentRow, 3, currentRow, 5);
    const cellObsVal = worksheet.getCell(currentRow, 3);
    cellObsVal.value = data.observations || '';
    cellObsVal.alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
    applyBorderGrid(cellObsVal);
    worksheet.getRow(currentRow).height = 60;
    currentRow++;

    worksheet.mergeCells(currentRow, 1, currentRow, 2);
    const cellRecLbl = worksheet.getCell(currentRow, 1);
    cellRecLbl.value = 'Professional Recommendations:';
    styleHeaderCell(cellRecLbl, 'FFF1F5F9', false);

    worksheet.mergeCells(currentRow, 3, currentRow, 5);
    const cellRecVal = worksheet.getCell(currentRow, 3);
    cellRecVal.value = data.recommendations || '';
    cellRecVal.alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
    applyBorderGrid(cellRecVal);
    worksheet.getRow(currentRow).height = 60;
    currentRow++;
  }

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

/**
 * 8. Power Factor / Capacitor Health Assessment Export
 */
export const exportPowerFactorToExcel = async (data: PowerFactorReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Power Factor');

  worksheet.columns = [
    { width: 20 }, // Feeder Name
    { width: 22 }, // Capacitor Bank in kVAR
    { width: 20 }, // Breaker Rating in A
    { width: 22 }, // Contactor Rating in A
    { width: 24 }, // Obtained Capacitance in µF
    { width: 25 }, // Actual RY Capacitance in µF
    { width: 25 }, // Actual YB Capacitance in µF
    { width: 25 }, // Actual BR Capacitance in µF
    { width: 18 }, // Measured kVAR
    { width: 35 }  // Acceptable Limit of Capacitance in kVAR
  ];

  let currentRow = 1;

  // Title Header
  worksheet.mergeCells(currentRow, 1, currentRow, 10);
  const titleCell = worksheet.getCell(currentRow, 1);
  titleCell.value = 'POWER FACTOR / CAPACITOR HEALTH ASSESSMENT';
  styleHeaderCell(titleCell, 'FFF97316'); // Orange-500
  titleCell.font = { name: 'Arial', size: 12, bold: true, color: { argb: 'FFFFFFFF' } };
  worksheet.getRow(currentRow).height = 28;
  currentRow++;

  // Metadata
  const metaRows = [
    ['Prepared By:', data.preparedBy || '', 'Tested By:', data.testedBy || '', 'Test Date:', data.testDate || ''],
    ['Tester Email:', data.testerEmail || '', 'Witnessed By:', data.witnessedBy || '', 'Global Status:', data.status || 'PENDING']
  ];

  metaRows.forEach((rowVals) => {
    const row = worksheet.getRow(currentRow);
    row.height = 20;
    rowVals.forEach((val, idx) => {
      const cell = row.getCell(idx + 1);
      cell.value = val;
      cell.font = { name: 'Arial', size: 10, bold: idx % 2 === 0 };
      if (idx % 2 === 0) {
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
      } else {
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
        applyBorderGrid(cell);
      }
    });
    currentRow++;
  });

  currentRow += 1;

  // Equipment List if present
  if (data.equipmentList && data.equipmentList.length > 0) {
    worksheet.mergeCells(currentRow, 1, currentRow, 6);
    const eqTitleCell = worksheet.getCell(currentRow, 1);
    eqTitleCell.value = 'LIST OF TESTING EQUIPMENT';
    styleHeaderCell(eqTitleCell, 'FF1E293B'); // Slate-800
    eqTitleCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
    worksheet.getRow(currentRow).height = 24;
    currentRow++;

    const eqHeaders = ['Equipment Name', 'Make', 'Model', 'Serial No', 'Calibration Date', 'Expiry Date'];
    const eqRow = worksheet.getRow(currentRow);
    eqRow.height = 22;
    eqHeaders.forEach((h, idx) => {
      const cell = eqRow.getCell(idx + 1);
      cell.value = h;
      styleHeaderCell(cell, 'FF475569');
    });
    currentRow++;

    data.equipmentList.forEach((eq) => {
      const row = worksheet.getRow(currentRow);
      row.height = 20;
      const vals = [eq.name, eq.make, eq.model, eq.serialNo, eq.calDate, eq.expDate];
      vals.forEach((val, idx) => {
        const cell = row.getCell(idx + 1);
        cell.value = val || '';
        applyBorderGrid(cell);
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        cell.font = { name: 'Arial', size: 10 };
      });
      currentRow++;
    });

    currentRow += 1;
  }

  // Panels
  const panels = data.panels && data.panels.length > 0 ? data.panels : [];
  panels.forEach((panel) => {
    // Panel Name
    worksheet.mergeCells(currentRow, 1, currentRow, 10);
    const panelCell = worksheet.getCell(currentRow, 1);
    panelCell.value = `APFC PANEL: ${panel.panelName || 'APFC PANEL'}`;
    styleHeaderCell(panelCell, 'FF2563EB'); // Blue-600
    panelCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
    worksheet.getRow(currentRow).height = 24;
    currentRow++;

    // Table 1: Capacitor Bank Metrics
    worksheet.mergeCells(currentRow, 1, currentRow, 10);
    const tbl1TitleCell = worksheet.getCell(currentRow, 1);
    tbl1TitleCell.value = 'CAPACITOR BANK METRICS';
    styleHeaderCell(tbl1TitleCell, 'FFF97316'); // Orange-500
    tbl1TitleCell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
    worksheet.getRow(currentRow).height = 22;
    currentRow++;

    const t1Headers = [
      'Feeder Name',
      'Capacitor Bank in kVAR',
      'Breaker Rating in A',
      'Contactor Rating in A',
      'Obtained Capacitance in µF',
      'Actual RY Capacitance in µF',
      'Actual YB Capacitance in µF',
      'Actual BR Capacitance in µF',
      'Measured kVAR',
      'Acceptable Limit of Capacitance in kVAR'
    ];

    const t1HeaderRow = worksheet.getRow(currentRow);
    t1HeaderRow.height = 22;
    t1Headers.forEach((h, idx) => {
      const cell = t1HeaderRow.getCell(idx + 1);
      cell.value = h;
      styleHeaderCell(cell, 'FF475569'); // Slate-600
    });
    currentRow++;

    (panel.bankRows || []).forEach((rowItem) => {
      const row = worksheet.getRow(currentRow);
      row.height = 20;

      const vals = [
        rowItem.feederName || '',
        rowItem.bankKvar !== '' ? (isNaN(Number(rowItem.bankKvar)) ? rowItem.bankKvar : Number(rowItem.bankKvar)) : '',
        rowItem.breakerRating !== '' ? (isNaN(Number(rowItem.breakerRating)) ? rowItem.breakerRating : Number(rowItem.breakerRating)) : '',
        rowItem.contactorRating !== '' ? (isNaN(Number(rowItem.contactorRating)) ? rowItem.contactorRating : Number(rowItem.contactorRating)) : '',
        rowItem.obtainedCap !== '' ? (isNaN(Number(rowItem.obtainedCap)) ? rowItem.obtainedCap : Number(rowItem.obtainedCap)) : '',
        rowItem.actualRY !== '' ? (isNaN(Number(rowItem.actualRY)) ? rowItem.actualRY : Number(rowItem.actualRY)) : '',
        rowItem.actualYB !== '' ? (isNaN(Number(rowItem.actualYB)) ? rowItem.actualYB : Number(rowItem.actualYB)) : '',
        rowItem.actualBR !== '' ? (isNaN(Number(rowItem.actualBR)) ? rowItem.actualBR : Number(rowItem.actualBR)) : '',
        rowItem.measuredKvar !== '' ? (isNaN(Number(rowItem.measuredKvar)) ? rowItem.measuredKvar : Number(rowItem.measuredKvar)) : '',
        rowItem.acceptableLimit || ''
      ];

      vals.forEach((val, idx) => {
        const cell = row.getCell(idx + 1);
        cell.value = val;
        applyBorderGrid(cell);
        cell.alignment = { vertical: 'middle', horizontal: idx === 0 ? 'left' : 'center' };
        cell.font = { name: 'Arial', size: 10, bold: idx === 0 };
      });

      currentRow++;
    });

    currentRow += 1; // Spacing

    // Table 2: Temperature & Phase Current Readings
    worksheet.mergeCells(currentRow, 1, currentRow, 6);
    const tbl2TitleCell = worksheet.getCell(currentRow, 1);
    tbl2TitleCell.value = 'TEMPERATURE & PHASE CURRENT READINGS';
    styleHeaderCell(tbl2TitleCell, 'FFF97316'); // Orange-500
    tbl2TitleCell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
    worksheet.getRow(currentRow).height = 22;
    currentRow++;

    const t2Headers = [
      'Feeder Name',
      'Case Temperature',
      'R Phase Current in Amp',
      'Y Phase Current in Amp',
      'B Phase Current in Amp',
      'Remarks'
    ];

    const t2HeaderRow = worksheet.getRow(currentRow);
    t2HeaderRow.height = 22;
    t2Headers.forEach((h, idx) => {
      const cell = t2HeaderRow.getCell(idx + 1);
      cell.value = h;
      styleHeaderCell(cell, 'FF475569'); // Slate-600
    });
    currentRow++;

    (panel.balanceRows || []).forEach((rowItem) => {
      const row = worksheet.getRow(currentRow);
      row.height = 20;

      const vals = [
        rowItem.feederName || '',
        rowItem.caseTemp !== '' ? (isNaN(Number(rowItem.caseTemp)) ? rowItem.caseTemp : Number(rowItem.caseTemp)) : '',
        rowItem.currentR !== '' ? (isNaN(Number(rowItem.currentR)) ? rowItem.currentR : Number(rowItem.currentR)) : '',
        rowItem.currentY !== '' ? (isNaN(Number(rowItem.currentY)) ? rowItem.currentY : Number(rowItem.currentY)) : '',
        rowItem.currentB !== '' ? (isNaN(Number(rowItem.currentB)) ? rowItem.currentB : Number(rowItem.currentB)) : '',
        rowItem.remarks || ''
      ];

      vals.forEach((val, idx) => {
        const cell = row.getCell(idx + 1);
        cell.value = val;
        applyBorderGrid(cell);
        cell.alignment = { vertical: 'middle', horizontal: idx === 0 ? 'left' : 'center' };
        cell.font = { name: 'Arial', size: 10, bold: idx === 0 };
      });

      currentRow++;
    });

    currentRow += 2;
  });

  // Observations & Recommendations
  if (data.observations || data.recommendations) {
    worksheet.mergeCells(currentRow, 1, currentRow, 10);
    const obsTitleCell = worksheet.getCell(currentRow, 1);
    obsTitleCell.value = 'OBSERVATIONS & RECOMMENDATIONS';
    styleHeaderCell(obsTitleCell, 'FFF97316');
    worksheet.getRow(currentRow).height = 24;
    currentRow++;

    worksheet.mergeCells(currentRow, 1, currentRow, 2);
    const cellObsLbl = worksheet.getCell(currentRow, 1);
    cellObsLbl.value = 'Test Observations:';
    styleHeaderCell(cellObsLbl, 'FFF1F5F9', false);

    worksheet.mergeCells(currentRow, 3, currentRow, 10);
    const cellObsVal = worksheet.getCell(currentRow, 3);
    cellObsVal.value = data.observations || '';
    cellObsVal.alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
    applyBorderGrid(cellObsVal);
    worksheet.getRow(currentRow).height = 50;
    currentRow++;

    worksheet.mergeCells(currentRow, 1, currentRow, 2);
    const cellRecLbl = worksheet.getCell(currentRow, 1);
    cellRecLbl.value = 'Professional Recommendations:';
    styleHeaderCell(cellRecLbl, 'FFF1F5F9', false);

    worksheet.mergeCells(currentRow, 3, currentRow, 10);
    const cellRecVal = worksheet.getCell(currentRow, 3);
    cellRecVal.value = data.recommendations || '';
    cellRecVal.alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
    applyBorderGrid(cellRecVal);
    worksheet.getRow(currentRow).height = 50;
    currentRow++;
  }

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

/**
 * Export Lightning Arrestor / Lightning Protection Test to Excel
 */
export const exportLightningArrestorToExcel = async (data: LightningArrestorReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Grounding Resistance');

  worksheet.columns = [
    { header: 'Sr. No', key: 'srNo', width: 10, style: { alignment: { vertical: 'middle', horizontal: 'center' } } },
    { header: 'Earth Pit Names', key: 'pitName', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'left' } } },
    { header: 'Arrester Location', key: 'location', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'left' } } },
    { header: 'Conductor Size & Type', key: 'conductorType', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'left' } } },
    { header: 'Grounding Value (Ω)', key: 'groundingValue', width: 22, style: { alignment: { vertical: 'middle', horizontal: 'center' } } },
    { header: 'Accept Value (Ω)', key: 'acceptValue', width: 20, style: { alignment: { vertical: 'middle', horizontal: 'center' } } },
    { header: 'Remarks', key: 'remarks', width: 25, style: { alignment: { vertical: 'middle', horizontal: 'left' } } },
    { header: 'Result', key: 'result', width: 15, style: { alignment: { vertical: 'middle', horizontal: 'center' } } },
  ];

  const headerRow = worksheet.getRow(1);
  headerRow.height = 26;
  headerRow.eachCell((cell) => {
    styleHeaderCell(cell, 'FFF97316'); // Orange theme header to match UI
  });

  (data.laReadings || []).forEach((r, idx) => {
    const gv = r.groundingValue !== '' && r.groundingValue !== undefined ? parseFloat(r.groundingValue) : '';
    const av = r.acceptValue !== '' && r.acceptValue !== undefined ? parseFloat(r.acceptValue) : '';

    const row = worksheet.addRow({
      srNo: idx + 1,
      pitName: r.pitName || '',
      location: r.location || '',
      conductorType: r.conductorType || '',
      groundingValue: isNaN(gv as number) ? r.groundingValue : gv,
      acceptValue: isNaN(av as number) ? r.acceptValue : av,
      remarks: r.remarks || '',
      result: r.result || '...'
    });
    row.height = 22;

    row.eachCell((cell, colNumber) => {
      applyBorderGrid(cell);
      cell.font = { name: 'Arial', size: 10 };
      if (colNumber === 1) {
        cell.font = { name: 'Arial', size: 10, bold: true };
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
      } else if (colNumber === 5 || colNumber === 6) {
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        cell.font = { name: 'Arial', size: 10, bold: true };
      } else if (colNumber === 8) {
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        const resStr = String(cell.value || '').toLowerCase();
        if (resStr === 'pass') {
          cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FF15803D' } };
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDCFCE7' } };
        } else if (resStr === 'fail') {
          cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFB91C1C' } };
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
        }
      }
    });
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

export const exportDGEnduranceToExcel = async (data: DGEnduranceReading, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const themeColor = 'FF0F172A'; // Slate 900
  
  if (!data.dgUnits || data.dgUnits.length === 0) {
    workbook.addWorksheet('No Data');
  } else {
    data.dgUnits.forEach((unit, uIdx) => {
      const prefix = `DG${uIdx + 1}`;
      
      // T1: Parameter matrix
      const wsT1 = workbook.addWorksheet(`${prefix} - Parameters`);
      wsT1.columns = [
        { header: 'Parameter', key: 'parameter', width: 25 },
        { header: 'Unit', key: 'unit', width: 10 },
        { header: '0', key: 'v0', width: 12 },
        { header: '25', key: 'v25', width: 12 },
        { header: '50', key: 'v50', width: 12 },
        { header: '75', key: 'v75', width: 12 },
        { header: '100', key: 'v100', width: 12 },
        { header: 'Remarks', key: 'remarks', width: 30 }
      ];
      const headerT1 = wsT1.getRow(1);
      headerT1.eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.loadReadings || []).forEach(r => {
        const row = wsT1.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T2: Transient Load Test Summary
      const wsT2 = workbook.addWorksheet(`${prefix} - Transient Load`);
      wsT2.columns = [
        { header: 'Sr No', key: 'srNo', width: 10 },
        { header: 'Transient Load', key: 'load', width: 25 },
        { header: 'Result', key: 'result', width: 15 }
      ];
      const headerT2 = wsT2.getRow(1);
      headerT2.eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.transientSummary || []).forEach(r => {
        const row = wsT2.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T3: Noise Level Measurement
      const wsT3 = workbook.addWorksheet(`${prefix} - Noise Level`);
      wsT3.columns = [
        { header: 'Load in %', key: 'load', width: 15 },
        { header: 'Doors Open', key: 'open', width: 15 },
        { header: 'Doors Closed', key: 'closed', width: 15 }
      ];
      const headerT3 = wsT3.getRow(1);
      headerT3.eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.noiseLevels || []).forEach(r => {
        const row = wsT3.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T4: Vibration Measurement Values
      const wsT4 = workbook.addWorksheet(`${prefix} - Vibration`);
      wsT4.columns = [
        { header: 'Load %', key: 'load', width: 10 },
        { header: 'A', key: 'a', width: 10 },
        { header: 'B', key: 'b', width: 10 },
        { header: 'C', key: 'c', width: 10 },
        { header: 'D', key: 'd', width: 10 },
        { header: 'E', key: 'e', width: 10 },
        { header: 'F', key: 'f', width: 10 },
        { header: 'G', key: 'g', width: 10 },
        { header: 'H', key: 'h', width: 10 }
      ];
      const headerT4 = wsT4.getRow(1);
      headerT4.eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.vibrationLevels || []).forEach(r => {
        const row = wsT4.addRow(r);
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });

      // T5: Fuel Consumption Summary
      const wsT5 = workbook.addWorksheet(`${prefix} - Fuel Consum`);
      wsT5.columns = [
        { header: 'Sr No', key: 'srNo', width: 10 },
        { header: '% LOAD', key: 'percentLoad', width: 15 },
        { header: 'TIME', key: 'time', width: 15 },
        { header: 'kWh Generated Initial', key: 'kwhInitial', width: 25 },
        { header: 'kWh Generated Final', key: 'kwhFinal', width: 25 },
        { header: 'kWh Generated Consumed', key: 'kwhUnits', width: 25 },
        { header: 'Fuel in Litres Initial', key: 'fuelInitial', width: 25 },
        { header: 'Fuel in Litres Final', key: 'fuelFinal', width: 25 },
        { header: 'Fuel in Litres Consumed', key: 'fuelConsum', width: 25 },
        { header: 'OEM Std (L/H)', key: 'oemStd', width: 20 },
        { header: 'Efficiency (kWh/L)', key: 'efficiency', width: 25 }
      ];
      const headerT5 = wsT5.getRow(1);
      headerT5.eachCell(cell => { styleHeaderCell(cell, themeColor); applyBorderGrid(cell); });
      (unit.fuelSummary || []).forEach(r => {
        const initKwh = parseFloat(r.kwhInitial) || 0;
        const finalKwh = parseFloat(r.kwhFinal) || 0;
        const consKwh = finalKwh - initKwh;
        const initF = parseFloat(r.fuelInitial) || 0;
        const finalF = parseFloat(r.fuelFinal) || 0;
        const consF = finalF - initF;
        const eff = consF > 0 ? (consKwh / consF).toFixed(2) : '0.00';
        
        const row = wsT5.addRow({
          ...r,
          kwhUnits: consKwh.toString(),
          fuelConsum: consF.toString(),
          efficiency: eff
        });
        row.eachCell(cell => { applyBorderGrid(cell); cell.alignment = { vertical: 'middle', horizontal: 'center' }; });
      });
    });
  }

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  saveAs(blob, fileName);
};
