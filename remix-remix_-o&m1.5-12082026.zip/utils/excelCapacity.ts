import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { PahuTable, PacTable, PahuEntry, PacEntry } from '../types';
import { applyBorderGrid, styleHeaderCell } from './excelExport';
import * as XLSX from 'xlsx';

export const exportPahuTableToExcel = async (table: PahuTable, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet((table.title || 'PAHU Table').substring(0, 31));

  worksheet.columns = [
    { width: 18 }, { width: 18 }, { width: 18 }, // Equip, Model, Serial
    { width: 15 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, { width: 15 }, // Design specs
    { width: 15 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, // Measured specs Air Side
    { width: 12 }, // Power
    { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, { width: 15 } // Measured specs Water Side
  ];

  let currentRow = 1;

  // 1. Table Header Row (Merged Title)
  worksheet.mergeCells(currentRow, 1, currentRow, 20);
  const titleCell = worksheet.getCell(currentRow, 1);
  titleCell.value = `${table.tableNumber || ''} - ${table.title || 'PAHU CAPACITY TABLE'}`.toUpperCase();
  styleHeaderCell(titleCell, 'FF1E3A8A'); // Navy Blue
  titleCell.font = { ...titleCell.font, color: { argb: 'FFFFFFFF' } };
  worksheet.getRow(currentRow).height = 40;
  currentRow++;

  // 2. Main Headers Row
  const eqCell = worksheet.getCell(currentRow, 1); eqCell.value = 'Equipment ID';
  const mdlCell = worksheet.getCell(currentRow, 2); mdlCell.value = 'Model No';
  const slCell = worksheet.getCell(currentRow, 3); slCell.value = 'Serial No';
  [eqCell, mdlCell, slCell].forEach(c => { styleHeaderCell(c, 'FFF97316'); c.font = { ...c.font, color: { argb: 'FFFFFFFF' } }; });
  
  worksheet.mergeCells(currentRow, 4, currentRow, 9);
  const mDesign = worksheet.getCell(currentRow, 4);
  mDesign.value = 'Design';
  styleHeaderCell(mDesign, 'FF3B82F6'); mDesign.font = { ...mDesign.font, color: { argb: 'FFFFFFFF' } };

  worksheet.mergeCells(currentRow, 10, currentRow, 20);
  const mMeasured = worksheet.getCell(currentRow, 10);
  mMeasured.value = 'Measured';
  styleHeaderCell(mMeasured, 'FF10B981'); mMeasured.font = { ...mMeasured.font, color: { argb: 'FFFFFFFF' } };

  currentRow++;

  // 3. Sub Headers Row
  const subHeaders = [
    '', '', '',
    'Airflow \n(CFM)', 'RA Temp \n(°C)', 'SA Temp \n(°C)', 'Power \n(kW)', 'Water Flow \n(GPM)', 'Cooling Tonnage \n(TR)',
    'Airflow \n(CFM)', 'SA Temp \n(°C)', 'RA Temp \n(°C)', 'Fan Speed \n(%)', 'Cooling Tonnage (Air) \n(TR)',
    'Power \n(kW)',
    'CHW In \n(°C)', 'CHW Out \n(°C)', 'Valve \n(%)', 'Water Flow \n(GPM)', 'Cooling Tonnage (Water) \n(TR)'
  ];

  const subRow = worksheet.getRow(currentRow);
  subRow.height = 35;
  subHeaders.forEach((sh, i) => {
    if (i < 3) return; // skip equip cols
    const c = subRow.getCell(i + 1);
    c.value = sh;
    
    if (i >= 3 && i <= 8) {
      styleHeaderCell(c, 'FF3B82F6'); c.font = { ...c.font, color: { argb: 'FFFFFFFF' } };
    } else {
      styleHeaderCell(c, 'FF10B981'); c.font = { ...c.font, color: { argb: 'FFFFFFFF' } };
    }
  });

  // Merge equip cells vertically
  worksheet.mergeCells(currentRow - 1, 1, currentRow, 1);
  worksheet.mergeCells(currentRow - 1, 2, currentRow, 2);
  worksheet.mergeCells(currentRow - 1, 3, currentRow, 3);
  
  currentRow++;

  const getNum = (v: any) => {
    if (!v) return 0;
    const p = parseFloat(String(v));
    return isNaN(p) ? 0 : p;
  };

  const numOrStr = (v: any) => {
    if (!v && v !== 0) return '';
    const p = parseFloat(String(v));
    return isNaN(p) ? v : p;
  };

  // Data processing
  (table.entries || []).forEach(ent => {
    const r = worksheet.getRow(currentRow);
    r.height = 25;

    const cfmDesign = getNum(ent.designAirflow);
    const raDesign = getNum(ent.designRaTemp);
    const saDesign = getNum(ent.designSaTemp);
    let dTr = 0;
    if (!(cfmDesign === 0 && raDesign === 0 && saDesign === 0)) {
      dTr = (1.06 * cfmDesign * (raDesign - saDesign) * 1.8) / 12000;
    }

    const cfmMeas = getNum(ent.measuredAirflow);
    const raMeas = getNum(ent.measuredRaTemp);
    const saMeas = getNum(ent.measuredSaTemp);
    let mTr = 0;
    if (!(cfmMeas === 0 && raMeas === 0 && saMeas === 0)) {
      mTr = (1.06 * cfmMeas * (raMeas - saMeas) * 1.8) / 12000;
    }
    
    // water calculation logic
    const gpmVal = getNum(ent.measuredWaterFlowRate);
    const inVal = getNum(ent.measuredChwIn);
    const outVal = getNum(ent.measuredChwOut);
    const deltaC = Math.abs(outVal - inVal);
    const waterTr = (gpmVal * deltaC * 1.8) / 24;

    const vals = [
      ent.equipmentId, ent.modelNo, ent.serialNo,
      numOrStr(ent.designAirflow), numOrStr(ent.designRaTemp), numOrStr(ent.designSaTemp), numOrStr(ent.designPower), numOrStr(ent.designWaterFlowRate), parseFloat(dTr.toFixed(2)),
      numOrStr(ent.measuredAirflow), numOrStr(ent.measuredSaTemp), numOrStr(ent.measuredRaTemp), numOrStr(ent.measuredFanSpeed), parseFloat(mTr.toFixed(2)),
      numOrStr(ent.measuredPower), 
      numOrStr(ent.measuredChwIn), numOrStr(ent.measuredChwOut), numOrStr(ent.measuredValveOpening), numOrStr(ent.measuredWaterFlowRate), parseFloat(waterTr.toFixed(2))
    ];

    vals.forEach((v, idx) => {
      const c = r.getCell(idx + 1);
      c.value = v;
      applyBorderGrid(c);
      c.alignment = { vertical: 'middle', horizontal: 'center' };
      if (idx === 8 || idx === 13 || idx === 19) {
         c.font = { bold: true };
      }
    });

    currentRow++;
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

export const parsePahuTableExcel = async (fileData: ArrayBuffer): Promise<PahuEntry[] | null> => {
  try {
    const workbook = XLSX.read(fileData, { type: 'buffer' });
    const pahu: PahuEntry[] = [];

    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    if (!sheet) return null;

    const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    let dataRowIdx = 0;
    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      if (!row || row.length === 0) continue;
      const col0 = String(row[0] || '').toUpperCase();
      if (col0.includes('EQUIPMENT ID') || col0.includes('EQUIPMENTID') || r >= 2) {
        dataRowIdx = r + 1;
        if (col0.includes('EQUIPMENT ID') || col0.includes('EQUIPMENTID')) {
           // Skip sub-header row if there's one
           dataRowIdx = r + 2; 
        }
        break;
      }
    }

    // Try to adjust if not getting data correctly. We usually expect data at index 3 or 4
    if (dataRowIdx < 3) dataRowIdx = 3;

    for (let r = dataRowIdx; r < rows.length; r++) {
      const row = rows[r];
      if (!row || row.length === 0) continue;
      const equipId = String(row[0] || '').trim();
      if (!equipId || equipId.toUpperCase().includes('TOTAL') || equipId.toUpperCase().includes('SUBTOTAL')) continue;
      if (equipId.includes('Airflow')) continue; // In case it matched header

      pahu.push({
        id: `pahu-imp-${Date.now()}-${r}`,
        equipmentId: equipId,
        modelNo: String(row[1] || ''),
        serialNo: String(row[2] || ''),
        designAirflow: String(row[3] || '0'),
        designRaTemp: String(row[4] || '0'),
        designSaTemp: String(row[5] || '0'),
        designPower: String(row[6] || '0'),
        designWaterFlowRate: String(row[7] || '0'),
        measuredAirflow: String(row[9] || '0'),
        measuredSaTemp: String(row[10] || '0'),
        measuredRaTemp: String(row[11] || '0'),
        measuredFanSpeed: String(row[12] || '0'),
        measuredPower: String(row[14] || '0'),
        measuredChwIn: String(row[15] || '0'),
        measuredChwOut: String(row[16] || '0'),
        measuredValveOpening: String(row[17] || '0'),
        measuredWaterFlowRate: String(row[18] || '0'),
        designCoolingTonnage: '',
        measuredCoolingTonnage: '',
        measuredWaterCoolingTonnage: ''
      });
    }

    return pahu;
  } catch (err) {
    console.error('Failed to parse PAHU Table Excel:', err);
    return null;
  }
};

export const exportPacTableToExcel = async (table: PacTable, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet((table.title || 'PAC Table').substring(0, 31));

  worksheet.columns = [
    { width: 18 }, { width: 18 }, { width: 18 }, // Equip, Model, Serial
    { width: 15 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 15 }, // Design specs
    { width: 12 }, // Fan speed
    { width: 15 }, { width: 12 }, { width: 12 }, { width: 15 }, { width: 12 }, { width: 12 } // Measured specs Air Side
  ];

  let currentRow = 1;

  worksheet.mergeCells(currentRow, 1, currentRow, 15);
  const titleCell = worksheet.getCell(currentRow, 1);
  titleCell.value = `${table.tableNumber || ''} - ${table.title || 'PAC CAPACITY TABLE'}`.toUpperCase();
  styleHeaderCell(titleCell, 'FF1E3A8A'); 
  titleCell.font = { ...titleCell.font, color: { argb: 'FFFFFFFF' } };
  worksheet.getRow(currentRow).height = 40;
  currentRow++;

  // Main Headers Row
  const eqCell = worksheet.getCell(currentRow, 1); eqCell.value = 'Equipment ID';
  const mdlCell = worksheet.getCell(currentRow, 2); mdlCell.value = 'Model No';
  const slCell = worksheet.getCell(currentRow, 3); slCell.value = 'Serial No';
  [eqCell, mdlCell, slCell].forEach(c => { styleHeaderCell(c, 'FFF97316'); c.font = { ...c.font, color: { argb: 'FFFFFFFF' } }; });
  
  worksheet.mergeCells(currentRow, 4, currentRow, 8);
  const mDesign = worksheet.getCell(currentRow, 4); mDesign.value = 'Design';
  styleHeaderCell(mDesign, 'FF3B82F6'); mDesign.font = { ...mDesign.font, color: { argb: 'FFFFFFFF' } };

  const fanCell = worksheet.getCell(currentRow, 9); fanCell.value = 'Measured';
  styleHeaderCell(fanCell, 'FFF97316'); fanCell.font = { ...fanCell.font, color: { argb: 'FFFFFFFF' } };

  worksheet.mergeCells(currentRow, 10, currentRow, 15);
  const mMeasured = worksheet.getCell(currentRow, 10); mMeasured.value = 'Measured';
  styleHeaderCell(mMeasured, 'FF3B82F6'); mMeasured.font = { ...mMeasured.font, color: { argb: 'FFFFFFFF' } };

  currentRow++;

  // Sub Headers Row
  const subHeaders = [
    '', '', '',
    'Airflow \n(CFM)', 'RA Temp \n(°C)', 'SA Temp \n(°C)', 'Power \n(kW)', 'Cooling Tonnage \n(TR)',
    'Fan Speed \n(%)',
    'Airflow \n(CFM)', 'RA Temp \n(°C)', 'SA Temp \n(°C)', 'Cooling Tonnage (Air) \n(TR)', 'Power \n(kW)', 'COP'
  ];

  const subRow = worksheet.getRow(currentRow);
  subRow.height = 35;
  subHeaders.forEach((sh, i) => {
    if (i < 3) return; 
    const c = subRow.getCell(i + 1);
    c.value = sh;
    
    if ((i >= 3 && i <= 7) || i >= 9) {
      styleHeaderCell(c, 'FF3B82F6'); c.font = { ...c.font, color: { argb: 'FFFFFFFF' } };
    } else {
      styleHeaderCell(c, 'FFF97316'); c.font = { ...c.font, color: { argb: 'FFFFFFFF' } };
    }
  });

  worksheet.mergeCells(currentRow - 1, 1, currentRow, 1);
  worksheet.mergeCells(currentRow - 1, 2, currentRow, 2);
  worksheet.mergeCells(currentRow - 1, 3, currentRow, 3);
  worksheet.mergeCells(currentRow - 1, 9, currentRow, 9); // fan speed
  
  currentRow++;

  const getNum = (v: any) => {
    if (!v) return 0;
    const p = parseFloat(String(v));
    return isNaN(p) ? 0 : p;
  };

  const numOrStr = (v: any) => {
    if (!v && v !== 0) return '';
    const p = parseFloat(String(v));
    return isNaN(p) ? v : p;
  };

  (table.entries || []).forEach(ent => {
    const r = worksheet.getRow(currentRow);
    r.height = 25;

    const cfmDesign = getNum(ent.designAirflow);
    const raDesign = getNum(ent.designRaTemp);
    const saDesign = getNum(ent.designSaTemp);
    let dTr = 0;
    if (!(cfmDesign === 0 && raDesign === 0 && saDesign === 0)) {
      dTr = (1.06 * cfmDesign * (raDesign - saDesign) * 1.8) / 12000;
    }

    const cfmMeas = getNum(ent.measuredAirflow);
    const raMeas = getNum(ent.measuredRaTemp);
    const saMeas = getNum(ent.measuredSaTemp);
    let mTr = 0;
    if (!(cfmMeas === 0 && raMeas === 0 && saMeas === 0)) {
      mTr = (1.06 * cfmMeas * (raMeas - saMeas) * 1.8) / 12000;
    }
    
    const power = getNum(ent.measuredPower);
    let cop = 0;
    if (mTr !== 0 && power !== 0) {
      cop = (mTr * 3.517) / power;
    }

    const vals = [
      ent.equipmentId, ent.modelNo, ent.serialNo,
      numOrStr(ent.designAirflow), numOrStr(ent.designRaTemp), numOrStr(ent.designSaTemp), numOrStr(ent.designPower), parseFloat(dTr.toFixed(2)),
      numOrStr(ent.fanSpeed),
      numOrStr(ent.measuredAirflow), numOrStr(ent.measuredRaTemp), numOrStr(ent.measuredSaTemp), parseFloat(mTr.toFixed(2)), numOrStr(ent.measuredPower), parseFloat(cop.toFixed(2))
    ];

    vals.forEach((v, idx) => {
      const c = r.getCell(idx + 1);
      c.value = v;
      applyBorderGrid(c);
      c.alignment = { vertical: 'middle', horizontal: 'center' };
      if (idx === 7 || idx === 12 || idx === 14) {
         c.font = { bold: true };
      }
    });

    currentRow++;
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

export const parsePacTableExcel = async (fileData: ArrayBuffer): Promise<PacEntry[] | null> => {
  try {
    const workbook = XLSX.read(fileData, { type: 'buffer' });
    const pac: PacEntry[] = [];

    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    if (!sheet) return null;

    const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    let dataRowIdx = 0;
    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      if (!row || row.length === 0) continue;
      const col0 = String(row[0] || '').toUpperCase();
      if (col0.includes('EQUIPMENT ID') || col0.includes('EQUIPMENTID') || r >= 2) {
        dataRowIdx = r + 1;
        if (col0.includes('EQUIPMENT ID') || col0.includes('EQUIPMENTID')) {
           dataRowIdx = r + 2; 
        }
        break;
      }
    }

    if (dataRowIdx < 3) dataRowIdx = 3;

    for (let r = dataRowIdx; r < rows.length; r++) {
      const row = rows[r];
      if (!row || row.length === 0) continue;
      const equipId = String(row[0] || '').trim();
      if (!equipId || equipId.toUpperCase().includes('TOTAL') || equipId.toUpperCase().includes('SUBTOTAL')) continue;
      if (equipId.includes('Airflow')) continue;

      pac.push({
        id: `pac-imp-${Date.now()}-${r}`,
        equipmentId: equipId,
        modelNo: String(row[1] || ''),
        serialNo: String(row[2] || ''),
        designAirflow: String(row[3] || '0'),
        designRaTemp: String(row[4] || '0'),
        designSaTemp: String(row[5] || '0'),
        designPower: String(row[6] || '0'),
        fanSpeed: String(row[8] || '0'),
        measuredAirflow: String(row[9] || '0'),
        measuredRaTemp: String(row[10] || '0'),
        measuredSaTemp: String(row[11] || '0'),
        measuredPower: String(row[13] || '0'),
        designCoolingTonnage: '',
        measuredCoolingTonnage: '',
        measuredFanSpeed: ''
      });
    }

    return pac;
  } catch (err) {
    console.error('Failed to parse PAC Table Excel:', err);
    return null;
  }
};
