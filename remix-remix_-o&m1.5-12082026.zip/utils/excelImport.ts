import * as XLSX from 'xlsx';
import ExcelJS from 'exceljs';
import { 
  CFMCacRow, 
  PahuEntry, 
  PacEntry, 
  RCITemperatureRow, 
  LifeCycleAssessmentRow, 
  VibrationSummaryRow 
} from '../types';

/**
 * Utility to convert values to standard floating numbers or return 0
 */
const parseFloatSafe = (val: any): number => {
  if (val === undefined || val === null) return 0;
  const parsed = parseFloat(String(val).replace(/,/g, ''));
  return isNaN(parsed) ? 0 : parsed;
};

/**
 * Recalculate CFM / CAC Airflow Required CFM
 */
export const calculateReqCFM = (loadW: string, deltaT?: number, multiplier?: number): number => {
  const loadVal = parseFloatSafe(loadW);
  const dT = deltaT || 15;
  const mult = multiplier || 1.1;
  if (loadVal <= 0 || dT <= 0) return 0;
  return (loadVal * 3.16 * mult) / dT;
};

/**
 * Recalculate PAHU & PAC Capacity Assessment TR
 * TR Formula: (1.06 * cfm * (raTemp - saTemp) * 1.8) / 12000
 */
export const calculateTR = (cfm: string, ra: string, sa: string): number => {
  const cfmVal = parseFloatSafe(cfm);
  const raVal = parseFloatSafe(ra);
  const saVal = parseFloatSafe(sa);
  if (cfmVal <= 0 || raVal <= 0 || saVal <= 0) return 0;
  return (1.06 * cfmVal * (raVal - saVal) * 1.8) / 12000;
};

/**
 * Recalculate COP: (TR * 3.517) / powerkW
 */
export const calculateCOP = (tr: number, powerKw: string): number => {
  const powerVal = parseFloatSafe(powerKw);
  if (tr <= 0 || powerVal <= 0) return 0;
  return (tr * 3.517) / powerVal;
};

/**
 * Parse uploaded Excel file for CFM / CAC Airflow Test
 */
export const parseCFMExcel = (
  fileData: any
): { left: CFMCacRow[]; right: CFMCacRow[] } | null => {
  try {
    const workbook = XLSX.read(fileData, { type: 'binary' });
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    const rowsJson: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    const left: CFMCacRow[] = [];
    const right: CFMCacRow[] = [];
    let foundHeader = false;

    for (let r = 0; r < rowsJson.length; r++) {
      const row = rowsJson[r];
      if (!row || row.length === 0) continue;

      const val0 = String(row[0] || '').trim().toUpperCase();
      if (val0.includes('RACK REFERENCE') || val0 === 'RACK_REFERENCE') {
        foundHeader = true;
        continue;
      }

      if (!foundHeader) continue;

      // Skip subtotal or footer labels or empty ending
      if (
        val0.includes('SUB TOTAL') ||
        val0.includes('SUBTOTAL') ||
        val0.includes('TOTAL') ||
        val0.includes('TOTAL SUPPLY CFM')
      ) {
        break;
      }

      const leftRack = String(row[0] !== undefined ? row[0] : '').trim();
      const leftLoad = String(row[1] !== undefined ? row[1] : '').trim();
      const leftCfm = String(row[2] !== undefined ? row[2] : '').trim();

      const rightRack = String(row[4] !== undefined ? row[4] : '').trim();
      const rightLoad = String(row[5] !== undefined ? row[5] : '').trim();
      const rightCfm = String(row[6] !== undefined ? row[6] : '').trim();

      if (!leftRack && !leftLoad && !leftCfm && !rightRack && !rightLoad && !rightCfm) {
        continue;
      }

      if (leftRack || leftLoad || leftCfm) {
        left.push({
          id: `left-${Date.now()}-${r}`,
          rackRef: leftRack,
          loadW: leftLoad,
          actualCFM: leftCfm,
        });
      }

      if (rightRack || rightLoad || rightCfm) {
        right.push({
          id: `right-${Date.now()}-${r}`,
          rackRef: rightRack,
          loadW: rightLoad,
          actualCFM: rightCfm,
        });
      }
    }

    return { left, right };
  } catch (err) {
    console.error('Failed parsing CFM airflow excel file:', err);
    return null;
  }
};

/**
 * Parse uploaded Excel file for PAHU & PAC Capacity Assessment
 */
export const parseCapacityExcel = (
  fileData: any
): { pahu: PahuEntry[]; pac: PacEntry[] } | null => {
  try {
    const workbook = XLSX.read(fileData, { type: 'binary' });
    const pahu: PahuEntry[] = [];
    const pac: PacEntry[] = [];

    // Parse PAHU sheet
    const pahuSheet = workbook.Sheets['PAHU CAPACITY'] || workbook.Sheets[workbook.SheetNames[0]];
    if (pahuSheet) {
      const pahuRows: any[][] = XLSX.utils.sheet_to_json(pahuSheet, { header: 1 });
      let dataRowIdx = 0;
      // Skip headers to find the actual columns
      for (let r = 0; r < pahuRows.length; r++) {
        const row = pahuRows[r];
        if (!row || row.length === 0) continue;
        const col0 = String(row[0] || '').toUpperCase();
        if (col0.includes('EQUIPMENT ID') || col0.includes('EQUIPMENTID') || r >= 2) {
          dataRowIdx = r + 1; // standard data starts after headers
          break;
        }
      }

      for (let r = dataRowIdx; r < pahuRows.length; r++) {
        const row = pahuRows[r];
        if (!row || row.length === 0) continue;
        const equipId = String(row[0] || '').trim();
        if (!equipId || equipId.toUpperCase().includes('TOTAL') || equipId.toUpperCase().includes('SUBTOTAL')) continue;

        let designAirflow = '';
        let designRaTemp = '';
        let designSaTemp = '';
        let designPower = '';
        let designWaterFlowRate = '';
        let designCoolingTonnage = '';

        let measuredAirflow = '';
        let measuredSaTemp = '';
        let measuredRaTemp = '';
        let measuredFanSpeed = '';
        let measuredCoolingTonnage = '';
        let measuredPower = '';
        let measuredChwIn = '';
        let measuredChwOut = '';
        let measuredValveOpening = '';
        let measuredWaterFlowRate = '';
        let measuredWaterCoolingTonnage = '';

        // If the row length suggests the new multi-column format (at least 15 elements)
        if (row.length >= 15) {
          designAirflow = String(row[3] !== undefined ? row[3] : '').trim();
          designRaTemp = String(row[4] !== undefined ? row[4] : '').trim();
          designSaTemp = String(row[5] !== undefined ? row[5] : '').trim();
          designPower = String(row[6] !== undefined ? row[6] : '').trim();
          designWaterFlowRate = String(row[7] !== undefined ? row[7] : '').trim();
          designCoolingTonnage = String(row[8] !== undefined ? row[8] : '').trim();

          measuredAirflow = String(row[9] !== undefined ? row[9] : '').trim();
          measuredSaTemp = String(row[10] !== undefined ? row[10] : '').trim();
          measuredRaTemp = String(row[11] !== undefined ? row[11] : '').trim();
          measuredFanSpeed = String(row[12] !== undefined ? row[12] : '').trim();
          measuredCoolingTonnage = String(row[13] !== undefined ? row[13] : '').trim();
          measuredPower = String(row[14] !== undefined ? row[14] : '').trim();

          measuredChwIn = String(row[15] !== undefined ? row[15] : '').trim();
          measuredChwOut = String(row[16] !== undefined ? row[16] : '').trim();
          measuredValveOpening = String(row[17] !== undefined ? row[17] : '').trim();
          measuredWaterFlowRate = String(row[18] !== undefined ? row[18] : '').trim();
          measuredWaterCoolingTonnage = String(row[19] !== undefined ? row[19] : '').trim();
        } else {
          designAirflow = String(row[3] !== undefined ? row[3] : '').trim();
          designRaTemp = String(row[4] !== undefined ? row[4] : '').trim();
          designSaTemp = String(row[5] !== undefined ? row[5] : '').trim();
          designPower = String(row[6] !== undefined ? row[6] : '').trim();
          designCoolingTonnage = String(row[7] !== undefined ? row[7] : '').trim();

          measuredAirflow = String(row[8] !== undefined ? row[8] : '').trim();
          measuredRaTemp = String(row[9] !== undefined ? row[9] : '').trim();
          measuredSaTemp = String(row[10] !== undefined ? row[10] : '').trim();
          measuredPower = String(row[11] !== undefined ? row[11] : '').trim();
          measuredCoolingTonnage = String(row[12] !== undefined ? row[12] : '').trim();
          measuredFanSpeed = String(row[13] !== undefined ? row[13] : '').trim();
        }

        // Recalculate TR if needed
        const trVal = calculateTR(measuredAirflow, measuredRaTemp, measuredSaTemp);
        const designTrVal = calculateTR(designAirflow, designRaTemp, designSaTemp);

        pahu.push({
          id: `pahu-${Date.now()}-${r}`,
          equipmentId: equipId,
          modelNo: String(row[1] || '').trim(),
          serialNo: String(row[2] || '').trim(),
          designAirflow,
          designRaTemp,
          designSaTemp,
          designPower,
          designWaterFlowRate,
          designCoolingTonnage: designCoolingTonnage || (designTrVal > 0 ? designTrVal.toFixed(2) : ''),
          measuredAirflow,
          measuredSaTemp,
          measuredRaTemp,
          measuredFanSpeed,
          measuredCoolingTonnage: measuredCoolingTonnage || (trVal > 0 ? trVal.toFixed(2) : ''),
          measuredPower,
          measuredChwIn,
          measuredChwOut,
          measuredValveOpening,
          measuredWaterFlowRate,
          measuredWaterCoolingTonnage,
        });
      }
    }

    // Parse PAC sheet
    const pacSheet = workbook.Sheets['PAC CAPACITY'] || workbook.Sheets[workbook.SheetNames[1]];
    if (pacSheet) {
      const pacRows: any[][] = XLSX.utils.sheet_to_json(pacSheet, { header: 1 });
      let dataRowIdx = 0;
      for (let r = 0; r < pacRows.length; r++) {
        const row = pacRows[r];
        if (!row || row.length === 0) continue;
        const col0 = String(row[0] || '').toUpperCase();
        if (col0.includes('EQUIPMENT ID') || col0.includes('EQUIPMENTID') || r >= 2) {
          dataRowIdx = r + 1;
          break;
        }
      }

      for (let r = dataRowIdx; r < pacRows.length; r++) {
        const row = pacRows[r];
        if (!row || row.length === 0) continue;
        const equipId = String(row[0] || '').trim();
        if (!equipId || equipId.toUpperCase().includes('TOTAL') || equipId.toUpperCase().includes('SUBTOTAL')) continue;

        const designAirflow = String(row[3] !== undefined ? row[3] : '').trim();
        const designRaTemp = String(row[4] !== undefined ? row[4] : '').trim();
        const designSaTemp = String(row[5] !== undefined ? row[5] : '').trim();
        const designPower = String(row[6] !== undefined ? row[6] : '').trim();

        const measuredAirflow = String(row[8] !== undefined ? row[8] : '').trim();
        const measuredRaTemp = String(row[9] !== undefined ? row[9] : '').trim();
        const measuredSaTemp = String(row[10] !== undefined ? row[10] : '').trim();
        const measuredPower = String(row[11] !== undefined ? row[11] : '').trim();
        const measuredFanSpeed = String(row[13] !== undefined ? row[13] : '').trim();

        const trVal = calculateTR(measuredAirflow, measuredRaTemp, measuredSaTemp);
        const designTrVal = calculateTR(designAirflow, designRaTemp, designSaTemp);

        pac.push({
          id: `pac-${Date.now()}-${r}`,
          equipmentId: equipId,
          modelNo: String(row[1] || '').trim(),
          serialNo: String(row[2] || '').trim(),
          designAirflow,
          designRaTemp,
          designSaTemp,
          designPower,
          designCoolingTonnage: designTrVal > 0 ? designTrVal.toFixed(2) : String(row[7] || '').trim(),
          fanSpeed: '', // legacy design fan speed
          measuredAirflow,
          measuredRaTemp,
          measuredSaTemp,
          measuredPower,
          measuredCoolingTonnage: trVal > 0 ? trVal.toFixed(2) : String(row[12] || '').trim(),
          measuredFanSpeed,
        });
      }
    }

    return { pahu, pac };
  } catch (err) {
    console.error('Failed parsing Capacity Assessment excel file:', err);
    return null;
  }
};

/**
 * Parse uploaded Excel file for Rack Cooling Index (RCI) Temperature Study
 */
export const parseRCICACExcel = (fileData: any): import('../types').RCITemperatureRow[] | null => {
  try {
    const workbook = XLSX.read(fileData, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rowsJson: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    const records: RCITemperatureRow[] = [];
    let foundHeader = false;

    for (let r = 0; r < rowsJson.length; r++) {
      const row = rowsJson[r];
      if (!row || row.length === 0) continue;

      const col1 = String(row[1] || '').trim().toUpperCase();
      if (col1.includes('CAC REFERENCE') || col1.includes('CAC REF') || r >= 1) {
        if (!foundHeader && (col1.includes('CAC REFERENCE') || col1.includes('CAC REF'))) {
          foundHeader = true;
          continue;
        }
      }

      // If header is not matching explicitly, assume data starts from row index 1
      if (r === 0) continue;

      const cacRef = String(row[1] !== undefined ? row[1] : '').trim();
      const rackRef = String(row[2] !== undefined ? row[2] : '').trim();
      if (!cacRef && !rackRef) continue;

      records.push({
        id: `rci-row-${Date.now()}-${r}`,
        sNo: row[0] !== undefined ? String(row[0]) : '',
        cacRef,
        rackRef,
        front15U: String(row[3] !== undefined ? row[3] : '').trim(),
        front22U: String(row[4] !== undefined ? row[4] : '').trim(),
        front35U: String(row[5] !== undefined ? row[5] : '').trim(),
        rear15U: String(row[6] !== undefined ? row[6] : '').trim(),
        rear22U: String(row[7] !== undefined ? row[7] : '').trim(),
        rear35U: String(row[8] !== undefined ? row[8] : '').trim(),
        rhFront: String(row[9] !== undefined ? row[9] : '').trim(),
        rhRear: String(row[10] !== undefined ? row[10] : '').trim(),
        inletTempResult: String(row[11] !== undefined ? row[11] : '').trim(),
        excessInletTemp: String(row[12] !== undefined ? row[12] : '').trim(),
        deficitInletTemp: String(row[13] !== undefined ? row[13] : '').trim(),
      });
    }

    return records;
  } catch (err) {
    console.error('Failed parsing RCI Study Excel:', err);
    return null;
  }
};

/**
 * Parse uploaded Excel file for Life Cycle Assessment (LCA)
 */
export const parseLCATable1Excel = (
  fileData: any
): LifeCycleAssessmentRow[] | null => {
  try {
    const workbook = XLSX.read(fileData, { type: 'binary' });
    const lifeCycleRows: LifeCycleAssessmentRow[] = [];

    // Parse Sheet 1
    const sheet1 = workbook.Sheets['LCA Table-1'] || workbook.Sheets['LCA Evaluation'] || workbook.Sheets[workbook.SheetNames[0]];
    if (sheet1) {
      const rows: any[][] = XLSX.utils.sheet_to_json(sheet1, { header: 1 });
      let dataIdx = 1;
      for (let r = 0; r < rows.length; r++) {
        const row = rows[r];
        if (row && row[1] && String(row[1] || '').toUpperCase().includes('EQUIPMENT TAG')) {
          dataIdx = r + 1;
          break;
        }
      }
      for (let r = dataIdx; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0) continue;
        const equipmentTag = String(row[1] || '').trim();
        if (!equipmentTag || equipmentTag.toUpperCase().includes('EQUIPMENT TAG')) continue;

        lifeCycleRows.push({
          id: `lca-t1-${Date.now()}-${r}`,
          equipmentTag,
          makeModel: String(row[2] !== undefined ? row[2] : '').trim(),
          serialNo: String(row[3] !== undefined ? row[3] : '').trim(),
          location: String(row[4] !== undefined ? row[4] : '').trim(),
          installYear: String(row[5] !== undefined ? row[5] : '').trim(),
          currentYear: String(row[6] !== undefined ? row[6] : '').trim(),
          ageYrs: String(row[7] !== undefined ? row[7] : '').trim(),
          vibrationScore: String(row[8] !== undefined ? row[8] : '').trim(),
          corrosionScore: String(row[9] !== undefined ? row[9] : '').trim(),
          maintScore: String(row[10] !== undefined ? row[10] : '').trim(),
          healthIndex: String(row[11] !== undefined ? row[11] : '').trim(),
          runningLifeYrs: String(row[12] !== undefined ? row[12] : '').trim(),
          utilizationRatio: String(row[13] !== undefined ? row[13] : '').trim(),
          utilizationFactor: String(row[14] !== undefined ? row[14] : '').trim()
        });
      }
    }
    return lifeCycleRows;
  } catch (err) {
    console.error('Failed parsing LCA Table-1 Study Excel:', err);
    return null;
  }
};

export const parseLCATable2Excel = (
  fileData: any
): LifeCycleAssessmentRow[] | null => {
  try {
    const workbook = XLSX.read(fileData, { type: 'binary' });
    const rulRows: LifeCycleAssessmentRow[] = [];

    // Parse Sheet 2 ('LCA Table-2' or first sheet if only 1 sheet uploaded)
    const sheet2 = workbook.Sheets['LCA Table-2'] || workbook.Sheets[workbook.SheetNames[0]];
    if (sheet2) {
      const rows: any[][] = XLSX.utils.sheet_to_json(sheet2, { header: 1 });
      let dataIdx = 1;
      for (let r = 0; r < rows.length; r++) {
        const row = rows[r];
        if (row && row[1] && String(row[1] || '').toUpperCase().includes('EQUIPMENT TAG')) {
          dataIdx = r + 1;
          break;
        }
      }
      for (let r = dataIdx; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0) continue;
        const equipmentTag = String(row[1] || '').trim();
        if (!equipmentTag || equipmentTag.toUpperCase().includes('EQUIPMENT TAG')) continue;

        rulRows.push({
          id: `lca-t2-${Date.now()}-${r}`,
          equipmentTag,
          makeModel: '',
          serialNo: '',
          location: '',
          installYear: '',
          currentYear: '',
          ageYrs: String(row[3] !== undefined ? row[3] : '').trim(),
          vibrationScore: '',
          corrosionScore: '',
          maintScore: '',
          healthIndex: String(row[4] !== undefined ? row[4] : '').trim(),
          runningLifeYrs: '',
          utilizationRatio: '',
          utilizationFactor: String(row[5] !== undefined ? row[5] : '').trim(),
          designLifeYrs: String(row[2] !== undefined ? row[2] : '').trim(),
          adjustedLifeAL: String(row[6] !== undefined ? row[6] : '').trim(),
          rulYrs: String(row[7] !== undefined ? row[7] : '').trim(),
          rulPct: String(row[8] !== undefined ? row[8] : '').trim(),
          lifeCycleStatus: String(row[9] !== undefined ? row[9] : '').trim(),
          remarksRul: String(row[10] !== undefined ? row[10] : '').trim()
        });
      }
    }
    return rulRows;
  } catch (err) {
    console.error('Failed parsing LCA Table-2 Study Excel:', err);
    return null;
  }
};

/**
 * Parse uploaded Excel file for Vibration Analysis Study
 */
export const parseVibrationGroupExcel = (fileData: any): import('../types').VibrationSummaryRow[] | null => {
  try {
    const workbook = XLSX.read(fileData, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rowsJson: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    const records: VibrationSummaryRow[] = [];
    let foundHeader = false;
    let headerRowsToSkip = 0;

    // Looking for "Equipment ID" header label
    for (let r = 0; r < rowsJson.length; r++) {
      const row = rowsJson[r];
      if (!row || row.length === 0) continue;
      const col0 = String(row[0] || '').trim().toUpperCase();
      if (col0.includes('EQUIPMENT ID') || col0.includes('EQUIPMENTID')) {
        foundHeader = true;
        headerRowsToSkip = r + 1;
        // In case of multi-header (rowSpan-ed 2 rows), check next row too
        if (rowsJson[r + 1] && String(rowsJson[r + 1][0] || '').trim() === '') {
          headerRowsToSkip = r + 1;
        }
        break;
      }
    }

    if (!foundHeader) {
      headerRowsToSkip = 2; // general default skip for top title / general headers
    }

    for (let r = headerRowsToSkip; r < rowsJson.length; r++) {
      const row = rowsJson[r];
      if (!row || row.length === 0) continue;

      const equipId = String(row[0] !== undefined ? row[0] : '').trim();
      if (!equipId) continue;
      if (equipId.toUpperCase().includes('EQUIPMENT ID') || equipId.toUpperCase().includes('MEASURED VIBRATION')) continue;

      const vertical = String(row[2] !== undefined ? row[2] : '').trim();
      const horizontal = String(row[3] !== undefined ? row[3] : '').trim();
      const axial = String(row[4] !== undefined ? row[4] : '').trim();
      let maxValueStr = String(row[5] !== undefined ? row[5] : '').trim();

      // Automatically determine maxValue if empty
      if (!maxValueStr) {
        const v = parseFloatSafe(vertical);
        const h = parseFloatSafe(horizontal);
        const a = parseFloatSafe(axial);
        const maxVal = Math.max(v, h, a);
        maxValueStr = maxVal > 0 ? (maxVal % 1 === 0 ? maxVal.toFixed(0) : maxVal.toFixed(2)) : '';
      }

      records.push({
        id: `vib-${Date.now()}-${r}`,
        equipmentId: equipId,
        classDetails: String(row[1] !== undefined ? row[1] : '').trim(),
        vertical,
        horizontal,
        axial,
        maxValue: maxValueStr,
        condition: String(row[6] !== undefined ? row[6] : 'GOOD').trim(),
      });
    }

    return records;
  } catch (err) {
    console.error('Failed parsing Vibration Analysis excel file:', err);
    return null;
  }
};
