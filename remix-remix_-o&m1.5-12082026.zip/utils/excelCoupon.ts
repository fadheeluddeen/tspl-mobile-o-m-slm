import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { CouponLocation, CorrosionReadingRow } from '../types';
import { applyBorderGrid, styleHeaderCell } from './excelExport';

export const exportCouponLocationToExcel = async (location: CouponLocation, fileName: string) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet((location.locationName || 'Coupon Test').substring(0, 31));

  worksheet.columns = [
    { width: 20 }, // Type of coupon
    { width: 15 }, // Oxide
    { width: 15 }, // Chloride
    { width: 15 }, // Sulfide
    { width: 15 }, // Other
    { width: 15 }, // Total (Å)
    { width: 20 }, // Level
    { width: 30 }, // Remarks
    { width: 40 }, // Image Graph
  ];

  // Header 
  const headerRow = worksheet.getRow(1);
  const headers = ['Type of coupon', 'Oxide', 'Chloride', 'Sulfide', 'Other', 'Total (Å)', 'Level', 'Remarks', 'Graph Image'];
  headers.forEach((h, idx) => {
    const cell = headerRow.getCell(idx + 1);
    cell.value = h;
    styleHeaderCell(cell, 'FF1E3A8A');
    cell.font = { ...cell.font, color: { argb: 'FFFFFFFF' } };
  });
  headerRow.height = 30;

  let currentRow = 2;
  (location.results || []).forEach((rowItem) => {
    const row = worksheet.getRow(currentRow);
    row.height = 25;
    
    const values = [
      rowItem.couponType,
      parseFloat(rowItem.oxide) || rowItem.oxide || 0,
      parseFloat(rowItem.chloride) || rowItem.chloride || 0,
      parseFloat(rowItem.sulfide) || rowItem.sulfide || 0,
      parseFloat(rowItem.other) || rowItem.other || 0,
      parseFloat(String(rowItem.totalAngstroms)) || 0,
      rowItem.isaLevel,
      rowItem.remarks
    ];

    values.forEach((v, colIdx) => {
      const cell = row.getCell(colIdx + 1);
      cell.value = v;
      applyBorderGrid(cell);
      cell.alignment = { vertical: 'middle', horizontal: colIdx === 0 ? 'left' : 'center' };
      if (colIdx >= 1 && colIdx <= 5) {
        cell.font = { name: 'Arial', size: 10 };
      }
    });
    
    // Add border to 9th column too
    applyBorderGrid(row.getCell(9));
    
    currentRow++;
  });

  // Adding the image if exists
  if (location.graphImage) {
    try {
      const base64Data = location.graphImage.includes(',') ? location.graphImage.split(',')[1] : location.graphImage;
      const extension = location.graphImage.includes('jpeg') || location.graphImage.includes('jpg') ? 'jpeg' : 'png';
      
      const imageId = workbook.addImage({
        base64: base64Data,
        extension: extension as 'jpeg' | 'png',
      });

      worksheet.addImage(imageId, {
        tl: { col: 8, row: 1 }, 
        ext: { width: 300, height: 200 }
      });
      // Optionally adjust row height to accommodate image
      if (currentRow < 10) {
        // give it some space or just leave default rows
      }
    } catch (err) {
      console.warn("Failed to embed image:", err);
    }
  }

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), fileName);
};

export const parseCouponLocationExcel = async (fileBuffer: ArrayBuffer): Promise<{ results: CorrosionReadingRow[], graphImage: string } | null> => {
  try {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(fileBuffer);
    
    const worksheet = workbook.worksheets[0];
    const results: CorrosionReadingRow[] = [];
    
    let graphImage = '';

    // Check for images
    const images = worksheet.getImages();
    if (images && images.length > 0) {
      const img = images[0];
      const media = workbook.getImage(img.imageId as any);
      if (media && media.buffer) {
        const ext = media.extension || 'png';
        
        // Convert Uint8Array buffer to base64
        let binary = '';
        const bytes = new Uint8Array(media.buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const b64 = btoa(binary);
        graphImage = `data:image/${ext};base64,${b64}`;
      }
    }

    // Read rows
    for (let i = 2; i <= worksheet.rowCount; i++) {
      const row = worksheet.getRow(i);
      const couponType = row.getCell(1).value?.toString() || '';
      
      if (!couponType || (!couponType.includes('Copper') && !couponType.includes('Silver'))) {
        continue; // skip empty or invalid rows
      }

      const totalValue = parseFloat(row.getCell(6).value?.toString() || '0');

      results.push({
        id: `coupon-row-${Date.now()}-${i}`,
        couponType: couponType as 'Copper (Cu)' | 'Silver (Ag)',
        oxide: row.getCell(2).value?.toString() || '0',
        chloride: row.getCell(3).value?.toString() || '0',
        sulfide: row.getCell(4).value?.toString() || '0',
        other: row.getCell(5).value?.toString() || '0',
        totalAngstroms: isNaN(totalValue) ? 0 : totalValue,
        isaLevel: row.getCell(7).value?.toString() || '',
        remarks: row.getCell(8).value?.toString() || ''
      });
    }

    return { results, graphImage };
  } catch (err) {
    console.error('Failed to parse Coupon Location Excel:', err);
    return null;
  }
};
