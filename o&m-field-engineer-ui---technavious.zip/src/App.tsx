/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ScreenId,
  ProjectRecord,
  TestRecord,
  TestTypeDefinition,
  SettingsState,
  ActiveCaptureContext,
} from './types';
import { INITIAL_PROJECTS, INITIAL_TESTS, TEST_TYPES } from './data/mockData';
import { TabletFrame } from './components/TabletFrame';
import { ScreenDashboard } from './components/screens/ScreenDashboard';
import { ScreenNewProject } from './components/screens/ScreenNewProject';
import { ScreenProjectDetail } from './components/screens/ScreenProjectDetail';
import { ScreenSelectTestType } from './components/screens/ScreenSelectTestType';
import { ScreenTestForm } from './components/screens/ScreenTestForm';
import { ScreenCapture } from './components/screens/ScreenCapture';
import { ScreenSettings } from './components/screens/ScreenSettings';
import { DesignSystemViewer } from './components/DesignSystemViewer';
import { ScreenOverviewGallery, SCREEN_SPECS } from './components/ScreenOverviewGallery';
import { ExcelExportDialog } from './components/ExcelExportDialog';
import {
  Tablet,
  Grid3X3,
  Palette,
  Sun,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Maximize2,
} from 'lucide-react';

export default function App() {
  // Navigation State
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('dashboard');
  const [activeTab, setActiveTab] = useState<'tablet' | 'gallery' | 'design_system'>('tablet');

  // Domain State
  const [projects, setProjects] = useState<ProjectRecord[]>(INITIAL_PROJECTS);
  const [tests, setTests] = useState<TestRecord[]>(INITIAL_TESTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('proj_01');
  const [selectedTestId, setSelectedTestId] = useState<string>('test_101');

  // Camera Capture Context
  const [captureContext, setCaptureContext] = useState<ActiveCaptureContext>({
    testId: 'test_101',
    fieldId: 'vertical',
    fieldName: 'Vertical Vibration',
    unit: 'mm/s',
    meterHint: 'Fluke 805 / CSI 2140',
  });

  // Background AI State
  const [isAiReadingFieldId, setIsAiReadingFieldId] = useState<string | null>(null);

  // Settings State
  const [settings, setSettings] = useState<SettingsState>({
    aiReadingMode: 'gemini',
    geminiApiKey: 'AIzaSyA8e6c53399be258105b19ed2Technavious',
    offlineModelInstalled: false, // Default to false so warning card is visible!
    offlineModelStatus: 'missing',
    outdoorMode: false,
    showTouchHitboxes: false,
  });

  // Export to Excel dialog state
  const [exportTestTarget, setExportTestTarget] = useState<TestRecord | null>(null);

  // Derived Active Data
  const activeProject = projects.find((p) => p.id === selectedProjectId) || projects[0] || {
    id: 'temp_proj',
    name: 'Technavious Facility Audit',
    clientName: 'Client Not Selected',
    address: 'Site Address',
    createdAt: '2026-09-28',
    testsCount: 0,
  };

  const projectTests = tests.filter((t) => t.projectId === activeProject.id);

  const activeTest = tests.find((t) => t.id === selectedTestId) || projectTests[0] || tests[0] || {
    id: 'temp_test',
    projectId: activeProject.id,
    testTypeId: 'vibration_analysis',
    testName: 'General Vibration Audit',
    status: 'Draft' as const,
    location: 'Basement Mechanical Room',
    docNo: 'TECH-VA-2026-01',
    createdAt: '2026-09-28',
    updatedAt: '2026-09-28',
    readings: {},
  };

  const activeTestType =
    TEST_TYPES.find((tt) => tt.id === activeTest.testTypeId) || TEST_TYPES[0];

  // Handlers for Screen 1 (Dashboard)
  const handleOpenProject = (projectId: string) => {
    setSelectedProjectId(projectId);
    setCurrentScreen('project_detail');
  };

  const handleDeleteProject = (projectId: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== projectId));
    setTests((prev) => prev.filter((t) => t.projectId !== projectId));
  };

  // Handlers for Screen 2 (New Project)
  const handleCreateProject = (newProjData: { name: string; clientName: string; address: string }) => {
    const newId = `proj_${Date.now()}`;
    const newProj: ProjectRecord = {
      id: newId,
      name: newProjData.name,
      clientName: newProjData.clientName,
      address: newProjData.address,
      createdAt: new Date().toISOString().split('T')[0],
      testsCount: 0,
    };
    setProjects([newProj, ...projects]);
    setSelectedProjectId(newId);
    setCurrentScreen('project_detail');
  };

  // Handlers for Screen 3 (Project Detail)
  const handleOpenTest = (testId: string) => {
    setSelectedTestId(testId);
    setCurrentScreen('test_form');
  };

  const handleDeleteTest = (testId: string) => {
    setTests((prev) => prev.filter((t) => t.id !== testId));
    setProjects((prev) =>
      prev.map((p) => (p.id === activeProject.id ? { ...p, testsCount: Math.max(0, p.testsCount - 1) } : p))
    );
  };

  // Handlers for Screen 4 (Select Test Type)
  const handleSelectTestType = (typeDef: TestTypeDefinition) => {
    const newTestId = `test_${Date.now()}`;
    const docPrefix = typeDef.name.substring(0, 2).toUpperCase();
    const newDocNo = `TECH-${docPrefix}-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newTestRecord: TestRecord = {
      id: newTestId,
      projectId: activeProject.id,
      testTypeId: typeDef.id,
      testName: `${typeDef.name} Protocol`,
      status: 'Draft',
      location: activeProject.name,
      docNo: newDocNo,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      readings: {},
    };

    setTests((prev) => [newTestRecord, ...prev]);
    setProjects((prev) =>
      prev.map((p) => (p.id === activeProject.id ? { ...p, testsCount: p.testsCount + 1 } : p))
    );
    setSelectedTestId(newTestId);
    setCurrentScreen('test_form');
  };

  // Handlers for Screen 5 (Test Form)
  const handleSaveTestForm = (updatedTest: TestRecord) => {
    setTests((prev) => prev.map((t) => (t.id === updatedTest.id ? updatedTest : t)));
  };

  const handleOpenCamera = (fieldId: string, fieldName: string, unit: string) => {
    setCaptureContext({
      testId: activeTest.id,
      fieldId,
      fieldName,
      unit,
      meterHint: activeTestType.meterTypeHint,
    });
    setCurrentScreen('capture');
  };

  const handleRereadAI = (fieldId: string) => {
    setIsAiReadingFieldId(fieldId);
    setTimeout(() => {
      setIsAiReadingFieldId(null);
      // Re-read simulation updates value with small variance
      const fieldDef = activeTestType.readingFields.find((f) => f.id === fieldId);
      const currentVal = activeTest.readings[fieldId]?.value || fieldDef?.sampleAiValue || '3.45';
      const num = parseFloat(currentVal) || 3.45;
      const updatedVal = (num + (Math.random() * 0.06 - 0.03)).toFixed(2);

      setTests((prev) =>
        prev.map((t) => {
          if (t.id === activeTest.id) {
            return {
              ...t,
              readings: {
                ...t.readings,
                [fieldId]: {
                  fieldId,
                  value: updatedVal,
                  aiSource: settings.aiReadingMode === 'gemini' ? 'Gemini AI' : 'Offline AI',
                  aiConfidence: 0.98,
                  photoTimestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  photoUrl: 'meter_reread.jpg',
                },
              },
            };
          }
          return t;
        })
      );
    }, 1100);
  };

  // Handlers for Screen 6 (Capture)
  const handleAcceptCapturedReading = (
    value: string,
    source: 'Gemini AI' | 'Offline AI' | 'Manual'
  ) => {
    const fieldId = captureContext.fieldId;
    setTests((prev) =>
      prev.map((t) => {
        if (t.id === activeTest.id) {
          return {
            ...t,
            readings: {
              ...t.readings,
              [fieldId]: {
                fieldId,
                value,
                aiSource: source,
                aiConfidence: 0.98,
                photoTimestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                photoUrl: 'captured_meter_photo.jpg',
              },
            },
          };
        }
        return t;
      })
    );
    setCurrentScreen('test_form');
  };

  // Handlers for Settings
  const handleUpdateSettings = (newSettings: Partial<SettingsState>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Reset sample data helper
  const handleResetSampleData = () => {
    setProjects(INITIAL_PROJECTS);
    setTests(INITIAL_TESTS);
    setSelectedProjectId('proj_01');
    setSelectedTestId('test_101');
  };

  // Render current tablet screen
  const renderCurrentScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return (
          <ScreenDashboard
            projects={projects}
            settings={settings}
            onOpenProject={handleOpenProject}
            onNewProject={() => setCurrentScreen('new_project')}
            onOpenSettings={() => setCurrentScreen('settings')}
            onDeleteProject={handleDeleteProject}
            onResetSampleData={handleResetSampleData}
            onClearAllProjects={() => setProjects([])}
          />
        );

      case 'new_project':
        return (
          <ScreenNewProject
            onBack={() => setCurrentScreen('dashboard')}
            onCreateProject={handleCreateProject}
          />
        );

      case 'project_detail':
        return (
          <ScreenProjectDetail
            project={activeProject}
            tests={projectTests}
            onBack={() => setCurrentScreen('dashboard')}
            onOpenTest={handleOpenTest}
            onAddTest={() => setCurrentScreen('select_test_type')}
            onDeleteTest={handleDeleteTest}
            onClearAllTests={() => setTests((prev) => prev.filter((t) => t.projectId !== activeProject.id))}
            onRestoreSampleTests={handleResetSampleData}
          />
        );

      case 'select_test_type':
        return (
          <ScreenSelectTestType
            onBack={() => setCurrentScreen('project_detail')}
            onSelectTestType={handleSelectTestType}
          />
        );

      case 'test_form':
        return (
          <ScreenTestForm
            test={activeTest}
            testType={activeTestType}
            onBack={() => setCurrentScreen('project_detail')}
            onSave={handleSaveTestForm}
            onExportExcel={(test) => setExportTestTarget(test)}
            onOpenCamera={handleOpenCamera}
            onRereadAI={handleRereadAI}
            isAiReadingFieldId={isAiReadingFieldId}
          />
        );

      case 'capture': {
        const fieldDef = activeTestType.readingFields.find((f) => f.id === captureContext.fieldId);
        return (
          <ScreenCapture
            fieldName={captureContext.fieldName}
            unit={captureContext.unit}
            aiMode={settings.aiReadingMode}
            suggestedSampleValue={fieldDef?.sampleAiValue || '3.42'}
            onBack={() => setCurrentScreen('test_form')}
            onAcceptReading={handleAcceptCapturedReading}
          />
        );
      }

      case 'settings':
        return (
          <ScreenSettings
            settings={settings}
            onBack={() => setCurrentScreen('dashboard')}
            onUpdateSettings={handleUpdateSettings}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Universal Top Bar */}
      <header className="h-16 px-4 md:px-8 border-b border-neutral-800 bg-neutral-900/90 backdrop-blur-md flex items-center justify-between shrink-0 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-orange-600 text-white font-black text-lg flex items-center justify-center shadow-sm">
            O
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base text-white tracking-tight">O&amp;M UI Design Spec</span>
              <span className="text-[11px] font-bold text-orange-400 bg-orange-950/80 border border-orange-800/80 px-2 py-0.5 rounded">
                Technavious Field Engine
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 hidden sm:block">
              Jetpack Compose + Material 3 · Lenovo Tab 11&quot; (1200×1920) · Min 48dp Touch Targets
            </p>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-neutral-800 rounded-xl border border-neutral-700/80">
            <button
              onClick={() => setActiveTab('tablet')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'tablet'
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Tablet className="w-3.5 h-3.5" />
              <span>Tablet Simulator</span>
            </button>
            <button
              onClick={() => setActiveTab('gallery')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'gallery'
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              <span>All 7 Screens Gallery</span>
            </button>
            <button
              onClick={() => setActiveTab('design_system')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'design_system'
                  ? 'bg-orange-600 text-white shadow-xs'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Design Tokens &amp; Specs</span>
            </button>
          </div>
        </div>
      </header>

      {/* QUICK SCREEN JUMP BAR & FIELD TOGGLES */}
      <div className="px-4 md:px-8 py-2.5 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between gap-4 overflow-x-auto text-xs shrink-0 select-none">
        {/* Screen jumps */}
        <div className="flex items-center gap-1.5">
          <span className="text-neutral-400 font-semibold text-[11px] uppercase tracking-wider mr-1">
            Jump to screen:
          </span>
          {SCREEN_SPECS.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                setCurrentScreen(s.id);
                if (activeTab !== 'tablet') setActiveTab('tablet');
              }}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1 ${
                currentScreen === s.id && activeTab === 'tablet'
                  ? 'bg-orange-600 text-white font-bold'
                  : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
              }`}
            >
              <span className="opacity-70 font-mono text-[10px]">0{s.number}</span>
              <span>{s.title.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Ergonomic Quick Toggles for testing site conditions */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Outdoor Mode Quick Toggle */}
          <button
            onClick={() => handleUpdateSettings({ outdoorMode: !settings.outdoorMode })}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 ${
              settings.outdoorMode
                ? 'bg-amber-500 text-neutral-950 shadow-xs'
                : 'bg-neutral-800 text-neutral-400 hover:text-white'
            }`}
            title="Toggle High Contrast Sunlight Mode for outdoors"
          >
            <Sun className="w-3.5 h-3.5" />
            <span>Outdoor Sunlight</span>
          </button>

          {/* Glove Hitbox Visualizer */}
          <button
            onClick={() => handleUpdateSettings({ showTouchHitboxes: !settings.showTouchHitboxes })}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 ${
              settings.showTouchHitboxes
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/60'
                : 'bg-neutral-800 text-neutral-400 hover:text-white'
            }`}
            title="Inspect ≥48dp touch targets for heavy field gloves"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>≥48dp Glove Overlay</span>
          </button>
        </div>
      </div>

      {/* Main View Area */}
      <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-y-auto">
        {activeTab === 'tablet' && (
          <div className="flex flex-col items-center justify-center">
            {/* Active Screen Info Pill */}
            <div className="mb-4 flex items-center gap-2 text-xs font-semibold text-neutral-400">
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
              <span>Simulating Lenovo Tab (11-inch Portrait, 1200×1920)</span>
              <span>·</span>
              <span className="text-orange-400">
                Active: {SCREEN_SPECS.find((s) => s.id === currentScreen)?.title}
              </span>
            </div>

            <TabletFrame settings={settings} currentScreenName={currentScreen}>
              {renderCurrentScreen()}
            </TabletFrame>
          </div>
        )}

        {activeTab === 'gallery' && (
          <ScreenOverviewGallery
            currentScreen={currentScreen}
            onNavigateToScreen={(scr) => {
              setCurrentScreen(scr);
              setActiveTab('tablet');
            }}
          />
        )}

        {activeTab === 'design_system' && <DesignSystemViewer />}
      </main>

      {/* Excel Export Dialog */}
      {exportTestTarget && (
        <ExcelExportDialog
          test={exportTestTarget}
          testType={activeTestType}
          onClose={() => setExportTestTarget(null)}
        />
      )}
    </div>
  );
}
