/**
 * Domain types for Technavious O&M Industrial Field App
 */

export type ScreenId =
  | 'dashboard'
  | 'new_project'
  | 'project_detail'
  | 'select_test_type'
  | 'test_form'
  | 'capture'
  | 'settings';

export type AIMode = 'gemini' | 'qwen';

export interface ReadingFieldDefinition {
  id: string;
  label: string;
  unit: string;
  placeholder?: string;
  typicalMin?: number;
  typicalMax?: number;
  sampleAiValue?: string;
}

export interface TestTypeDefinition {
  id: string;
  name: string;
  category: 'Mechanical' | 'Electrical' | 'Thermal' | 'Protection' | 'Environmental';
  description: string;
  hasAiMeterReading: boolean;
  meterTypeHint?: string;
  readingFields: ReadingFieldDefinition[];
}

export interface FieldReadingValue {
  fieldId: string;
  value: string;
  photoUrl?: string;
  photoTimestamp?: string;
  aiSource?: 'Gemini AI' | 'Offline AI' | 'Manual';
  aiConfidence?: number;
}

export interface TestRecord {
  id: string;
  projectId: string;
  testTypeId: string;
  testName: string;
  status: 'Draft' | 'Completed';
  location: string;
  docNo: string;
  createdAt: string;
  updatedAt: string;
  readings: Record<string, FieldReadingValue>;
}

export interface ProjectRecord {
  id: string;
  name: string;
  clientName: string;
  address: string;
  createdAt: string;
  testsCount: number;
}

export interface SettingsState {
  aiReadingMode: AIMode;
  geminiApiKey: string;
  offlineModelInstalled: boolean;
  offlineModelStatus: 'missing' | 'installed' | 'syncing';
  outdoorMode: boolean; // High-contrast outdoor mode
  showTouchHitboxes: boolean; // Visualizer for >=48dp touch targets
}

export interface ActiveCaptureContext {
  testId: string;
  fieldId: string;
  fieldName: string;
  unit: string;
  meterHint?: string;
}
