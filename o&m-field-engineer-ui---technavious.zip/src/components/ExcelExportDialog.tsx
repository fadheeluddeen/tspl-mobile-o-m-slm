import React from 'react';
import { FileSpreadsheet, Download, X, CheckCircle2 } from 'lucide-react';
import { TestRecord, TestTypeDefinition } from '../types';

interface ExcelExportDialogProps {
  test: TestRecord;
  testType: TestTypeDefinition;
  onClose: () => void;
}

export const ExcelExportDialog: React.FC<ExcelExportDialogProps> = ({
  test,
  testType,
  onClose,
}) => {
  const downloadCsv = () => {
    const headers = ['Field ID', 'Parameter Name', 'Measured Value', 'Unit', 'AI Source', 'Timestamp'];
    const rows = testType.readingFields.map((field) => {
      const reading = test.readings[field.id];
      return [
        field.id,
        `"${field.label}"`,
        reading?.value || 'N/A',
        field.unit || '-',
        reading?.aiSource || 'Manual',
        reading?.photoTimestamp || '-',
      ].join(',');
    });

    const csvContent = [
      `"Technavious O&M Field Engineering Test Report"`,
      `"Project:","${test.testName}"`,
      `"Protocol:","${testType.name}"`,
      `"Location:","${test.location}"`,
      `"Doc No:","${test.docNo}"`,
      `"Status:","${test.status}"`,
      `"Date:","${test.updatedAt || test.createdAt}"`,
      '',
      headers.join(','),
      ...rows,
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${test.docNo || 'Test_Report'}_${testType.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-md p-6 animate-fadeIn">
      <div className="bg-white/90 backdrop-blur-2xl rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-white/80">
        <div className="flex items-center justify-between border-b border-slate-200/50 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100/90 border border-emerald-300 text-emerald-700 flex items-center justify-center shadow-xs">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Export to Excel (.xlsx / .csv)
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                {test.docNo} · {testType.name}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-500 hover:text-slate-800 bg-white/40 hover:bg-white border border-white/60 backdrop-blur-sm transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Report Preview with Frosted Glass Box */}
        <div className="bg-white/50 backdrop-blur-sm rounded-xl p-4 border border-slate-200/70 space-y-3 mb-6 shadow-inner">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-slate-500 block">Facility Location:</span>
              <span className="font-bold text-slate-800">{test.location || 'Not Specified'}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Status:</span>
              <span className="font-bold text-emerald-700">{test.status}</span>
            </div>
          </div>

          <div className="border-t border-slate-200/50 pt-2">
            <span className="text-[11px] font-bold text-slate-600 block mb-1.5">
              Readings to be exported ({testType.readingFields.length} parameters):
            </span>
            <div className="space-y-1 max-h-36 overflow-y-auto">
              {testType.readingFields.map((f) => (
                <div key={f.id} className="flex justify-between text-xs py-0.5">
                  <span className="text-slate-600">{f.label}:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {test.readings[f.id]?.value || '—'} {f.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[48px] px-5 rounded-xl font-semibold text-sm text-slate-700 bg-white/60 hover:bg-white border border-slate-200 transition-all"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              downloadCsv();
              onClose();
            }}
            className="min-h-[48px] px-6 rounded-xl font-bold text-sm bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white flex items-center gap-2 shadow-md shadow-emerald-600/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Download className="w-4 h-4" />
            <span>Download CSV / Excel</span>
          </button>
        </div>
      </div>
    </div>
  );
};
