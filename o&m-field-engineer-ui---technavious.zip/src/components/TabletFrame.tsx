import React from 'react';
import { Wifi, Battery, Signal, Sun, Tablet } from 'lucide-react';
import { SettingsState } from '../types';

interface TabletFrameProps {
  children: React.ReactNode;
  settings: SettingsState;
  currentScreenName: string;
}

export const TabletFrame: React.FC<TabletFrameProps> = ({
  children,
  settings,
  currentScreenName,
}) => {
  return (
    <div className="relative mx-auto flex flex-col items-center">
      {/* Tablet Hardware Body (Lenovo Tab 11-inch Portrait ~1200x1920 ratio) */}
      <div
        className={`relative w-full max-w-[560px] md:max-w-[620px] lg:max-w-[660px] aspect-[10/16] max-h-[92vh] rounded-[44px] p-3.5 bg-neutral-900 border-[7px] border-neutral-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.6),0_0_0_1px_rgba(255,255,255,0.08)] flex flex-col transition-all duration-300 ${
          settings.outdoorMode ? 'ring-4 ring-amber-500/40' : ''
        }`}
      >
        {/* Tablet Top Bezel: Front Camera & Ambient Light Sensor */}
        <div className="h-6 w-full flex items-center justify-center gap-3 shrink-0 select-none">
          <div className="w-2.5 h-2.5 rounded-full bg-neutral-950 border border-neutral-700/80 shadow-inner" />
          <div className="w-1.5 h-1.5 rounded-full bg-neutral-950/80" />
        </div>

        {/* Tablet Screen Canvas (10:16 aspect ratio display) */}
        <div
          className={`relative flex-1 w-full rounded-[30px] overflow-hidden flex flex-col bg-slate-100 transition-all ${
            settings.outdoorMode ? 'outdoor-sunlight-mode' : ''
          }`}
        >
          {/* Ambient luminous glow background orbs for authentic glassmorphism depth */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
            <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-orange-400/20 blur-3xl" />
            <div className="absolute top-1/3 -left-20 w-72 h-72 rounded-full bg-amber-300/15 blur-3xl" />
            <div className="absolute -bottom-20 right-10 w-96 h-96 rounded-full bg-orange-500/15 blur-3xl" />
            <div className="absolute bottom-1/4 left-1/4 w-60 h-60 rounded-full bg-blue-400/10 blur-3xl" />
          </div>

          {/* Android Status Bar (Material 3 style) */}
          <div className="h-7 px-5 bg-white/70 backdrop-blur-xl text-slate-800 border-b border-white/50 flex items-center justify-between text-xs font-semibold shrink-0 select-none z-30">
            <div className="flex items-center gap-2">
              <span className="font-bold text-[11px] font-mono tracking-tight">10:42 AM</span>
              <span className="text-[10px] text-orange-700 font-mono font-bold bg-orange-100/80 px-1 rounded border border-orange-200/50">
                5G SA
              </span>
            </div>

            <div className="flex items-center gap-2.5 text-slate-600 text-[11px]">
              {settings.outdoorMode && (
                <span className="flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-100/90 border border-amber-300/60 px-1.5 py-0.5 rounded shadow-2xs">
                  <Sun className="w-3 h-3 text-amber-600" />
                  <span>84k lx</span>
                </span>
              )}
              <Signal className="w-3.5 h-3.5 text-slate-700" />
              <Wifi className="w-3.5 h-3.5 text-slate-700" />
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-mono font-bold text-slate-700">94%</span>
                <Battery className="w-4 h-4 text-emerald-600" />
              </div>
            </div>
          </div>

          {/* Active Screen Container */}
          <div className={`relative flex-1 w-full overflow-hidden z-10 ${settings.showTouchHitboxes ? 'show-hitbox-overlay' : ''}`}>
            {children}
          </div>

          {/* Android Navigation Gesture Bar */}
          <div className="h-4 w-full bg-white/50 backdrop-blur-md flex items-center justify-center shrink-0 select-none z-30">
            <div className="w-32 h-1 rounded-full bg-slate-400/50" />
          </div>
        </div>

        {/* Physical Lenovo Tablet Subtle Bottom Brand Text */}
        <div className="h-4 w-full flex items-center justify-center shrink-0 select-none">
          <span className="text-[9px] font-bold tracking-widest text-neutral-500 uppercase">
            Lenovo Tab · 11&quot; Field Edition (1200×1920)
          </span>
        </div>
      </div>
    </div>
  );
};
