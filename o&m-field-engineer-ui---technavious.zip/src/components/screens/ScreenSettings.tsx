import React, { useState } from 'react';
import {
  ArrowLeft,
  Key,
  AlertTriangle,
  Cpu,
  Sparkles,
  Download,
  CheckCircle2,
  Sun,
  Shield,
  Layers,
  Save,
  HelpCircle,
} from 'lucide-react';
import { SettingsState, AIMode } from '../../types';

interface ScreenSettingsProps {
  settings: SettingsState;
  onBack: () => void;
  onUpdateSettings: (newSettings: Partial<SettingsState>) => void;
}

export const ScreenSettings: React.FC<ScreenSettingsProps> = ({
  settings,
  onBack,
  onUpdateSettings,
}) => {
  const [apiKeyInput, setApiKeyInput] = useState(settings.geminiApiKey || '');
  const [keySavedNotification, setKeySavedNotification] = useState(false);
  const [isDownloadingModel, setIsDownloadingModel] = useState(false);

  const handleSaveApiKey = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({ geminiApiKey: apiKeyInput });
    setKeySavedNotification(true);
    setTimeout(() => setKeySavedNotification(false), 2500);
  };

  const handleToggleMode = (mode: AIMode) => {
    onUpdateSettings({ aiReadingMode: mode });
  };

  const handleSimulateModelDownload = () => {
    setIsDownloadingModel(true);
    setTimeout(() => {
      setIsDownloadingModel(false);
      onUpdateSettings({
        offlineModelInstalled: true,
        offlineModelStatus: 'installed',
      });
    }, 2000);
  };

  const handleToggleMissingState = () => {
    onUpdateSettings({
      offlineModelInstalled: !settings.offlineModelInstalled,
      offlineModelStatus: settings.offlineModelInstalled ? 'missing' : 'installed',
    });
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-slate-900 select-none">
      {/* Material 3 TopAppBar with Glassmorphism */}
      <header className="h-16 px-4 glass-panel border-b border-white/60 flex items-center justify-between shrink-0 shadow-xs z-10">
        <div className="flex items-center gap-2">
          {/* Back button - 48dp minimum touch hitbox */}
          <button
            onClick={onBack}
            aria-label="Navigate back"
            className="w-12 h-12 flex items-center justify-center rounded-full text-slate-700 hover:text-slate-900 bg-white/40 hover:bg-white/80 border border-white/60 backdrop-blur-md active:bg-white transition-all m3-ripple shadow-2xs"
          >
            <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
          </button>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-tight">
              Settings
            </h1>
            <p className="text-xs text-slate-600 font-medium">Technavious Field Engine Diagnostics</p>
          </div>
        </div>

        <span className="text-xs font-bold text-slate-700 font-mono bg-white/60 border border-white/70 backdrop-blur-xs px-3 py-1 rounded-md shadow-2xs">
          v2.4.1
        </span>
      </header>

      {/* Main Scrollable Content */}
      <main className="flex-1 overflow-y-auto px-6 py-6 pb-20 space-y-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* SECTION 1: AI READING MODE SWITCH WITH GLASS CARDS */}
          <div className="glass-card rounded-2xl p-5 shadow-xs space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-orange-600" />
                <span>AI Reading Mode</span>
              </h2>
              <p className="text-xs text-slate-600 font-medium mt-1">
                Select the visual OCR engine used to transcribe industrial meter displays.
              </p>
            </div>

            {/* Mode Selector Cards (large touch hitboxes min 56dp) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* Option A: Gemini AI (Online) */}
              <div
                onClick={() => handleToggleMode('gemini')}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all m3-ripple ${
                  settings.aiReadingMode === 'gemini'
                    ? 'border-orange-500 bg-orange-100/60 backdrop-blur-md shadow-xs ring-2 ring-orange-200/50'
                    : 'border-white/70 hover:border-orange-300 bg-white/50 backdrop-blur-sm'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-orange-100/90 border border-orange-200 text-orange-700 flex items-center justify-center shadow-2xs">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-sm text-slate-900">Gemini AI (Online)</span>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      settings.aiReadingMode === 'gemini'
                        ? 'border-orange-600 bg-orange-600'
                        : 'border-slate-400'
                    }`}
                  >
                    {settings.aiReadingMode === 'gemini' && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                </div>
                {/* One-line description */}
                <p className="text-xs text-slate-600 font-medium leading-relaxed">
                  Cloud multi-modal recognition with highest accuracy on complex dials and thermal scans.
                </p>
              </div>

              {/* Option B: Qwen VL (Offline) */}
              <div
                onClick={() => handleToggleMode('qwen')}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all m3-ripple ${
                  settings.aiReadingMode === 'qwen'
                    ? 'border-orange-500 bg-orange-100/60 backdrop-blur-md shadow-xs ring-2 ring-orange-200/50'
                    : 'border-white/70 hover:border-orange-300 bg-white/50 backdrop-blur-sm'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-slate-200/90 border border-slate-300 text-slate-800 flex items-center justify-center shadow-2xs">
                      <Cpu className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-sm text-slate-900">Qwen VL (Offline)</span>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      settings.aiReadingMode === 'qwen'
                        ? 'border-orange-600 bg-orange-600'
                        : 'border-slate-400'
                    }`}
                  >
                    {settings.aiReadingMode === 'qwen' && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                </div>
                {/* One-line description */}
                <p className="text-xs text-slate-600 font-medium leading-relaxed">
                  On-device NPU inference for zero-connectivity plant basements, shielded vaults, and tunnels.
                </p>
              </div>
            </div>

            {/* Offline Model Missing Status Toggle for review */}
            <div className="pt-1 flex items-center justify-between text-xs text-slate-500">
              <span>Offline weights state simulation:</span>
              <button
                type="button"
                onClick={handleToggleMissingState}
                className="font-semibold text-orange-700 hover:underline"
              >
                Toggle {settings.offlineModelInstalled ? 'Missing State' : 'Installed State'}
              </button>
            </div>
          </div>

          {/* WARNING CARD SHOWN WHEN OFFLINE MODEL FILES ARE MISSING (FROSTED GLASS) */}
          {(!settings.offlineModelInstalled || settings.aiReadingMode === 'qwen') && (
            <div
              className={`rounded-2xl border-2 p-5 transition-all shadow-sm backdrop-blur-xl ${
                !settings.offlineModelInstalled
                  ? 'bg-amber-50/80 border-amber-300/80 text-amber-950'
                  : 'bg-emerald-50/80 border-emerald-300/80 text-emerald-950'
              }`}
            >
              {!settings.offlineModelInstalled ? (
                /* Warning card shown when offline model files are missing */
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-100/90 border border-amber-300 text-amber-700 flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                      <AlertTriangle className="w-6 h-6 stroke-[2.5]" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-sm font-bold text-amber-900 leading-snug">
                        Offline Model Weights Missing
                      </h3>
                      <p className="text-xs text-amber-800 font-medium leading-relaxed mt-1">
                        The Qwen VL 2.5 on-device inference package (~1.4 GB) is not detected on this tablet storage partition. Offline AI camera recognition is unavailable in shielded plant basements until synced over Wi-Fi.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-amber-200/80">
                    <span className="text-[11px] font-mono text-amber-800">
                      Partition: /data/technavious/models/qwen-vl.bin [NOT FOUND]
                    </span>

                    <button
                      type="button"
                      disabled={isDownloadingModel}
                      onClick={handleSimulateModelDownload}
                      className="min-h-[44px] px-4 rounded-xl bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-colors m3-ripple"
                    >
                      <Download className={`w-4 h-4 ${isDownloadingModel ? 'animate-bounce' : ''}`} />
                      <span>{isDownloadingModel ? 'Syncing Weights (1.4 GB)...' : 'Download Offline Package'}</span>
                    </button>
                  </div>
                </div>
              ) : (
                /* Installed state with Frosted Glass */
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100/90 border border-emerald-300 text-emerald-700 flex items-center justify-center shrink-0 shadow-2xs">
                      <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-emerald-900">
                        Offline Model Installed &amp; Ready
                      </h3>
                      <p className="text-xs text-emerald-800 font-medium">
                        Qwen-VL-Int4 weights active on tablet Snapdragon NPU (1.4 GB cached).
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-900 bg-emerald-200/80 border border-emerald-300 px-2.5 py-1 rounded-md shadow-2xs">
                    Ready
                  </span>
                </div>
              )}
            </div>
          )}

          {/* SECTION 2: GEMINI API KEY + "Save New Key" BUTTON */}
          <div className="glass-card rounded-2xl p-5 shadow-xs space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Key className="w-5 h-5 text-orange-600" />
                <span>Gemini API Key Configuration</span>
              </h2>
              <p className="text-xs text-slate-600 font-medium mt-1">
                Required for cloud OCR and multi-modal meter analysis when connected to 5G / Wi-Fi.
              </p>
            </div>

            <form onSubmit={handleSaveApiKey} className="space-y-4">
              <div className="space-y-1.5">
                <label
                  htmlFor="apiKeyInput"
                  className="block text-xs font-bold text-slate-700 uppercase tracking-wide"
                >
                  API Key <span className="text-slate-400 font-normal">(Encrypted in Keystore)</span>
                </label>
                <div className="relative">
                  <input
                    id="apiKeyInput"
                    type="password"
                    value={apiKeyInput}
                    onChange={(e) => setApiKeyInput(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full min-h-[52px] px-4 py-2.5 rounded-xl glass-input text-slate-900 font-mono text-sm placeholder:text-slate-400 focus:outline-hidden transition-all shadow-2xs"
                  />
                </div>
              </div>

              {/* "Save New Key" button - min 48dp hitbox */}
              <div className="flex items-center justify-between pt-1">
                <p className="text-xs text-slate-600 font-medium flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-slate-600" />
                  <span>Stored on tablet hardware Secure Enclave</span>
                </p>

                <button
                  type="submit"
                  className="min-h-[48px] px-6 rounded-xl glass-fab text-white font-bold text-xs flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] m3-ripple"
                >
                  <Save className="w-4 h-4 stroke-[2.5]" />
                  <span>Save New Key</span>
                </button>
              </div>

              {keySavedNotification && (
                <div className="bg-emerald-100/90 border border-emerald-300 text-emerald-900 px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 animate-fadeIn shadow-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  <span>API Key successfully updated in tablet secure keystore.</span>
                </div>
              )}
            </form>
          </div>

          {/* SECTION 3: FIELD ERGONOMICS (Outdoor Mode & Glove Hitboxes) */}
          <div className="glass-card rounded-2xl p-5 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sun className="w-5 h-5 text-orange-600" />
              <span>Field Conditions &amp; Ergonomics</span>
            </h2>

            <div className="divide-y divide-slate-200/50">
              {/* Outdoor Sunlight Mode Switch */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <span className="text-sm font-bold text-slate-900 block">
                    Outdoor Ultra-Contrast Sunlight Mode
                  </span>
                  <span className="text-xs text-slate-600 font-medium">
                    Boosts font weight, stark black backgrounds, and maximum LCD border contrast for reading under 100,000 lux outdoor glare.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ outdoorMode: !settings.outdoorMode })}
                  className={`w-14 h-8 flex items-center rounded-full p-1 transition-colors ${
                    settings.outdoorMode ? 'bg-orange-600' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`bg-white w-6 h-6 rounded-full shadow-md transform transition-transform ${
                      settings.outdoorMode ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Glove Touch Target Visualizer */}
              <div className="py-3 flex items-center justify-between">
                <div className="pr-4">
                  <span className="text-sm font-bold text-slate-900 block">
                    Highlight ≥48dp Touch Hitboxes
                  </span>
                  <span className="text-xs text-slate-600 font-medium">
                    Displays visual safety bounding boxes on all interactive elements to inspect glove tap compliance.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ showTouchHitboxes: !settings.showTouchHitboxes })}
                  className={`w-14 h-8 flex items-center rounded-full p-1 transition-colors ${
                    settings.showTouchHitboxes ? 'bg-orange-600' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`bg-white w-6 h-6 rounded-full shadow-md transform transition-transform ${
                      settings.showTouchHitboxes ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
