import React, { useState } from 'react';
import { ArrowLeft, Camera, Sparkles, Search, ChevronRight, Zap, Activity, Thermometer, ShieldAlert, Wind } from 'lucide-react';
import { TestTypeDefinition } from '../../types';
import { TEST_TYPES } from '../../data/mockData';

interface ScreenSelectTestTypeProps {
  onBack: () => void;
  onSelectTestType: (testType: TestTypeDefinition) => void;
}

export const ScreenSelectTestType: React.FC<ScreenSelectTestTypeProps> = ({
  onBack,
  onSelectTestType,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Electrical', 'Mechanical', 'Thermal', 'Protection', 'Environmental'];

  const filteredTests = TEST_TYPES.filter((test) => {
    const matchesSearch =
      test.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      test.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || test.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Electrical':
        return <Zap className="w-4 h-4 text-amber-600" />;
      case 'Mechanical':
        return <Activity className="w-4 h-4 text-blue-600" />;
      case 'Thermal':
        return <Thermometer className="w-4 h-4 text-rose-600" />;
      case 'Protection':
        return <ShieldAlert className="w-4 h-4 text-emerald-600" />;
      case 'Environmental':
        return <Wind className="w-4 h-4 text-cyan-600" />;
      default:
        return <Activity className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-slate-900 select-none">
      {/* Material 3 TopAppBar with Glassmorphism */}
      <header className="h-16 px-4 glass-panel border-b border-white/60 flex items-center justify-between shrink-0 shadow-xs z-10">
        <div className="flex items-center gap-2">
          {/* Back button - 48dp minimum touch hitbox */}
          <button
            onClick={onBack}
            aria-label="Navigate back"
            className="w-12 h-12 flex items-center justify-center rounded-full text-slate-700 hover:text-slate-900 bg-white/40 hover:bg-white/80 border border-white/60 backdrop-blur-md active:bg-white transition-all m3-ripple shadow-2xs"
          >
            <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
          </button>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-tight">
              Select Test Type
            </h1>
            <p className="text-xs text-slate-600 font-medium">{TEST_TYPES.length} Industrial Standard Protocols</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-100/90 text-orange-900 text-xs font-bold border border-orange-300 backdrop-blur-xs shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-orange-600" />
            <span>AI Reading Available</span>
          </div>
        </div>
      </header>

      {/* Search & Filter Header with Glassmorphism */}
      <div className="px-6 py-4 bg-white/45 backdrop-blur-md border-b border-white/50 space-y-3 shrink-0">
        {/* Search Input - min 48dp height */}
        <div className="relative">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none">
            <Search className="w-5 h-5" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search 20 test types (e.g. Vibration, Earth, Battery, Arc Flash)..."
            className="w-full min-h-[48px] pl-12 pr-4 py-2.5 rounded-xl glass-input text-slate-900 text-sm placeholder:text-slate-500 focus:outline-hidden transition-all shadow-2xs"
          />
        </div>

        {/* Filter Chips - Glassmorphic pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`min-h-[42px] px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 m3-ripple shadow-2xs ${
                selectedCategory === cat
                  ? 'glass-fab text-white shadow-xs'
                  : 'bg-white/60 backdrop-blur-md border border-white/70 text-slate-700 hover:bg-white'
              }`}
            >
              <span>{cat}</span>
              {cat === 'All' && <span className="opacity-80">({TEST_TYPES.length})</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Main List of ~20 Test Types with Glass Cards */}
      <main className="flex-1 overflow-y-auto px-6 py-6 pb-20">
        <div className="space-y-3">
          {filteredTests.map((test) => (
            <div
              key={test.id}
              onClick={() => onSelectTestType(test)}
              className="group relative glass-card rounded-2xl p-4.5 shadow-xs hover:shadow-lg hover:border-orange-400/80 hover:bg-white/85 active:bg-white/95 transition-all cursor-pointer m3-ripple"
            >
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1 min-w-0 pr-2">
                  <div className="flex items-center gap-2.5 mb-1.5 flex-wrap">
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-slate-700 bg-white/70 backdrop-blur-xs border border-white/80 px-2.5 py-0.5 rounded-md shadow-2xs">
                      {getCategoryIcon(test.category)}
                      <span>{test.category}</span>
                    </span>

                    {/* AI Meter Reading Badge */}
                    {test.hasAiMeterReading ? (
                      <span className="inline-flex items-center gap-1 text-xs font-black text-orange-900 bg-orange-100/90 border border-orange-300 backdrop-blur-xs px-2 py-0.5 rounded-md shadow-2xs">
                        <Camera className="w-3.5 h-3.5 text-orange-600" />
                        <span>AI Camera OCR</span>
                      </span>
                    ) : (
                      <span className="text-xs text-slate-500 font-medium">Manual Entry</span>
                    )}

                    <span className="text-xs text-slate-600 font-semibold">
                      · {test.readingFields.length} {test.readingFields.length === 1 ? 'Reading Field' : 'Reading Fields'}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 group-hover:text-orange-600 transition-colors">
                    {test.name}
                  </h3>

                  <p className="text-xs text-slate-600 font-medium mt-1 line-clamp-2 leading-relaxed">
                    {test.description}
                  </p>

                  {test.meterTypeHint && (
                    <p className="text-[11px] text-slate-600 font-mono mt-1.5 flex items-center gap-1">
                      <span className="font-semibold text-slate-600">Instrument:</span>
                      <span className="truncate">{test.meterTypeHint}</span>
                    </p>
                  )}
                </div>

                <div className="w-10 h-10 rounded-full flex items-center justify-center text-slate-400 bg-white/40 border border-white/50 backdrop-blur-xs group-hover:text-orange-600 group-hover:bg-orange-50 transition-all shrink-0">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          ))}

          {filteredTests.length === 0 && (
            <div className="text-center py-12 text-slate-600">
              <p className="font-semibold text-sm">No test types match your search criteria</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="mt-3 text-xs font-bold text-orange-700 hover:underline"
              >
                Clear filters
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
