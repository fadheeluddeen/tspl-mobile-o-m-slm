import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Camera,
  RotateCw,
  Check,
  RefreshCcw,
  Zap,
  Lightbulb,
  Sparkles,
  Cpu,
  Eye,
  Sliders,
  Maximize2,
} from 'lucide-react';
import { AIMode } from '../../types';

interface ScreenCaptureProps {
  fieldName: string;
  unit: string;
  aiMode: AIMode;
  suggestedSampleValue?: string;
  onBack: () => void;
  onAcceptReading: (value: string, source: 'Gemini AI' | 'Offline AI' | 'Manual') => void;
}

export const ScreenCapture: React.FC<ScreenCaptureProps> = ({
  fieldName,
  unit,
  aiMode,
  suggestedSampleValue = '3.42',
  onBack,
  onAcceptReading,
}) => {
  // Capture states
  const [hasCaptured, setHasCaptured] = useState(false);
  const [isReadingAi, setIsReadingAi] = useState(false);
  const [readingValue, setReadingValue] = useState(suggestedSampleValue);
  const [readingSource, setReadingSource] = useState<'Gemini AI' | 'Offline AI' | 'Photo saved – tap Retry to read'>(
    aiMode === 'gemini' ? 'Gemini AI' : 'Offline AI'
  );
  const [confidence, setConfidence] = useState<number>(0.97);

  // Camera simulation controls
  const [meterPreset, setMeterPreset] = useState<'fluke_digital' | 'lcd_backlit' | 'thermal_spot' | 'analog_dial'>('fluke_digital');
  const [torchOn, setTorchOn] = useState(false);
  const [gridOverlay, setGridOverlay] = useState(true);
  const [usingLiveWebcam, setUsingLiveWebcam] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Handle capture shutter click
  const handleShutter = () => {
    setHasCaptured(true);
    runAiRecognition();
  };

  const runAiRecognition = () => {
    setIsReadingAi(true);
    setReadingSource(aiMode === 'gemini' ? 'Gemini AI' : 'Offline AI');

    const latency = aiMode === 'gemini' ? 900 : 1200;
    setTimeout(() => {
      setIsReadingAi(false);
      const parsed = parseFloat(suggestedSampleValue) || 3.42;
      const variation = (parsed + (Math.random() * 0.04 - 0.02)).toFixed(2);
      setReadingValue(variation);
      setConfidence(0.96 + Math.random() * 0.03);
    }, latency);
  };

  const handleRetake = () => {
    setHasCaptured(false);
  };

  const handleAccept = () => {
    const finalSource = readingSource === 'Photo saved – tap Retry to read' ? 'Manual' : readingSource;
    onAcceptReading(readingValue, finalSource as any);
  };

  const toggleRealCamera = async () => {
    if (!usingLiveWebcam) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          setUsingLiveWebcam(true);
        }
      } catch (err) {
        console.warn('Real webcam not accessible, keeping high-fidelity industrial meter simulation', err);
      }
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
        videoRef.current.srcObject = null;
      }
      setUsingLiveWebcam(false);
    }
  };

  useEffect(() => {
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  return (
    <div className="relative flex flex-col h-full bg-black text-white select-none overflow-hidden">
      {/* Top Bar Overlay: Title "Capture: <field name>"; Back button with Glassmorphic styling */}
      <header className="absolute top-0 inset-x-0 h-16 px-4 bg-black/40 backdrop-blur-xl border-b border-white/10 flex items-center justify-between z-30 shadow-md">
        <div className="flex items-center gap-3">
          {/* Back button - 48dp minimum touch hitbox */}
          <button
            onClick={onBack}
            aria-label="Back to test form"
            className="w-12 h-12 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-white border border-white/20 backdrop-blur-md transition-all m3-ripple shadow-2xs"
          >
            <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
          </button>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white leading-tight drop-shadow-md">
              Capture: {fieldName} {unit ? `(${unit})` : ''}
            </h1>
            <p className="text-xs text-orange-400 font-mono flex items-center gap-1.5">
              <span>{aiMode === 'gemini' ? 'Gemini 2.5 Flash' : 'Qwen 2.5 VL Offline'}</span>
              <span>· Auto-OCR</span>
            </p>
          </div>
        </div>

        {/* Viewfinder Tools */}
        <div className="flex items-center gap-2">
          {/* Torch toggle */}
          <button
            onClick={() => setTorchOn(!torchOn)}
            className={`w-11 h-11 flex items-center justify-center rounded-full border backdrop-blur-md transition-all shadow-2xs ${
              torchOn
                ? 'bg-amber-400/90 border-amber-300 text-slate-950 font-bold shadow-amber-400/30 shadow-md'
                : 'bg-white/10 border-white/20 text-white hover:bg-white/20'
            }`}
            title="Toggle Flashlight / Torch"
          >
            <Lightbulb className="w-5 h-5" />
          </button>

          {/* Grid overlay toggle */}
          <button
            onClick={() => setGridOverlay(!gridOverlay)}
            className={`w-11 h-11 flex items-center justify-center rounded-full border backdrop-blur-md transition-all shadow-2xs ${
              gridOverlay
                ? 'bg-white/25 border-white/40 text-white'
                : 'bg-white/10 border-white/20 text-white/60 hover:bg-white/20'
            }`}
            title="Toggle Alignment Reticle"
          >
            <Sliders className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* FULL-SCREEN LIVE CAMERA PREVIEW */}
      <div className="relative flex-1 bg-neutral-950 flex items-center justify-center overflow-hidden">
        {/* Real video tag if webcam enabled */}
        {usingLiveWebcam && (
          <video
            ref={videoRef}
            className="absolute inset-0 w-full h-full object-cover"
            playsInline
            muted
          />
        )}

        {/* High-Fidelity Simulated Industrial Meter Viewport */}
        {!usingLiveWebcam && (
          <div className="absolute inset-0 flex items-center justify-center p-6 bg-radial from-neutral-800 to-black">
            {/* Ambient backlight glow */}
            <div className="absolute w-80 h-80 rounded-full bg-orange-600/15 blur-3xl pointer-events-none" />

            {/* Industrial Meter Housing Simulation with Glass Details */}
            <div className="relative w-full max-w-md aspect-4/3 rounded-3xl bg-neutral-900/90 backdrop-blur-xl border-8 border-amber-500 shadow-2xl p-6 flex flex-col items-center justify-between">
              {/* Brand Label on Meter */}
              <div className="w-full flex items-center justify-between border-b border-neutral-700/80 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-600 animate-pulse shadow-xs shadow-red-500" />
                  <span className="text-xs font-mono font-black tracking-widest text-amber-400 uppercase">
                    FLUKE 805 PRO
                  </span>
                </div>
                <span className="text-[10px] font-mono text-neutral-400">RMS VIB ANALYZER</span>
              </div>

              {/* Meter LCD Screen with Glass Sheen */}
              <div
                className={`relative w-full flex-1 my-3 rounded-xl border-4 p-4 flex flex-col justify-between overflow-hidden transition-colors shadow-inner ${
                  torchOn
                    ? 'bg-emerald-950/80 border-emerald-500 shadow-emerald-500/20'
                    : 'bg-emerald-950/90 border-emerald-600'
                }`}
              >
                {/* Diagonal Glass Sheen Line */}
                <div className="absolute inset-0 bg-linear-to-tr from-transparent via-white/5 to-transparent pointer-events-none" />

                <div className="flex justify-between items-center text-emerald-400 text-xs font-mono font-bold z-10">
                  <span>MEASURE PK</span>
                  <span className="bg-emerald-900/70 border border-emerald-500/30 px-2 py-0.5 rounded backdrop-blur-xs">
                    AUTO RNG
                  </span>
                  <span>ISO 10816</span>
                </div>

                {/* Main 7-segment digital meter readout */}
                <div className="my-auto text-center py-2 z-10">
                  <div className="text-6xl font-black font-mono tracking-tighter text-emerald-300 drop-shadow-[0_0_14px_rgba(110,231,183,0.5)]">
                    {suggestedSampleValue}
                  </div>
                  <div className="text-lg font-mono font-bold text-emerald-400 tracking-wider mt-1">
                    {unit || 'mm/s'}
                  </div>
                </div>

                <div className="flex justify-between items-center text-[10px] text-emerald-400 font-mono z-10">
                  <span>SENSOR: 100mV/g</span>
                  <span className="text-amber-400 font-bold">OK · SEVERITY A</span>
                  <span>BAT: 92%</span>
                </div>
              </div>

              {/* Meter Buttons */}
              <div className="w-full flex justify-around pt-2">
                <div className="w-8 h-4 rounded-sm bg-neutral-700/80 border border-white/10" />
                <div className="w-8 h-4 rounded-sm bg-neutral-700/80 border border-white/10" />
                <div className="w-8 h-4 rounded-sm bg-orange-600 border border-orange-400/40 shadow-xs shadow-orange-600" />
                <div className="w-8 h-4 rounded-sm bg-neutral-700/80 border border-white/10" />
              </div>
            </div>
          </div>
        )}

        {/* Camera Alignment Reticle & Target Guidelines */}
        {gridOverlay && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-8">
            <div className="relative w-full max-w-lg aspect-4/3 border-2 border-dashed border-orange-500/70 rounded-2xl flex items-center justify-center backdrop-blur-2xs">
              {/* Corner brackets */}
              <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-orange-500 -mt-1 -ml-1 rounded-tl shadow-xs shadow-orange-500/50" />
              <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-orange-500 -mt-1 -mr-1 rounded-tr shadow-xs shadow-orange-500/50" />
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-orange-500 -mb-1 -ml-1 rounded-bl shadow-xs shadow-orange-500/50" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-orange-500 -mb-1 -mr-1 rounded-br shadow-xs shadow-orange-500/50" />

              {/* Center Crosshair */}
              <div className="w-6 h-0.5 bg-orange-500/80 shadow-xs" />
              <div className="h-6 w-0.5 bg-orange-500/80 absolute shadow-xs" />

              {/* Field Target Hint */}
              <div className="absolute bottom-3 bg-black/60 backdrop-blur-md border border-white/15 px-3.5 py-1 rounded-full text-[11px] font-mono font-semibold text-orange-300 shadow-lg">
                Align LCD meter reading inside box
              </div>
            </div>
          </div>
        )}

        {/* Torch highlight overlay */}
        {torchOn && (
          <div className="absolute inset-0 bg-amber-100/10 mix-blend-screen pointer-events-none" />
        )}

        {/* Quick simulator switcher pill with Glassmorphism */}
        <div className="absolute top-20 left-4 z-20 flex items-center gap-2">
          <button
            onClick={toggleRealCamera}
            className="text-[11px] font-bold px-3 py-1.5 rounded-full bg-black/50 border border-white/20 text-white backdrop-blur-xl hover:bg-black/70 flex items-center gap-1.5 shadow-md"
          >
            <Camera className="w-3.5 h-3.5 text-orange-400" />
            <span>{usingLiveWebcam ? 'Switch to Test Meter' : 'Use Device Camera'}</span>
          </button>
        </div>
      </div>

      {/* BOTTOM CONTROLS & RESULT PANEL WITH DEEP FROSTED GLASS */}
      {!hasCaptured ? (
        /* Viewfinder Shutter Control (large shutter button min 64dp–80dp) */
        <div className="h-28 px-8 bg-black/50 backdrop-blur-2xl border-t border-white/15 flex items-center justify-between shrink-0 z-30 shadow-2xl">
          <div className="w-14" /> {/* Spacer */}

          {/* Large Shutter Button (72x72dp) with glove-friendly outer ring & glass border */}
          <button
            type="button"
            onClick={handleShutter}
            aria-label="Capture meter reading photo"
            className="relative w-20 h-20 rounded-full border-4 border-white/80 backdrop-blur-md flex items-center justify-center active:scale-95 transition-transform m3-ripple shadow-2xl shadow-orange-600/30"
          >
            <div className="w-16 h-16 rounded-full glass-fab flex items-center justify-center text-white shadow-inner">
              <Camera className="w-7 h-7" />
            </div>
          </button>

          <div className="w-14 text-right">
            <span className="text-[11px] font-mono text-neutral-400">1080P RAW</span>
          </div>
        </div>
      ) : (
        /* AFTER CAPTURE RESULT PANEL WITH DARK GLASSMORPHISM:
           - status/source tag (e.g. "Photo saved – tap Retry to read", "Gemini AI", "Offline AI")
           - editable reading value (large text)
           - buttons: Accept, Retry (runs AI; shows "Reading..." + spinner while busy), Retake
        */
        <div className="bg-slate-950/85 backdrop-blur-2xl border-t border-orange-500/40 p-6 z-40 animate-slideUp shadow-[0_-15px_40px_rgba(0,0,0,0.6)] space-y-5">
          {/* Status & Source Tag Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/40 backdrop-blur-md shadow-xs">
                {aiMode === 'gemini' ? (
                  <Sparkles className="w-3.5 h-3.5 text-orange-400" />
                ) : (
                  <Cpu className="w-3.5 h-3.5 text-orange-400" />
                )}
                <span>{readingSource}</span>
              </span>

              {confidence && !isReadingAi && (
                <span className="text-xs font-mono text-emerald-400">
                  {Math.round(confidence * 100)}% match
                </span>
              )}
            </div>

            <span className="text-xs font-medium text-slate-400">
              Field: <span className="font-bold text-white">{fieldName}</span>
            </span>
          </div>

          {/* Large Editable Reading Value with Frosted Glass Box */}
          <div className="bg-black/60 border border-white/20 rounded-2xl p-4 flex items-center justify-between focus-within:border-orange-500 backdrop-blur-xl transition-all shadow-inner">
            <div className="flex-1 min-w-0 pr-4">
              <label htmlFor="readingValue" className="block text-[11px] uppercase font-bold tracking-wider text-slate-400 mb-1">
                Detected Meter Value (Tap to adjust)
              </label>

              {isReadingAi ? (
                <div className="flex items-center gap-3 py-2 text-orange-400">
                  <RotateCw className="w-6 h-6 animate-spin" />
                  <span className="text-xl font-bold font-mono tracking-wide">
                    Reading meter optical display...
                  </span>
                </div>
              ) : (
                <div className="flex items-baseline gap-2">
                  <input
                    id="readingValue"
                    type="text"
                    inputMode="decimal"
                    value={readingValue}
                    onChange={(e) => setReadingValue(e.target.value)}
                    className="w-full bg-transparent text-4xl md:text-5xl font-black font-mono text-white tracking-tight focus:outline-hidden"
                  />
                  {unit && (
                    <span className="text-xl font-mono font-bold text-orange-400 shrink-0">
                      {unit}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons: Accept, Retry, Retake - All min 48dp height */}
          <div className="grid grid-cols-3 gap-3 pt-1">
            {/* Retake Button with Frosted Glass */}
            <button
              type="button"
              disabled={isReadingAi}
              onClick={handleRetake}
              className="min-h-[52px] rounded-xl bg-white/10 hover:bg-white/15 active:bg-white/20 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-2 border border-white/15 backdrop-blur-md transition-all m3-ripple shadow-2xs"
            >
              <RefreshCcw className="w-4 h-4" />
              <span>Retake</span>
            </button>

            {/* Retry Button (runs AI; shows "Reading..." + spinner while busy) */}
            <button
              type="button"
              disabled={isReadingAi}
              onClick={runAiRecognition}
              className="min-h-[52px] rounded-xl bg-orange-950/40 hover:bg-orange-900/50 active:bg-orange-900/70 disabled:opacity-50 text-orange-300 text-xs font-bold flex items-center justify-center gap-2 border border-orange-500/40 backdrop-blur-md transition-all m3-ripple shadow-2xs"
            >
              <RotateCw className={`w-4 h-4 ${isReadingAi ? 'animate-spin' : ''}`} />
              <span>{isReadingAi ? 'Reading...' : 'Retry AI'}</span>
            </button>

            {/* Accept Button */}
            <button
              type="button"
              disabled={isReadingAi || !readingValue.trim()}
              onClick={handleAccept}
              className="min-h-[52px] rounded-xl glass-fab disabled:bg-slate-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-xl shadow-orange-600/30 transition-all hover:scale-[1.02] active:scale-[0.98] m3-ripple"
            >
              <Check className="w-5 h-5 stroke-[3]" />
              <span>Accept</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
