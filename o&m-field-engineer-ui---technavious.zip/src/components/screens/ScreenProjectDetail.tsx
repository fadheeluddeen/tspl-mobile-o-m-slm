import React, { useState } from 'react';
import { ArrowLeft, Plus, Trash2, ClipboardList, ChevronRight, MapPin, Building2, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { ProjectRecord, TestRecord } from '../../types';

interface ScreenProjectDetailProps {
  project: ProjectRecord;
  tests: TestRecord[];
  onBack: () => void;
  onOpenTest: (testId: string) => void;
  onAddTest: () => void;
  onDeleteTest: (testId: string) => void;
  onClearAllTests?: () => void;
  onRestoreSampleTests?: () => void;
}

export const ScreenProjectDetail: React.FC<ScreenProjectDetailProps> = ({
  project,
  tests,
  onBack,
  onOpenTest,
  onAddTest,
  onDeleteTest,
  onClearAllTests,
  onRestoreSampleTests,
}) => {
  const [testToDelete, setTestToDelete] = useState<TestRecord | null>(null);

  const confirmDelete = () => {
    if (testToDelete) {
      onDeleteTest(testToDelete.id);
      setTestToDelete(null);
    }
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-slate-900 select-none">
      {/* Material 3 TopAppBar with Glassmorphism */}
      <header className="h-16 px-4 glass-panel border-b border-white/60 flex items-center justify-between shrink-0 shadow-xs z-10">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          {/* Back button - 48dp minimum touch hitbox */}
          <button
            onClick={onBack}
            aria-label="Navigate back"
            className="w-12 h-12 flex items-center justify-center rounded-full text-slate-700 hover:text-slate-900 bg-white/40 hover:bg-white/80 border border-white/60 backdrop-blur-md active:bg-white transition-all m3-ripple shadow-2xs shrink-0"
          >
            <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
          </button>
          <div className="min-w-0 pr-2">
            <h1 className="text-xl font-bold tracking-tight text-slate-900 truncate leading-tight">
              {project.name}
            </h1>
            <p className="text-xs text-slate-600 font-medium truncate">{project.clientName}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs font-bold text-slate-800 bg-white/60 border border-white/70 backdrop-blur-xs px-2.5 py-1 rounded-md shadow-2xs">
            {tests.length} {tests.length === 1 ? 'Test' : 'Tests'}
          </span>
        </div>
      </header>

      {/* Project Meta Card with Glassmorphism */}
      <div className="px-6 py-4 bg-white/45 backdrop-blur-md border-b border-white/50 flex items-center justify-between gap-4 shrink-0">
        <div className="space-y-1 min-w-0">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="font-semibold text-slate-800 truncate">{project.clientName}</span>
            <span className="text-slate-400">·</span>
            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="truncate">{project.address}</span>
          </div>
        </div>

        {/* Demo empty state toggle for design review */}
        <div className="shrink-0 flex items-center gap-2">
          {tests.length === 0 ? (
            <button
              onClick={onRestoreSampleTests}
              className="text-xs font-semibold px-2.5 py-1 rounded-md bg-orange-100/90 border border-orange-300 text-orange-900 hover:bg-orange-200 transition-colors shadow-2xs"
            >
              Restore Tests
            </button>
          ) : (
            <button
              onClick={onClearAllTests}
              className="text-xs font-medium px-2 py-1 rounded-md bg-white/50 border border-white/60 text-slate-700 hover:text-slate-900 hover:bg-white/80 transition-colors"
              title="Test empty state"
            >
              Test Empty
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto px-6 py-6 pb-28">
        {tests.length === 0 ? (
          /* Empty state: "No tests yet — tap + to add a test" */
          <div className="h-full min-h-[380px] flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-orange-300/80 rounded-3xl bg-white/50 backdrop-blur-lg shadow-sm">
            <div className="w-18 h-18 rounded-2xl bg-orange-100/80 border border-orange-300 flex items-center justify-center text-orange-600 mb-4 shadow-sm backdrop-blur-sm">
              <ClipboardList className="w-9 h-9" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">No tests yet</h3>
            <p className="text-sm font-medium text-slate-600 max-w-sm mb-6">
              Tap the <span className="font-semibold text-orange-700">+ Add Test</span> button below to choose an industrial test type and record meter readings.
            </p>
            <button
              onClick={onAddTest}
              className="h-12 px-6 rounded-xl glass-fab text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-orange-600/25 transition-all active:scale-[0.98] m3-ripple"
            >
              <Plus className="w-5 h-5 stroke-[2.5]" />
              <span>Add Test</span>
            </button>
          </div>
        ) : (
          /* List of tests in this project: test name + status chip (Draft / Completed) + Delete icon */
          <div className="space-y-3.5">
            {tests.map((test) => {
              const isCompleted = test.status === 'Completed';
              const readingCount = Object.keys(test.readings || {}).length;

              return (
                <div
                  key={test.id}
                  onClick={() => onOpenTest(test.id)}
                  className="group relative glass-card rounded-2xl p-4.5 shadow-xs hover:shadow-lg hover:border-orange-400/80 hover:bg-white/85 active:bg-white/95 transition-all cursor-pointer m3-ripple"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2.5 mb-1.5 flex-wrap">
                        {/* Status Chip (Draft / Completed) with Glassmorphic pill */}
                        <span
                          className={`inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full backdrop-blur-sm shadow-2xs ${
                            isCompleted
                              ? 'bg-emerald-100/80 text-emerald-900 border border-emerald-300/80'
                              : 'bg-amber-100/80 text-amber-900 border border-amber-300/80'
                          }`}
                        >
                          {isCompleted ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                          ) : (
                            <Clock className="w-3.5 h-3.5 text-amber-700" />
                          )}
                          <span>{test.status}</span>
                        </span>

                        <span className="text-xs text-slate-600 font-mono">
                          {test.docNo}
                        </span>

                        {readingCount > 0 && (
                          <span className="text-xs text-slate-600 font-medium">
                            · {readingCount} {readingCount === 1 ? 'reading recorded' : 'readings recorded'}
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-slate-900 group-hover:text-orange-600 transition-colors truncate">
                        {test.testName}
                      </h3>

                      <p className="text-xs text-slate-600 truncate mt-1">
                        Location: <span className="font-semibold text-slate-700">{test.location}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {/* Delete icon on each test - min 48dp hitbox */}
                      <button
                        type="button"
                        aria-label={`Delete ${test.testName}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          setTestToDelete(test);
                        }}
                        className="w-12 h-12 flex items-center justify-center rounded-xl text-slate-500 hover:text-red-600 bg-white/40 hover:bg-red-50/80 border border-white/50 backdrop-blur-sm active:bg-red-100 transition-all m3-ripple shadow-2xs"
                        title="Delete Test Log"
                      >
                        <Trash2 className="w-5 h-5 stroke-[2]" />
                      </button>

                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 group-hover:text-orange-600 transition-colors">
                        <ChevronRight className="w-5 h-5" />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Floating Action Button: "+" Add Test button (min 56dp / 64dp) with Glassmorphism */}
      <div className="absolute bottom-6 right-6 z-20">
        <button
          onClick={onAddTest}
          className="h-15 px-6 rounded-2xl glass-fab text-white font-bold text-base flex items-center gap-3 transition-all hover:scale-[1.02] active:scale-[0.97] m3-ripple"
        >
          <div className="w-7 h-7 rounded-lg bg-white/25 border border-white/30 flex items-center justify-center shadow-xs">
            <Plus className="w-5 h-5 stroke-[3]" />
          </div>
          <span className="tracking-wide">Add Test</span>
        </button>
      </div>

      {/* Delete Confirmation Dialog (Material 3 AlertDialog with Frosted Glass) */}
      {testToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-md p-6 animate-fadeIn">
          <div className="bg-white/90 backdrop-blur-2xl rounded-3xl max-w-md w-full p-6 shadow-2xl border border-white/80">
            <div className="w-14 h-14 rounded-2xl bg-red-100/90 border border-red-200 text-red-600 flex items-center justify-center mb-4 shadow-xs">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 mb-2">
              Delete Test Log?
            </h3>
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              Are you sure you want to delete <span className="font-semibold text-slate-900">&ldquo;{testToDelete.testName}&rdquo;</span>? All captured meter photos and recorded data points will be lost.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setTestToDelete(null)}
                className="min-h-[48px] px-5 rounded-xl font-semibold text-sm text-slate-700 bg-white/60 hover:bg-white border border-slate-200 transition-all m3-ripple shadow-2xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="min-h-[48px] px-6 rounded-xl font-semibold text-sm bg-red-600 hover:bg-red-700 active:bg-red-800 text-white shadow-md shadow-red-600/30 transition-all m3-ripple"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
