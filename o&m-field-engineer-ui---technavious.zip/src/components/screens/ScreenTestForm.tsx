import React, { useState } from 'react';
import {
  ArrowLeft,
  Save,
  FileSpreadsheet,
  Camera,
  RotateCw,
  Sparkles,
  CheckCircle2,
  MapPin,
  FileText,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { TestRecord, TestTypeDefinition, FieldReadingValue } from '../../types';

interface ScreenTestFormProps {
  test: TestRecord;
  testType: TestTypeDefinition;
  onBack: () => void;
  onSave: (updatedTest: TestRecord) => void;
  onExportExcel: (test: TestRecord) => void;
  onOpenCamera: (fieldId: string, fieldName: string, unit: string) => void;
  onRereadAI: (fieldId: string) => void;
  isAiReadingFieldId?: string | null;
}

export const ScreenTestForm: React.FC<ScreenTestFormProps> = ({
  test,
  testType,
  onBack,
  onSave,
  onExportExcel,
  onOpenCamera,
  onRereadAI,
  isAiReadingFieldId,
}) => {
  const [testName, setTestName] = useState(test.testName);
  const [location, setLocation] = useState(test.location);
  const [docNo, setDocNo] = useState(test.docNo);
  const [readings, setReadings] = useState<Record<string, FieldReadingValue>>(test.readings || {});
  const [status, setStatus] = useState<'Draft' | 'Completed'>(test.status);
  const [saveSuccessNotification, setSaveSuccessNotification] = useState(false);

  const handleFieldValueChange = (fieldId: string, val: string) => {
    setReadings((prev) => ({
      ...prev,
      [fieldId]: {
        ...prev[fieldId],
        fieldId,
        value: val,
      },
    }));
  };

  const handleSave = () => {
    const filledCount = Object.values(readings).filter((r) => r.value && r.value.trim() !== '').length;
    const computedStatus = filledCount >= Math.ceil(testType.readingFields.length / 2) ? 'Completed' : status;

    const updated: TestRecord = {
      ...test,
      testName,
      location,
      docNo,
      readings,
      status: computedStatus,
      updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    onSave(updated);
    setSaveSuccessNotification(true);
    setTimeout(() => setSaveSuccessNotification(false), 2500);
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-slate-900 select-none">
      {/* Material 3 TopAppBar with Glassmorphism */}
      <header className="h-16 px-4 glass-panel border-b border-white/60 flex items-center justify-between shrink-0 shadow-xs z-10">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          {/* Back button - 48dp minimum touch hitbox */}
          <button
            onClick={onBack}
            aria-label="Navigate back"
            className="w-12 h-12 flex items-center justify-center rounded-full text-slate-700 hover:text-slate-900 bg-white/40 hover:bg-white/80 border border-white/60 backdrop-blur-md active:bg-white transition-all m3-ripple shadow-2xs shrink-0"
          >
            <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
          </button>
          <div className="min-w-0 pr-2">
            <h1 className="text-lg font-bold tracking-tight text-slate-900 truncate leading-tight">
              {testName || testType.name}
            </h1>
            <p className="text-xs text-slate-600 font-medium truncate">{testType.name} · {testType.category}</p>
          </div>
        </div>

        {/* Action Buttons: Save, and Export-to-Excel buttons */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Export to Excel Button - 48dp minimum hitbox */}
          <button
            type="button"
            onClick={() => onExportExcel({ ...test, testName, location, docNo, readings, status })}
            title="Export to Excel (.xlsx)"
            className="min-h-[48px] px-3.5 rounded-xl border border-white/80 bg-white/60 hover:bg-white active:bg-white/90 backdrop-blur-md text-slate-700 text-xs font-bold flex items-center gap-2 transition-all m3-ripple shadow-2xs"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">Export Excel</span>
          </button>

          {/* Save Button - 48dp minimum hitbox */}
          <button
            type="button"
            onClick={handleSave}
            title="Save Test Form"
            className="min-h-[48px] px-5 rounded-xl glass-fab text-white text-xs font-bold flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] m3-ripple"
          >
            <Save className="w-4 h-4 stroke-[2.5]" />
            <span>Save</span>
          </button>
        </div>
      </header>

      {/* Save Notification Toast with Frosted Emerald Glass */}
      {saveSuccessNotification && (
        <div className="bg-emerald-600/90 backdrop-blur-xl border-b border-emerald-400/40 text-white px-6 py-2.5 text-xs font-bold flex items-center justify-between transition-all animate-fadeIn shadow-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Test readings and headers saved successfully.</span>
          </div>
          <span className="text-[11px] opacity-80">Synced locally</span>
        </div>
      )}

      {/* Main Scrollable Form Body */}
      <main className="flex-1 overflow-y-auto px-6 py-6 pb-24 space-y-6">
        {/* SECTION 1: HEADER SECTION (Location, Doc No.) with Glassmorphic Card */}
        <div className="glass-card rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200/50 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-orange-100/90 border border-orange-300/80 text-orange-800 flex items-center justify-center font-bold text-xs shadow-2xs">
                1
              </div>
              <h2 className="text-base font-bold text-slate-900">Header Information</h2>
            </div>
            {/* Status toggle chip */}
            <button
              type="button"
              onClick={() => setStatus(status === 'Completed' ? 'Draft' : 'Completed')}
              className={`text-xs font-bold px-3 py-1.5 rounded-full border backdrop-blur-sm transition-all flex items-center gap-1.5 shadow-2xs ${
                status === 'Completed'
                  ? 'bg-emerald-100/80 text-emerald-900 border-emerald-300/80'
                  : 'bg-amber-100/80 text-amber-900 border-amber-300/80'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${status === 'Completed' ? 'bg-emerald-600' : 'bg-amber-600'}`} />
              <span>Status: {status}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Location OutlinedTextField with Glassmorphism */}
            <div className="space-y-1.5">
              <label htmlFor="testLocation" className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                Location <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                  <MapPin className="w-4 h-4" />
                </div>
                <input
                  id="testLocation"
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Basement 2, Central Chiller Plant Room"
                  className="w-full min-h-[50px] pl-11 pr-4 py-2.5 rounded-xl glass-input text-slate-900 text-sm placeholder:text-slate-400 focus:outline-hidden transition-all shadow-2xs"
                />
              </div>
            </div>

            {/* Doc No. OutlinedTextField with Glassmorphism */}
            <div className="space-y-1.5">
              <label htmlFor="testDocNo" className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                Doc No. <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                  <FileText className="w-4 h-4" />
                </div>
                <input
                  id="testDocNo"
                  type="text"
                  value={docNo}
                  onChange={(e) => setDocNo(e.target.value)}
                  placeholder="e.g. TECH-VA-2026-0915-01"
                  className="w-full min-h-[50px] pl-11 pr-4 py-2.5 rounded-xl glass-input text-slate-900 font-mono text-sm placeholder:text-slate-400 focus:outline-hidden transition-all shadow-2xs"
                />
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2: READINGS SECTION (2–9 reading fields depending on test) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-orange-100/90 border border-orange-300/80 text-orange-800 flex items-center justify-center font-bold text-xs shadow-2xs">
                2
              </div>
              <h2 className="text-base font-bold text-slate-900">
                Readings ({testType.readingFields.length} parameters)
              </h2>
            </div>

            {testType.hasAiMeterReading && (
              <span className="text-xs font-bold text-orange-900 bg-orange-100/90 border border-orange-300 backdrop-blur-xs px-2.5 py-1 rounded-md flex items-center gap-1 shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-orange-600" />
                <span>AI Meter Reading enabled</span>
              </span>
            )}
          </div>

          {/* List of 2 to 9 Reading Cards with Glassmorphism */}
          <div className="space-y-3.5">
            {testType.readingFields.map((field, idx) => {
              const currentVal = readings[field.id]?.value || '';
              const photoExists = Boolean(readings[field.id]?.photoUrl || readings[field.id]?.photoTimestamp);
              const isAiAnalyzing = isAiReadingFieldId === field.id;
              const aiSource = readings[field.id]?.aiSource;

              return (
                <div
                  key={field.id}
                  className="glass-card rounded-2xl p-4 shadow-xs hover:border-orange-300/80 transition-all"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3.5">
                    {/* Field Identification & Number Input */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="w-5 h-5 rounded-full bg-white/70 border border-slate-200 text-slate-700 flex items-center justify-center text-[11px] font-bold shadow-2xs">
                          {idx + 1}
                        </span>
                        <label
                          htmlFor={`reading-${field.id}`}
                          className="text-sm font-bold text-slate-900"
                        >
                          {field.label}
                        </label>
                        {field.unit && (
                          <span className="text-xs font-mono font-bold text-orange-800 bg-orange-100/80 px-2 py-0.5 rounded border border-orange-200/80 shadow-2xs">
                            {field.unit}
                          </span>
                        )}
                        {aiSource && (
                          <span className="text-[11px] font-semibold text-slate-700 bg-white/60 border border-white/70 backdrop-blur-xs px-2 py-0.5 rounded shadow-2xs">
                            {aiSource}
                          </span>
                        )}
                      </div>

                      {/* Number Input Box (large touch target min 52dp) */}
                      <div className="relative flex items-center">
                        <input
                          id={`reading-${field.id}`}
                          type="text"
                          inputMode="decimal"
                          value={currentVal}
                          onChange={(e) => handleFieldValueChange(field.id, e.target.value)}
                          placeholder={`Enter ${field.label} reading`}
                          className="w-full min-h-[52px] pl-4 pr-16 py-2.5 rounded-xl glass-input text-slate-900 font-mono text-lg font-bold placeholder:text-slate-400 placeholder:font-normal placeholder:text-sm focus:outline-hidden transition-all shadow-2xs"
                        />
                        {field.unit && (
                          <span className="absolute right-4 text-xs font-bold text-slate-600 font-mono pointer-events-none">
                            {field.unit}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Camera Button / Photo Thumbnail + "Re-read with AI" */}
                    <div className="flex items-center gap-3 shrink-0 self-end md:self-center">
                      {!photoExists ? (
                        /* Camera Button (Take a photo of the meter) - large touch target min 48dp */
                        <button
                          type="button"
                          onClick={() => onOpenCamera(field.id, field.label, field.unit)}
                          className="min-h-[52px] px-4 rounded-xl bg-orange-50/80 hover:bg-orange-100/90 active:bg-orange-200 border border-orange-300/90 backdrop-blur-sm text-orange-950 text-xs font-bold flex items-center gap-2.5 transition-colors m3-ripple shadow-2xs"
                          title={`Snap photo of ${field.label} meter`}
                        >
                          <Camera className="w-5 h-5 text-orange-600" />
                          <span>Capture Meter</span>
                        </button>
                      ) : (
                        /* Photo thumbnail exists: show thumbnail preview + "Re-read with AI" button */
                        <div className="flex items-center gap-2.5 bg-white/55 backdrop-blur-md border border-white/80 p-2 rounded-xl shadow-2xs">
                          {/* Photo Thumbnail */}
                          <div
                            onClick={() => onOpenCamera(field.id, field.label, field.unit)}
                            className="relative w-12 h-12 rounded-lg overflow-hidden bg-slate-900 border border-slate-300 cursor-pointer group shrink-0 shadow-xs"
                            title="Tap to review/retake photo"
                          >
                            {/* Realistic industrial LCD thumbnail simulation */}
                            <div className="w-full h-full bg-linear-to-br from-slate-800 to-slate-950 flex flex-col items-center justify-center p-1 text-center">
                              <span className="text-[8px] font-mono text-emerald-400 leading-tight">
                                {currentVal || 'LCD'}
                              </span>
                              <span className="text-[7px] text-slate-400 font-mono truncate">
                                {field.unit}
                              </span>
                            </div>
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                              <Camera className="w-3.5 h-3.5" />
                            </div>
                          </div>

                          <div className="flex flex-col">
                            <span className="text-[10px] font-mono text-slate-500">
                              Photo saved
                            </span>
                            {/* "Re-read with AI" button - min 44-48dp height */}
                            <button
                              type="button"
                              disabled={isAiAnalyzing}
                              onClick={() => onRereadAI(field.id)}
                              className="mt-1 min-h-[44px] px-3 py-1.5 rounded-lg glass-fab disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all m3-ripple"
                              title="Re-run AI optical reading algorithm"
                            >
                              <RotateCw className={`w-3.5 h-3.5 ${isAiAnalyzing ? 'animate-spin' : ''}`} />
                              <span>{isAiAnalyzing ? 'Reading...' : 'Re-read with AI'}</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </main>

      {/* Sticky Bottom Summary Bar with Frosted Glass */}
      <footer className="h-16 px-6 glass-panel border-t border-white/60 flex items-center justify-between shrink-0 shadow-lg">
        <div className="flex items-center gap-3">
          <span className="text-xs font-medium text-slate-600">Completion:</span>
          <div className="w-32 bg-slate-200/80 backdrop-blur-xs h-2.5 rounded-full overflow-hidden border border-white/60">
            <div
              className="bg-linear-to-r from-orange-500 to-orange-600 h-full rounded-full transition-all duration-300 shadow-xs"
              style={{
                width: `${Math.round(
                  (Object.values(readings).filter((r) => r.value?.trim()).length /
                    testType.readingFields.length) *
                    100
                )}%`,
              }}
            />
          </div>
          <span className="text-xs font-bold text-slate-800 font-mono">
            {Object.values(readings).filter((r) => r.value?.trim()).length} / {testType.readingFields.length}
          </span>
        </div>

        <button
          type="button"
          onClick={handleSave}
          className="min-h-[48px] px-6 rounded-xl glass-fab text-white text-sm font-bold flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] m3-ripple"
        >
          <Save className="w-4 h-4 stroke-[2.5]" />
          <span>Save Changes</span>
        </button>
      </footer>
    </div>
  );
};
