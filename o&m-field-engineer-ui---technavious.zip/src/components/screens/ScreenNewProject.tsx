import React, { useState } from 'react';
import { ArrowLeft, Building2, MapPin, FileText, CheckCircle2 } from 'lucide-react';

interface ScreenNewProjectProps {
  onBack: () => void;
  onCreateProject: (project: { name: string; clientName: string; address: string }) => void;
}

export const ScreenNewProject: React.FC<ScreenNewProjectProps> = ({
  onBack,
  onCreateProject,
}) => {
  const [name, setName] = useState('');
  const [clientName, setClientName] = useState('');
  const [address, setAddress] = useState('');
  const [errors, setErrors] = useState<{ name?: string; clientName?: string; address?: string }>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: typeof errors = {};
    if (!name.trim()) newErrors.name = 'Project name is required';
    if (!clientName.trim()) newErrors.clientName = 'Client name is required';
    if (!address.trim()) newErrors.address = 'Site address is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onCreateProject({
      name: name.trim(),
      clientName: clientName.trim(),
      address: address.trim(),
    });
  };

  // Preset quick fill for fast testing/demo
  const fillSample = (preset: 'dataCenter' | 'refinery' | 'substation') => {
    if (preset === 'dataCenter') {
      setName('Singtel DC West Hyperscale Facility');
      setClientName('Singtel Telecommunications Ltd');
      setAddress('38 Jurong Port Road, Singapore 619106');
    } else if (preset === 'refinery') {
      setName('Shell Bukom Cracker Unit O&M');
      setClientName('Shell Eastern Petroleum Ltd');
      setAddress('Pulau Bukom Island, Sector 4, Singapore');
    } else {
      setName('SP PowerGrid 230kV Substation Audit');
      setClientName('SP Group Energy Singapore');
      setAddress('15 Kallang Sector, Singapore 349280');
    }
    setErrors({});
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-slate-900 select-none">
      {/* Material 3 TopAppBar with Glassmorphism */}
      <header className="h-16 px-4 glass-panel border-b border-white/60 flex items-center justify-between shrink-0 shadow-xs z-10">
        <div className="flex items-center gap-2">
          {/* Back button - 48dp minimum touch hitbox */}
          <button
            onClick={onBack}
            aria-label="Navigate back"
            className="w-12 h-12 flex items-center justify-center rounded-full text-slate-700 hover:text-slate-900 bg-white/40 hover:bg-white/80 border border-white/60 backdrop-blur-md active:bg-white transition-all m3-ripple shadow-2xs"
          >
            <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
          </button>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-tight">
              New Project
            </h1>
            <p className="text-xs text-slate-600 font-medium">Technavious Field O&amp;M</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <span className="text-xs font-bold text-orange-800 bg-orange-100/80 border border-orange-200/80 backdrop-blur-xs px-2.5 py-1 rounded-md shadow-2xs">
            M3 Form
          </span>
        </div>
      </header>

      {/* Main Scrollable Form Body */}
      <main className="flex-1 overflow-y-auto px-6 py-6 pb-20">
        <div className="max-w-xl mx-auto space-y-6">
          {/* Context Card / Instructions with Frosted Glass */}
          <div className="glass-card rounded-2xl p-4.5 flex items-start gap-3.5 border-orange-200/60 bg-white/65 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-linear-to-br from-orange-500 to-orange-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm shadow-orange-600/30">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-orange-950">Site Audit Work Order</h2>
              <p className="text-xs text-orange-900 font-medium leading-relaxed mt-0.5">
                All industrial test logs, thermal scans, and meter readings will be categorized under this facility record.
              </p>
            </div>
          </div>

          {/* Quick presets for rapid evaluation */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-semibold text-slate-600">Quick fill demo:</span>
            <button
              type="button"
              onClick={() => fillSample('dataCenter')}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-white/60 hover:bg-white border border-white/70 text-slate-800 backdrop-blur-sm transition-all shadow-2xs"
            >
              Data Center
            </button>
            <button
              type="button"
              onClick={() => fillSample('refinery')}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-white/60 hover:bg-white border border-white/70 text-slate-800 backdrop-blur-sm transition-all shadow-2xs"
            >
              Refinery
            </button>
            <button
              type="button"
              onClick={() => fillSample('substation')}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-white/60 hover:bg-white border border-white/70 text-slate-800 backdrop-blur-sm transition-all shadow-2xs"
            >
              Substation
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Field 1: Project Name (OutlinedTextField with Glassmorphism) */}
            <div className="space-y-1.5">
              <label
                htmlFor="projectName"
                className="block text-sm font-bold text-slate-800"
              >
                Project Name <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <input
                  id="projectName"
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors({ ...errors, name: undefined });
                  }}
                  placeholder="e.g. Jurong Island Substation 66kV O&M"
                  className={`w-full min-h-[56px] px-4 py-3 rounded-xl glass-input text-slate-900 text-base placeholder:text-slate-400 focus:outline-hidden transition-all ${
                    errors.name
                      ? 'border-red-500 focus:border-red-600 focus:ring-2 focus:ring-red-100'
                      : 'focus:border-orange-600 focus:ring-3 focus:ring-orange-100'
                  }`}
                />
              </div>
              {errors.name && (
                <p className="text-xs font-semibold text-red-600">{errors.name}</p>
              )}
              <p className="text-xs text-slate-600 font-medium">Unique facility or contract identifier</p>
            </div>

            {/* Field 2: Client Name (OutlinedTextField with Glassmorphism) */}
            <div className="space-y-1.5">
              <label
                htmlFor="clientName"
                className="block text-sm font-bold text-slate-800"
              >
                Client Name <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none">
                  <Building2 className="w-5 h-5" />
                </div>
                <input
                  id="clientName"
                  type="text"
                  value={clientName}
                  onChange={(e) => {
                    setClientName(e.target.value);
                    if (errors.clientName) setErrors({ ...errors, clientName: undefined });
                  }}
                  placeholder="e.g. ExxonMobil Asia Pacific Pte Ltd"
                  className={`w-full min-h-[56px] pl-12 pr-4 py-3 rounded-xl glass-input text-slate-900 text-base placeholder:text-slate-400 focus:outline-hidden transition-all ${
                    errors.clientName
                      ? 'border-red-500 focus:border-red-600 focus:ring-2 focus:ring-red-100'
                      : 'focus:border-orange-600 focus:ring-3 focus:ring-orange-100'
                  }`}
                />
              </div>
              {errors.clientName && (
                <p className="text-xs font-semibold text-red-600">{errors.clientName}</p>
              )}
            </div>

            {/* Field 3: Address (OutlinedTextField with Glassmorphism) */}
            <div className="space-y-1.5">
              <label
                htmlFor="projectAddress"
                className="block text-sm font-bold text-slate-800"
              >
                Site Address <span className="text-red-600">*</span>
              </label>
              <div className="relative">
                <div className="absolute left-4 top-4 text-slate-500 pointer-events-none">
                  <MapPin className="w-5 h-5" />
                </div>
                <textarea
                  id="projectAddress"
                  rows={3}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. 100 Pioneer Road, Jurong Island, Singapore 627888"
                  className={`w-full pl-12 pr-4 py-3 rounded-xl glass-input text-slate-900 text-base placeholder:text-slate-400 focus:outline-hidden resize-none transition-all ${
                    errors.address
                      ? 'border-red-500 focus:border-red-600 focus:ring-2 focus:ring-red-100'
                      : 'focus:border-orange-600 focus:ring-3 focus:ring-orange-100'
                  }`}
                />
              </div>
              {errors.address && (
                <p className="text-xs font-semibold text-red-600">{errors.address}</p>
              )}
            </div>

            {/* Action Button: "Create Project" button with Glassmorphic FAB style */}
            <div className="pt-4">
              <button
                type="submit"
                className="w-full min-h-[56px] px-6 rounded-2xl glass-fab text-white font-bold text-base flex items-center justify-center gap-3 transition-all hover:scale-[1.01] active:scale-[0.98] m3-ripple"
              >
                <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                <span>Create Project</span>
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};
