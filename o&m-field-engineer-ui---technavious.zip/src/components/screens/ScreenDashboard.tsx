import React, { useState } from 'react';
import { Settings, Plus, Trash2, FolderKanban, AlertTriangle, ChevronRight, Building2, MapPin } from 'lucide-react';
import { ProjectRecord, SettingsState } from '../../types';

interface ScreenDashboardProps {
  projects: ProjectRecord[];
  settings: SettingsState;
  onOpenProject: (projectId: string) => void;
  onNewProject: () => void;
  onOpenSettings: () => void;
  onDeleteProject: (projectId: string) => void;
  onResetSampleData?: () => void;
  onClearAllProjects?: () => void;
}

export const ScreenDashboard: React.FC<ScreenDashboardProps> = ({
  projects,
  settings,
  onOpenProject,
  onNewProject,
  onOpenSettings,
  onDeleteProject,
  onResetSampleData,
  onClearAllProjects,
}) => {
  const [projectToDelete, setProjectToDelete] = useState<ProjectRecord | null>(null);

  const confirmDelete = () => {
    if (projectToDelete) {
      onDeleteProject(projectToDelete.id);
      setProjectToDelete(null);
    }
  };

  return (
    <div className="flex flex-col h-full bg-transparent text-slate-900 select-none">
      {/* Material 3 TopAppBar with Glassmorphism */}
      <header className="h-16 px-6 glass-panel border-b border-white/60 flex items-center justify-between shrink-0 shadow-xs z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-linear-to-br from-orange-500 to-orange-600 border border-white/40 flex items-center justify-center text-white font-black text-xl tracking-tight shadow-md shadow-orange-600/25">
            O
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-tight">
                O&amp;M
              </h1>
              <span className="text-[11px] font-bold uppercase tracking-wider text-orange-800 bg-orange-100/80 backdrop-blur-xs border border-orange-200/70 px-2 py-0.5 rounded-md">
                Technavious
              </span>
            </div>
            <p className="text-xs text-slate-600 font-medium">Field Engineering &amp; Testing Suite</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Settings Icon Button - Strict min 48dp touch hitbox */}
          <button
            onClick={onOpenSettings}
            aria-label="Settings"
            title="Open Settings"
            className="w-12 h-12 flex items-center justify-center rounded-full text-slate-700 hover:text-slate-900 bg-white/40 hover:bg-white/80 border border-white/60 backdrop-blur-md active:bg-white transition-all m3-ripple shadow-2xs"
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Screen Sub-header / Quick context bar with Frosted Glass */}
      <div className="px-6 py-4 bg-white/40 backdrop-blur-md border-b border-white/50 flex items-center justify-between shrink-0">
        <div>
          <h2 className="text-base font-bold text-slate-900">Active Industrial Projects</h2>
          <p className="text-xs text-slate-600">
            {projects.length} {projects.length === 1 ? 'facility project' : 'facility projects'} configured
          </p>
        </div>

        {/* Quick state switcher for design review */}
        <div className="flex items-center gap-2">
          {projects.length === 0 ? (
            <button
              onClick={onResetSampleData}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-orange-100/90 backdrop-blur-sm border border-orange-300 text-orange-900 hover:bg-orange-200 transition-colors shadow-2xs"
            >
              Restore Sample Projects
            </button>
          ) : (
            <button
              onClick={onClearAllProjects}
              className="text-xs font-medium px-2.5 py-1 rounded-lg bg-white/50 backdrop-blur-sm border border-white/60 text-slate-700 hover:text-slate-900 hover:bg-white/80 transition-colors"
              title="Test empty state screen"
            >
              Test Empty State
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto px-6 py-6 pb-28">
        {projects.length === 0 ? (
          /* Empty State: "No projects yet — tap + to create a new project" */
          <div className="h-full min-h-[380px] flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-orange-300/80 rounded-3xl bg-white/50 backdrop-blur-lg shadow-sm">
            <div className="w-18 h-18 rounded-2xl bg-orange-100/80 border border-orange-300 flex items-center justify-center text-orange-600 mb-4 shadow-sm backdrop-blur-sm">
              <FolderKanban className="w-9 h-9" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">No projects yet</h3>
            <p className="text-sm font-medium text-slate-600 max-w-sm mb-6">
              Tap the <span className="font-semibold text-orange-700">+ New Project</span> button below to create your first site audit project.
            </p>
            <button
              onClick={onNewProject}
              className="h-12 px-6 rounded-xl glass-fab text-white font-semibold text-sm flex items-center gap-2 shadow-lg shadow-orange-600/25 transition-all active:scale-[0.98] m3-ripple"
            >
              <Plus className="w-5 h-5 stroke-[2.5]" />
              <span>Create New Project</span>
            </button>
          </div>
        ) : (
          /* List of project cards with Glassmorphism */
          <div className="space-y-4">
            {projects.map((project) => (
              <div
                key={project.id}
                onClick={() => onOpenProject(project.id)}
                className="group relative glass-card rounded-2xl p-5 shadow-xs hover:shadow-lg hover:border-orange-400/80 hover:bg-white/85 active:bg-white/95 transition-all cursor-pointer m3-ripple"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs font-semibold text-orange-800 bg-orange-100/80 border border-orange-200/80 backdrop-blur-xs px-2 py-0.5 rounded-md shadow-2xs">
                        {project.testsCount} {project.testsCount === 1 ? 'Test Log' : 'Test Logs'}
                      </span>
                      <span className="text-xs text-slate-600 font-mono">
                        {project.createdAt}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-slate-900 tracking-tight leading-snug group-hover:text-orange-600 transition-colors">
                      {project.name}
                    </h3>

                    <div className="mt-2.5 space-y-1">
                      <div className="flex items-center gap-2 text-sm text-slate-700 font-medium">
                        <Building2 className="w-4 h-4 text-slate-500 shrink-0" />
                        <span className="truncate">{project.clientName}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-600">
                        <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span className="truncate">{project.address}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions & Chevron */}
                  <div className="flex items-center gap-1 shrink-0 pt-1">
                    {/* Delete icon on each project card - min 48dp hitbox */}
                    <button
                      type="button"
                      aria-label={`Delete ${project.name}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        setProjectToDelete(project);
                      }}
                      className="w-12 h-12 flex items-center justify-center rounded-xl text-slate-500 hover:text-red-600 bg-white/40 hover:bg-red-50/80 border border-white/50 backdrop-blur-sm active:bg-red-100 transition-all m3-ripple shadow-2xs"
                      title="Delete Project"
                    >
                      <Trash2 className="w-5 h-5 stroke-[2]" />
                    </button>

                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 group-hover:text-orange-600 transition-colors">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Floating Action Button: "+" New Project button (Glassmorphic FAB) */}
      <div className="absolute bottom-6 right-6 z-20">
        <button
          onClick={onNewProject}
          className="h-15 px-6 rounded-2xl glass-fab text-white font-bold text-base flex items-center gap-3 transition-all hover:scale-[1.02] active:scale-[0.97] m3-ripple"
        >
          <div className="w-7 h-7 rounded-lg bg-white/25 border border-white/30 flex items-center justify-center shadow-xs">
            <Plus className="w-5 h-5 stroke-[3]" />
          </div>
          <span className="tracking-wide">New Project</span>
        </button>
      </div>

      {/* Delete Confirmation Dialog with Deep Frosted Glass */}
      {projectToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-md p-6 animate-fadeIn">
          <div className="bg-white/90 backdrop-blur-2xl rounded-3xl max-w-md w-full p-6 shadow-2xl border border-white/80">
            <div className="w-14 h-14 rounded-2xl bg-red-100/90 border border-red-200 text-red-600 flex items-center justify-center mb-4 shadow-xs">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 mb-2">
              Delete Project?
            </h3>
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              Are you sure you want to delete <span className="font-semibold text-slate-900">&ldquo;{projectToDelete.name}&rdquo;</span>? All associated meter test logs and readings will be permanently removed.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setProjectToDelete(null)}
                className="min-h-[48px] px-5 rounded-xl font-semibold text-sm text-slate-700 bg-white/60 hover:bg-white border border-slate-200 transition-all m3-ripple shadow-2xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="min-h-[48px] px-6 rounded-xl font-semibold text-sm bg-red-600 hover:bg-red-700 active:bg-red-800 text-white shadow-md shadow-red-600/30 transition-all m3-ripple"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
