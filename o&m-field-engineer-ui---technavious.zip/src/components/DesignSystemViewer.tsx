import React, { useState } from 'react';
import { Palette, Type, Ruler, Code2, Copy, Check, ShieldCheck, Sun, Sparkles } from 'lucide-react';
import {
  M3_COLOR_PALETTE,
  M3_TYPOGRAPHY,
  M3_SPACING_GRID,
} from '../theme/designSystem';

const COMPOSE_GLASSMORPHISM_SNIPPET = `
// Jetpack Compose Material 3 Glassmorphism Specification
// For Lenovo Tab 11" Industrial Field Suite

@Composable
fun Modifier.glassmorphicCard(
    cornerRadius: Dp = 20.dp,
    containerAlpha: Float = 0.72f,
    borderAlpha: Float = 0.65f
): Modifier = this
    .clip(RoundedCornerShape(cornerRadius))
    .background(
        MaterialTheme.colorScheme.surface.copy(alpha = containerAlpha)
    )
    .border(
        width = 1.dp,
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.White.copy(alpha = borderAlpha),
                Color.White.copy(alpha = borderAlpha * 0.35f)
            )
        ),
        shape = RoundedCornerShape(cornerRadius)
    )
    .blur(radius = 16.dp)

@Composable
fun GlassmorphicFAB(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .sizeIn(minWidth = 64.dp, minHeight = 64.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFEA580C).copy(alpha = 0.92f),
                        Color(0xFFC2410C).copy(alpha = 0.96f)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                color = Color.White.copy(alpha = 0.4f),
                shape = RoundedCornerShape(22.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
`;

export const DesignSystemViewer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'palette' | 'glassmorphism' | 'typography' | 'spacing' | 'compose'>('glassmorphism');
  const [copiedCode, setCopiedCode] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(COMPOSE_GLASSMORPHISM_SNIPPET);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 p-4 md:p-8 text-slate-900 bg-white/90 backdrop-blur-2xl rounded-3xl border border-white/80 shadow-xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200/80 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-xs font-black uppercase tracking-wider text-orange-800 bg-orange-100/90 border border-orange-300 px-2.5 py-0.5 rounded-full shadow-2xs">
              Material 3 Glassmorphism
            </span>
            <span className="text-xs font-semibold text-slate-700 bg-white/70 border border-slate-200 px-2 py-0.5 rounded-full">
              Lenovo Tab 11&quot; Field Spec
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
            Technavious O&amp;M Design System
          </h2>
          <p className="text-sm text-slate-600 font-medium mt-1">
            Translucent frosted glass surfaces with high-contrast safety orange accents engineered for outdoor daylight and heavy work gloves.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 p-1.5 bg-slate-100/80 backdrop-blur-md rounded-2xl shrink-0 overflow-x-auto border border-white/60">
          <button
            onClick={() => setActiveTab('glassmorphism')}
            className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'glassmorphism'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4 text-orange-600" />
            <span>Glassmorphism Spec</span>
          </button>
          <button
            onClick={() => setActiveTab('palette')}
            className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'palette'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Palette className="w-4 h-4 text-orange-600" />
            <span>Color Palette</span>
          </button>
          <button
            onClick={() => setActiveTab('typography')}
            className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'typography'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Type className="w-4 h-4 text-blue-600" />
            <span>Typography</span>
          </button>
          <button
            onClick={() => setActiveTab('spacing')}
            className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'spacing'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Ruler className="w-4 h-4 text-emerald-600" />
            <span>Spacing (≥48dp)</span>
          </button>
          <button
            onClick={() => setActiveTab('compose')}
            className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'compose'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Code2 className="w-4 h-4 text-purple-600" />
            <span>Compose Code</span>
          </button>
        </div>
      </div>

      {/* TAB: GLASSMORPHISM SPEC */}
      {activeTab === 'glassmorphism' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="glass-card p-5 rounded-2xl space-y-3">
              <span className="text-xs font-bold text-orange-800 bg-orange-100/90 px-2 py-0.5 rounded">
                Surface Translucency
              </span>
              <h3 className="text-base font-bold text-slate-900">Frosted Glass (alpha = 0.72)</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-medium">
                Allows underlying machine schematics and ambient status glow to refract while preserving high-contrast text legibility.
              </p>
              <div className="p-3 bg-white/40 border border-white/60 rounded-xl text-[11px] font-mono text-slate-700">
                backdrop-filter: blur(14px);
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl space-y-3">
              <span className="text-xs font-bold text-blue-800 bg-blue-100/90 px-2 py-0.5 rounded">
                Specular Luminous Borders
              </span>
              <h3 className="text-base font-bold text-slate-900">1px Micro-Borders</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-medium">
                Subtle linear gradient borders simulate optical edge refraction and make card edges distinct against bright sunlight glare.
              </p>
              <div className="p-3 bg-white/40 border border-white/60 rounded-xl text-[11px] font-mono text-slate-700">
                border: 1px solid rgba(255,255,255,0.8);
              </div>
            </div>

            <div className="glass-card p-5 rounded-2xl space-y-3">
              <span className="text-xs font-bold text-emerald-800 bg-emerald-100/90 px-2 py-0.5 rounded">
                Safety Orange Radiant Glow
              </span>
              <h3 className="text-base font-bold text-slate-900">Luminescent FABs</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-medium">
                Primary CTA buttons feature an intense orange gradient with ambient light emission for rapid thumb identification.
              </p>
              <div className="p-3 bg-white/40 border border-white/60 rounded-xl text-[11px] font-mono text-slate-700">
                box-shadow: 0 10px 25px rgba(234,88,12,0.35);
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: COLOR PALETTE */}
      {activeTab === 'palette' && (
        <div className="space-y-6">
          <div className="bg-orange-50/80 border border-orange-200/90 rounded-2xl p-4 flex items-start gap-3 backdrop-blur-md">
            <Sun className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
            <div className="text-xs text-orange-950 leading-relaxed font-medium">
              <strong className="font-bold">Outdoor Sunlight Readability Rule:</strong> The primary safety orange (<code className="font-mono font-bold">#EA580C</code> / <code className="font-mono font-bold">#C2410C</code>) is tuned specifically to meet WCAG AAA contrast when displayed outdoors against direct bright sunlight. High-contrast outlines (<code className="font-mono">1.5dp to 2dp</code>) guarantee visible boundaries even when viewing LCD screens through polarized safety goggles.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {M3_COLOR_PALETTE.map((token) => (
              <div
                key={token.composeToken}
                className="glass-card rounded-2xl p-4 flex flex-col justify-between hover:border-orange-300 transition-all shadow-2xs"
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{token.name}</h3>
                    <code className="text-[11px] font-mono font-semibold text-orange-700 bg-orange-100/80 px-1.5 py-0.5 rounded">
                      {token.composeToken}
                    </code>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <div
                      className="w-10 h-10 rounded-xl border border-black/15 shadow-inner"
                      style={{ backgroundColor: token.lightHex }}
                    />
                  </div>
                </div>

                <p className="text-xs text-slate-600 font-medium leading-relaxed mb-3">
                  {token.role}
                </p>

                <div className="pt-2 border-t border-slate-200/70 flex items-center justify-between text-[11px] font-mono">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500">Hex:</span>
                    <span className="font-bold text-slate-800">{token.lightHex}</span>
                  </div>
                  <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                    {token.contrastRatio}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: TYPOGRAPHY */}
      {activeTab === 'typography' && (
        <div className="space-y-6">
          <div className="glass-card rounded-2xl p-4 text-xs text-blue-950 font-medium leading-relaxed">
            <strong className="font-bold">Android Material 3 Typography Scale:</strong> Scaled with <code className="font-mono">sp</code> units for user accessibility font scaling. Numeric meter measurements utilize tabular-width typography (<code className="font-mono">font-variant-numeric: tabular-nums</code>) to prevent visual jitter during real-time vibration/frequency updates.
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-200 text-slate-700 bg-slate-50/70">
                  <th className="py-3 px-4 font-bold">M3 Role</th>
                  <th className="py-3 px-4 font-bold">Compose Token</th>
                  <th className="py-3 px-4 font-bold">Size / Line Height</th>
                  <th className="py-3 px-4 font-bold">Weight</th>
                  <th className="py-3 px-4 font-bold">Usage in O&amp;M Tablet App</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {M3_TYPOGRAPHY.map((t) => (
                  <tr key={t.composeToken} className="hover:bg-white/60 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">{t.name}</td>
                    <td className="py-3 px-4 font-mono text-purple-700">{t.composeToken}</td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">
                      {t.fontSizeSp}sp / {t.lineHeightDp}dp
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-700">{t.fontWeight}</td>
                    <td className="py-3 px-4 text-slate-600 font-medium">{t.usage}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SPACING & TOUCH TARGETS */}
      {activeTab === 'spacing' && (
        <div className="space-y-6">
          <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3 backdrop-blur-md">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs text-emerald-950 font-medium leading-relaxed">
              <strong className="font-bold">Glove-Friendly Touch Target Guarantee (≥ 48dp):</strong> Field engineers on chemical refineries and high-voltage substations wear heavy Class 0 electrical or nitrile work gloves. Every single button, icon trigger, input field, and list card enforces a minimum 48×48dp physical hitbox to prevent accidental mis-taps.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {M3_SPACING_GRID.map((space) => (
              <div
                key={space.name}
                className="glass-card rounded-2xl p-5 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900">{space.name}</h3>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                    ≥ 48dp OK
                  </span>
                </div>

                <code className="block text-xs font-mono font-bold text-orange-700 bg-white/70 p-2 rounded-lg border border-slate-200">
                  {space.composeDp}
                </code>

                <p className="text-xs text-slate-600 font-medium leading-relaxed">
                  {space.usage}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: COMPOSE ARCHITECTURE */}
      {activeTab === 'compose' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-600 font-medium">
              Kotlin Jetpack Compose Glassmorphism modifier implementation for Lenovo Tab 11-inch.
            </p>
            <button
              onClick={handleCopyCode}
              className="text-xs font-bold px-3 py-1.5 rounded-lg glass-fab text-white hover:scale-[1.02] flex items-center gap-1.5 transition-all shadow-sm"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? 'Copied!' : 'Copy Compose Code'}</span>
            </button>
          </div>

          <pre className="p-4 rounded-2xl bg-slate-950/95 text-slate-200 font-mono text-xs overflow-x-auto leading-relaxed border border-slate-800 shadow-2xl backdrop-blur-xl">
            {COMPOSE_GLASSMORPHISM_SNIPPET}
          </pre>
        </div>
      )}
    </div>
  );
};
