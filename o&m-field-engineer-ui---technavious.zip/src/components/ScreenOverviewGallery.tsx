import React from 'react';
import { ScreenId } from '../types';
import {
  LayoutDashboard,
  FolderPlus,
  FolderKanban,
  ListPlus,
  FileSpreadsheet,
  Camera,
  Settings,
  ArrowRight,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

interface ScreenOverviewGalleryProps {
  currentScreen: ScreenId;
  onNavigateToScreen: (screen: ScreenId) => void;
}

interface ScreenSpecCard {
  id: ScreenId;
  number: number;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  requiredElements: string[];
  m3Components: string[];
}

export const SCREEN_SPECS: ScreenSpecCard[] = [
  {
    id: 'dashboard',
    number: 1,
    title: 'Dashboard (home)',
    subtitle: 'Main plant engineering audit portal',
    icon: <LayoutDashboard className="w-5 h-5 text-orange-600" />,
    requiredElements: [
      'App title ("O&M" by Technavious)',
      'Settings icon button (≥48dp hitbox)',
      'List of project cards (project name, client name) — tap to open',
      'Delete icon on each card with ripple',
      '"+" New Project button (Glassmorphic FAB)',
      'Empty state: "No projects yet — tap + to create a new project"',
      'Delete confirmation dialog (Delete / Cancel)',
    ],
    m3Components: ['TopAppBar', 'ElevatedCard (Glass)', 'ExtendedFAB', 'AlertDialog', 'IconButton'],
  },
  {
    id: 'new_project',
    number: 2,
    title: 'New Project',
    subtitle: 'Facility work order registration',
    icon: <FolderPlus className="w-5 h-5 text-orange-600" />,
    requiredElements: [
      'Back button (≥48dp)',
      'Fields: Project Name, Client Name, Site Address',
      '"Create Project" prominent CTA button',
      'Quick test-bench sample auto-fills',
    ],
    m3Components: ['TopAppBar', 'OutlinedTextField (Frosted)', 'ButtonDefaults', 'Surface'],
  },
  {
    id: 'project_detail',
    number: 3,
    title: 'Project Detail',
    subtitle: 'Audit test register for chosen facility',
    icon: <FolderKanban className="w-5 h-5 text-orange-600" />,
    requiredElements: [
      'Title = project name',
      'Back button (≥48dp)',
      'List of tests in this project: test name + status chip (Draft / Completed)',
      'Delete icon on each test row',
      '"+" Add Test button',
      'Empty state: "No tests yet — tap + to add a test"',
      'Delete confirmation dialog',
    ],
    m3Components: ['TopAppBar', 'FilterChip (Glass)', 'OutlinedCard', 'FAB', 'AlertDialog'],
  },
  {
    id: 'select_test_type',
    number: 4,
    title: 'Select Test Type',
    subtitle: '20 standard industrial meter protocols',
    icon: <ListPlus className="w-5 h-5 text-orange-600" />,
    requiredElements: [
      'Back button (≥48dp)',
      'List of ~20 test types (Vibration Analysis, Thermography, Battery Impedance, Earth Station, Rack Cooling, etc.)',
      'Types that support AI meter reading show camera/"AI" badge',
      'Glove-friendly category filter bar',
    ],
    m3Components: ['TopAppBar', 'FilterChip (Glass)', 'SearchField', 'ElevatedCard', 'Badge'],
  },
  {
    id: 'test_form',
    number: 5,
    title: 'Test Form (Main Screen)',
    subtitle: 'Industrial meter readings entry sheet',
    icon: <FileSpreadsheet className="w-5 h-5 text-orange-600" />,
    requiredElements: [
      'Title = test name',
      'Back, Save, and Export-to-Excel buttons in header',
      '"Header" section: Location, Doc No.',
      '"Readings" section: 2–9 reading fields with number input + label + unit',
      'Camera button on each field (take photo of meter)',
      'After photo exists: photo thumbnail + "Re-read with AI" button',
    ],
    m3Components: ['TopAppBar', 'OutlinedTextField', 'GlassmorphicCard', 'Button', 'ProgressIndicator'],
  },
  {
    id: 'capture',
    number: 6,
    title: 'Capture (camera)',
    subtitle: 'Full-screen meter OCR vision interface',
    icon: <Camera className="w-5 h-5 text-orange-600" />,
    requiredElements: [
      'Title "Capture: <field name>"',
      'Back button (≥48dp)',
      'Full-screen live camera preview with target reticle',
      'Large shutter button (≥72dp)',
      'After capture, result panel with: status/source tag ("Gemini AI" / "Offline AI" / "Photo saved")',
      'Editable reading value (large text in tabular numerals)',
      'Buttons: Accept, Retry (runs AI with "Reading..." spinner), Retake',
    ],
    m3Components: ['Surface', 'IconButton', 'CircularProgress', 'GlassmorphicTonalButton', 'Button'],
  },
  {
    id: 'settings',
    number: 7,
    title: 'Settings',
    subtitle: 'AI inference models & field ergonomics',
    icon: <Settings className="w-5 h-5 text-orange-600" />,
    requiredElements: [
      'Back button (≥48dp)',
      'AI Reading Mode switch: "Gemini AI (Online)" vs "Qwen VL (Offline)" with one-line description',
      'Warning card shown when offline model files are missing',
      'Gemini API Key text field + "Save New Key" button',
      'Outdoor high-contrast sunlight toggle & glove hitbox visualizer',
    ],
    m3Components: ['TopAppBar', 'Switch', 'OutlinedTextField', 'FrostedCard', 'Button'],
  },
];

export const ScreenOverviewGallery: React.FC<ScreenOverviewGalleryProps> = ({
  currentScreen,
  onNavigateToScreen,
}) => {
  return (
    <div className="max-w-6xl mx-auto space-y-6 select-none">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-orange-400 bg-orange-950/80 border border-orange-800/80 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-orange-400" />
              <span>Glassmorphism Edition</span>
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">
            All 7 Required Screen Mockups &amp; Specifications
          </h2>
          <p className="text-xs md:text-sm text-neutral-400 font-medium mt-1">
            Frosted translucent glassmorphism surfaces with high-contrast industrial readability. Tap any card to test in the Lenovo Tab simulator.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {SCREEN_SPECS.map((spec) => {
          const isActive = currentScreen === spec.id;

          return (
            <div
              key={spec.id}
              onClick={() => onNavigateToScreen(spec.id)}
              className={`rounded-2xl p-5 border-2 transition-all cursor-pointer flex flex-col justify-between m3-ripple backdrop-blur-xl ${
                isActive
                  ? 'bg-neutral-900/90 border-orange-500 shadow-xl shadow-orange-600/20 ring-2 ring-orange-500/30'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/80 hover:shadow-lg'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between mb-3">
                  <span className="w-7 h-7 rounded-lg bg-orange-600/20 border border-orange-500/40 text-orange-400 font-black text-xs flex items-center justify-center">
                    0{spec.number}
                  </span>
                  <div className="flex items-center gap-1">
                    {spec.icon}
                    {isActive && (
                      <span className="text-[10px] font-black uppercase text-orange-400 bg-orange-500/20 border border-orange-500/40 px-2 py-0.5 rounded">
                        Active in Tab
                      </span>
                    )}
                  </div>
                </div>

                <h3 className="text-base font-bold text-white">
                  {spec.title}
                </h3>
                <p className="text-xs text-neutral-400 font-medium mb-3">
                  {spec.subtitle}
                </p>

                {/* Elements Checklist */}
                <div className="space-y-1.5 border-t border-neutral-800 pt-3">
                  <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                    Verified Elements:
                  </span>
                  {spec.requiredElements.map((elem, i) => (
                    <div key={i} className="flex items-start gap-1.5 text-xs text-neutral-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="line-clamp-2">{elem}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Compose Tokens Used */}
              <div className="pt-4 mt-4 border-t border-neutral-800 flex items-center justify-between">
                <div className="flex flex-wrap gap-1">
                  {spec.m3Components.slice(0, 3).map((comp, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-mono text-neutral-400 bg-neutral-800/80 border border-neutral-700/50 px-1.5 py-0.5 rounded"
                    >
                      {comp}
                    </span>
                  ))}
                </div>

                <span className="text-xs font-bold text-orange-400 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  <span>Open</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
