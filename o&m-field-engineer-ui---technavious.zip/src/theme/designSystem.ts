/**
 * Design System Specifications for Technavious O&M Industrial Tablet App
 * Jetpack Compose + Material 3 Design Tokens & Specifications
 */

export interface ColorToken {
  name: string;
  composeToken: string;
  lightHex: string;
  outdoorHex: string;
  darkHex: string;
  role: string;
  contrastRatio: string;
}

export interface TypographyToken {
  name: string;
  composeToken: string;
  fontSizeSp: number;
  lineHeightDp: number;
  fontWeight: string;
  tracking: string;
  usage: string;
}

export interface SpacingToken {
  name: string;
  composeDp: string;
  pixelValue: number;
  touchTargetCompliant: boolean;
  usage: string;
}

export const M3_COLOR_PALETTE: ColorToken[] = [
  {
    name: 'Primary (Technavious Safety Orange)',
    composeToken: 'MaterialTheme.colorScheme.primary',
    lightHex: '#EA580C',
    outdoorHex: '#C2410C',
    darkHex: '#FB923C',
    role: 'Primary action buttons, active FABs, focused outlines, brand accent',
    contrastRatio: '5.2:1 (AAA on White outdoor canvas)',
  },
  {
    name: 'On Primary',
    composeToken: 'MaterialTheme.colorScheme.onPrimary',
    lightHex: '#FFFFFF',
    outdoorHex: '#FFFFFF',
    darkHex: '#431407',
    role: 'Text/icons displayed on top of primary orange containers',
    contrastRatio: '18.4:1',
  },
  {
    name: 'Primary Container',
    composeToken: 'MaterialTheme.colorScheme.primaryContainer',
    lightHex: '#FFEDD5',
    outdoorHex: '#FED7AA',
    darkHex: '#7C2D12',
    role: 'Subtle tinted cards, active state pills, AI badge background',
    contrastRatio: '4.8:1',
  },
  {
    name: 'On Primary Container',
    composeToken: 'MaterialTheme.colorScheme.onPrimaryContainer',
    lightHex: '#9A3412',
    outdoorHex: '#7C2D12',
    darkHex: '#FFEDD5',
    role: 'Text and icons inside primary container cards',
    contrastRatio: '7.1:1 (AAA)',
  },
  {
    name: 'Surface (Canvas)',
    composeToken: 'MaterialTheme.colorScheme.surface',
    lightHex: '#F8FAFC',
    outdoorHex: '#FFFFFF',
    darkHex: '#0B0F19',
    role: 'Main background of tablet screen (anti-glare neutral)',
    contrastRatio: 'Baseline',
  },
  {
    name: 'On Surface (Headings & Body)',
    composeToken: 'MaterialTheme.colorScheme.onSurface',
    lightHex: '#0F172A',
    outdoorHex: '#000000',
    darkHex: '#F8FAFC',
    role: 'Primary reading labels, meter digits, high-contrast text',
    contrastRatio: '16.8:1 (AAA High Sunlight)',
  },
  {
    name: 'Surface Variant / Card Surface',
    composeToken: 'MaterialTheme.colorScheme.surfaceVariant',
    lightHex: '#FFFFFF',
    outdoorHex: '#FFFFFF',
    darkHex: '#161F30',
    role: 'Project cards, reading input containers, modal backgrounds',
    contrastRatio: '14.2:1 with onSurface',
  },
  {
    name: 'Outline / Border',
    composeToken: 'MaterialTheme.colorScheme.outline',
    lightHex: '#CBD5E1',
    outdoorHex: '#64748B',
    darkHex: '#334155',
    role: '1.5dp high-visibility borders for input fields and divider rules',
    contrastRatio: '3.6:1 (Meets UI component WCAG AA)',
  },
  {
    name: 'Error Container',
    composeToken: 'MaterialTheme.colorScheme.errorContainer',
    lightHex: '#FEE2E2',
    outdoorHex: '#FECACA',
    darkHex: '#7F1D1D',
    role: 'Delete confirmation highlights, missing offline model warning banner',
    contrastRatio: '4.5:1',
  },
  {
    name: 'Success Chip Container',
    composeToken: 'MaterialTheme.colorScheme.tertiaryContainer',
    lightHex: '#DCFCE7',
    outdoorHex: '#BBF7D0',
    darkHex: '#14532D',
    role: 'Completed test chip container',
    contrastRatio: '4.7:1',
  },
];

export const M3_TYPOGRAPHY: TypographyToken[] = [
  {
    name: 'Headline Large',
    composeToken: 'MaterialTheme.typography.headlineLarge',
    fontSizeSp: 32,
    lineHeightDp: 40,
    fontWeight: 'Bold (700)',
    tracking: '0sp',
    usage: 'Tablet top app bar primary screen titles (e.g. Dashboard, Project Detail)',
  },
  {
    name: 'Headline Medium',
    composeToken: 'MaterialTheme.typography.headlineMedium',
    fontSizeSp: 26,
    lineHeightDp: 34,
    fontWeight: 'SemiBold (600)',
    tracking: '0sp',
    usage: 'Section headers (Header, Readings), Dialog titles',
  },
  {
    name: 'Title Large',
    composeToken: 'MaterialTheme.typography.titleLarge',
    fontSizeSp: 20,
    lineHeightDp: 28,
    fontWeight: 'Bold (700)',
    tracking: '0sp',
    usage: 'Project card names, Test item names, Camera reading preview',
  },
  {
    name: 'Title Medium',
    composeToken: 'MaterialTheme.typography.titleMedium',
    fontSizeSp: 16,
    lineHeightDp: 24,
    fontWeight: 'SemiBold (600)',
    tracking: '+0.15sp',
    usage: 'Input field labels (e.g. "Vertical", "Location", "Doc No.")',
  },
  {
    name: 'Body Large',
    composeToken: 'MaterialTheme.typography.bodyLarge',
    fontSizeSp: 16,
    lineHeightDp: 24,
    fontWeight: 'Normal (400)',
    tracking: '+0.5sp',
    usage: 'OutlinedTextField input values, client addresses, descriptions',
  },
  {
    name: 'Body Medium',
    composeToken: 'MaterialTheme.typography.bodyMedium',
    fontSizeSp: 14,
    lineHeightDp: 20,
    fontWeight: 'Normal (400)',
    tracking: '+0.25sp',
    usage: 'Card secondary client names, subtitle hints, settings explanations',
  },
  {
    name: 'Label Large (Buttons)',
    composeToken: 'MaterialTheme.typography.labelLarge',
    fontSizeSp: 15,
    lineHeightDp: 20,
    fontWeight: 'Bold (700)',
    tracking: '+0.1sp',
    usage: 'Button action labels ("Create Project", "Save", "Accept", "Retry")',
  },
  {
    name: 'Label Small (Chips & Badges)',
    composeToken: 'MaterialTheme.typography.labelSmall',
    fontSizeSp: 12,
    lineHeightDp: 16,
    fontWeight: 'SemiBold (600)',
    tracking: '+0.5sp',
    usage: 'Draft/Completed status chips, AI camera badges, unit labels',
  },
  {
    name: 'Meter Numerical Value',
    composeToken: 'MaterialTheme.typography.displayMedium.copy(fontFamily = JetBrainsMono)',
    fontSizeSp: 38,
    lineHeightDp: 44,
    fontWeight: 'Bold (700)',
    tracking: '-0.5sp (Tabular Nums)',
    usage: 'Live captured reading display in Screen 6 result panel for quick glance in sunlight',
  },
];

export const M3_SPACING_GRID: SpacingToken[] = [
  {
    name: 'Touch Target Hitbox (Strict Rule)',
    composeDp: '48.dp (Modifier.sizeIn(minWidth = 48.dp, minHeight = 48.dp))',
    pixelValue: 48,
    touchTargetCompliant: true,
    usage: 'All icon buttons, delete trash triggers, back buttons, chips, and field camera triggers',
  },
  {
    name: 'Primary FAB Target',
    composeDp: '56.dp to 64.dp (FloatingActionButton / ExtendedFAB)',
    pixelValue: 64,
    touchTargetCompliant: true,
    usage: '+ New Project and + Add Test bottom-right action button for gloved thumb reach',
  },
  {
    name: 'OutlinedTextField Height',
    composeDp: '56.dp minimum vertical height',
    pixelValue: 56,
    touchTargetCompliant: true,
    usage: 'Project Name, Client Name, Address, Location, and Meter Reading inputs',
  },
  {
    name: 'Screen Edge Padding (Tablet)',
    composeDp: '24.dp (horizontal) / 16.dp (vertical)',
    pixelValue: 24,
    touchTargetCompliant: true,
    usage: 'Outer margin ensuring field tablet bezel palm-rejection & comfortable single/two-hand grip',
  },
  {
    name: 'Card Content Padding',
    composeDp: '16.dp to 20.dp',
    pixelValue: 20,
    touchTargetCompliant: true,
    usage: 'Inner padding inside ElevatedCard components for readability',
  },
  {
    name: 'Element Spacing (Stack Gap)',
    composeDp: '12.dp to 16.dp (Arrangement.spacedBy(16.dp))',
    pixelValue: 16,
    touchTargetCompliant: true,
    usage: 'Vertical separation between reading cards to prevent accidental taps on neighboring meters',
  },
];

export const JETPACK_COMPOSE_SCAFFOLD_SNIPPET = `
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OMTabletScaffold(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    floatingActionButton: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(48.dp) // Glove-friendly 48dp hitbox
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        floatingActionButton = floatingActionButton,
        containerColor = MaterialTheme.colorScheme.surface,
        content = content
    )
}
`;
